import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step8.${stamp}@example.com`;
const emailB = `ibrahim.step8b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const ctx = extra?.memoryContext ?? "";
  if (/black tea/i.test(ctx) || /Tea preference/i.test(ctx)) {
    return { ok: true, text: "Pinned memory is in context: black tea." };
  }
  return { ok: true, text: "Aegis-step8-fixture: no matching memory context." };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Create an account" }).click();
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

async function sendComposer(page, text) {
  await page.getByLabel("Message").fill(text);
  await page.getByRole("button", { name: "Send" }).click();
  await page.getByText("Thinking").waitFor({ state: "visible", timeout: 10000 }).catch(() => {});
  await page.getByText("Thinking").waitFor({ state: "hidden", timeout: 45000 });
}

let restored = false;
process.on("exit", () => {
  if (!restored) {
    try {
      restoreComplete();
    } catch {
      /* ignore */
    }
  }
});

const browser = await chromium.launch({ headless: true });
const contextA = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page = await contextA.newPage();
const consoleErrors = [];
page.on("pageerror", (err) => consoleErrors.push(String(err)));
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});

try {
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("signed-out-memory", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const list401 = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record("signed-out-list-401", /unauthorized/i.test(list401.error || ""), list401.error || JSON.stringify(list401));
  const create401 = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "Nope",
    body: "Should not save",
    tags: "",
    pinned: true,
  });
  record("signed-out-create-401", /unauthorized/i.test(create401.error || ""), create401.error || JSON.stringify(create401));

  await signup(page, { name: "Ibrahim Step8", email: emailA });
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("dashboard-regression", await page.getByRole("heading", { name: /Hello/ }).isVisible());
  record("dashboard-memory-copy", await page.getByText(/Open Memory to pin/).isVisible());

  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "What lasts" }).waitFor({ timeout: 15000 });
  record("empty-state", await page.getByText(/Nothing stored yet/).isVisible());
  record("nav-memory-active", (await page.locator("aside nav a", { hasText: "Memory" }).first().getAttribute("aria-current")) === "page");

  await page.getByRole("button", { name: "Add memory" }).click();
  await page.getByRole("form", { name: "New memory" }).waitFor({ timeout: 10000 });
  await page.getByRole("button", { name: "Preference" }).click();
  await page.getByLabel("Title").fill("Tea preference");
  await page.getByLabel("Keep this").fill("I drink black tea every morning.");
  await page.getByLabel("Tags").fill("drinks");
  const pinBox = page.getByRole("checkbox", { name: /Pin this/ });
  if (!(await pinBox.isChecked())) await pinBox.check();
  await page.getByRole("button", { name: "Save memory" }).click();
  const teaCard = page.getByRole("article", { name: /Preference: Tea preference/i });
  await teaCard.waitFor({ timeout: 15000 });
  record(
    "created-pinned-card",
    /Pinned/i.test(await teaCard.innerText()) && /black tea/i.test(await teaCard.innerText()),
    (await teaCard.innerText()).slice(0, 240),
  );

  await page.reload({ waitUntil: "networkidle" });
  await page.getByRole("article", { name: /Preference: Tea preference/i }).waitFor({ timeout: 15000 });
  record("refresh-persists-memory", true);

  const listed = await callFn(page, "/src/lib/memory.ts", "listMemories");
  const tea = (listed.result ?? []).find((m) => m.title === "Tea preference");
  record(
    "listed-owned",
    Boolean(tea) && tea.pinned === true && tea.kind === "preference" && tea.source === "user",
    JSON.stringify(tea || listed),
  );
  const teaId = tea?.id ?? 0;

  const retrieved = await callFn(page, "/src/lib/memory.ts", "retrieveMemoriesForChat", {
    query: "What do I like to drink?",
  });
  const retrievedTitles = (retrieved.result ?? []).map((m) => m.title);
  record(
    "retrieve-includes-pinned",
    retrievedTitles.includes("Tea preference"),
    JSON.stringify(retrievedTitles),
  );

  const emptyCreate = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "",
    body: "x",
    tags: "",
    pinned: false,
  });
  record("empty-title-rejected", !emptyCreate.ok, JSON.stringify(emptyCreate).slice(0, 200));
  const huge = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "Huge",
    body: "x".repeat(4001),
    tags: "",
    pinned: false,
  });
  record("oversized-body-rejected", !huge.ok, JSON.stringify(huge).slice(0, 200));

  installStub();
  await sleep(2500);

  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  await page.getByText("No conversations yet").waitFor({ timeout: 15000 });
  await sendComposer(page, "What do I like to drink in the morning?");
  await page.waitForURL(/\/app\/chat\/\d+/, { timeout: 15000 });
  await page.getByText("Pinned memory is in context: black tea.").waitFor({ timeout: 15000 });
  record("new-chat-sees-pinned", true);
  const bodyChat = await page.locator("body").innerText();
  record(
    "chat-no-payload-json",
    !bodyChat.includes("<<<aegis-proposals") && !/\bApprove\b/.test(bodyChat),
  );

  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  await page.getByRole("article", { name: /Preference: Tea preference/i }).waitFor({ timeout: 10000 });
  await page.getByRole("button", { name: "Edit Tea preference" }).click();
  await page.getByRole("form", { name: "Edit memory" }).waitFor({ timeout: 10000 });
  await page.getByLabel("Title").fill("Tea preference kept");
  await page.getByRole("button", { name: "Save changes" }).click();
  await page.getByRole("article", { name: /Preference: Tea preference kept/i }).waitFor({ timeout: 15000 });
  record("edit-persists", true);

  await page.getByRole("button", { name: "Unpin Tea preference kept" }).click();
  await page.getByRole("button", { name: "Pin Tea preference kept" }).waitFor({ timeout: 10000 });
  record("unpinned", true);
  await page.getByRole("button", { name: "Pin Tea preference kept" }).click();
  await page.getByRole("button", { name: "Unpin Tea preference kept" }).waitFor({ timeout: 10000 });
  record("re-pinned", true);

  await page.getByRole("button", { name: "Add memory" }).click();
  await page.getByLabel("Title").fill("Second note");
  await page.getByLabel("Keep this").fill("A quieter fact.");
  const pin2 = page.getByRole("checkbox", { name: /Pin this/ });
  if (await pin2.isChecked()) await pin2.uncheck();
  await page.getByRole("button", { name: "Save memory" }).click();
  await page.getByRole("article", { name: /Fact: Second note/i }).waitFor({ timeout: 15000 });
  record("second-memory-created", true);

  await page.getByRole("button", { name: "Delete Second note" }).click();
  await page.getByRole("button", { name: "Confirm delete Second note" }).click();
  await page.getByRole("article", { name: /Fact: Second note/i }).waitFor({ state: "hidden", timeout: 10000 });
  record("deleted", true);

  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("settings-regression", await page.getByLabel("Display name").isVisible());

  const contextB = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other User", email: emailB });
  const idorGet = await callFn(pageB, "/src/lib/memory.ts", "getMemory", { id: teaId });
  record("idor-get", /not found/i.test(idorGet.error || ""), JSON.stringify(idorGet).slice(0, 200));
  const idorList = await callFn(pageB, "/src/lib/memory.ts", "listMemories");
  const otherTitles = (idorList.result ?? []).map((m) => m.title);
  record("idor-list", !otherTitles.includes("Tea preference kept") && !otherTitles.includes("Tea preference"), JSON.stringify(otherTitles));
  const idorUpdate = await callFn(pageB, "/src/lib/memory.ts", "updateMemory", {
    id: teaId,
    kind: "fact",
    title: "Hijacked",
    body: "nope",
    tags: "",
    pinned: true,
  });
  record("idor-update", /not found/i.test(idorUpdate.error || ""), JSON.stringify(idorUpdate).slice(0, 200));
  const idorDelete = await callFn(pageB, "/src/lib/memory.ts", "deleteMemory", { id: teaId });
  record("idor-delete", /not found/i.test(idorDelete.error || ""), JSON.stringify(idorDelete).slice(0, 200));
  await contextB.close();

  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("owner-still-has-tea", await page.getByRole("article", { name: /Tea preference kept/i }).isVisible());

  await signOut(page);
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("signout-memory-gate", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("signin-same-memory", await page.getByRole("article", { name: /Tea preference kept/i }).isVisible());

  await page.screenshot({ path: "/workspace/screenshots/step8-memory.png", fullPage: true });

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
  );
  const labels = await page.locator("nav[aria-label='Primary']").innerText();
  record(
    "mobile-nav",
    !overflow && /Dashboard/.test(labels) && /Chat/.test(labels) && /Memory/.test(labels) && /Settings/.test(labels),
    JSON.stringify({ overflow, labels: labels.split(/\s+/).filter(Boolean) }),
  );
  record("mobile-card", await page.getByRole("article", { name: /Tea preference kept/i }).isVisible());
  await page.screenshot({ path: "/workspace/screenshots/step8-memory-mobile.png", fullPage: true });

  const serious = consoleErrors.filter(
    (e) => !/Download the React DevTools/i.test(e) && !/not found/i.test(e),
  );
  record("console-errors", serious.length === 0, serious.join(" | ").slice(0, 300));
} catch (err) {
  record("fatal", false, err && err.stack ? err.stack : String(err));
} finally {
  restoreComplete();
  restored = true;
  await browser.close();
}

const ok = results.filter((r) => r.ok).length;
const total = results.length;
writeFileSync(
  "/workspace/screenshots/verify-step8.json",
  JSON.stringify({ emailA, emailB, ok, total, results }, null, 2),
);
console.log(`\n${ok}/${total} passed`);
process.exit(ok === total ? 0 : 1);
