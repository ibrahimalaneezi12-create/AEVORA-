import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step14.${stamp}@example.com`;
const emailB = `ibrahim.step14b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const last = history[history.length - 1]?.content ?? "";
  if (/auto-run|change my permissions/i.test(last)) {
    return {
      ok: true,
      text: [
        "I cannot change permissions.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "permission.update",
            title: "Turn on auto-run",
            summary: "Enable automatic execution",
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/email the bank|external\\.email/i.test(last)) {
    return {
      ok: true,
      text: [
        "I would have to send mail.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "external.email",
            title: "Email the bank",
            summary: "Send a payment email.",
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/run a shell|shell\\.exec/i.test(last)) {
    return {
      ok: true,
      text: [
        "I would run a command.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "shell.exec",
            title: "Run a command",
            summary: "Unregistered tool.",
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/broken payload/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can delete that memory. It will not be removed until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.delete",
            title: "Delete kettle note",
            summary: "Remove the kettle memory.",
            payload: { id: "not-a-number" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/search my memories/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can search your memory. It will not run until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.search",
            title: "Search tea memories",
            summary: "Look for tea in your keep.",
            payload: { query: "tea" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/create a task to buy tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can add that task. It will not be created until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "task.create",
            title: "Buy loose-leaf tea",
            summary: "Add a task to buy tea.",
            payload: { title: "Buy loose-leaf tea", status: "todo" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/remember|black tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remember that you drink tea. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.save",
            title: "Save tea preference",
            summary: "Remember that you drink black tea every morning.",
            payload: { kind: "preference", body: "payload-secret-orchid-77" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  return { ok: true, text: "Aegis-step14-fixture: a quiet reply with no proposed action." };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Create an account" }).click();
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

function leaky(value) {
  const s = typeof value === "string" ? value : JSON.stringify(value ?? "");
  return /payload_json|payload-secret-orchid-77/i.test(s);
}

let restored = false;
const consoleErrors = [];
installStub();

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage();
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});
page.on("pageerror", (err) => consoleErrors.push(String(err)));

try {
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("signed-out-settings", /\/login/.test(page.url()), page.url());

  const unauthList = await callFn(page, "/src/lib/tools/registry.ts", "listToolCatalog", {});
  record(
    "unauth-catalog",
    !unauthList.ok && /unauthorized/i.test(unauthList.error || ""),
    unauthList.error || "",
  );
  const unauthApprove = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: 1 });
  record(
    "unauth-approve",
    !unauthApprove.ok && /unauthorized/i.test(unauthApprove.error || ""),
    unauthApprove.error || "",
  );

  await signup(page, { name: "Ibrahim", email: emailA });

  const catalog = await callFn(page, "/src/lib/tools/registry.ts", "listToolCatalog", {});
  const tools = catalog.result ?? [];
  const byId = Object.fromEntries(tools.map((t) => [t.id, t]));
  record(
    "catalog-loaded",
    catalog.ok && Array.isArray(tools) && tools.length >= 11,
    String(tools.length),
  );
  record(
    "catalog-metadata",
    byId["memory.search"]?.permissionLevel === "safe" &&
      byId["memory.save"]?.permissionLevel === "review" &&
      byId["memory.delete"]?.permissionLevel === "approval" &&
      byId["permission.update"]?.permissionLevel === "restricted" &&
      byId["task.create"]?.enabled === true,
    JSON.stringify(byId["memory.save"] ?? {}).slice(0, 200),
  );
  record(
    "catalog-no-external",
    !tools.some((t) => t.id.startsWith("external.") || /email|http|pay/.test(t.id)),
    tools.map((t) => t.id).join(","),
  );
  record(
    "catalog-no-chat-reply",
    !tools.some((t) => t.id === "chat.reply"),
  );
  record(
    "catalog-no-payload-or-handler",
    !leaky(catalog.result) &&
      tools.every((t) => !("handler" in t) && !("payload" in t) && !("userId" in t)),
  );

  const defs = await page.evaluate(async () => {
    const mod = await import("/src/lib/tools/definitions.ts");
    return {
      save: mod.canRunTool("memory.save"),
      restricted: mod.canRunTool("permission.update"),
      unknown: mod.canRunTool("shell.exec"),
      external: mod.canRunTool("external.email"),
      execute: typeof mod.executeRegisteredTool,
      list: typeof mod.listToolCatalog,
    };
  });
  record(
    "runnable-vs-restricted",
    defs.save === true &&
      defs.restricted === false &&
      defs.unknown === false &&
      defs.external === false &&
      defs.execute === "undefined" &&
      defs.list === "undefined",
    JSON.stringify(defs),
  );

  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Permissions" }).waitFor({ timeout: 15000 });
  record("settings-catalog-ui", await page.getByText("Search memory").isVisible());
  record("settings-restricted-row", await page.getByText("Change permissions").isVisible());

  installStub();
  utimesSync(COMPLETE, new Date(), new Date());
  await sleep(800);

  const mem = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "Kettle note",
    body: "The kettle is in the cupboard.",
    tags: "",
    pinned: false,
  });
  record("seed-memory", mem.ok && mem.result?.id > 0);

  const unknown = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please run a shell.exec command.",
  });
  record(
    "unregistered-rejected",
    (unknown.result?.proposals ?? []).length === 0 &&
      (unknown.result?.rejected ?? []).some((r) => r.toolId === "shell.exec"),
    JSON.stringify(unknown.result ?? {}).slice(0, 240),
  );

  const external = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please email the bank.",
  });
  record(
    "external-rejected",
    (external.result?.proposals ?? []).length === 0 &&
      (external.result?.rejected ?? []).some((r) => r.toolId === "external.email"),
    JSON.stringify(external.result ?? {}).slice(0, 240),
  );

  const restricted = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please change my permissions and turn on auto-run.",
  });
  record(
    "restricted-rejected",
    (restricted.result?.proposals ?? []).length === 0 &&
      (restricted.result?.rejected ?? []).some((r) => r.toolId === "permission.update"),
  );
  const restrictedApprove = await callFn(page, "/src/lib/confirm.ts", "approveProposal", {
    id: 999999,
  });
  record(
    "missing-proposal-not-found",
    !restrictedApprove.ok && /not found/i.test(restrictedApprove.error || ""),
    restrictedApprove.error || "",
  );

  const sent = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Remember I drink black tea.",
  });
  const save = (sent.result?.proposals ?? []).find((p) => p.toolId === "memory.save");
  record("proposal-pending", Boolean(save && save.status === "pending"), JSON.stringify(save ?? {}).slice(0, 200));

  const denied = await callFn(page, "/src/lib/confirm.ts", "denyProposal", { id: save.id });
  record("deny-still-works", denied.ok && denied.result?.status === "denied");
  const memAfterDeny = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "deny-no-side-effect",
    (memAfterDeny.result ?? []).every((m) => m.body !== "payload-secret-orchid-77"),
  );

  const sent2 = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Remember I drink black tea.",
  });
  const save2 = (sent2.result?.proposals ?? []).find((p) => p.toolId === "memory.save");
  const approved = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: save2.id });
  record(
    "approve-via-registry",
    approved.ok && approved.result?.status === "executed",
    JSON.stringify(approved.result ?? {}).slice(0, 200),
  );
  const replay = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: save2.id });
  record(
    "replay-blocked",
    !replay.ok && /no longer pending/i.test(replay.error || ""),
    replay.error || "",
  );

  const search = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Search my memories for tea.",
  });
  const searchP = (search.result?.proposals ?? []).find((p) => p.toolId === "memory.search");
  const searchOk = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: searchP.id });
  record(
    "safe-search-via-registry",
    searchOk.ok && searchOk.result?.status === "executed",
    JSON.stringify(searchOk.result ?? {}).slice(0, 200),
  );

  const task = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Create a task to buy tea.",
  });
  const taskP = (task.result?.proposals ?? []).find((p) => p.toolId === "task.create");
  const taskOk = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: taskP.id });
  record(
    "review-task-via-registry",
    taskOk.ok && taskOk.result?.status === "executed",
    JSON.stringify(taskOk.result ?? {}).slice(0, 200),
  );

  const broken = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Delete the kettle with a broken payload.",
  });
  const delP = (broken.result?.proposals ?? []).find((p) => p.toolId === "memory.delete");
  record("malformed-proposed", Boolean(delP && delP.status === "pending"));
  const brokenOk = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: delP.id });
  record(
    "malformed-fails-closed",
    brokenOk.ok && brokenOk.result?.status === "failed",
    JSON.stringify(brokenOk.result ?? {}).slice(0, 240),
  );
  const memAfterBroken = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "malformed-did-not-delete",
    (memAfterBroken.result ?? []).some((m) => m.title === "Kettle note"),
  );

  const activity = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  const actions = (activity.result?.items ?? []).map((e) => e.action);
  record(
    "activity-execution-events",
    actions.includes("proposal.executed") &&
      actions.includes("proposal.approved") &&
      actions.includes("proposal.denied") &&
      actions.includes("proposal.rejected") &&
      actions.includes("proposal.failed"),
    actions.slice(0, 12).join(","),
  );
  record("activity-no-secret", !/payload-secret-orchid-77/.test(JSON.stringify(activity.result ?? "")));

  restoreComplete();
  restored = true;
  utimesSync(COMPLETE, new Date(), new Date());
  await sleep(800);

  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("dashboard-regression", await page.getByRole("heading", { name: /Hello/i }).isVisible());
  record(
    "dashboard-no-approve",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0,
  );
  await page.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  record("activity-regression", await page.getByRole("heading", { name: "The record" }).isVisible());
  record(
    "activity-no-approve-deny",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /^Deny$/ }).count()) === 0,
  );
  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  record("goals-regression", await page.getByRole("heading", { name: "Working toward" }).isVisible());
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("memory-regression", await page.getByRole("heading", { name: "What lasts" }).isVisible());
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("settings-regression", await page.getByRole("heading", { name: "Permissions" }).isVisible());
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  record("chat-regression", await page.getByRole("heading", { name: "Conversations" }).isVisible());

  const contextB = await browser.newContext();
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other", email: emailB });
  const bApprove = await callFn(pageB, "/src/lib/confirm.ts", "approveProposal", { id: save2.id });
  record(
    "idor-approve",
    !bApprove.ok && /not found/i.test(bApprove.error || ""),
    bApprove.error || "",
  );
  const bMem = await callFn(pageB, "/src/lib/memory.ts", "listMemories");
  record(
    "idor-memory",
    (bMem.result ?? []).every((m) => m.title !== "Kettle note"),
  );
  const bAct = await callFn(pageB, "/src/lib/audit.ts", "listActivity", { level: "all" });
  record(
    "idor-activity",
    !JSON.stringify(bAct.result ?? {}).includes("Kettle note"),
  );
  await contextB.close();

  await signOut(page);
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("signout-gate", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Permissions" }).waitFor({ timeout: 15000 });
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
  );
  record("mobile-no-overflow", !overflow, JSON.stringify({ overflow }));
  await page.screenshot({ path: "/workspace/screenshots/step14-catalog-mobile.png", fullPage: true });
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  await page.screenshot({ path: "/workspace/screenshots/step14-catalog.png", fullPage: true });

  const serious = consoleErrors.filter(
    (e) => !/Download the React DevTools/i.test(e) && !/not found/i.test(e),
  );
  record("console-errors", serious.length === 0, serious.join(" | ").slice(0, 300));
} catch (err) {
  record("fatal", false, err && err.stack ? err.stack : String(err));
} finally {
  if (!restored) {
    restoreComplete();
    restored = true;
  }
  await browser.close();
}

const ok = results.filter((r) => r.ok).length;
const total = results.length;
writeFileSync(
  "/workspace/screenshots/verify-step14.json",
  JSON.stringify({ emailA, emailB, ok, total, results }, null, 2),
);
console.log(`\n${ok}/${total} passed`);
process.exit(ok === total ? 0 : 1);
