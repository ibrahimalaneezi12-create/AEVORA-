import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step13.${stamp}@example.com`;
const emailB = `ibrahim.step13b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const last = history[history.length - 1]?.content ?? "";
  if (/auto-run|change my permissions/i.test(last)) {
    return {
      ok: true,
      text: [
        "I cannot change permissions.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "permission.update",
            title: "Turn on auto-run",
            summary: "Enable automatic execution",
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/remember|black tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remember that you drink tea. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.save",
            title: "Save tea preference",
            summary: "Remember that you drink black tea every morning.",
            payload: { kind: "preference", body: "payload-secret-orchid-77" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  return { ok: true, text: "Aegis-step13-fixture: a quiet reply with no proposed action." };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Create an account" }).click();
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

function leaky(value) {
  const s = typeof value === "string" ? value : JSON.stringify(value ?? "");
  return /payload_json|payload-secret-orchid-77/i.test(s);
}

let restored = false;
const consoleErrors = [];
installStub();

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage();
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});
page.on("pageerror", (err) => consoleErrors.push(String(err)));

try {
  await page.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  record("signed-out-activity", /\/login/.test(page.url()), page.url());

  const unauth = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  record("unauth-list", !unauth.ok && /unauthorized/i.test(unauth.error || ""), unauth.error || "");

  await signup(page, { name: "Ibrahim", email: emailA });
  await page.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "The record" }).waitFor({ timeout: 15000 });
  record("activity-heading", await page.getByRole("heading", { name: "The record" }).isVisible());
  record(
    "empty-state",
    await page.getByText(/Nothing recorded yet/i).isVisible(),
  );
  record(
    "nav-activity",
    (await page.getByRole("link", { name: "Activity" }).count()) > 0,
  );
  record(
    "empty-no-approve",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /^Deny$/ }).count()) === 0,
  );

  const listedEmpty = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  record(
    "empty-list",
    listedEmpty.ok &&
      Array.isArray(listedEmpty.result?.items) &&
      listedEmpty.result.items.length === 0 &&
      listedEmpty.result.nextCursor === null,
    JSON.stringify(listedEmpty.result ?? {}).slice(0, 200),
  );
  record(
    "list-no-user-id-field",
    listedEmpty.ok &&
      listedEmpty.result &&
      !("userId" in listedEmpty.result) &&
      !("user_id" in listedEmpty.result) &&
      !leaky(listedEmpty.result),
  );

  const noDelete = await page.evaluate(async () => {
    const mod = await import("/src/lib/audit.ts");
    return {
      del: typeof mod.deleteActivity,
      upd: typeof mod.updateActivity,
      append: typeof mod.appendAudit,
      list: typeof mod.listActivity,
    };
  });
  record(
    "no-edit-exports",
    noDelete.del === "undefined" && noDelete.upd === "undefined" && noDelete.list === "function",
    JSON.stringify(noDelete),
  );

  const mem = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "Kettle note",
    body: "The kettle is in the cupboard.",
    tags: "",
    pinned: false,
  });
  record("create-memory", mem.ok && mem.result?.id > 0, JSON.stringify(mem).slice(0, 160));
  const afterCreate = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  const createdRows = (afterCreate.result?.items ?? []).filter((e) => e.action === "memory.created");
  record(
    "memory-created-once",
    createdRows.length === 1 && createdRows[0].detail === "Kettle note",
    JSON.stringify(createdRows).slice(0, 240),
  );
  record(
    "newest-first-single",
    afterCreate.ok && afterCreate.result.items[0]?.action === "memory.created",
  );
  record("create-no-payload-leak", !leaky(afterCreate.result));

  await callFn(page, "/src/lib/memory.ts", "updateMemory", {
    id: mem.result.id,
    kind: "fact",
    title: "Kettle note",
    body: "The kettle is on the shelf.",
    tags: "",
    pinned: false,
  });
  await callFn(page, "/src/lib/goals.ts", "createGoal", {
    title: "Drink better tea",
    description: "",
    status: "active",
    targetDate: null,
  });
  await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Buy loose-leaf tea",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: null,
  });
  await callFn(page, "/src/lib/permissions.ts", "updatePermissionSettings", {
    confirmFloor: "review",
  });
  await callFn(page, "/src/lib/permissions.ts", "updatePermissionSettings", {
    confirmFloor: "safe",
  });

  const domain = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  const actions = (domain.result?.items ?? []).map((e) => e.action);
  record(
    "domain-event-types",
    actions.includes("memory.created") &&
      actions.includes("memory.updated") &&
      actions.includes("goal.created") &&
      actions.includes("task.created") &&
      actions.includes("permission.settings.updated"),
    actions.join(","),
  );
  record(
    "ordered-newest-first",
    actions[0] === "permission.settings.updated" && actions.includes("memory.created"),
    actions.slice(0, 6).join(","),
  );
  const permRows = (domain.result?.items ?? []).filter(
    (e) => e.action === "permission.settings.updated",
  );
  record("permission-not-duplicated-wrongly", permRows.length === 2, String(permRows.length));
  record("domain-no-payload-leak", !leaky(domain.result));

  installStub();
  utimesSync(COMPLETE, new Date(), new Date());
  await sleep(800);

  const sent = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Remember I drink black tea.",
  });
  const save = (sent.result?.proposals ?? []).find((p) => p.toolId === "memory.save");
  record(
    "proposal-created-pending",
    Boolean(save && save.status === "pending"),
    JSON.stringify(sent.result?.proposals ?? []).slice(0, 240),
  );

  const afterProp = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  const propCreated = (afterProp.result?.items ?? []).filter((e) => e.action === "proposal.created");
  record(
    "proposal-created-event",
    propCreated.length >= 1 && propCreated[0].permissionLevel === "review",
    JSON.stringify(propCreated[0] ?? {}).slice(0, 240),
  );
  record("proposal-event-no-secret", !leaky(afterProp.result));

  const denied = await callFn(page, "/src/lib/confirm.ts", "denyProposal", { id: save.id });
  record("deny-still-works", denied.ok && denied.result?.status === "denied");
  const afterDeny = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  record(
    "proposal-denied-event",
    (afterDeny.result?.items ?? []).some((e) => e.action === "proposal.denied" && e.entityId === String(save.id)),
  );
  const memAfterDeny = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "deny-did-not-write-memory",
    (memAfterDeny.result ?? []).every((m) => m.body !== "payload-secret-orchid-77"),
  );

  const sent2 = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Remember I drink black tea.",
  });
  const save2 = (sent2.result?.proposals ?? []).find((p) => p.toolId === "memory.save");
  const approved = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: save2.id });
  record("approve-still-works", approved.ok && approved.result?.status === "executed");
  const afterExec = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  const execActions = (afterExec.result?.items ?? []).map((e) => e.action);
  record(
    "proposal-approved-and-executed",
    execActions.includes("proposal.approved") && execActions.includes("proposal.executed"),
    execActions.slice(0, 8).join(","),
  );
  record("executed-no-secret", !leaky(afterExec.result));

  const restricted = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please change my permissions and turn on auto-run.",
  });
  record(
    "restricted-rejected",
    (restricted.result?.proposals ?? []).length === 0 &&
      (restricted.result?.rejected ?? []).some((r) => r.toolId === "permission.update"),
    JSON.stringify(restricted.result ?? {}).slice(0, 240),
  );
  const afterRej = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "restricted" });
  record(
    "filter-restricted",
    afterRej.ok &&
      (afterRej.result?.items ?? []).length >= 1 &&
      (afterRej.result?.items ?? []).every((e) => e.permissionLevel === "restricted") &&
      (afterRej.result?.items ?? []).some((e) => e.action === "proposal.rejected"),
    JSON.stringify(afterRej.result?.items ?? []).slice(0, 240),
  );
  const reviewOnly = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "review" });
  record(
    "filter-review",
    reviewOnly.ok &&
      (reviewOnly.result?.items ?? []).length >= 1 &&
      (reviewOnly.result?.items ?? []).every((e) => e.permissionLevel === "review"),
    String((reviewOnly.result?.items ?? []).length),
  );
  const allLevel = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  record(
    "filter-all-includes-unlevelled",
    (allLevel.result?.items ?? []).some((e) => e.action === "memory.created" && e.permissionLevel == null),
  );
  const newest = allLevel.result?.items?.[0];
  const olderPage = newest
    ? await callFn(page, "/src/lib/audit.ts", "listActivity", {
        level: "all",
        cursor: `${newest.createdAt}|${newest.id}`,
      })
    : { ok: false, result: null };
  record(
    "cursor-skips-newer",
    Boolean(
      newest &&
        olderPage.ok &&
        !(olderPage.result?.items ?? []).some((e) => e.id === newest.id) &&
        (olderPage.result?.items ?? []).length >= 1,
    ),
    String((olderPage.result?.items ?? []).length),
  );

  await page.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "The record" }).waitFor({ timeout: 15000 });
  record("refresh-keeps-rows", await page.getByText("Added a memory").first().isVisible());
  record(
    "ui-no-payload-secret",
    !(await page.getByText("payload-secret-orchid-77").count()),
  );
  record(
    "activity-no-approve-deny",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /^Deny$/ }).count()) === 0,
  );
  await page.getByRole("tab", { name: "Restricted" }).click();
  await page.getByText("Rejected a restricted action").waitFor({ timeout: 10000 });
  record(
    "ui-filter-restricted",
    (await page.getByText("Rejected a restricted action").first().isVisible()) &&
      (await page.getByText("Added a memory").count()) === 0,
  );
  await page.getByRole("tab", { name: "All" }).click();
  await page.getByText("Added a memory").waitFor({ timeout: 10000 });
  record("ui-filter-all", await page.getByText("Added a memory").first().isVisible());
  record(
    "no-load-more-when-short",
    (await page.getByRole("button", { name: "Load earlier" }).count()) === 0,
  );

  restoreComplete();
  restored = true;
  utimesSync(COMPLETE, new Date(), new Date());
  await sleep(800);

  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("dashboard-regression", await page.getByRole("heading", { name: /Hello/i }).isVisible());
  record(
    "dashboard-no-approve",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0,
  );
  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  record("goals-regression", await page.getByRole("heading", { name: "Working toward" }).isVisible());
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("memory-regression", await page.getByRole("heading", { name: "What lasts" }).isVisible());
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("settings-regression", await page.getByRole("heading", { name: "Permissions" }).isVisible());
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  record("chat-regression", await page.getByRole("heading", { name: "Conversations" }).isVisible());

  const contextB = await browser.newContext();
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other", email: emailB });
  const bList = await callFn(pageB, "/src/lib/audit.ts", "listActivity", { level: "all" });
  const bActions = (bList.result?.items ?? []).map((e) => `${e.action}:${e.detail}`);
  record(
    "idor-no-foreign-events",
    bList.ok &&
      !(bList.result?.items ?? []).some(
        (e) => e.detail === "Kettle note" || e.detail?.includes("Save tea preference"),
      ),
    bActions.join("|").slice(0, 200),
  );
  await pageB.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  record(
    "idor-page-empty-or-own",
    (await pageB.getByText("Kettle note").count()) === 0 &&
      (await pageB.getByText("Save tea preference").count()) === 0,
  );
  await contextB.close();

  await signOut(page);
  await page.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  record("signout-gate", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "The record" }).waitFor({ timeout: 15000 });
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
  );
  record("mobile-no-overflow", !overflow, JSON.stringify({ overflow }));
  await page.screenshot({ path: "/workspace/screenshots/step13-activity-mobile.png", fullPage: true });
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  await page.screenshot({ path: "/workspace/screenshots/step13-activity.png", fullPage: true });

  const serious = consoleErrors.filter(
    (e) => !/Download the React DevTools/i.test(e) && !/not found/i.test(e),
  );
  record("console-errors", serious.length === 0, serious.join(" | ").slice(0, 300));
} catch (err) {
  record("fatal", false, err && err.stack ? err.stack : String(err));
} finally {
  if (!restored) {
    restoreComplete();
    restored = true;
  }
  await browser.close();
}

const ok = results.filter((r) => r.ok).length;
const total = results.length;
writeFileSync(
  "/workspace/screenshots/verify-step13.json",
  JSON.stringify({ emailA, emailB, ok, total, results }, null, 2),
);
console.log(`\n${ok}/${total} passed`);
process.exit(ok === total ? 0 : 1);
