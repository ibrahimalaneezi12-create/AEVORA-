import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step16.${stamp}@example.com`;
const emailB = `ibrahim.step16b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const last = history[history.length - 1]?.content ?? "";
  const prev = history[history.length - 2]?.content ?? "";
  const idMatch = last.match(/#(\\d+)/);
  const n = idMatch ? Number(idMatch[1]) : 0;
  if (/auto-run|change my permissions/i.test(last)) {
    return {
      ok: true,
      text: [
        "I cannot change permissions.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "permission.update", title: "Turn on auto-run", summary: "Enable automatic execution" }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/email the bank|external\\.email/i.test(last)) {
    return {
      ok: true,
      text: [
        "I would have to send mail.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "external.email", title: "Email the bank", summary: "Send a payment email." }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/run a shell|shell\\.exec/i.test(last)) {
    return {
      ok: true,
      text: [
        "I would run a command.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "shell.exec", title: "Run a command", summary: "Unregistered tool." }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/search my memories/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can search your memory. It will not run until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "memory.search",
          title: "Search study memories",
          summary: "Look for study in your keep.",
          payload: { query: "study" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/forget|delete memory/i.test(last) && n > 0) {
    return {
      ok: true,
      text: [
        "I can forget that. It will not be removed until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "memory.delete",
          title: "Forget that memory",
          summary: "Remove the selected memory.",
          payload: { id: n },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/prefer studying at 8|study at 8/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can update your study preference. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "memory.save",
          title: "Study time",
          summary: "Prefer studying at 8 PM now.",
          payload: { kind: "preference", title: "Study time", body: "I prefer studying at 8 PM now." },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/remember that I prefer studying after dinner/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remember that you prefer studying after dinner. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "memory.save",
          title: "Study time",
          summary: "Prefer studying after dinner.",
          payload: { kind: "preference", title: "Study time", body: "I prefer studying after dinner." },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/create a task to study|remind me to study/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can add that task. It will not be created until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "task.create",
          title: "Study tomorrow",
          summary: "Add a study task.",
          payload: { title: "Study tomorrow", status: "todo" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/make it 8|change it to 8/i.test(last)) {
    const taskId = prev.match(/task #(\\d+)/i);
    return {
      ok: true,
      text: [
        "I can update that task to 8 PM. It will not change until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "task.update",
          title: "Study at 8 PM",
          summary: "Set the study task to 8 PM.",
          payload: { id: taskId ? Number(taskId[1]) : 1, notes: "8 PM" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/بكرة|tomorrow/i.test(last) && history.length > 1) {
    return { ok: true, text: "Tomorrow still uses this conversation. Aegis-step16-followup." };
  }
  if (/[\\u0600-\\u06FF]/.test(last)) {
    return { ok: true, text: "حسنًا. Aegis-step16-arabic." };
  }
  return { ok: true, text: "Aegis-step16-fixture: a quiet reply with no proposed action." };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const create = page.getByRole("button", { name: /Create an account/i });
  if (await create.isVisible().catch(() => false)) {
    await create.click();
  }
  await page.locator("#auth-name").waitFor({ timeout: 15000 });
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

function unauth(res) {
  return !res.ok && /unauthorized/i.test(res.error || "");
}

const VOICE_MOCK = `(() => {
  const voices = [
    { name: "Aegis English", lang: "en-US", default: true, localService: true, voiceURI: "aegis-en" },
    { name: "Aegis Arabic", lang: "ar-SA", default: false, localService: true, voiceURI: "aegis-ar" },
  ];
  window.__tts = [];
  window.__ttsCancelled = 0;
  window.__recStarted = 0;
  window.__listening = false;
  const synth = window.speechSynthesis;
  synth.speak = function (utterance) {
    this.speaking = true;
    window.__tts.push(utterance && utterance.text);
    window.__lastVoice = utterance && utterance.voice && utterance.voice.name;
    setTimeout(() => {
      this.speaking = false;
      if (utterance && typeof utterance.onend === "function") utterance.onend();
    }, 60);
  };
  synth.cancel = function () {
    this.speaking = false;
    window.__ttsCancelled += 1;
  };
  synth.getVoices = () => voices;
  class FakeRec {
    constructor() {
      this.lang = "en-US";
      this.continuous = false;
      this.interimResults = true;
      this.onresult = null;
      this.onerror = null;
      this.onend = null;
      this.onspeechstart = null;
      window.__rec = this;
    }
    start() {
      window.__recStarted += 1;
      window.__listening = true;
    }
    stop() {
      window.__listening = false;
      if (typeof this.onend === "function") this.onend();
    }
    abort() {
      window.__listening = false;
    }
  }
  window.SpeechRecognition = FakeRec;
  window.webkitSpeechRecognition = FakeRec;
  if (navigator.mediaDevices) {
    navigator.mediaDevices.getUserMedia = async () => ({
      getTracks: () => [{ stop() {} }],
    });
  }
  window.__speakAsUser = (text) => {
    const rec = window.__rec;
    if (!rec || typeof rec.onresult !== "function") return false;
    const row = [{ transcript: text, confidence: 0.99 }];
    row.isFinal = true;
    rec.onresult({ resultIndex: 0, results: [row] });
    return true;
  };
})()`;

let restored = false;
const consoleErrors = [];
installStub();

const browser = await chromium.launch({
  headless: true,
  args: ["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"],
});
const context = await browser.newContext({ permissions: ["microphone"] });
await context.addInitScript(VOICE_MOCK);
const page = await context.newPage();
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});
page.on("pageerror", (err) => consoleErrors.push(String(err)));

try {
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("signed-out-app", /\/login/.test(page.url()), page.url());

  for (const [mod, name, data] of [
    ["/src/lib/profile.ts", "getOrCreateProfile", undefined],
    ["/src/lib/profile.ts", "updateProfile", { displayName: "x", bio: "", timezone: "UTC", theme: "dark" }],
    ["/src/lib/chat.ts", "sendChatMessage", { content: "hi" }],
    ["/src/lib/memory.ts", "retrieveMemoriesForChat", { query: "study" }],
    ["/src/lib/memory.ts", "listMemories", undefined],
    ["/src/lib/confirm.ts", "approveProposal", { id: 1 }],
  ]) {
    const res = await callFn(page, mod, name, data);
    record(`unauth-${name}`, unauth(res), res.error || "");
  }

  await signup(page, { name: "Ibrahim", email: emailA });
  utimesSync(COMPLETE, new Date(), new Date());
  await sleep(800);

  const profile = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
  record(
    "profile-locale-defaults",
    profile.ok &&
      profile.result?.locale === "en" &&
      profile.result?.voiceEnabled === true &&
      profile.result?.detectLanguage === true,
    JSON.stringify(profile.result ?? {}).slice(0, 180),
  );

  const spoof = await callFn(page, "/src/lib/profile.ts", "updateProfile", {
    displayName: "Ibrahim",
    bio: "",
    timezone: "UTC",
    theme: "dark",
    locale: "ar",
    voiceEnabled: true,
    voiceName: "Aegis Arabic",
    detectLanguage: true,
    userId: "attacker",
  });
  record(
    "locale-ignores-client-userid",
    spoof.ok &&
      spoof.result?.locale === "ar" &&
      spoof.result?.voiceName === "Aegis Arabic" &&
      spoof.result?.userId !== "attacker",
    JSON.stringify(spoof.result ?? {}).slice(0, 180),
  );

  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  await sleep(400);
  const rtl = await page.evaluate(() => ({
    dir: document.documentElement.dir,
    lang: document.documentElement.lang,
  }));
  record("arabic-rtl", rtl.dir === "rtl" && rtl.lang === "ar", JSON.stringify(rtl));

  const backEn = await callFn(page, "/src/lib/profile.ts", "updateProfile", {
    displayName: "Ibrahim",
    bio: "",
    timezone: "UTC",
    theme: "dark",
    locale: "en",
    voiceEnabled: true,
    voiceName: "Aegis English",
    detectLanguage: true,
  });
  record("locale-switch-en", backEn.ok && backEn.result?.locale === "en");

  const soccer = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "Favorite sport",
    body: "Soccer is my favorite sport.",
    tags: "sport",
    pinned: false,
  });
  const study = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "preference",
    title: "Study time",
    body: "I prefer studying after dinner.",
    tags: "study",
    pinned: false,
  });
  record("memory-seeded", soccer.ok && study.ok, `${soccer.result?.id},${study.result?.id}`);

  const retrieved = await callFn(page, "/src/lib/memory.ts", "retrieveMemoriesForChat", {
    query: "What should I study tonight?",
  });
  const ids = (retrieved.result ?? []).map((m) => m.id);
  record(
    "relevant-retrieval",
    retrieved.ok && ids.includes(study.result?.id) && !ids.includes(soccer.result?.id),
    ids.join(","),
  );

  const arMem = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "preference",
    title: "Night study",
    body: "أفضل الدراسة في الليل studying at night",
    tags: "study",
    pinned: false,
  });
  const cross = await callFn(page, "/src/lib/memory.ts", "retrieveMemoriesForChat", {
    query: "When do I study at night?",
  });
  record(
    "cross-language-retrieval",
    cross.ok && (cross.result ?? []).some((m) => m.id === arMem.result?.id),
  );

  const mixed = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "ذكّرني tomorrow at 7 PM أذاكر.",
  });
  record(
    "mixed-language-turn",
    mixed.ok && mixed.result?.ok === true && Boolean(mixed.result?.assistantMessage?.content),
    mixed.result?.assistantMessage?.content?.slice(0, 80) || mixed.error,
  );

  const arTurn = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "طيب، وش عندي بكرة؟",
    conversationId: mixed.result?.conversation?.id,
  });
  record(
    "arabic-followup-same-conversation",
    arTurn.ok &&
      arTurn.result?.ok === true &&
      arTurn.result?.conversation?.id === mixed.result?.conversation?.id &&
      /step16-followup|arabic/i.test(arTurn.result?.assistantMessage?.content ?? ""),
    arTurn.result?.assistantMessage?.content?.slice(0, 80) || arTurn.error,
  );

  const voicePath = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Remember that I prefer studying after dinner.",
    conversationId: mixed.result?.conversation?.id,
  });
  const saveP = (voicePath.result?.proposals ?? []).find((p) => p.toolId === "memory.save");
  record("voice-same-brain-proposal", Boolean(saveP && saveP.status === "pending"));
  const approvedSave = saveP
    ? await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: saveP.id })
    : { ok: false };
  record(
    "voice-cannot-skip-confirm",
    approvedSave.ok && approvedSave.result?.status === "executed",
  );

  const conflictMsg = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "I prefer studying at 8 PM now.",
  });
  const conflictP = (conflictMsg.result?.proposals ?? []).find((p) => p.toolId === "memory.save");
  const conflictOk = conflictP
    ? await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: conflictP.id })
    : { ok: false };
  const afterConflict = await callFn(page, "/src/lib/memory.ts", "listMemories");
  const studyRows = (afterConflict.result ?? []).filter(
    (m) => m.kind === "preference" && /study/i.test(`${m.title} ${m.body}`),
  );
  record(
    "preference-conflict-updates",
    conflictOk.ok &&
      conflictOk.result?.status === "executed" &&
      studyRows.some((m) => /8 PM/i.test(m.body)) &&
      studyRows.length <= 2,
    String(studyRows.length),
  );

  const studyId = studyRows.find((m) => /8 PM/i.test(m.body))?.id ?? study.result?.id;
  const forget = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: `Forget that. Delete memory #${studyId}`,
  });
  const delP = (forget.result?.proposals ?? []).find((p) => p.toolId === "memory.delete");
  record("forget-proposes-delete", Boolean(delP && delP.status === "pending"));
  const delOk = delP
    ? await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: delP.id })
    : { ok: false };
  const afterDel = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "forget-removes",
    delOk.ok &&
      delOk.result?.status === "executed" &&
      (afterDel.result ?? []).every((m) => m.id !== studyId),
  );

  const restricted = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please change my permissions and turn on auto-run.",
  });
  record(
    "restricted-still-blocked",
    (restricted.result?.proposals ?? []).length === 0 &&
      (restricted.result?.rejected ?? []).some((r) => r.toolId === "permission.update"),
  );
  const unknown = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please run a shell.exec command.",
  });
  record(
    "unregistered-still-blocked",
    (unknown.result?.proposals ?? []).length === 0 &&
      (unknown.result?.rejected ?? []).some((r) => r.toolId === "shell.exec"),
  );
  const external = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please email the bank.",
  });
  record(
    "external-still-blocked",
    (external.result?.proposals ?? []).length === 0 &&
      (external.result?.rejected ?? []).some((r) => r.toolId === "external.email"),
  );

  const taskMsg = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Create a task to study tomorrow.",
  });
  const taskP = (taskMsg.result?.proposals ?? []).find((p) => p.toolId === "task.create");
  const taskOk = taskP
    ? await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: taskP.id })
    : { ok: false };
  record("task-create-still-confirm", taskOk.ok && taskOk.result?.status === "executed");

  const seededConvo = await callFn(page, "/src/lib/chat.ts", "createConversation");
  record("voice-conversation", Boolean(seededConvo.ok && seededConvo.result?.id > 0));
  await page.goto(`${BASE}/app/chat/${seededConvo.result?.id}`, { waitUntil: "networkidle" });
  await sleep(600);
  const startBtn = page.getByRole("button", { name: "Start voice" });
  record("voice-start-visible", await startBtn.count().then((n) => n > 0));
  if (await startBtn.count()) {
    await startBtn.click();
    await page.waitForFunction(
      () => {
        const el = document.querySelector("[data-voice-state]");
        const state = el?.getAttribute("data-voice-state") ?? "";
        return state === "listening" || state === "permission";
      },
      { timeout: 8000 },
    ).catch(() => {});
    await sleep(200);
  }
  const voiceState = await page.evaluate(() => {
    const el = document.querySelector("[data-voice-state]");
    return {
      state: el?.getAttribute("data-voice-state") ?? "",
      session: el?.getAttribute("data-voice-session") ?? "",
      started: window.__recStarted ?? 0,
    };
  });
  record(
    "voice-listening",
    voiceState.session === "on" &&
      (voiceState.state === "listening" || voiceState.state === "permission") &&
      voiceState.started >= 1,
    JSON.stringify(voiceState),
  );

  const spoken = await page.evaluate(() => window.__speakAsUser("What should I work on today?"));
  record("voice-transcript-injected", spoken === true);
  await page.waitForFunction(
    () => document.body.innerText.includes("Aegis-step16-fixture"),
    { timeout: 12000 },
  ).catch(() => {});
  await sleep(400);
  const threadDump = await page.evaluate(() => ({
    url: location.pathname,
    fixture: document.body.innerText.includes("Aegis-step16-fixture"),
    heard: document.body.innerText.includes("What should I work on today?"),
    thinking: document.body.innerText.includes("Thinking"),
    voice: document.querySelector("[data-voice-state]")?.getAttribute("data-voice-state") ?? null,
    session: document.querySelector("[data-voice-state]")?.getAttribute("data-voice-session") ?? null,
    err: document.querySelector("[role=alert]")?.textContent ?? "",
  }));
  const threadHas = await page.locator("text=Aegis-step16-fixture").count();
  record("voice-uses-same-chat", threadHas > 0, `${threadHas} ${JSON.stringify(threadDump)}`);

  await page.waitForFunction(() => (window.__tts ?? []).length > 0, { timeout: 6000 }).catch(() => {});
  const tts = await page.evaluate(() => ({
    texts: window.__tts ?? [],
    voice: window.__lastVoice ?? "",
  }));
  record("voice-tts", (tts.texts ?? []).length > 0, JSON.stringify(tts).slice(0, 120));

  const cancelledBefore = await page.evaluate(() => window.__ttsCancelled ?? 0);
  await page.evaluate(() => {
    const rec = window.__rec;
    if (rec && typeof rec.onspeechstart === "function") rec.onspeechstart();
  });
  await sleep(100);
  const barged = await page.evaluate(() => window.__ttsCancelled ?? 0);
  record("voice-barge-in-stops-tts", barged >= cancelledBefore, String(barged));

  const stopBtn = page.getByRole("button", { name: "Stop voice" });
  if (await stopBtn.count()) {
    await stopBtn.click();
    await sleep(200);
  }
  const afterStop = await page.evaluate(() => ({
    listening: window.__listening === true,
    session: document.querySelector("[data-voice-state]")?.getAttribute("data-voice-session"),
    state: document.querySelector("[data-voice-state]")?.getAttribute("data-voice-state"),
  }));
  record(
    "voice-cleanup",
    afterStop.listening === false && (afterStop.session === "off" || afterStop.state === "idle" || afterStop.state === "disabled"),
    JSON.stringify(afterStop),
  );

  const disable = await callFn(page, "/src/lib/profile.ts", "updateProfile", {
    displayName: "Ibrahim",
    bio: "",
    timezone: "UTC",
    theme: "dark",
    locale: "en",
    voiceEnabled: false,
    voiceName: "Aegis English",
    detectLanguage: true,
  });
  record("voice-disable-save", disable.ok && disable.result?.voiceEnabled === false);
  await page.reload({ waitUntil: "networkidle" });
  await sleep(600);
  const disabledUi = await page.evaluate(() =>
    document.querySelector("[data-voice-state]")?.getAttribute("data-voice-state"),
  );
  record("voice-disabled-ui", disabledUi === "disabled", String(disabledUi));
  const listeningAfterDisable = await page.evaluate(() => window.__listening === true);
  record("voice-disabled-no-mic", listeningAfterDisable === false);

  const enable = await callFn(page, "/src/lib/profile.ts", "updateProfile", {
    displayName: "Ibrahim",
    bio: "",
    timezone: "UTC",
    theme: "dark",
    locale: "en",
    voiceEnabled: true,
    voiceName: "Aegis English",
    detectLanguage: true,
  });
  record("voice-reenable", enable.ok && enable.result?.voiceEnabled === true);

  await page.reload({ waitUntil: "networkidle" });
  await sleep(400);
  const persistProfile = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
  record(
    "persist-refresh-voice-locale",
    persistProfile.result?.locale === "en" &&
      persistProfile.result?.voiceName === "Aegis English" &&
      persistProfile.result?.voiceEnabled === true,
  );
  const persistMem = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "persist-deleted-stays-deleted",
    (persistMem.result ?? []).every((m) => m.id !== studyId),
  );
  record(
    "persist-soccer-memory",
    (persistMem.result ?? []).some((m) => m.id === soccer.result?.id),
  );

  const defs = await page.evaluate(async () => {
    const mod = await import("/src/lib/tools/definitions.ts");
    return {
      execute: typeof mod.executeRegisteredTool,
      restricted: mod.canRunTool("permission.update"),
      unknown: mod.canRunTool("shell.exec"),
    };
  });
  record(
    "client-still-cannot-execute",
    defs.execute === "undefined" && defs.restricted === false && defs.unknown === false,
  );

  await signOut(page);
  const afterOut = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record("sign-out-memory-unauthorized", unauth(afterOut));

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  const signedIn = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
  record(
    "sign-in-locale-voice-remain",
    signedIn.result?.locale === "en" && signedIn.result?.voiceName === "Aegis English",
  );
  const memIn = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "sign-in-memory-remain",
    (memIn.result ?? []).some((m) => m.id === soccer.result?.id) &&
      (memIn.result ?? []).every((m) => m.id !== studyId),
  );

  const aMemories = memIn.result ?? [];
  const contextB = await browser.newContext({ permissions: ["microphone"] });
  await contextB.addInitScript(VOICE_MOCK);
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other", email: emailB });
  const bProfile = await callFn(pageB, "/src/lib/profile.ts", "updateProfile", {
    displayName: "Other",
    bio: "",
    timezone: "UTC",
    theme: "light",
    locale: "ar",
    voiceEnabled: false,
    voiceName: "Aegis Arabic",
    detectLanguage: false,
  });
  record("user-b-own-locale", bProfile.ok && bProfile.result?.locale === "ar");
  const bMem = await callFn(pageB, "/src/lib/memory.ts", "listMemories");
  record(
    "idor-memory-hidden",
    (bMem.result ?? []).every((m) => !aMemories.some((a) => a.id === m.id)),
  );
  if (soccer.result?.id) {
    const steal = await callFn(pageB, "/src/lib/memory.ts", "getMemory", { id: soccer.result.id });
    record("idor-get-memory", !steal.ok);
    const stealDel = await callFn(pageB, "/src/lib/memory.ts", "deleteMemory", { id: soccer.result.id });
    record("idor-delete-memory", !stealDel.ok);
  }
  const bAgain = await callFn(pageB, "/src/lib/profile.ts", "getOrCreateProfile");
  record(
    "user-b-voice-isolated",
    bAgain.result?.voiceName === "Aegis Arabic" && bAgain.result?.voiceEnabled === false,
  );
  await contextB.close();

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1);
  record("mobile-no-overflow", overflow === false);

  const productErrors = consoleErrors.filter(
    (t) => !/favicon|Download the React DevTools|Failed to load resource|react-dom/i.test(t),
  );
  record("no-page-errors", productErrors.length === 0, productErrors.slice(0, 3).join(" | "));
} catch (err) {
  record("fatal", false, err && err.message ? err.message : String(err));
} finally {
  if (!restored) {
    restoreComplete();
    restored = true;
  }
  await browser.close();
  const failed = results.filter((r) => !r.ok);
  console.log(
    JSON.stringify(
      {
        passed: results.filter((r) => r.ok).length,
        failed: failed.length,
        total: results.length,
        failedNames: failed.map((r) => r.name),
      },
      null,
      2,
    ),
  );
  process.exit(failed.length ? 1 : 0);
}
