import { Link } from "@tanstack/react-router";
import type { ProposedActionView, RejectedProposalView } from "@/lib/orchestrator/types";
import { LevelBadge } from "@/components/permissions/level-badge";
import { DecisionControls } from "@/components/permissions/decision-controls";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function statusLine(proposal: ProposedActionView): string {
  if (proposal.status === "pending") {
    return `${proposal.displayName}. Nothing will run until you confirm.`;
  }
  if (proposal.status === "denied") return "Denied. Nothing ran.";
  if (proposal.status === "executed") return "Executed.";
  if (proposal.status === "failed") return "This action failed.";
  if (proposal.status === "approved") return "Approved.";
  return proposal.status;
}

export function ProposalCard({
  proposal,
  deciding,
  onApprove,
  onDeny,
}: {
  proposal: ProposedActionView;
  deciding?: boolean;
  onApprove?: (id: number) => void;
  onDeny?: (id: number) => void;
}) {
  const pending = proposal.status === "pending";
  const fullPage = proposal.permissionLevel === "approval";
  const inThreadDecide = pending && !fullPage && proposal.permissionLevel !== "restricted";
  const compact = proposal.permissionLevel === "safe";

  return (
    <article
      className={cn(
        "max-w-[40rem] border-t border-border py-4",
        compact ? "p-3" : "p-4",
      )}
      aria-label={`Proposed action: ${proposal.title}`}
    >
      <div className="flex flex-wrap items-center gap-2">
        <LevelBadge level={proposal.permissionLevel} />
        <span className="text-xs uppercase tracking-[0.14em] text-subtle">
          {pending ? "Pending" : proposal.status}
        </span>
      </div>
      <h2 className={cn("text-sm font-medium text-fg", compact ? "mt-2" : "mt-3")}>
        {proposal.title}
      </h2>
      <p className="mt-1 text-sm leading-relaxed text-muted">{proposal.summary}</p>
      <p className="mt-3 text-xs leading-relaxed text-subtle">{statusLine(proposal)}</p>

      {inThreadDecide && onApprove && onDeny ? (
        <DecisionControls
          canApprove
          canDeny
          busy={Boolean(deciding)}
          onApprove={() => onApprove(proposal.id)}
          onDeny={() => onDeny(proposal.id)}
        />
      ) : null}

      {pending && fullPage ? (
        <div className="mt-4">
          <Button asChild size="sm">
            <Link to="/app/approvals/$id" params={{ id: String(proposal.id) }}>
              Review this action
            </Link>
          </Button>
        </div>
      ) : null}
    </article>
  );
}

export function RestrictedNotice({ item }: { item: RejectedProposalView }) {
  return (
    <article
      className="max-w-[40rem] rounded-md border border-danger/30 bg-surface p-4"
      aria-label={`Rejected action: ${item.title}`}
    >
      <div className="flex flex-wrap items-center gap-2">
        <LevelBadge level="restricted" />
        <span className="text-xs uppercase tracking-[0.14em] text-subtle">Rejected</span>
      </div>
      <h2 className="mt-3 text-sm font-medium text-fg">{item.title}</h2>
      <p className="mt-1 text-sm leading-relaxed text-muted">{item.reason}</p>
      <p className="mt-3 text-xs leading-relaxed text-subtle">
        This action is not allowed and cannot be approved.
      </p>
    </article>
  );
}
