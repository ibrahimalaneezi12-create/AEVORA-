import { Bell, BookMarked, Briefcase, CalendarDays, Flag, Globe, LineChart, ListTodo, Mail, Mic, PenLine, ScrollText, Sun } from "lucide-react";
import { cn } from "@/lib/utils";

export type QuickAction = {
  id: string;
  label: string;
  text: string;
  send: boolean;
  icon: typeof Sun;
};

const QUICK_ACTIONS: QuickAction[] = [
  { id: "plan-day", label: "Plan my day", text: "Plan my day.", send: true, icon: Sun },
  { id: "briefing", label: "Daily briefing", text: "Give me my daily briefing.", send: true, icon: CalendarDays },
  { id: "reminder", label: "Reminder", text: "Remind me ", send: false, icon: Bell },
  { id: "task", label: "Add task", text: "Create a task: ", send: false, icon: ListTodo },
  { id: "goal", label: "Add goal", text: "Create a goal: ", send: false, icon: Flag },
  { id: "memory", label: "Memory", text: "Remember that ", send: false, icon: BookMarked },
  { id: "activity", label: "Recent activity", text: "What happened recently in my keep?", send: true, icon: ScrollText },
  { id: "search", label: "Search", text: "Search for ", send: false, icon: Globe },
  { id: "calendar", label: "Calendar", text: "What's on my calendar today?", send: true, icon: CalendarDays },
  { id: "business", label: "Business", text: "Give me my business briefing.", send: true, icon: Briefcase },
  { id: "invest", label: "Invest", text: "Review my watchlist.", send: true, icon: LineChart },
  { id: "mail", label: "Mail", text: "Draft an email ", send: false, icon: Mail },
  { id: "create", label: "Write", text: "Write ", send: false, icon: PenLine },
  { id: "voice", label: "Voice", text: "", send: false, icon: Mic },
];

export function QuickActions({
  disabled,
  onPick,
  onVoice,
}: {
  disabled?: boolean;
  onPick: (action: QuickAction) => void;
  onVoice?: () => void;
}) {
  return (
    <div
      className="-mx-1 flex gap-1 overflow-x-auto px-1 pb-2"
      data-quick-actions="true"
      aria-label="Quick actions"
    >
      {QUICK_ACTIONS.map((action) => {
        const Icon = action.icon;
        return (
          <button
            key={action.id}
            type="button"
            data-quick-action={action.id}
            disabled={disabled}
            onClick={() => {
              if (action.id === "voice") {
                onVoice?.();
                return;
              }
              onPick(action);
            }}
            className={cn(
              "inline-flex h-11 shrink-0 items-center gap-1.5 rounded-full border border-border bg-bg px-3 text-xs text-muted transition-colors duration-150",
              "hover:border-border-strong hover:text-fg disabled:opacity-50",
            )}
          >
            <Icon className="size-3.5" strokeWidth={1.75} />
            {action.label}
          </button>
        );
      })}
    </div>
  );
}
