import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Mic, MicOff, X } from "lucide-react";
import { AegisPresence } from "@/components/chat/aegis-presence";
import { getOrCreateProfile } from "@/lib/profile";
import { resolveLocale, type AppLocale } from "@/lib/locale";
import { speakAudio } from "@/lib/tts";
import { transcribeAudioBuffer } from "@/lib/stt";
import { resolveTtsVoiceId } from "@/lib/tts-format";
import { nextSpeakableChunks } from "@/lib/canonical-response";
import { echoGuard, voiceCopyFor, type VoiceState } from "@/lib/voice-format";
import { reduceVoice } from "@/lib/voice-machine";
import {
  bargeThreshold,
  concatFloat32,
  createVadState,
  downsampleTo16k,
  encodeWavPcm16,
  MAX_UTTERANCE_MS,
  PcmRing,
  prerollSampleCount,
  rmsFloat,
  stepVad,
  TARGET_SAMPLE_RATE,
  trimSilence,
  type VadState,
} from "@/lib/voice-pcm";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  emptyVoiceLatencyMarks,
  formatVoiceGapRows,
  formatVoiceLatencyRows,
  shouldExposeVoiceDiag,
  type VoiceLatencyKey,
  type VoiceLatencyMarks,
} from "@/lib/latency-format";

const SILENT_WAV =
  "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA=";

let liveVoiceSession = false;
let lastSpokenId: number | null = null;

function audioContextCtor(): (typeof AudioContext) | null {
  if (typeof window === "undefined") return null;
  const w = window as Window & { webkitAudioContext?: typeof AudioContext };
  return window.AudioContext || w.webkitAudioContext || null;
}

async function unlockPlayback(audio: HTMLAudioElement, ctx: AudioContext | null) {
  try {
    await ctx?.resume();
  } catch {
    /* autoplay policies vary */
  }
  try {
    audio.src = SILENT_WAV;
    audio.setAttribute("playsinline", "true");
    await audio.play();
    audio.pause();
  } catch {
    /* gesture unlock is best-effort */
  }
}

export function VoiceDock({
  disabled,
  busy,
  lastAssistant,
  streamingText = "",
  onSend,
  firstOutputAt = null,
  orchestratorAt = null,
  reasoningAt = null,
  onInterrupt,
}: {
  disabled: boolean;
  busy: boolean;
  lastAssistant: { id: number; content: string; createdAt?: string } | null;
  streamingText?: string;
  onSend: (text: string) => void;
  firstOutputAt?: number | null;
  orchestratorAt?: number | null;
  reasoningAt?: number | null;
  onInterrupt?: () => void;
}) {
  const [locale, setLocale] = useState<AppLocale>("en");
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [voiceName, setVoiceName] = useState("");
  const [voiceSpeed, setVoiceSpeed] = useState(1);
  const [phase, setPhase] = useState<VoiceState>(liveVoiceSession ? "thinking" : "idle");
  const [sessionOn, setSessionOn] = useState(liveVoiceSession);
  const [level, setLevel] = useState(0);
  const [interim, setInterim] = useState("");
  const [errorDetail, setErrorDetail] = useState("");
  const [latencyMarks, setLatencyMarks] = useState(() => emptyVoiceLatencyMarks());
  const phaseRef = useRef<VoiceState>(phase);
  const sessionRef = useRef(liveVoiceSession);
  const busyRef = useRef(busy);
  const streamRef = useRef<MediaStream | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const procRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const muteRef = useRef<GainNode | null>(null);
  const vadRef = useRef<VadState>(createVadState());
  const ringRef = useRef<PcmRing>(new PcmRing(prerollSampleCount()));
  const partsRef = useRef<Float32Array[]>([]);
  const capturingRef = useRef(false);
  const lastUiLevelAt = useRef(0);
  const rafRef = useRef(0);
  const spokenRef = useRef("");
  const spokenIdRef = useRef<number | null>(lastSpokenId);
  const ttsQueueRef = useRef<string[]>([]);
  const drainingRef = useRef(false);
  const spokenChunkCountRef = useRef(0);
  const speakTurnRef = useRef(0);
  const captureTurnRef = useRef(0);
  const ttsAbortRef = useRef<AbortController | null>(null);
  const playAnalyserRef = useRef<AnalyserNode | null>(null);
  const mediaSourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const playRafRef = useRef(0);
  const readyClipsRef = useRef<{ url: string }[]>([]);
  const marksRef = useRef<VoiceLatencyMarks>(emptyVoiceLatencyMarks());
  const onSendRef = useRef(onSend);
  const onInterruptRef = useRef(onInterrupt);
  const [queueDepth, setQueueDepth] = useState(0);
  const [chunkTotal, setChunkTotal] = useState(0);

  const applyPhase = useCallback((next: VoiceState, error?: string) => {
    phaseRef.current = next;
    setPhase(next);
    if (error) setErrorDetail(error);
  }, []);

  const dispatch = useCallback(
    (event: Parameters<typeof reduceVoice>[1]) => {
      const next = reduceVoice(phaseRef.current, event);
      applyPhase(next.phase, next.error);
    },
    [applyPhase],
  );

  const stamp = useCallback((key: VoiceLatencyKey, at = Date.now(), note?: string) => {
    const marks = marksRef.current;
    if (marks.originMs == null) marks.originMs = at;
    if (marks.at[key] == null) marks.at[key] = at;
    if (note) marks.note[key] = note;
    setLatencyMarks({ ...marks, at: { ...marks.at }, note: { ...marks.note } });
  }, []);

  useEffect(() => {
    onSendRef.current = onSend;
  }, [onSend]);
  useEffect(() => {
    onInterruptRef.current = onInterrupt;
  }, [onInterrupt]);
  useEffect(() => {
    busyRef.current = busy;
  }, [busy]);
  useEffect(() => {
    sessionRef.current = sessionOn;
  }, [sessionOn]);

  useEffect(() => {
    if (firstOutputAt) stamp("t6", firstOutputAt);
  }, [firstOutputAt, stamp]);
  useEffect(() => {
    if (orchestratorAt) stamp("t4", orchestratorAt);
  }, [orchestratorAt, stamp]);
  useEffect(() => {
    if (reasoningAt) stamp("t5", reasoningAt);
  }, [reasoningAt, stamp]);

  useEffect(() => {
    if (!sessionOn || typeof document === "undefined") return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [sessionOn]);

  useEffect(() => {
    if (phase !== "speaking") {
      if (playRafRef.current) cancelAnimationFrame(playRafRef.current);
      playRafRef.current = 0;
      return;
    }
    const analyser = playAnalyserRef.current;
    if (!analyser) return;
    const data = new Uint8Array(analyser.fftSize);
    const tick = () => {
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i += 1) {
        const v = ((data[i] ?? 128) - 128) / 128;
        sum += v * v;
      }
      setLevel(Math.sqrt(sum / data.length));
      playRafRef.current = requestAnimationFrame(tick);
    };
    playRafRef.current = requestAnimationFrame(tick);
    return () => {
      if (playRafRef.current) cancelAnimationFrame(playRafRef.current);
    };
  }, [phase]);

  const copy = voiceCopyFor(locale);

  const stopTts = useCallback(() => {
    ttsQueueRef.current = [];
    drainingRef.current = false;
    speakTurnRef.current += 1;
    ttsAbortRef.current?.abort();
    ttsAbortRef.current = null;
    setQueueDepth(0);
    for (const clip of readyClipsRef.current) URL.revokeObjectURL(clip.url);
    readyClipsRef.current = [];
    const audio = audioRef.current;
    if (audio) {
      audio.pause();
      audio.removeAttribute("src");
    }
  }, []);

  const cleanup = useCallback(() => {
    capturingRef.current = false;
    liveVoiceSession = false;
    sessionRef.current = false;
    setSessionOn(false);
    stopTts();
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = 0;
    procRef.current?.disconnect();
    sourceRef.current?.disconnect();
    muteRef.current?.disconnect();
    analyserRef.current?.disconnect();
    procRef.current = null;
    sourceRef.current = null;
    muteRef.current = null;
    analyserRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    void ctxRef.current?.close().catch(() => undefined);
    ctxRef.current = null;
    mediaSourceRef.current = null;
    playAnalyserRef.current = null;
  }, [stopTts]);

  const drainTts = useCallback(async () => {
    if (drainingRef.current) return;
    drainingRef.current = true;
    const turn = speakTurnRef.current;
    const voiceId = resolveTtsVoiceId(voiceName);
    const fetchClip = async (text: string) => {
      if (marksRef.current.at.t8 == null) stamp("t8");
      const ac = new AbortController();
      ttsAbortRef.current = ac;
      const result = await speakAudio({
        text,
        voiceId,
        locale,
        speed: voiceSpeed,
        signal: ac.signal,
      });
      if (marksRef.current.at.t9 == null) stamp("t9", Date.now(), result.ok ? `${result.ttsMs ?? "n/a"} ms` : result.error);
      if (!result.ok) return null;
      const blob = new Blob([result.audio], { type: result.mime || "audio/mpeg" });
      return { url: URL.createObjectURL(blob) };
    };
    const nextFetch = () => {
      const text = ttsQueueRef.current.shift();
      setQueueDepth(ttsQueueRef.current.length);
      if (!text) return Promise.resolve(null);
      return fetchClip(text);
    };
    let pending = nextFetch();
    while (sessionRef.current && speakTurnRef.current === turn) {
      const clip = await pending;
      pending = nextFetch();
      if (!clip) break;
      const audio = audioRef.current;
      if (!audio) {
        URL.revokeObjectURL(clip.url);
        break;
      }
      await new Promise<void>((resolve) => {
        audio.onplaying = () => {
          if (marksRef.current.at.t10 == null) stamp("t10");
        };
        audio.onended = () => resolve();
        audio.onerror = () => resolve();
        audio.src = clip.url;
        void audio.play().then(() => {
          if (marksRef.current.at.t10 == null) stamp("t10");
        }).catch(() => resolve());
      });
      URL.revokeObjectURL(clip.url);
    }
    drainingRef.current = false;
    if (!sessionRef.current || speakTurnRef.current !== turn) return;
    if (ttsQueueRef.current.length) {
      void drainTts();
      return;
    }
    if (busyRef.current) return;
    spokenRef.current = "";
    stamp("t11", Date.now(), chunkTotal ? `${chunkTotal} TTS chunks` : undefined);
    dispatch({ type: "playback_done" });
  }, [chunkTotal, dispatch, locale, stamp, voiceName, voiceSpeed]);

  const enqueueChunks = useCallback(
    (chunks: string[], id: number) => {
      if (!sessionRef.current || chunks.length === 0) return;
      spokenIdRef.current = id;
      lastSpokenId = id;
      spokenRef.current = `${spokenRef.current} ${chunks.join(" ")}`.trim();
      ttsQueueRef.current.push(...chunks);
      setChunkTotal((n) => n + chunks.length);
      setQueueDepth(ttsQueueRef.current.length);
      if (marksRef.current.at.t7 == null) stamp("t7");
      dispatch({ type: "first_audio" });
      void drainTts();
    },
    [dispatch, drainTts, stamp],
  );

  useEffect(() => {
    if (busy) {
      spokenChunkCountRef.current = 0;
      setChunkTotal(0);
    }
  }, [busy]);

  useEffect(() => {
    if (!sessionOn) return;
    const canonical = streamingText.trim()
      ? streamingText
      : !busy && lastAssistant
        ? lastAssistant.content
        : "";
    if (!canonical) return;
    if (streamingText.trim() && marksRef.current.at.t6 == null) stamp("t6");
    const next = nextSpeakableChunks({
      canonical,
      already: spokenChunkCountRef.current,
      ended: !busy,
    });
    spokenChunkCountRef.current = next.nextIndex;
    if (next.chunks.length) {
      enqueueChunks(next.chunks, lastAssistant?.id ?? -1);
      return;
    }
    if (
      !busy &&
      !drainingRef.current &&
      ttsQueueRef.current.length === 0 &&
      phaseRef.current === "thinking"
    ) {
      dispatch({ type: "playback_done" });
    }
  }, [busy, lastAssistant, sessionOn, streamingText, enqueueChunks, dispatch, stamp]);

  const finishUtterance = useCallback(async (samples: Float32Array, sampleRate: number) => {
    const turn = captureTurnRef.current;
    const trimmed = trimSilence(downsampleTo16k(samples, sampleRate));
    if (trimmed.length < TARGET_SAMPLE_RATE * 0.18) {
      dispatch({ type: "mic_ready" });
      return;
    }
    const wav = encodeWavPcm16(trimmed);
    stamp("t2");
    const result = await transcribeAudioBuffer(wav, "audio/wav", locale);
    if (turn !== captureTurnRef.current || !sessionRef.current) return;
    stamp("t3", Date.now(), result.ok ? `${result.sttMs ?? "n/a"} ms` : result.error);
    if (!result.ok) {
      dispatch({ type: "error", message: result.error });
      return;
    }
    const text = result.text.trim();
    setInterim(text);
    if (!text || echoGuard(text, spokenRef.current)) {
      dispatch({ type: "mic_ready" });
      return;
    }
    dispatch({ type: "transcript" });
    stamp("t4");
    onSendRef.current(text);
  }, [dispatch, locale, stamp]);

  const attachCapture = useCallback(
    (stream: MediaStream, ctx: AudioContext) => {
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 1024;
      const proc = ctx.createScriptProcessor(1024, 1, 1);
      const mute = ctx.createGain();
      mute.gain.value = 0;
      source.connect(analyser);
      source.connect(proc);
      proc.connect(mute);
      mute.connect(ctx.destination);
      sourceRef.current = source;
      analyserRef.current = analyser;
      procRef.current = proc;
      muteRef.current = mute;
      vadRef.current = createVadState();
      ringRef.current = new PcmRing(prerollSampleCount());
      partsRef.current = [];
      capturingRef.current = true;
      const rate = ctx.sampleRate;
      proc.onaudioprocess = (ev) => {
        if (!capturingRef.current) return;
        const input = ev.inputBuffer.getChannelData(0);
        const copy = new Float32Array(input.length);
        copy.set(input);
        const rms = rmsFloat(copy);
        const now = Date.now();
        if (now - lastUiLevelAt.current > 40) {
          lastUiLevelAt.current = now;
          setLevel(rms);
        }
        const frameMs = (copy.length / rate) * 1000;
        const phaseNow = phaseRef.current;
        if (phaseNow === "speaking" || phaseNow === "thinking") {
          if (rms >= bargeThreshold(vadRef.current.noiseFloor)) {
            stopTts();
            onInterruptRef.current?.();
            dispatch({ type: "barge" });
            captureTurnRef.current += 1;
            vadRef.current = createVadState();
            partsRef.current = [];
            ringRef.current = new PcmRing(prerollSampleCount());
          }
          return;
        }
        ringRef.current.write(copy);
        const result = stepVad(vadRef.current, rms, frameMs);
        if (result.started) {
          stamp("t1");
          partsRef.current = [ringRef.current.snapshot(), copy];
          dispatch({ type: "speech_start" });
        } else if (vadRef.current.speaking) {
          partsRef.current.push(copy);
          if (vadRef.current.speechMs >= MAX_UTTERANCE_MS) {
            const samples = concatFloat32(partsRef.current);
            partsRef.current = [];
            vadRef.current = createVadState();
            dispatch({ type: "speech_end" });
            void finishUtterance(samples, rate);
          }
        } else if (result.ended && (phaseNow === "user_speaking" || phaseNow === "interrupted")) {
          const samples = concatFloat32(partsRef.current);
          partsRef.current = [];
          dispatch({ type: "speech_end" });
          void finishUtterance(samples, rate);
        }
      };
    },
    [dispatch, finishUtterance, stamp, stopTts],
  );

  async function startSession() {
    if (disabled) return;
    marksRef.current = emptyVoiceLatencyMarks();
    setLatencyMarks(emptyVoiceLatencyMarks());
    stamp("t0");
    setErrorDetail("");
    setInterim("");
    spokenChunkCountRef.current = 0;
    setChunkTotal(0);
    dispatch({ type: "start" });
    if (!navigator.mediaDevices?.getUserMedia) {
      dispatch({ type: "unsupported" });
      return;
    }
    if (!audioRef.current) {
      const audio = new Audio();
      audio.setAttribute("playsinline", "true");
      audio.crossOrigin = "anonymous";
      audioRef.current = audio;
    }
    const Ctx = audioContextCtor();
    if (Ctx && !ctxRef.current) {
      try {
        ctxRef.current = new Ctx({ latencyHint: "interactive" });
      } catch {
        ctxRef.current = new Ctx();
      }
    }
    await unlockPlayback(audioRef.current, ctxRef.current);
    const ctx = ctxRef.current;
    const audio = audioRef.current;
    if (ctx && audio && !mediaSourceRef.current) {
      try {
        const src = ctx.createMediaElementSource(audio);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;
        src.connect(analyser);
        analyser.connect(ctx.destination);
        mediaSourceRef.current = src;
        playAnalyserRef.current = analyser;
      } catch {
        /* element source can only be created once */
      }
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 },
        video: false,
      });
      streamRef.current = stream;
      if (!ctxRef.current) {
        dispatch({ type: "unsupported" });
        return;
      }
      await ctxRef.current.resume();
      attachCapture(stream, ctxRef.current);
      liveVoiceSession = true;
      sessionRef.current = true;
      setSessionOn(true);
      dispatch({ type: "mic_ready" });
    } catch (err) {
      const denied = err instanceof DOMException && (err.name === "NotAllowedError" || err.name === "PermissionDeniedError");
      if (denied) dispatch({ type: "permission_denied" });
      else dispatch({ type: "error", message: copy.unavailable });
    }
  }

  function stopSession() {
    dispatch({ type: "stop" });
    cleanup();
    applyPhase(voiceEnabled ? "idle" : "disabled");
  }

  useEffect(() => {
    if (disabled || !voiceEnabled || sessionOn) return;
    try {
      if (sessionStorage.getItem("aegis-start-voice") !== "1") return;
      sessionStorage.removeItem("aegis-start-voice");
    } catch {
      return;
    }
    void startSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [disabled, voiceEnabled, sessionOn]);

  useEffect(() => {
    let cancelled = false;
    getOrCreateProfile()
      .then((row) => {
        if (cancelled) return;
        setLocale(resolveLocale(row.locale));
        setVoiceEnabled(row.voiceEnabled);
        setVoiceName(row.voiceName);
        setVoiceSpeed(row.voiceSpeed);
        if (!row.voiceEnabled) {
          liveVoiceSession = false;
          applyPhase("disabled");
          setSessionOn(false);
        }
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [applyPhase]);

  if (!voiceEnabled) {
    return (
      <div className="flex items-center gap-2 px-1" data-voice-state="disabled" data-voice-session="off">
        <MicOff className="size-4 text-subtle" aria-hidden="true" />
        <p className="sr-only">{copy.disabled}</p>
      </div>
    );
  }

  const label =
    phase === "listening"
      ? copy.listening
      : phase === "user_speaking"
        ? copy.user_speaking
        : phase === "thinking"
          ? copy.thinking
          : phase === "speaking"
            ? copy.speaking
            : phase === "interrupted"
              ? copy.interrupted
              : phase === "permission"
                ? copy.permission
                : phase === "error"
                  ? errorDetail || copy.error
                  : sessionOn
                    ? copy.listening
                    : copy.idle;

  const spokenVisible = (streamingText || lastAssistant?.content || "").trim();
  const lastClause =
    spokenVisible
      .split(/(?<=[.!?؟])\s+/)
      .filter(Boolean)
      .at(-1) ?? spokenVisible;
  const caption =
    phase === "listening"
      ? copy.listening
      : phase === "user_speaking"
        ? interim || copy.user_speaking
        : phase === "thinking"
          ? copy.thinking
          : phase === "speaking"
            ? lastClause.slice(0, 220)
            : phase === "interrupted"
              ? copy.interrupted
              : phase === "permission"
                ? copy.permission
                : phase === "error"
                  ? errorDetail || copy.error
                  : label;
  const showDiag = shouldExposeVoiceDiag();

  const compact = (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      className={cn("size-11 shrink-0 rounded-full", phase === "permission" && "text-caution")}
      aria-label={copy.start}
      disabled={disabled}
      data-voice-state={phase}
      data-voice-session="off"
      onClick={() => void startSession()}
    >
      <Mic className="size-5" strokeWidth={1.75} />
    </Button>
  );

  const overlay =
    typeof document === "undefined"
      ? null
      : createPortal(
          <div
            className="fixed inset-0 z-50 flex flex-col bg-bg text-fg"
            data-voice-mode="on"
            data-voice-state={phase}
            data-voice-session="on"
            role="dialog"
            aria-modal="true"
            aria-label="AEVORA Voice"
          >
            <header className="flex items-center justify-between px-5 pt-[max(1rem,env(safe-area-inset-top))] pb-2">
              <p className="font-display text-xl tracking-tight">AEVORA</p>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-11 rounded-full"
                aria-label={copy.stop}
                onClick={stopSession}
              >
                <X className="size-5" strokeWidth={1.75} />
              </Button>
            </header>
            <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-10 px-6">
              <AegisPresence phase={phase} level={level} />
              <p
                className={cn(
                  "max-w-md text-center font-display text-xl leading-snug tracking-tight",
                  phase === "speaking" || phase === "user_speaking" ? "text-fg" : "text-muted",
                )}
                dir="auto"
                aria-live="polite"
              >
                {caption}
              </p>
            </div>
            <div className="flex flex-col gap-3 px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-2">
              {phase === "permission" || phase === "error" ? (
                <Button type="button" variant="secondary" className="min-h-12 w-full" onClick={() => void startSession()}>
                  {copy.retry}
                </Button>
              ) : (
                <p className="text-center text-xs text-subtle">{label}</p>
              )}
              {showDiag && latencyMarks.originMs != null ? (
                <dl data-voice-latency="1" className="grid gap-x-3 gap-y-0.5 border border-border bg-surface px-3 py-2 text-[11px] leading-4 text-muted">
                  <div className="mb-1 text-[10px] uppercase tracking-[0.14em] text-subtle">Voice diagnostics</div>
                  {formatVoiceGapRows(latencyMarks).map((row) => (
                    <div key={row.id} className="grid grid-cols-[4.5rem_1fr_auto] gap-x-2">
                      <dt className="font-medium text-fg">{row.id}</dt>
                      <dd className="min-w-0 truncate">{row.label}</dd>
                      <dd className="text-right tabular-nums text-fg">{row.value}</dd>
                    </div>
                  ))}
                  {formatVoiceLatencyRows(latencyMarks).map((row) => (
                    <div key={row.id} className="grid grid-cols-[4.5rem_1fr_auto] gap-x-2">
                      <dt className="font-medium text-fg">{row.id}</dt>
                      <dd className="min-w-0 truncate">{row.label}</dd>
                      <dd className="text-right tabular-nums text-fg" data-voice-mark={row.id}>
                        {row.value}
                      </dd>
                    </div>
                  ))}
                  <div className="mt-1 grid grid-cols-[4.5rem_1fr_auto] gap-x-2 text-subtle">
                    <dt>Q</dt>
                    <dd>TTS queue</dd>
                    <dd className="text-right tabular-nums">
                      {queueDepth} / {chunkTotal} chunks
                    </dd>
                  </div>
                </dl>
              ) : null}
            </div>
          </div>,
          document.body,
        );

  return sessionOn ? overlay : compact;
}
