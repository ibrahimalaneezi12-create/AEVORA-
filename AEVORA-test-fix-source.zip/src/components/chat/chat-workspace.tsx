import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { getAiStatus } from "@/lib/ai/chat";
import {
  createConversation,
  getConversation,
  listConversations,
  retryChat,
  sendChatMessage,
  type ChatMessage,
  type Conversation,
  type SendChatResult,
} from "@/lib/chat";
import { sendChatStream } from "@/lib/chat-stream";
import { conversationIdFromHash, workspaceDraftKey, workspaceThreadLink, type ChatWorkspaceId } from "@/lib/chat-workspace";
import { approveProposal, denyProposal } from "@/lib/confirm";
import type { ProposedActionView, RejectedProposalView } from "@/lib/orchestrator/types";
import { ConversationList } from "@/components/chat/conversation-list";
import { ChatThread } from "@/components/chat/thread";
import { cn } from "@/lib/utils";

function conversationIdFromPath(pathname: string): number | null | "invalid" {
  if (pathname === "/app/chat" || pathname === "/app/chat/") return null;
  const match = pathname.match(/^\/app\/chat\/([^/]+)\/?$/);
  if (!match) return null;
  const raw = match[1] ?? "";
  const n = Number.parseInt(raw, 10);
  if (!Number.isInteger(n) || n < 1 || String(n) !== raw) return "invalid";
  return n;
}

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) {
    return "Sign in to talk to AEVORA.";
  }
  if (err instanceof Error && /not found/i.test(err.message)) {
    return "Conversation not found.";
  }
  if (err instanceof Error && err.message) return err.message;
  return "The request did not complete. Try once more.";
}

export function ChatWorkspace({ workspace = "main" }: { workspace?: ChatWorkspaceId }) {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hash = useRouterState({ select: (s) => s.location.hash });
  const selected = workspace === "main" ? conversationIdFromPath(pathname) : conversationIdFromHash(hash);
  const conversationId = typeof selected === "number" ? selected : null;
  const invalid = selected === "invalid";

  const [conversations, setConversations] = useState<Conversation[] | null>(null);
  const [listError, setListError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const [title, setTitle] = useState("New conversation");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [proposals, setProposals] = useState<ProposedActionView[]>([]);
  const [rejected, setRejected] = useState<RejectedProposalView[]>([]);
  const rejectedByConvo = useRef(new Map<number, RejectedProposalView[]>());
  const abortRef = useRef<AbortController | null>(null);
  const [threadLoading, setThreadLoading] = useState(false);
  const [missing, setMissing] = useState(invalid);

  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [available, setAvailable] = useState<boolean | null>(null);
  const [sendError, setSendError] = useState<string | null>(null);
  const [decidingId, setDecidingId] = useState<number | null>(null);
  const [streamStatus, setStreamStatus] = useState<string | null>(null);
  const [firstOutputAt, setFirstOutputAt] = useState<number | null>(null);
  const [orchestratorAt, setOrchestratorAt] = useState<number | null>(null);
  const [reasoningAt, setReasoningAt] = useState<number | null>(null);

  const refreshList = useCallback(() => {
    listConversations({ data: { workspace } })
      .then((rows) => {
        setConversations(rows);
        setListError(null);
      })
      .catch((err) => {
        setListError(errorText(err));
      });
  }, [workspace]);

  useEffect(() => {
    refreshList();
  }, [refreshList]);

  useEffect(() => {
    try {
      const key = workspaceDraftKey(workspace);
      const seeded = sessionStorage.getItem(key);
      if (seeded) sessionStorage.removeItem(key);
      if (!seeded) return;
      setDraft((current) => (current.trim() ? current : seeded));
    } catch {
      /* private mode */
    }
  }, [workspace]);

  useEffect(() => {
    let cancelled = false;
    getAiStatus()
      .then((s) => {
        if (!cancelled) setAvailable(s.available);
      })
      .catch(() => {
        if (!cancelled) setAvailable(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (invalid) {
      setMissing(true);
      setThreadLoading(false);
      setMessages([]);
      setProposals([]);
      setRejected([]);
      setTitle("Not found");
      setSendError(null);
      return;
    }
    if (conversationId === null) {
      setMissing(false);
      setThreadLoading(false);
      setMessages([]);
      setProposals([]);
      setRejected([]);
      setTitle("New conversation");
      setSendError(null);
      return;
    }
    let cancelled = false;
    setThreadLoading(true);
    setMissing(false);
    setSendError(null);
    setMessages([]);
    setProposals([]);
    setRejected([]);
    getConversation({ data: { conversationId, workspace } })
      .then((detail) => {
        if (cancelled) return;
        setTitle(detail.conversation.title);
        setMessages(detail.messages);
        setProposals(detail.proposals);
        setRejected(rejectedByConvo.current.get(conversationId) ?? []);
        setMissing(false);
      })
      .catch((err) => {
        if (cancelled) return;
        setMessages([]);
        setProposals([]);
        setRejected([]);
        setTitle("Not found");
        setMissing(true);
        if (err instanceof Error && /unauthorized/i.test(err.message)) {
          setSendError("Sign in to talk to AEVORA.");
        }
      })
      .finally(() => {
        if (!cancelled) setThreadLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [conversationId, invalid, workspace]);

  const last = messages[messages.length - 1];
  const canRetry =
    Boolean(conversationId) &&
    last?.role === "user" &&
    !busy &&
    available !== false &&
    !missing;

  async function onNew() {
    if (creating) return;
    setCreating(true);
    try {
      const created = await createConversation({ data: { workspace } });
      setConversations((prev) =>
        prev ? [created, ...prev.filter((c) => c.id !== created.id)] : [created],
      );
      await navigate(workspaceThreadLink(workspace, created.id));
    } catch (err) {
      setListError(errorText(err));
    } finally {
      setCreating(false);
    }
  }

  async function send(text: string, source: "typed" | "voice" = "typed") {
    const prompt = text.trim();
    if (!prompt || available === false || missing) return;
    if (busy && source === "typed") return;
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;
    setDraft("");
    setBusy(true);
    setSendError(null);
    setStreamStatus(null);
    setFirstOutputAt(null);
    setOrchestratorAt(null);
    setReasoningAt(null);
    const tempId = -Date.now();
    setMessages((prev) => [
      ...prev,
      {
        id: tempId,
        conversationId: conversationId ?? 0,
        role: "user",
        content: prompt,
        createdAt: new Date().toISOString(),
      },
    ]);
    const streamId = tempId - 1;
    let streamed = "";

    const applyResult = async (result: SendChatResult) => {
      if (result.ok) {
        setMessages((prev) => {
          const rest = prev.filter(
            (m) =>
              m.id !== tempId &&
              m.id !== streamId &&
              m.id !== result.userMessage.id &&
              m.id !== result.assistantMessage.id,
          );
          return [...rest, result.userMessage, result.assistantMessage];
        });
        setTitle(result.conversation.title);
        setProposals(result.proposals);
        setRejected(result.rejected);
        rejectedByConvo.current.set(result.conversation.id, result.rejected);
        setConversations((prev) => {
          const others = (prev ?? []).filter((c) => c.id !== result.conversation.id);
          return [result.conversation, ...others];
        });
        if (conversationId == null) {
          await navigate(workspaceThreadLink(workspace, result.conversation.id));
        }
      } else {
        if (result.unavailable) setAvailable(false);
        if (result.userMessage) {
          setMessages((prev) =>
            prev
              .filter((m) => m.id !== streamId)
              .map((m) => (m.id === tempId ? result.userMessage! : m)),
          );
          if (result.conversation) {
            setTitle(result.conversation.title);
            setConversations((prev) => {
              const others = (prev ?? []).filter((c) => c.id !== result.conversation!.id);
              return [result.conversation!, ...others];
            });
            if (conversationId == null) {
              await navigate(workspaceThreadLink(workspace, result.conversation.id));
            }
          }
        } else {
          setMessages((prev) => prev.filter((m) => m.id !== tempId && m.id !== streamId));
          setDraft(prompt);
        }
        setSendError(result.error);
      }
    };

    try {
      let result: SendChatResult;
      try {
        result = await sendChatStream(prompt, conversationId ?? undefined, {
          onDelta: (piece) => {
            if (ac.signal.aborted) return;
            if (!streamed) setFirstOutputAt(Date.now());
            streamed += piece;
            setMessages((prev) => {
              const rest = prev.filter((m) => m.id !== streamId);
              return [
                ...rest,
                {
                  id: streamId,
                  conversationId: conversationId ?? 0,
                  role: "assistant",
                  content: streamed,
                  createdAt: new Date().toISOString(),
                },
              ];
            });
          },
          onStatus: (text) => {
            if (ac.signal.aborted) return;
            setReasoningAt((prev) => prev ?? Date.now());
            setStreamStatus(text);
          },
          onMeta: () => {
            if (ac.signal.aborted) return;
            setOrchestratorAt((prev) => prev ?? Date.now());
            setReasoningAt((prev) => prev ?? Date.now());
          },
        }, ac.signal, workspace);
      } catch (err) {
        if (ac.signal.aborted || (err instanceof DOMException && err.name === "AbortError") || (err instanceof Error && err.name === "AbortError")) {
          return;
        }
        result = await sendChatMessage({
          data: {
            content: prompt,
            conversationId: conversationId ?? undefined,
            workspace,
          },
        });
      }
      if (ac.signal.aborted) return;
      await applyResult(result);
    } catch (err) {
      if (ac.signal.aborted || (err instanceof Error && err.name === "AbortError")) return;
      setMessages((prev) => prev.filter((m) => m.id !== tempId && m.id !== streamId));
      setDraft(prompt);
      setSendError(errorText(err));
    } finally {
      if (abortRef.current === ac) {
        setBusy(false);
        setStreamStatus(null);
      }
    }
  }

  async function onRetry() {
    if (!conversationId || busy) return;
    setBusy(true);
    setSendError(null);
    try {
      const result = await retryChat({ data: { conversationId, workspace } });
      if (result.ok) {
        setMessages((prev) => {
          if (prev.some((m) => m.id === result.assistantMessage.id)) return prev;
          return [...prev, result.assistantMessage];
        });
        setTitle(result.conversation.title);
        refreshList();
        setProposals(result.proposals);
        setRejected(result.rejected);
        rejectedByConvo.current.set(result.conversation.id, result.rejected);
      } else {
        if (result.unavailable) setAvailable(false);
        setSendError(result.error);
      }
    } catch (err) {
      setSendError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  async function onDecide(id: number, kind: "approve" | "deny") {
    if (decidingId) return;
    setDecidingId(id);
    setSendError(null);
    try {
      const next =
        kind === "approve"
          ? await approveProposal({ data: { id } })
          : await denyProposal({ data: { id } });
      setProposals((prev) =>
        prev.map((row) => (row.id === next.id ? { ...row, status: next.status } : row)),
      );
    } catch (err) {
      setSendError(errorText(err));
    } finally {
      setDecidingId(null);
    }
  }

  const showList = conversationId === null && !invalid;
  const showThread = conversationId !== null || invalid;

  return (
    <div className="flex min-h-0 flex-1">
      <div className={cn("min-h-0", showList ? "flex w-full md:w-auto" : "hidden md:flex")}>
        <ConversationList
          conversations={conversations}
          selectedId={conversationId}
          loading={conversations === null && !listError}
          error={listError}
          creating={creating}
          onNew={() => void onNew()}
          workspace={workspace}
        />
      </div>
      <div
        className={cn(
          "min-h-0 min-w-0 flex-1",
          showThread ? "flex" : "hidden md:flex",
        )}
      >
        <ChatThread
          title={title}
          messages={messages}
          proposals={proposals}
          rejected={rejected}
          decidingId={decidingId}
          onApprove={(id) => void onDecide(id, "approve")}
          onDeny={(id) => void onDecide(id, "deny")}
          loading={Boolean(conversationId) && threadLoading}
          missing={invalid || (missing && conversationId !== null)}
          draft={draft}
          onDraftChange={setDraft}
          busy={busy}
          available={available}
          sendError={sendError}
          canRetry={canRetry}
          onSend={(text) => void send(text, "voice")}
          onInterrupt={() => abortRef.current?.abort()}
          onRetry={() => void onRetry()}
          streamStatus={streamStatus}
          firstOutputAt={firstOutputAt}
          orchestratorAt={orchestratorAt}
          reasoningAt={reasoningAt}
          workspace={workspace}
        />
      </div>
    </div>
  );
}
