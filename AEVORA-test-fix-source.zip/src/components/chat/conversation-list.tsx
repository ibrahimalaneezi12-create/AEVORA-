import { Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import type { Conversation } from "@/lib/chat";
import type { ChatWorkspaceId } from "@/lib/chat-workspace";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function relativeTime(iso: string): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return "";
  const s = Math.round((Date.now() - t) / 1000);
  if (s < 45) return "Just now";
  if (s < 3600) return `${Math.max(1, Math.round(s / 60))}m`;
  if (s < 86400) return `${Math.max(1, Math.round(s / 3600))}h`;
  const d = Math.round(s / 86400);
  if (d < 7) return `${d}d`;
  return new Date(t).toLocaleDateString();
}

export function ConversationList({
  conversations,
  selectedId,
  loading,
  error,
  creating,
  onNew,
  workspace = "main",
}: {
  conversations: Conversation[] | null;
  selectedId: number | null;
  loading: boolean;
  error: string | null;
  creating: boolean;
  onNew: () => void;
  workspace?: ChatWorkspaceId;
}) {
  const heading = workspace === "business" ? "Business chat" : workspace === "invest" ? "Invest chat" : "Main chat";
  const empty =
    workspace === "main"
      ? "No conversations yet. Start one — it stays in your keep."
      : "No conversations in this workspace yet. They stay separate from personal chat.";
  return (
    <aside className="flex h-full min-h-0 w-full flex-col bg-bg md:w-72 md:shrink-0">
      <div className="flex items-center justify-between gap-2 px-4 py-5">
        <div className="min-w-0">
          {workspace !== "main" ? (
            <Link
              to={workspace === "business" ? "/app/business" : "/app/invest"}
              hash=""
              className="text-xs text-muted hover:text-fg"
            >
              {workspace === "business" ? "Business" : "Invest"}
            </Link>
          ) : null}
          <h1 className="font-display text-2xl tracking-tight text-fg">{heading}</h1>
        </div>
        <Button
          type="button"
          variant="secondary"
          onClick={onNew}
          disabled={creating}
          aria-label="New conversation"
          className="h-11 min-h-11 shrink-0 px-4"
        >
          <Plus className="size-4" strokeWidth={1.75} />
          New
        </Button>
      </div>
      <nav aria-label="Conversations" className="min-h-0 flex-1 overflow-y-auto p-2">
        {error ? (
          <p className="px-2 py-3 text-sm text-danger" role="alert">
            {error}
          </p>
        ) : loading || conversations === null ? (
          <div className="space-y-2" aria-hidden="true">
            <div className="h-11 animate-pulse rounded-md bg-surface" />
            <div className="h-11 animate-pulse rounded-md bg-surface" />
            <div className="h-11 animate-pulse rounded-md bg-surface" />
          </div>
        ) : conversations.length === 0 ? (
          <div className="px-2 py-6">
            <p className="text-sm leading-relaxed text-muted">{empty}</p>
            <Button
              type="button"
              className="mt-4 w-full"
              onClick={onNew}
              disabled={creating}
            >
              New conversation
            </Button>
          </div>
        ) : (
          <ul className="flex flex-col gap-0.5">
            {conversations.map((item) => {
              const selected = item.id === selectedId;
              return (
                <li key={item.id}>
                  {workspace === "main" ? (
                    <Link
                      to="/app/chat/$id"
                      params={{ id: String(item.id) }}
                      aria-current={selected ? "page" : undefined}
                      className={cn(
                        "flex min-h-11 items-center justify-between gap-2 rounded-sm px-3 py-2 text-sm transition-colors duration-150",
                        selected
                          ? "bg-surface-2 text-fg"
                          : "text-muted hover:bg-surface hover:text-fg",
                      )}
                    >
                      <span className="min-w-0 flex-1 truncate">{item.title}</span>
                      <span className="shrink-0 text-xs text-subtle">{relativeTime(item.updatedAt)}</span>
                    </Link>
                  ) : (
                    <Link
                      to={workspace === "business" ? "/app/business" : "/app/invest"}
                      hash={`chat/${item.id}`}
                      aria-current={selected ? "page" : undefined}
                      className={cn(
                        "flex min-h-11 items-center justify-between gap-2 rounded-sm px-3 py-2 text-sm transition-colors duration-150",
                        selected
                          ? "bg-surface-2 text-fg"
                          : "text-muted hover:bg-surface hover:text-fg",
                      )}
                    >
                      <span className="min-w-0 flex-1 truncate">{item.title}</span>
                      <span className="shrink-0 text-xs text-subtle">{relativeTime(item.updatedAt)}</span>
                    </Link>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </nav>
    </aside>
  );
}
