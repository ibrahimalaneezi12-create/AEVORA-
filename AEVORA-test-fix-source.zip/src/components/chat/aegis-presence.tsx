import { cn } from "@/lib/utils";
import type { VoiceState } from "@/lib/voice-format";

export function AegisPresence({
  phase,
  level,
}: {
  phase: VoiceState;
  level: number;
}) {
  const energy = Math.min(1, Math.max(0, level * 4));
  const live =
    phase === "listening" ||
    phase === "user_speaking" ||
    phase === "speaking";
  const scale = live ? 1 + energy * 0.12 : 1;
  const ring =
    phase === "user_speaking"
      ? "stroke-fg"
      : phase === "speaking"
        ? "stroke-fg/90"
        : phase === "thinking"
          ? "stroke-accent"
          : phase === "interrupted"
            ? "stroke-caution"
            : phase === "error" || phase === "permission"
              ? "stroke-caution"
              : "stroke-fg/35";

  return (
    <div
      className="relative grid size-48 place-items-center sm:size-56"
      data-aegis-presence={phase}
      data-voice-level={level.toFixed(3)}
      aria-hidden="true"
    >
      <svg
        viewBox="0 0 120 120"
        className={cn(
          "size-full origin-center transition-transform duration-75 ease-out",
          phase === "thinking" && "aegis-breathe",
        )}
        style={live ? { transform: `scale(${scale})` } : undefined}
      >
        <path
          d="M60 14 L98 32 V62 C98 86 78 102 60 108 C42 102 22 86 22 62 V32 Z"
          className={cn("fill-none", ring)}
          strokeWidth="1.4"
          strokeLinejoin="round"
        />
        <path
          d="M60 14 L98 32 V62 C98 86 78 102 60 108 C42 102 22 86 22 62 V32 Z"
          className="fill-fg/5"
        />
        <path
          d="M60 38 V78"
          className={cn(
            "stroke-fg",
            phase === "thinking" && "stroke-accent",
            phase === "interrupted" && "stroke-caution",
          )}
          strokeWidth="2"
          strokeLinecap="round"
        />
        <circle
          cx="60"
          cy="60"
          r={18 + energy * 10}
          className={cn("fill-none stroke-fg/15", phase === "speaking" && "stroke-fg/25")}
          strokeWidth="0.8"
        />
      </svg>
    </div>
  );
}
