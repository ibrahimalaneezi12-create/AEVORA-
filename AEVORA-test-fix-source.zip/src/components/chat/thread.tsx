import { useEffect, useRef, type FormEvent, type KeyboardEvent } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowUp, ChevronLeft, LoaderCircle } from "lucide-react";
import type { ChatMessage } from "@/lib/chat";
import { CHAT_MESSAGE_MAX } from "@/lib/chat";
import { workspaceChatHash, workspaceChatPath, type ChatWorkspaceId } from "@/lib/chat-workspace";
import type { ProposedActionView, RejectedProposalView } from "@/lib/orchestrator/types";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ProposalCard, RestrictedNotice } from "@/components/chat/proposal-card";
import { VoiceDock } from "@/components/chat/voice-dock";
import { cn } from "@/lib/utils";

export function ChatThread({
  title,
  messages,
  proposals,
  rejected,
  decidingId,
  onApprove,
  onDeny,
  loading,
  missing,
  draft,
  onDraftChange,
  busy,
  available,
  sendError,
  canRetry,
  onSend,
  onRetry,
  onInterrupt,
  streamStatus,
  firstOutputAt,
  orchestratorAt,
  reasoningAt,
  workspace = "main",
}: {
  title: string;
  messages: ChatMessage[];
  proposals: ProposedActionView[];
  rejected: RejectedProposalView[];
  decidingId: number | null;
  onApprove: (id: number) => void;
  onDeny: (id: number) => void;
  loading: boolean;
  missing: boolean;
  draft: string;
  onDraftChange: (value: string) => void;
  busy: boolean;
  available: boolean | null;
  sendError: string | null;
  canRetry: boolean;
  onSend: (text: string) => void;
  onRetry: () => void;
  onInterrupt?: () => void;
  streamStatus?: string | null;
  firstOutputAt?: number | null;
  orchestratorAt?: number | null;
  reasoningAt?: number | null;
  workspace?: ChatWorkspaceId;
}) {
  const bottomRef = useRef<HTMLDivElement>(null);
  const areaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages, proposals, busy, sendError]);

  useEffect(() => {
    if (!loading && !missing) areaRef.current?.focus();
  }, [loading, missing, title]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    onSend(draft);
  }

  function onKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      onSend(draft);
    }
  }

  const canSend = draft.trim().length > 0 && !busy && available !== false && !missing;

  return (
    <section className="flex min-h-0 min-w-0 flex-1 flex-col bg-bg">
      <header className="flex items-center gap-3 px-3 py-4 md:px-6">
        <Link
          to={workspaceChatPath(workspace)}
          hash={workspaceChatHash(workspace)}
          aria-label="Back to conversations"
          className="grid size-11 shrink-0 place-items-center rounded-full text-muted hover:bg-surface hover:text-fg md:hidden"
        >
          <ChevronLeft className="size-5" strokeWidth={1.75} />
        </Link>
        <div className="min-w-0 flex-1">
          <p className="truncate font-display text-lg tracking-tight text-fg">{title}</p>
        </div>
        <StatusChip available={available} />
      </header>

      <div
        className="min-h-0 flex-1 space-y-7 overflow-y-auto px-5 py-4 md:px-8"
        aria-live="polite"
      >
        {missing ? (
          <p className="text-sm leading-relaxed text-muted" role="alert">
            This conversation was not found.
          </p>
        ) : loading ? (
          <div className="space-y-3" aria-hidden="true">
            <div className="h-16 max-w-sm animate-pulse rounded-md bg-surface" />
            <div className="ml-auto h-12 max-w-xs animate-pulse rounded-md bg-surface" />
            <div className="h-20 max-w-md animate-pulse rounded-md bg-surface" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex h-full min-h-[16rem] flex-col justify-end gap-3 pb-8">
            <p className="font-display text-4xl tracking-tight text-fg">AEVORA</p>
            <p className="max-w-md font-display text-2xl tracking-tight text-fg/90">
              {dayGreeting()}
            </p>
            <p className="max-w-sm text-base leading-relaxed text-muted">
              Ask anything. I will not act unless you confirm.
            </p>
          </div>
        ) : (
          messages.map((line) => <ChatLine key={line.id} line={line} />)
        )}
        {proposals.length > 0 || rejected.length > 0 ? (
          <div className="flex flex-col gap-3" aria-label="Proposed actions">
            {proposals.map((proposal) => (
              <ProposalCard
                key={proposal.id}
                proposal={proposal}
                deciding={decidingId === proposal.id}
                onApprove={onApprove}
                onDeny={onDeny}
              />
            ))}
            {rejected.map((item, index) => (
              <RestrictedNotice key={`${item.toolId}-${index}`} item={item} />
            ))}
          </div>
        ) : null}
        {busy && messages.at(-1)?.role !== "assistant" ? (
          <p className="flex items-center gap-2 text-sm text-muted">
            <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
            {statusLabel(streamStatus)}
          </p>
        ) : null}
        {sendError ? (
          <p className="max-w-md text-sm leading-relaxed text-caution" role="alert">
            {sendError}
          </p>
        ) : null}
        {canRetry ? (
          <div className="max-w-md">
            <Button
              type="button"
              variant="secondary"
              size="sm"
              disabled={busy}
              onClick={onRetry}
            >
              Try again
            </Button>
          </div>
        ) : null}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={onSubmit}
        className="px-3 pb-[max(0.85rem,env(safe-area-inset-bottom))] pt-1 md:px-6"
      >
        <div className="composer-shell flex items-end gap-1 rounded-full px-1.5 py-1.5">
          <VoiceDock
            disabled={available === false || missing}
            busy={busy}
            lastAssistant={
              [...messages].reverse().find((m) => m.role === "assistant" && m.id > 0) ?? null
            }
            streamingText={
              busy
                ? ([...messages].reverse().find((m) => m.role === "assistant" && m.id < 0)?.content ?? "")
                : ""
            }
            onSend={onSend}
            onInterrupt={onInterrupt}
            firstOutputAt={firstOutputAt}
            orchestratorAt={orchestratorAt}
            reasoningAt={reasoningAt}
          />
          <Textarea
            ref={areaRef}
            value={draft}
            onChange={(e) => onDraftChange(e.target.value)}
            onKeyDown={onKeyDown}
            disabled={busy || available === false || missing}
            maxLength={CHAT_MESSAGE_MAX}
            rows={1}
            placeholder={
              available === false
                ? "Grok is not connected"
                : missing
                  ? "This conversation was not found"
                  : "Message AEVORA"
            }
            aria-label="Message"
            className="min-h-11 flex-1 border-0 bg-transparent px-2 py-2 shadow-none ring-0 focus-visible:ring-0"
          />
          <Button
            type="submit"
            size="icon"
            disabled={!canSend}
            aria-label="Send"
            className="shrink-0 rounded-full"
          >
            <ArrowUp className="size-4" strokeWidth={2} />
          </Button>
        </div>
      </form>
    </section>
  );
}

function dayGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 5 || hour >= 18) return "Good evening.";
  if (hour < 12) return "Good morning.";
  return "Good afternoon.";
}

function StatusChip({ available }: { available: boolean | null }) {
  const label =
    available === null ? "Checking" : available ? "Ready" : "Unavailable";
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-muted">
      <span
        className={cn(
          "size-1.5 rounded-full",
          available === null && "bg-muted",
          available === true && "bg-accent",
          available === false && "bg-danger",
        )}
        aria-hidden="true"
      />
      {label}
    </span>
  );
}

function statusLabel(status?: string | null): string {
  if (status === "searching") return "Searching";
  if (status === "researching") return "Researching";
  return "Thinking";
}

function splitSpeechSources(content: string): { speech: string; sources: string[] } {
  const match = content.match(/\n\nSources:\n([\s\S]+)$/i);
  if (!match || match.index == null) return { speech: content, sources: [] };
  const speech = content.slice(0, match.index).trimEnd();
  const sources = [...match[1].matchAll(/https?:\/\/[^\s)]+/gi)].map((row) =>
    row[0].replace(/[.,;]+$/, ""),
  );
  return { speech, sources: [...new Set(sources)] };
}

function ChatLine({ line }: { line: ChatMessage }) {
  if (line.role === "user") {
    return (
      <div className="flex justify-end">
        <p
          dir="auto"
          className="max-w-[min(78%,32rem)] text-[15px] leading-relaxed whitespace-pre-wrap break-words text-muted"
        >
          {line.content}
        </p>
      </div>
    );
  }
  const { speech, sources } = splitSpeechSources(line.content);
  return (
    <div className="max-w-[42rem]">
      <p dir="auto" className="prose-aegis whitespace-pre-wrap break-words text-fg">
        {speech}
      </p>
      {sources.length > 0 ? (
        <ul className="mt-3 flex flex-col gap-1" aria-label="Sources">
          {sources.map((url, index) => (
            <li key={url} className="truncate text-xs">
              <a
                href={url}
                target="_blank"
                rel="noreferrer"
                className="text-muted underline-offset-4 hover:text-fg hover:underline"
              >
                {index + 1}. {url.replace(/^https?:\/\//i, "")}
              </a>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

