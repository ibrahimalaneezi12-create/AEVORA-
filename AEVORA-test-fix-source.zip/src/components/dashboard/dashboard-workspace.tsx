import { useCallback, useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { getDashboard, type DashboardSnapshot } from "@/lib/dashboard";
import { getDailyBriefing, type DailyBriefing } from "@/lib/plan";
import { getPulse, type PulseSnapshot } from "@/lib/pulse";
import { workspaceChatHref } from "@/lib/chat-workspace";
import { Button } from "@/components/ui/button";
import { AegisMark } from "@/components/brand/aegis-mark";

function greetingLine(name: string | null | undefined): string {
  const hour = new Date().getHours();
  const part = hour < 5 || hour >= 18 ? "Good evening" : hour < 12 ? "Good morning" : "Good afternoon";
  const who = (name ?? "").trim();
  return who ? `${part}, ${who}.` : `${part}.`;
}

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) {
    return "Sign in to see AEVORA.";
  }
  return "AEVORA could not load. Try once more.";
}

type Cue = {
  text: string;
  href: string;
};

function cuesFor(
  snap: DashboardSnapshot,
  brief: DailyBriefing | null,
  pulse: PulseSnapshot | null,
): Cue[] {
  const cues: Cue[] = [];
  if (snap.pending[0]) {
    cues.push({
      text:
        snap.pendingTotal === 1
          ? `${snap.pending[0].title} is waiting for you.`
          : `${snap.pendingTotal} things are waiting for your say.`,
      href: `/app/approvals/${snap.pending[0].id}`,
    });
  }
  const reminder = brief?.reminders[0];
  if (reminder) {
    cues.push({
      text: `I’ll remind you: ${reminder.title}`,
      href: "/app/reminders",
    });
  }
  if (snap.todaysTasks[0]) {
    cues.push({
      text: `Today: ${snap.todaysTasks[0].title}`,
      href: "/app/goals",
    });
  } else if (snap.activeGoals[0]) {
    cues.push({
      text: `Still working on ${snap.activeGoals[0].title}.`,
      href: "/app/goals",
    });
  }
  if (pulse?.enabled && !pulse.quiet && pulse.suggestions[0]) {
    cues.push({
      text: pulse.suggestions[0].title,
      href: "/app/chat",
    });
  }
  if (snap.lastConversation) {
    cues.push({
      text: `Continue ${snap.lastConversation.title}`,
      href: workspaceChatHref(snap.lastConversation.workspace ?? "main", snap.lastConversation.id),
    });
  }
  if (snap.recentMemories[0]) {
    cues.push({
      text: `I remember ${snap.recentMemories[0].title}.`,
      href: "/app/memory",
    });
  }
  return cues.slice(0, 3);
}

export function DashboardWorkspace() {
  const [snap, setSnap] = useState<DashboardSnapshot | null>(null);
  const [brief, setBrief] = useState<DailyBriefing | null>(null);
  const [pulse, setPulse] = useState<PulseSnapshot | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const refresh = useCallback(() => {
    getDashboard()
      .then((page) => {
        setSnap(page);
        setLoadError(null);
      })
      .catch((err) => {
        setLoadError(errorText(err));
      });
    getDailyBriefing()
      .then(setBrief)
      .catch(() => setBrief(null));
    getPulse()
      .then(setPulse)
      .catch(() => setPulse(null));
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const loaded = snap !== null;
  const cues = loaded ? cuesFor(snap, brief, pulse) : [];

  return (
    <main className="mx-auto flex w-full max-w-xl min-h-0 flex-1 flex-col justify-center overflow-y-auto px-6 py-12 md:px-8">
      <AegisMark className="size-12" />
      <h1 className="font-display mt-8 text-4xl leading-[1.08] tracking-tight md:text-5xl">
        {greetingLine(snap?.greetingName)}
      </h1>
      <p className="mt-4 max-w-sm text-xl leading-relaxed text-muted">What can I help you with?</p>

      <div className="mt-10 flex flex-col gap-3 sm:flex-row">
        <Button asChild className="h-14 min-h-14 flex-1 px-8 text-base">
          <Link
            to="/app/chat"
            onClick={() => {
              try {
                sessionStorage.setItem("aegis-start-voice", "1");
              } catch {
                /* private mode */
              }
            }}
          >
            Talk
          </Link>
        </Button>
        <Button asChild variant="secondary" className="h-14 min-h-14 flex-1 px-8 text-base">
          <Link to="/app/chat">Type</Link>
        </Button>
      </div>
      <p className="mt-6 flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted">
        <Link to="/app/create" className="underline-offset-4 hover:text-fg hover:underline">
          Create something
        </Link>
        <Link to="/app/memory" className="underline-offset-4 hover:text-fg hover:underline md:hidden">
          Memory
        </Link>
        <Link to="/app/goals" className="underline-offset-4 hover:text-fg hover:underline md:hidden">
          Plans
        </Link>
      </p>

      {loadError ? (
        <div className="mt-10 flex flex-col gap-3">
          <p className="text-sm text-danger" role="alert">
            {loadError}
          </p>
          <Button type="button" variant="secondary" onClick={refresh}>
            Try again
          </Button>
        </div>
      ) : null}

      {!loaded && !loadError ? (
        <div className="mt-12 h-12 w-48 animate-pulse bg-surface/70" aria-hidden="true" />
      ) : null}

      {loaded && cues.length > 0 ? (
        <ul className="mt-16 flex max-w-md flex-col gap-3" aria-label="Worth knowing">
          {cues.slice(0, 2).map((cue) => (
            <li key={cue.text}>
              <a href={cue.href} className="text-[15px] leading-relaxed text-muted hover:text-fg">
                {cue.text}
              </a>
            </li>
          ))}
        </ul>
      ) : null}
    </main>
  );
}
