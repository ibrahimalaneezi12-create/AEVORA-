import { Link } from "@tanstack/react-router";
import { Sun } from "lucide-react";
import type { DailyBriefing } from "@/lib/plan";
import { Button } from "@/components/ui/button";

export function BriefingPanel({ brief }: { brief: DailyBriefing | null }) {
  if (!brief) {
    return (
      <section aria-label="Daily briefing" className="border-t border-border py-6">
        <div className="flex items-center gap-2 text-muted">
          <Sun className="size-4" strokeWidth={1.75} />
          <p className="text-sm font-medium text-fg">Daily briefing</p>
        </div>
        <p className="mt-3 text-sm text-muted">Loading your actual keep…</p>
      </section>
    );
  }

  const empty = brief.empty;
  return (
    <section
      aria-label="Daily briefing"
      data-briefing="true"
      data-briefing-empty={empty ? "true" : "false"}
      className="border-t border-border py-6"
    >
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Sun className="size-4 text-muted" strokeWidth={1.75} />
          <p className="text-sm font-medium text-fg">Daily briefing</p>
        </div>
        <p className="text-xs text-muted">{brief.today}</p>
      </div>
      {empty ? (
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted">
          Nothing is due today. No reminders, deadlines, or stalled goals in
          the keep. Nothing here was invented.
        </p>
      ) : (
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <BriefList title="Today" items={brief.tasks.map((t) => `#${t.id} ${t.title} (${t.detail})`)} />
          <BriefList title="Reminders" items={brief.reminders.map((r) => `#${r.id} ${r.title}`)} />
          <BriefList title="Upcoming" items={brief.deadlines.map((d) => `#${d.id} ${d.title} ${d.detail}`)} />
          <BriefList title="Follow-ups" items={brief.followUps} />
        </div>
      )}
      {brief.conflicts.length > 0 ? (
        <p className="mt-3 text-xs text-caution">{brief.conflicts.join(" ")}</p>
      ) : null}
      {brief.suggestedPriorities.length > 0 ? (
        <p className="mt-3 text-sm text-fg">Focus: {brief.suggestedPriorities.join(" · ")}</p>
      ) : null}
      <div className="mt-4">
        <Button asChild variant="secondary" size="sm">
          <Link to="/app/chat">Ask AEVORA to plan the day</Link>
        </Button>
      </div>
    </section>
  );
}

function BriefList({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <p className="text-xs font-medium tracking-wide text-muted uppercase">{title}</p>
      {items.length === 0 ? (
        <p className="mt-1 text-xs text-subtle">None</p>
      ) : (
        <ul className="mt-1 space-y-1">
          {items.slice(0, 4).map((line) => (
            <li key={line} className="text-sm text-fg/90">
              {line}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
