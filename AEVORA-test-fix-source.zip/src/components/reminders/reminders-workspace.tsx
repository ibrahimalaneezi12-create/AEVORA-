import { useCallback, useEffect, useState, type FormEvent } from "react";
import { Bell } from "lucide-react";
import {
  cancelReminder,
  completeReminder,
  createReminder,
  listReminders,
  snoozeReminder,
  type Reminder,
} from "@/lib/reminders";
import { requestNotificationPermission } from "@/lib/notify-permission";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) {
    return "Sign in to see reminders.";
  }
  if (err instanceof Error && err.message) return err.message;
  return "Reminders could not be loaded. Try once more.";
}

function defaultWhen(): { date: string; time: string } {
  const at = new Date(Date.now() + 60 * 60 * 1000);
  const date = `${at.getFullYear()}-${String(at.getMonth() + 1).padStart(2, "0")}-${String(at.getDate()).padStart(2, "0")}`;
  const time = `${String(at.getHours()).padStart(2, "0")}:${String(at.getMinutes()).padStart(2, "0")}`;
  return { date, time };
}

function whenLabel(row: Reminder): string {
  const t = Date.parse(row.fireAt);
  if (Number.isNaN(t)) return row.fireAt;
  return new Date(t).toLocaleString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function RemindersWorkspace() {
  const [rows, setRows] = useState<Reminder[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [notify, setNotify] = useState<"default" | "granted" | "denied">("default");
  const defaults = defaultWhen();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [localDate, setLocalDate] = useState(defaults.date);
  const [localTime, setLocalTime] = useState(defaults.time);
  const [recurrence, setRecurrence] = useState<"once" | "daily" | "weekly" | "weekdays">("once");
  const [saving, setSaving] = useState(false);

  const refresh = useCallback(() => {
    listReminders()
      .then((list) => {
        setRows(list);
        setError(null);
      })
      .catch((err) => setError(errorText(err)));
  }, []);

  useEffect(() => {
    refresh();
    if (typeof Notification !== "undefined") {
      setNotify(Notification.permission === "granted" ? "granted" : Notification.permission === "denied" ? "denied" : "default");
    }
  }, [refresh]);

  async function act(id: number, fn: () => Promise<unknown>) {
    if (busyId) return;
    setBusyId(id);
    setError(null);
    try {
      await fn();
      refresh();
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusyId(null);
    }
  }

  async function onCreate(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    setError(null);
    try {
      await createReminder({
        data: {
          title,
          body,
          localDate,
          localTime,
          recurrence,
        },
      });
      setTitle("");
      setBody("");
      refresh();
    } catch (err) {
      setError(errorText(err));
    } finally {
      setSaving(false);
    }
  }

  const list = rows ?? [];
  const active = list.filter((r) => r.status === "scheduled" || r.status === "snoozed" || r.status === "pending_delivery");

  return (
    <main className="mx-auto w-full max-w-3xl min-h-0 flex-1 overflow-y-auto px-5 py-10 md:px-8">
      <p className="text-sm font-medium text-accent">Reminders</p>
      <h1 className="font-display mt-2 text-3xl tracking-tight">I’ll remember this</h1>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
        Real times, in your timezone. Create one here, or ask in chat and
        confirm. Notifications fire on this device when permission is granted
        and the keep is open. Closed-tab delivery needs a push subscription
        and is not claimed until then.
      </p>

      <div className="mt-6 flex flex-wrap gap-2">
        <Button
          type="button"
          variant="secondary"
          size="sm"
          disabled={notify === "granted"}
          onClick={() => {
            void requestNotificationPermission().then(setNotify);
          }}
        >
          {notify === "granted" ? "Notifications on" : "Allow notifications"}
        </Button>
        <p className="self-center text-xs text-muted" data-notify-permission={notify}>
          {notify === "denied"
            ? "This browser blocked notifications. Reminders still appear here."
            : notify === "granted"
              ? "This device can show reminder alerts."
              : "Alerts need permission. Delivery is still recorded in-app."}
        </p>
      </div>

      {error ? (
        <p className="mt-6 text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}

      <form
        onSubmit={(e) => void onCreate(e)}
        className="mt-8 space-y-4 rounded-lg border border-border bg-surface p-4"
        aria-labelledby="new-reminder-heading"
      >
        <h2 id="new-reminder-heading" className="text-sm font-medium text-fg">
          New reminder
        </h2>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="md:col-span-2">
            <Label htmlFor="reminder-title">Title</Label>
            <Input
              id="reminder-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              maxLength={80}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="reminder-date">Date</Label>
            <Input
              id="reminder-date"
              type="date"
              value={localDate}
              onChange={(e) => setLocalDate(e.target.value)}
              required
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="reminder-time">Time</Label>
            <Input
              id="reminder-time"
              type="time"
              value={localTime}
              onChange={(e) => setLocalTime(e.target.value)}
              required
              className="mt-1"
            />
          </div>
          <div className="md:col-span-2">
            <Label htmlFor="reminder-body">Note</Label>
            <Input
              id="reminder-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              maxLength={500}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="reminder-repeat">Repeat</Label>
            <select
              id="reminder-repeat"
              value={recurrence}
              onChange={(e) => setRecurrence(e.target.value as typeof recurrence)}
              className="mt-1 h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
            >
              <option value="once">Once</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="weekdays">Weekdays</option>
            </select>
          </div>
        </div>
        <Button type="submit" disabled={saving || title.trim().length === 0}>
          {saving ? "Saving…" : "Save reminder"}
        </Button>
      </form>

      {rows === null && !error ? (
        <div className="mt-8 space-y-3" aria-hidden="true">
          <div className="h-24 animate-pulse rounded-lg bg-surface" />
          <div className="h-24 animate-pulse rounded-lg bg-surface" />
        </div>
      ) : null}

      {rows && active.length === 0 ? (
        <p className="mt-10 max-w-md text-sm leading-relaxed text-muted" data-reminders-empty="true">
          No scheduled reminders. Ask AEVORA: “Remind me tomorrow at 7 to study.”
        </p>
      ) : null}

      <ul className="mt-8 flex flex-col gap-3">
        {active.map((row) => (
          <li
            key={row.id}
            data-reminder-id={row.id}
            className="rounded-lg border border-border bg-surface p-4"
          >
            <div className="flex items-start gap-3">
              <Bell className="mt-0.5 size-4 shrink-0 text-muted" strokeWidth={1.75} />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-fg">{row.title}</p>
                {row.body ? <p className="mt-1 text-xs text-muted">{row.body}</p> : null}
                <p className="mt-1 text-xs text-muted">
                  {whenLabel(row)} · {row.recurrence} · {row.status}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    disabled={busyId === row.id}
                    onClick={() => void act(row.id, () => snoozeReminder({ data: { id: row.id, minutes: 10 } }))}
                  >
                    Snooze 10m
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    disabled={busyId === row.id}
                    onClick={() => void act(row.id, () => completeReminder({ data: { id: row.id } }))}
                  >
                    Done
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className={cn("text-danger")}
                    disabled={busyId === row.id}
                    onClick={() => void act(row.id, () => cancelReminder({ data: { id: row.id } }))}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </main>
  );
}
