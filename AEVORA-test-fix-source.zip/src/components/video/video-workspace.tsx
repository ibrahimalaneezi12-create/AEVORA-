import { useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import {
  cancelVideoRender,
  createVideoProject,
  editVideoProject,
  getVideoCapabilities,
  getVideoProject,
  listVideoJobs,
  listVideoProjects,
  listVideoVersions,
  pollVideoRender,
  saveVideoCaptions,
  startVideoRender,
  type VideoJob,
  type VideoProject,
} from "@/lib/video";
import {
  DEFAULT_STUDIO_CONTROLS,
  SCENE_DURATION_MAX,
  VIDEO_ASPECTS,
  VIDEO_ASPECT_LABELS,
  VIDEO_RESOLUTIONS,
  VIDEO_RESOLUTION_LABELS,
  aspectFrameClass,
  jobStatusCopy,
  publicVideoError,
  type StudioControls,
  type VideoAspect,
  type VideoResolution,
} from "@/lib/video-format";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function errorText(err: unknown): string {
  if (err instanceof Error) return publicVideoError(err.message);
  return publicVideoError(null);
}

export function VideoWorkspace({ onBack }: { onBack: () => void }) {
  const [projects, setProjects] = useState<VideoProject[] | null>(null);
  const [open, setOpen] = useState<VideoProject | null>(null);
  const [jobs, setJobs] = useState<VideoJob[]>([]);
  const [versions, setVersions] = useState<{ id: number; label: string }[]>([]);
  const [brief, setBrief] = useState("");
  const [edit, setEdit] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [available, setAvailable] = useState<boolean | null>(null);
  const [activeJobId, setActiveJobId] = useState<number | null>(null);
  const [advanced, setAdvanced] = useState(false);
  const [controls, setControls] = useState<StudioControls>(DEFAULT_STUDIO_CONTROLS);
  const fileRef = useRef<HTMLInputElement>(null);

  const refreshList = useCallback(() => {
    listVideoProjects()
      .then(setProjects)
      .catch((err) => setError(errorText(err)));
  }, []);

  useEffect(() => {
    refreshList();
    getVideoCapabilities()
      .then((caps) => setAvailable(caps.available))
      .catch(() => setAvailable(false));
  }, [refreshList]);

  useEffect(() => {
    if (!activeJobId) return;
    let cancelled = false;
    const tick = async () => {
      try {
        const result = await pollVideoRender({ data: { id: activeJobId } });
        if (cancelled) return;
        setOpen(result.project);
        setJobs((prev) => prev.map((j) => (j.id === result.job.id ? result.job : j)));
        if (result.job.status === "processing" || result.job.status === "queued") return;
        setActiveJobId(null);
        refreshList();
      } catch (err) {
        if (!cancelled) {
          setError(errorText(err));
          setActiveJobId(null);
        }
      }
    };
    const id = window.setInterval(() => void tick(), 3000);
    void tick();
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [activeJobId, refreshList]);

  async function openProject(id: number) {
    setError(null);
    try {
      const project = await getVideoProject({ data: { id } });
      setOpen(project);
      setBrief(project.brief || project.description);
      setControls({
        aspectRatio: project.aspectRatio,
        resolution: project.resolution,
        durationSec: project.scenes[0]?.durationSec ?? 8,
        generateAudio: project.generateAudio,
      });
      const [jobList, versionList] = await Promise.all([
        listVideoJobs({ data: { id } }),
        listVideoVersions({ data: { id } }),
      ]);
      setJobs(jobList);
      setVersions(versionList);
      const processing = jobList.find((j) => j.status === "processing" || j.status === "queued");
      setActiveJobId(processing?.id ?? null);
    } catch (err) {
      setError(errorText(err));
    }
  }

  async function onGenerate(e?: FormEvent) {
    e?.preventDefault();
    if (busy || !brief.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const project = open
        ? await editVideoProject({
            data: {
              id: open.id,
              instruction: `Use ${controls.aspectRatio}. ${controls.durationSec} seconds. ${controls.generateAudio ? "with audio" : "silent"}. ${controls.resolution}.`,
            },
          })
        : await createVideoProject({
            data: {
              brief,
              imageDataUrl: image ?? undefined,
              aspectRatio: controls.aspectRatio,
              resolution: controls.resolution,
              durationSec: controls.durationSec,
              generateAudio: controls.generateAudio,
            },
          });
      const result = await startVideoRender({
        data: { id: project.id, imageDataUrl: image ?? undefined },
      });
      setOpen(result.project);
      setJobs((prev) => [result.job, ...prev]);
      setActiveJobId(result.job.id);
      refreshList();
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  async function onRefine() {
    if (!open || busy || !edit.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const project = await editVideoProject({ data: { id: open.id, instruction: edit } });
      setOpen(project);
      setEdit("");
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  async function onCancel(jobId: number) {
    try {
      await cancelVideoRender({ data: { id: jobId } });
      setActiveJobId(null);
      if (open) await openProject(open.id);
    } catch (err) {
      setError(errorText(err));
    }
  }

  function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Add a still image to guide the video.");
      return;
    }
    if (file.size > 3_500_000) {
      setError("Keep stills under 3.5 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setImage(typeof reader.result === "string" ? reader.result : null);
    reader.readAsDataURL(file);
  }

  const previewScene = open?.scenes.find((s) => s.hasMedia) ?? open?.scenes[0];
  const liveJob = jobs.find((j) => j.status === "processing" || j.status === "queued") ?? jobs[0];
  const creating = Boolean(activeJobId) || liveJob?.status === "processing" || liveJob?.status === "queued";
  const status = jobStatusCopy(creating ? "processing" : previewScene?.status ?? "draft");

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
      <header className="flex items-center justify-between gap-3 px-5 pt-6 md:px-10">
        <button
          type="button"
          onClick={onBack}
          className="min-h-11 text-sm text-muted transition-colors duration-150 hover:text-fg"
        >
          Studio
        </button>
        <p className="text-sm text-subtle">15s · 1080p max</p>
      </header>

      <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col px-5 pb-16 pt-6 md:px-10 md:pt-10">
        <p className="text-sm font-medium tracking-wide text-accent">Video Studio</p>
        <h1 className="font-display mt-2 text-3xl tracking-tight md:text-5xl">Turn an idea into a scene.</h1>

        {available === false ? (
          <p className="mt-4 text-sm text-caution" role="status">
            Video generation is unavailable right now.
          </p>
        ) : null}

        <div className="mt-10 grid items-start gap-10 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
          <form onSubmit={onGenerate} className="flex flex-col">
            <label htmlFor="studio-brief" className="text-sm text-muted">
              What do you want to create?
            </label>
            <textarea
              id="studio-brief"
              value={brief}
              onChange={(e) => setBrief(e.target.value)}
              rows={6}
              maxLength={2000}
              placeholder="Describe the scene you imagine…"
              className="mt-3 min-h-36 w-full resize-y rounded-[1.5rem] bg-surface px-5 py-4 text-base leading-relaxed text-fg outline-none ring-0 placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-accent/70"
            />

            <div className="mt-6 flex flex-wrap gap-2" role="group" aria-label="Aspect ratio">
              {VIDEO_ASPECTS.map((ratio) => (
                <button
                  key={ratio}
                  type="button"
                  onClick={() => setControls((c) => ({ ...c, aspectRatio: ratio }))}
                  className={cn(
                    "min-h-11 rounded-full px-4 text-sm transition-colors duration-150",
                    controls.aspectRatio === ratio ? "bg-fg text-bg" : "bg-surface text-muted hover:text-fg",
                  )}
                  aria-pressed={controls.aspectRatio === ratio}
                >
                  {VIDEO_ASPECT_LABELS[ratio]}
                </button>
              ))}
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-6">
              <label className="flex min-h-11 items-center gap-3 text-sm text-muted">
                Duration
                <input
                  type="range"
                  min={1}
                  max={SCENE_DURATION_MAX}
                  value={controls.durationSec}
                  onChange={(e) => setControls((c) => ({ ...c, durationSec: Number(e.target.value) }))}
                  aria-valuetext={`${controls.durationSec} seconds`}
                />
                <span className="tabular-nums text-fg">{controls.durationSec}s</span>
              </label>
              <label className="flex min-h-11 items-center gap-3 text-sm text-muted">
                Audio
                <button
                  type="button"
                  role="switch"
                  aria-checked={controls.generateAudio}
                  onClick={() => setControls((c) => ({ ...c, generateAudio: !c.generateAudio }))}
                  className={cn(
                    "h-7 w-12 rounded-full transition-colors duration-150",
                    controls.generateAudio ? "bg-accent" : "bg-surface-2",
                  )}
                >
                  <span className={cn("block size-6 rounded-full bg-bg transition-transform duration-150", controls.generateAudio ? "translate-x-5" : "translate-x-0.5")} />
                </button>
              </label>
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-3">
              <input ref={fileRef} type="file" accept="image/*" className="sr-only" onChange={onFile} />
              <Button type="button" variant="secondary" onClick={() => fileRef.current?.click()}>
                {image ? "Change reference" : "Add reference"}
              </Button>
              {image ? (
                <button type="button" className="min-h-11 text-sm text-muted hover:text-fg" onClick={() => setImage(null)}>
                  Remove
                </button>
              ) : (
                <span className="text-sm text-subtle">Optional still to guide the video</span>
              )}
            </div>
            {image ? (
              <img src={image} alt="Reference for this scene" className="mt-4 max-h-40 rounded-2xl object-cover" />
            ) : null}

            <button
              type="button"
              className="mt-6 self-start min-h-11 text-sm text-muted hover:text-fg"
              onClick={() => setAdvanced((v) => !v)}
              aria-expanded={advanced}
            >
              {advanced ? "Hide advanced" : "Advanced"}
            </button>
            {advanced ? (
              <div className="mt-3 flex flex-col gap-4">
                <div className="flex flex-wrap gap-2" role="group" aria-label="Quality">
                  {VIDEO_RESOLUTIONS.map((res) => (
                    <button
                      key={res}
                      type="button"
                      onClick={() => setControls((c) => ({ ...c, resolution: res }))}
                      className={cn(
                        "min-h-11 rounded-full px-4 text-sm",
                        controls.resolution === res ? "bg-fg text-bg" : "bg-surface text-muted",
                      )}
                    >
                      {VIDEO_RESOLUTION_LABELS[res]} {res}
                    </button>
                  ))}
                </div>
                <p className="text-xs leading-relaxed text-subtle">
                  Native generation is 1080p at most. 4K is not offered.
                </p>
                {open ? (
                  <div>
                    <label htmlFor="studio-refine" className="text-sm text-muted">
                      Refine this project
                    </label>
                    <textarea
                      id="studio-refine"
                      value={edit}
                      onChange={(e) => setEdit(e.target.value)}
                      rows={2}
                      className="mt-2 w-full rounded-2xl bg-surface px-4 py-3 text-sm"
                      placeholder="Make it darker. Use portrait. Add captions."
                    />
                    <Button type="button" variant="secondary" className="mt-2" disabled={!edit.trim()} onClick={() => void onRefine()}>
                      Apply
                    </Button>
                  </div>
                ) : null}
              </div>
            ) : null}

            <Button type="submit" className="mt-8 h-14 min-h-14 w-full max-w-xs text-base" disabled={busy || !brief.trim() || available === false}>
              {busy || creating ? "Creating" : open?.scenes.some((s) => s.hasMedia) ? "Regenerate" : "Generate"}
            </Button>
          </form>

          <section aria-live="polite">
            {creating ? (
              <div className="flex min-h-64 flex-col justify-center rounded-[1.75rem] bg-surface px-8 py-16 text-center">
                <p className="font-display text-2xl tracking-tight">{status.title}</p>
                <p className="mt-3 text-sm text-muted">{status.detail}</p>
                {liveJob ? (
                  <Button type="button" variant="ghost" className="mt-8" onClick={() => void onCancel(liveJob.id)}>
                    Cancel
                  </Button>
                ) : null}
              </div>
            ) : previewScene?.hasMedia ? (
              <div>
                <div className={cn("overflow-hidden rounded-[1.75rem] bg-surface", aspectFrameClass(open?.aspectRatio ?? "16:9"))}>
                  <video
                    className="size-full object-contain"
                    controls
                    playsInline
                    src={`/api/video/media/${previewScene.id}`}
                  />
                </div>
                {open?.captions ? (
                  <p dir="auto" className="mt-4 text-sm leading-relaxed">
                    {open.captions}
                  </p>
                ) : null}
                <div className="mt-5 flex flex-wrap gap-2">
                  <Button type="button" variant="secondary" onClick={() => void onGenerate()}>
                    Regenerate
                  </Button>
                  {open ? (
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => {
                        const next = open.captions ? "" : open.description;
                        void saveVideoCaptions({ data: { id: open.id, captions: next } }).then(setOpen);
                      }}
                    >
                      {open.captions ? "Hide captions" : "Captions"}
                    </Button>
                  ) : null}
                </div>
                {open ? (
                  <p className="mt-4 text-sm text-muted">
                    {open.title} · {open.aspectRatio} · {open.resolution}
                  </p>
                ) : null}
              </div>
            ) : (
              <div className={cn("flex min-h-64 items-center justify-center rounded-[1.75rem] bg-surface text-center", aspectFrameClass(controls.aspectRatio))}>
                <p className="max-w-xs px-6 text-sm leading-relaxed text-muted">Your scene will appear here.</p>
              </div>
            )}
          </section>
        </div>

        {error ? (
          <p className="mt-6 text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}

        {versions.length > 0 ? (
          <div className="mt-12">
            <p className="text-sm text-muted">Versions</p>
            <ol className="mt-3 flex flex-wrap gap-2">
              {versions.map((version, index) => (
                <li key={version.id} className="rounded-full bg-surface px-4 py-2 text-sm text-muted">
                  {versions.length - index}
                </li>
              ))}
            </ol>
          </div>
        ) : null}

        <section className="mt-16">
          <p className="text-sm font-medium">Your Studio</p>
          {projects === null ? (
            <p className="mt-4 text-sm text-muted">Loading projects</p>
          ) : projects.length === 0 ? (
            <p className="mt-4 max-w-sm text-base leading-relaxed text-muted">
              Nothing here yet. Give AEVORA an idea and create your first scene.
            </p>
          ) : (
            <ul className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
              {projects.map((row) => (
                <li key={row.id}>
                  <button
                    type="button"
                    onClick={() => void openProject(row.id)}
                    className="flex min-h-28 w-full flex-col justify-end rounded-[1.5rem] bg-surface px-5 py-5 text-left transition-colors duration-150 hover:bg-surface-2"
                  >
                    <span className="font-display text-xl tracking-tight">{row.title}</span>
                    <span className="mt-2 text-sm text-muted">
                      {VIDEO_ASPECT_LABELS[row.aspectRatio as VideoAspect] ?? row.aspectRatio} · {row.resolution as VideoResolution}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}