import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Pencil, Pin, PinOff, Plus, Trash2 } from "lucide-react";
import {
  MEMORY_BODY_MAX,
  MEMORY_KINDS,
  MEMORY_TAGS_MAX,
  MEMORY_TITLE_MAX,
  createMemory,
  deleteMemory,
  listMemories,
  updateMemory,
  type Memory,
  type MemoryKind,
} from "@/lib/memory";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

const KIND_COPY: Record<MemoryKind, string> = {
  fact: "About me",
  preference: "Preferences",
  person: "People",
  project: "Projects",
  decision: "Important decisions",
};

type Draft = {
  kind: MemoryKind;
  title: string;
  body: string;
  tags: string;
  pinned: boolean;
};

const EMPTY_DRAFT: Draft = {
  kind: "fact",
  title: "",
  body: "",
  tags: "",
  pinned: false,
};

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) {
    return "Sign in to manage memory.";
  }
  if (err instanceof Error && /not found/i.test(err.message)) {
    return "That memory was not found.";
  }
  return "The request did not complete. Try once more.";
}

export function MemoryWorkspace() {
  const [items, setItems] = useState<Memory[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [editing, setEditing] = useState<"new" | number | null>(null);
  const [draft, setDraft] = useState<Draft>(EMPTY_DRAFT);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);

  function refresh() {
    listMemories()
      .then((rows) => {
        setItems(rows);
        setLoadError(null);
      })
      .catch((err) => {
        setLoadError(errorText(err));
      });
  }

  useEffect(() => {
    refresh();
  }, []);

  function openNew() {
    setEditing("new");
    setDraft({ ...EMPTY_DRAFT, pinned: false });
    setSaved(false);
    setSaveError(null);
  }

  function openEdit(row: Memory) {
    setEditing(row.id);
    setDraft({
      kind: row.kind,
      title: row.title,
      body: row.body,
      tags: row.tags,
      pinned: row.pinned,
    });
    setSaved(false);
    setSaveError(null);
  }

  function closeForm() {
    setEditing(null);
    setDraft(EMPTY_DRAFT);
    setSaved(false);
    setSaveError(null);
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    setSaveError(null);
    setSaved(false);
    try {
      const payload = {
        kind: draft.kind,
        title: draft.title,
        body: draft.body,
        tags: draft.tags,
        pinned: draft.pinned,
      };
      const savedRow =
        editing === "new"
          ? await createMemory({ data: payload })
          : await updateMemory({ data: { id: editing as number, ...payload } });
      setItems((prev) => {
        const rest = (prev ?? []).filter((m) => m.id !== savedRow.id);
        const next = [savedRow, ...rest];
        next.sort((a, b) => Number(b.pinned) - Number(a.pinned));
        return next;
      });
      setSaved(true);
      closeForm();
    } catch (err) {
      setSaveError(errorText(err));
    } finally {
      setSaving(false);
    }
  }

  async function onTogglePin(row: Memory) {
    if (busyId) return;
    setBusyId(row.id);
    try {
      const savedRow = await updateMemory({
        data: {
          id: row.id,
          kind: row.kind,
          title: row.title,
          body: row.body,
          tags: row.tags,
          pinned: !row.pinned,
        },
      });
      setItems((prev) => {
        const rest = (prev ?? []).filter((m) => m.id !== savedRow.id);
        const next = [savedRow, ...rest];
        next.sort((a, b) => Number(b.pinned) - Number(a.pinned));
        return next;
      });
    } catch (err) {
      setLoadError(errorText(err));
    } finally {
      setBusyId(null);
    }
  }

  async function onConfirmDelete(id: number) {
    if (busyId) return;
    setBusyId(id);
    try {
      await deleteMemory({ data: { id } });
      setItems((prev) => (prev ?? []).filter((m) => m.id !== id));
      if (editing === id) closeForm();
      setDeletingId(null);
    } catch (err) {
      setLoadError(errorText(err));
    } finally {
      setBusyId(null);
    }
  }

  const canSave = draft.title.trim().length > 0 && draft.body.trim().length > 0 && !saving;

  return (
    <main className="mx-auto flex w-full max-w-2xl min-h-0 flex-1 flex-col overflow-y-auto px-5 py-10 md:px-8">
      <p className="text-sm font-medium text-accent">Memory</p>
      <h1 className="font-display mt-2 text-3xl tracking-tight">What AEVORA knows about you</h1>
      <p className="mt-3 max-w-xl text-base leading-relaxed text-muted">
        Chat is temporary. These stay until you change them.
      </p>

      <div className="mt-8">
        <Button type="button" onClick={openNew} disabled={editing === "new"}>
          <Plus className="size-4" strokeWidth={1.75} />
          Remember something
        </Button>
      </div>

      {editing !== null ? (
        <form
          onSubmit={onSubmit}
          className="mt-8 flex flex-col gap-5 border-t border-border py-6"
          aria-label={editing === "new" ? "New memory" : "Edit memory"}
        >
          <fieldset>
            <legend className="text-xs font-medium text-muted">Kind</legend>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
              {MEMORY_KINDS.map((value) => {
                const selected = draft.kind === value;
                return (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => {
                      setDraft((d) => ({ ...d, kind: value }));
                      setSaved(false);
                    }}
                    className={cn(
                      "flex min-h-11 items-center justify-center rounded-sm border px-2 py-2 text-sm transition-colors duration-150",
                      selected
                        ? "border-border-strong bg-surface-2 text-fg"
                        : "border-border bg-bg text-muted hover:text-fg",
                    )}
                  >
                    {KIND_COPY[value]}
                  </button>
                );
              })}
            </div>
          </fieldset>
          <Field label="Title" htmlFor="memory-title">
            <Input
              id="memory-title"
              name="title"
              value={draft.title}
              onChange={(e) => {
                setDraft((d) => ({ ...d, title: e.target.value }));
                setSaved(false);
              }}
              maxLength={MEMORY_TITLE_MAX}
              placeholder="A short name"
            />
          </Field>
          <Field label="Keep this" htmlFor="memory-body">
            <Textarea
              id="memory-body"
              name="body"
              value={draft.body}
              onChange={(e) => {
                setDraft((d) => ({ ...d, body: e.target.value }));
                setSaved(false);
              }}
              maxLength={MEMORY_BODY_MAX}
              rows={5}
              placeholder="What AEVORA should keep"
            />
          </Field>
          <Field label="Tags" htmlFor="memory-tags">
            <Input
              id="memory-tags"
              name="tags"
              value={draft.tags}
              onChange={(e) => {
                setDraft((d) => ({ ...d, tags: e.target.value }));
                setSaved(false);
              }}
              maxLength={MEMORY_TAGS_MAX}
              placeholder="Optional, comma separated"
            />
          </Field>
          <label className="flex min-h-11 items-center gap-3 text-sm text-fg">
            <input
              type="checkbox"
              checked={draft.pinned}
              onChange={(e) => {
                setDraft((d) => ({ ...d, pinned: e.target.checked }));
                setSaved(false);
              }}
            />
            Pin into new conversations
          </label>
          {saveError ? (
            <p className="text-sm text-danger" role="alert">
              {saveError}
            </p>
          ) : null}
          {saved ? (
            <p className="text-sm text-muted" role="status">
              Saved.
            </p>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <Button type="submit" disabled={!canSave}>
              {saving ? "Saving" : editing === "new" ? "Save memory" : "Save changes"}
            </Button>
            <Button type="button" variant="secondary" onClick={closeForm} disabled={saving}>
              Cancel
            </Button>
          </div>
        </form>
      ) : null}

      {loadError ? (
        <p className="mt-6 text-sm text-danger" role="alert">
          {loadError}
        </p>
      ) : null}

      {items === null && !loadError ? (
        <div className="mt-8 space-y-3" aria-hidden="true">
          <div className="h-12 animate-pulse bg-surface/70" />
          <div className="h-12 animate-pulse bg-surface/70" />
        </div>
      ) : items && items.length === 0 && editing === null ? (
        <p className="mt-8 max-w-md text-base leading-relaxed text-muted">
          Nothing stored yet. Add what AEVORA should remember about you.
        </p>
      ) : (
        <div className="mt-10 flex flex-col gap-10">
          {MEMORY_KINDS.map((kind) => {
            const rows = (items ?? []).filter((row) => row.kind === kind);
            if (rows.length === 0) return null;
            return (
              <section key={kind} aria-label={KIND_COPY[kind]}>
                <h2 className="text-[11px] font-medium uppercase tracking-[0.16em] text-subtle">
                  {KIND_COPY[kind]}
                </h2>
                <ul className="mt-3 flex flex-col">
                  {rows.map((row) => (
                    <li key={row.id}>
                      <article
                        className="border-t border-border py-5"
                        aria-label={`${KIND_COPY[row.kind]}: ${row.title}`}
                      >
                        {row.pinned ? (
                          <p className="mb-2 text-xs uppercase tracking-[0.14em] text-accent">Pinned</p>
                        ) : null}
                        <h3 className="text-base font-medium text-fg">{row.title}</h3>
                        <p className="mt-1 text-sm leading-relaxed whitespace-pre-wrap break-words text-muted">
                          {row.body}
                        </p>
                        {row.tags.trim() ? (
                          <p className="mt-2 text-xs text-subtle">{row.tags}</p>
                        ) : null}
                        <div className="mt-4 flex flex-wrap gap-2">
                          <Button
                            type="button"
                            variant="secondary"
                            size="sm"
                            disabled={busyId === row.id}
                            onClick={() => void onTogglePin(row)}
                            aria-label={row.pinned ? `Unpin ${row.title}` : `Pin ${row.title}`}
                          >
                            {row.pinned ? (
                              <PinOff className="size-4" strokeWidth={1.75} />
                            ) : (
                              <Pin className="size-4" strokeWidth={1.75} />
                            )}
                            {row.pinned ? "Unpin" : "Pin"}
                          </Button>
                          <Button
                            type="button"
                            variant="secondary"
                            size="sm"
                            disabled={busyId === row.id}
                            onClick={() => openEdit(row)}
                          >
                            <Pencil className="size-4" strokeWidth={1.75} />
                            Edit
                          </Button>
                          {deletingId === row.id ? (
                            <>
                              <Button
                                type="button"
                                variant="secondary"
                                size="sm"
                                disabled={busyId === row.id}
                                onClick={() => void onConfirmDelete(row.id)}
                              >
                                <Trash2 className="size-4" strokeWidth={1.75} />
                                Delete
                              </Button>
                              <Button type="button" variant="ghost" size="sm" onClick={() => setDeletingId(null)}>
                                Keep
                              </Button>
                            </>
                          ) : (
                            <Button type="button" variant="ghost" size="sm" onClick={() => setDeletingId(row.id)}>
                              Remove
                            </Button>
                          )}
                        </div>
                      </article>
                    </li>
                  ))}
                </ul>
              </section>
            );
          })}
        </div>
      )}
    </main>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
    </div>
  );
}
