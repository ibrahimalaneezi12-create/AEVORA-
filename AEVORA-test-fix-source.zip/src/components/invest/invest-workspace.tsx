import { useEffect, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { listInvestPage, type InvestNote, type InvestOverview, type InvestPlan, type WatchItem } from "@/lib/invest";
import { brokerStatus, connectAlpaca, disconnectAlpaca, loadBrokerSnapshot } from "@/lib/broker";
import type { BrokerSnapshot } from "@/lib/invest-brain";
import { workspaceDraftKey } from "@/lib/chat-workspace";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) {
    return "Sign in to see investments.";
  }
  return "AEVORA could not load this page. Try once more.";
}

function seedChat(draft: string) {
  try {
    sessionStorage.setItem(workspaceDraftKey("invest"), draft);
  } catch {
    /* private mode */
  }
}

export function InvestWorkspace() {
  const [watchlist, setWatchlist] = useState<WatchItem[] | null>(null);
  const [notes, setNotes] = useState<InvestNote[]>([]);
  const [overview, setOverview] = useState<InvestOverview | null>(null);
  const [planName, setPlanName] = useState<string>("");
  const [accessLine, setAccessLine] = useState<string>("");
  const [plans, setPlans] = useState<InvestPlan[]>([]);
  const [hello, setHello] = useState("");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [snapshot, setSnapshot] = useState<BrokerSnapshot | null>(null);
  const [mode, setMode] = useState<"paper" | "live">("paper");
  const [keyId, setKeyId] = useState("");
  const [secret, setSecret] = useState("");
  const [connectError, setConnectError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function refreshBroker() {
    return Promise.all([brokerStatus(), loadBrokerSnapshot()])
      .then(([, snap]) => setSnapshot(snap))
      .catch(() =>
        setSnapshot((current) => {
          if (current) return current;
          return {
            connected: false,
            verified: false,
            mode: null,
            provider: "",
            capabilities: [],
            account: null,
            positions: [],
            orders: [],
            accountStatus: "",
            lastCheckedAt: "",
            error: "The broker status could not be read. Nothing was changed.",
          };
        }),
      );
  }

  useEffect(() => {
    listInvestPage()
      .then((page) => {
        setWatchlist(page.watchlist);
        setNotes(page.notes);
        setOverview(page.overview);
        setPlanName(page.planName);
        setAccessLine(page.accessLine);
        setPlans(page.plans);
        setLoadError(null);
      })
      .catch((err) => setLoadError(errorText(err)));
    void refreshBroker();
    const hour = new Date().getHours();
    setHello(hour < 12 ? "Good morning." : hour < 18 ? "Good afternoon." : "Good evening.");
  }, []);

  async function onConnect(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setConnectError(null);
    try {
      const result = await connectAlpaca({ data: { mode, keyId, secret } });
      setSecret("");
      setKeyId("");
      if (!result.ok) {
        setConnectError(result.error);
      }
      await refreshBroker();
    } catch {
      setConnectError("The broker could not be reached. Nothing was saved.");
    } finally {
      setBusy(false);
    }
  }

  async function onDisconnect() {
    if (!snapshot?.mode) return;
    setBusy(true);
    try {
      await disconnectAlpaca({ data: { mode: snapshot.mode } });
      await refreshBroker();
    } finally {
      setBusy(false);
    }
  }

  const loaded = watchlist !== null;

  return (
    <main
      data-context="invest"
      className="mx-auto flex w-full max-w-xl min-h-0 flex-1 flex-col justify-center overflow-y-auto px-6 py-12 md:px-8"
    >
      <p className="text-sm font-medium text-ok">Invest</p>
      {hello ? <p className="font-display mt-3 text-2xl tracking-tight">{hello}</p> : null}
      <h1 className="font-display mt-2 text-4xl leading-[1.08] tracking-tight">How is my portfolio?</h1>
      <p className="mt-4 max-w-md text-lg leading-relaxed text-muted">
        Research a company or ask about a connected account. AEVORA will not invent a price, a balance, or a fill.
      </p>

      <div className="mt-8">
        <Button asChild className="h-14 min-h-14 px-8 text-base">
          <Link to="/app/invest" hash="chat" onClick={() => seedChat("How is my portfolio?")}>
            Invest chat
          </Link>
        </Button>
      </div>
      <p className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted">
        <Link to="/app/invest" hash="chat" className="hover:text-fg" onClick={() => seedChat("How is my portfolio?")}>
          How is my portfolio?
        </Link>
        <Link to="/app/invest" hash="chat" className="hover:text-fg" onClick={() => seedChat("Compare ")}>
          Compare two
        </Link>
        <Link to="/app/invest" hash="chat" className="hover:text-fg" onClick={() => seedChat("Should I rebalance?")}>
          Rebalance
        </Link>
        <Link to="/app/invest" hash="chat" className="hover:text-fg" onClick={() => seedChat("What is my investment thesis?")}>
          Thesis
        </Link>
      </p>

      {loadError ? (
        <p className="mt-8 text-sm text-danger" role="alert">
          {loadError}
        </p>
      ) : null}

      {!loaded && !loadError ? (
        <div className="mt-12 h-12 w-48 animate-pulse bg-surface/70" aria-hidden="true" />
      ) : null}

      {loaded && overview?.empty ? (
        <p className="mt-10 max-w-md text-sm leading-relaxed text-muted">
          Nothing is on the watchlist yet. Name a company in chat.
        </p>
      ) : null}

      {loaded && watchlist.length > 0 ? (
        <section className="mt-12 max-w-md" aria-label="Watchlist">
          <h2 className="text-sm font-medium text-fg">Watching</h2>
          <ul className="mt-2 flex flex-col gap-2">
            {watchlist.map((item) => (
              <li key={item.id} className="text-sm leading-relaxed text-muted">
                <span className="text-fg">{item.symbol}</span>
                {item.name ? ` · ${item.name}` : ""}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {loaded && notes.length > 0 ? (
        <section className="mt-8 max-w-md" aria-label="Notes">
          <h2 className="text-sm font-medium text-fg">Notes</h2>
          <ul className="mt-2 flex flex-col gap-2">
            {notes.slice(0, 4).map((note) => (
              <li key={note.id} className="text-sm leading-relaxed text-muted">
                {note.title}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {loaded && plans.length > 0 ? (
        <section className="mt-8 max-w-md" aria-label="Plans">
          <h2 className="text-sm font-medium text-fg">Plans you wrote</h2>
          <ul className="mt-2 flex flex-col gap-2">
            {plans.map((plan) => (
              <li key={plan.id} className="text-sm leading-relaxed text-muted">
                <span className="text-fg">{plan.title}</span>
                {plan.contribution ? ` · ${plan.contribution}` : ""}
                {" · does not place an order"}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="mt-12 max-w-md" aria-label="Broker">
        <h2 className="text-sm font-medium text-fg">Broker</h2>
        {snapshot === null ? (
          <div className="mt-4 h-10 w-40 animate-pulse bg-surface/70" aria-hidden="true" />
        ) : snapshot.verified ? (
          <div className="mt-3 flex flex-col gap-3 text-sm leading-relaxed text-muted">
            <p>
              Connected · Alpaca {snapshot.mode}
              {snapshot.accountStatus ? ` · account ${snapshot.accountStatus}` : ""}
              {snapshot.account?.equity ? ` · equity ${snapshot.account.equity}` : " · equity was not returned"}
              {snapshot.account?.cash ? ` · cash ${snapshot.account.cash}` : ""}
            </p>
            {snapshot.capabilities.length > 0 ? (
              <p>Verified capabilities: {snapshot.capabilities.join(", ")}.</p>
            ) : null}
            {snapshot.error ? <p role="alert">{snapshot.error}</p> : null}
            {snapshot.positions.length === 0 ? (
              <p>
                {snapshot.capabilities.includes("positions.read")
                  ? "The broker returned no open positions."
                  : "Positions were not read."}
              </p>
            ) : (
              <ul>
                {snapshot.positions.slice(0, 6).map((position) => (
                  <li key={position.symbol}>
                    {position.symbol} · {position.qty || "quantity not returned"}
                  </li>
                ))}
              </ul>
            )}
            {snapshot.orders.length === 0 ? (
              <p>
                {snapshot.capabilities.includes("orders.read")
                  ? "The broker returned no recent orders."
                  : "Recent orders were not read."}
              </p>
            ) : (
              <ul>
                {snapshot.orders.slice(0, 5).map((order) => (
                  <li key={order.id}>
                    {order.symbol} · {order.side} · {order.status}
                  </li>
                ))}
              </ul>
            )}
            <p>An order is sent only after you approve it in chat. Nothing is running in the background.</p>
            <Button type="button" variant="secondary" className="min-h-12 w-fit" disabled={busy} onClick={() => void onDisconnect()}>
              Disconnect
            </Button>
          </div>
        ) : snapshot.connected ? (
          <div className="mt-3 flex flex-col gap-3 text-sm leading-relaxed text-muted">
            <p role="alert">{snapshot.error || "Alpaca could not be verified. Nothing was read."}</p>
            <Button type="button" variant="secondary" className="min-h-12 w-fit" disabled={busy} onClick={() => void onDisconnect()}>
              Disconnect
            </Button>
          </div>
        ) : (
          <form className="mt-4 flex flex-col gap-3" onSubmit={(event) => void onConnect(event)}>
            <p className="text-sm leading-relaxed text-muted">
              Connect your own Alpaca paper or live key. It stays on the server. Paper never calls the live host.
            </p>
            <div className="flex gap-2">
              <Button type="button" variant={mode === "paper" ? "primary" : "secondary"} className="min-h-12" onClick={() => setMode("paper")}>
                Paper
              </Button>
              <Button type="button" variant={mode === "live" ? "primary" : "secondary"} className="min-h-12" onClick={() => setMode("live")}>
                Live
              </Button>
            </div>
            <div className="flex flex-col gap-1">
              <Label htmlFor="alpaca-key">Key id</Label>
              <Input id="alpaca-key" type="password" autoComplete="off" value={keyId} onChange={(event) => setKeyId(event.target.value)} />
            </div>
            <div className="flex flex-col gap-1">
              <Label htmlFor="alpaca-secret">Secret</Label>
              <Input
                id="alpaca-secret"
                type="password"
                autoComplete="off"
                value={secret}
                onChange={(event) => setSecret(event.target.value)}
              />
            </div>
            {connectError || snapshot.error ? (
              <p className="text-sm text-danger" role="alert">
                {connectError || snapshot.error}
              </p>
            ) : null}
            <Button type="submit" className="min-h-12 w-fit" disabled={busy || keyId.length < 8 || secret.length < 8}>
              {busy ? "Checking Alpaca…" : "Connect Alpaca"}
            </Button>
          </form>
        )}
      </section>

      {loaded ? (
        <p className="mt-12 max-w-md text-xs leading-relaxed text-subtle">
          {planName ? `${planName}. ` : ""}
          {accessLine}
        </p>
      ) : null}
    </main>
  );
}