import { useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import {
  editStudioVideo,
  getStudioCapabilities,
  getStudioProject,
  pollStudioVideo,
  restoreStudioAsset,
  uploadStudioMedia,
  type StudioProject,
} from "@/lib/studio";
import { classifyVideoEdit, publicStudioError } from "@/lib/studio-format";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function errorText(err: unknown): string {
  if (err instanceof Error) return publicStudioError(err.message);
  return publicStudioError(null);
}

export function VideoEditWorkspace({
  onBack,
  onOpenPhoto,
  initialId,
}: {
  onBack: () => void;
  onOpenPhoto: (projectId?: number) => void;
  initialId?: number;
}) {
  const [project, setProject] = useState<StudioProject | null>(null);
  const [prompt, setPrompt] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [available, setAvailable] = useState<boolean | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const load = useCallback(async (id: number) => {
    const next = await getStudioProject({ data: { id } });
    setProject(next);
  }, []);

  useEffect(() => {
    getStudioCapabilities()
      .then((caps) => setAvailable(caps.videoAvailable))
      .catch(() => setAvailable(false));
  }, []);

  useEffect(() => {
    if (!initialId) return;
    void load(initialId).catch((err) => setError(errorText(err)));
  }, [initialId, load]);

  useEffect(() => {
    if (project?.status !== "processing") return;
    const id = window.setInterval(() => {
      void pollStudioVideo({ data: { id: project.id } })
        .then(setProject)
        .catch((err) => setError(errorText(err)));
    }, 3000);
    return () => window.clearInterval(id);
  }, [project?.id, project?.status]);

  function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.includes("mp4") && file.type !== "video/quicktime") {
      setError("Use an MP4 clip under 8.7 seconds.");
      return;
    }
    if (file.size > 12_000_000) {
      setError("Keep clips under 12 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUri = typeof reader.result === "string" ? reader.result : "";
      setBusy(true);
      uploadStudioMedia({ data: { kind: "video", dataUri, title: file.name } })
        .then((next) => {
          setProject(next);
          setError(null);
        })
        .catch((err) => setError(errorText(err)))
        .finally(() => setBusy(false));
    };
    reader.readAsDataURL(file);
  }

  async function onEdit(e: FormEvent) {
    e.preventDefault();
    if (!project || busy || !prompt.trim()) return;
    const allowed = classifyVideoEdit(prompt);
    if (!allowed.ok) {
      setError(allowed.reason);
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const next = await editStudioVideo({ data: { id: project.id, instruction: prompt } });
      setProject(next);
      setPrompt("");
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  function grabFrame() {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 720;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUri = canvas.toDataURL("image/jpeg", 0.92);
    setBusy(true);
    uploadStudioMedia({ data: { kind: "photo", dataUri, title: `${project?.title || "Frame"} still` } })
      .then((next) => onOpenPhoto(next.id))
      .catch((err) => setError(errorText(err)))
      .finally(() => setBusy(false));
  }

  const current = project?.currentAssetId;
  const creating = project?.status === "processing";

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
      <header className="flex items-center justify-between px-5 pt-6 md:px-10">
        <button type="button" onClick={onBack} className="min-h-11 text-sm text-muted hover:text-fg">
          Studio
        </button>
        <p className="text-sm text-subtle">Edit video · MP4 under 8.7s</p>
      </header>

      <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col px-5 pb-16 pt-6 md:px-10">
        <p className="text-sm font-medium tracking-wide text-accent">Edit video</p>
        <h1 className="font-display mt-2 text-3xl tracking-tight md:text-5xl">Change how a short clip looks.</h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted">
          Mood, objects, weather, clothing. Not cuts, slow-motion, or louder audio.
        </p>
        {available === false ? (
          <p className="mt-4 text-sm text-caution">Video editing is unavailable right now.</p>
        ) : null}

        <div className="mt-10 grid items-start gap-10 lg:grid-cols-2">
          <div>
            {!project ? (
              <>
                <input ref={fileRef} type="file" accept="video/mp4,video/quicktime" className="sr-only" onChange={onFile} />
                <Button type="button" className="h-14 min-h-14" onClick={() => fileRef.current?.click()}>
                  Upload clip
                </Button>
              </>
            ) : (
              <form onSubmit={onEdit}>
                <label htmlFor="video-edit" className="text-sm text-muted">
                  What should change?
                </label>
                <textarea
                  id="video-edit"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={4}
                  className="mt-3 w-full rounded-[1.5rem] bg-surface px-5 py-4 text-base"
                  placeholder="Add rain. Give them a silver necklace."
                />
                <Button type="submit" className="mt-6 h-14 min-h-14" disabled={busy || creating || !prompt.trim()}>
                  {busy || creating ? "Working" : "Apply edit"}
                </Button>
              </form>
            )}
          </div>
          <section>
            {creating ? (
              <div className="flex min-h-72 flex-col justify-center rounded-[1.75rem] bg-surface px-8 text-center">
                <p className="font-display text-2xl tracking-tight">Creating your scene</p>
                <p className="mt-3 text-sm text-muted">Your video is being generated.</p>
              </div>
            ) : current ? (
              <video
                ref={videoRef}
                className="w-full rounded-[1.75rem] bg-surface"
                controls
                playsInline
                src={`/api/studio/media/${current}`}
              />
            ) : (
              <div className="flex min-h-72 items-center justify-center rounded-[1.75rem] bg-surface">
                <p className="px-6 text-sm text-muted">Your clip will appear here.</p>
              </div>
            )}
          </section>
        </div>

        {error ? (
          <p className="mt-6 text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}

        {current ? (
          <Button type="button" variant="secondary" className="mt-8 w-fit" disabled={busy} onClick={grabFrame}>
            Choose this frame
          </Button>
        ) : null}

        {project && project.assets.length > 1 ? (
          <ul className="mt-10 flex flex-wrap gap-2">
            {project.assets.map((asset) => (
              <li key={asset.id}>
                <button
                  type="button"
                  className={cn("rounded-full px-4 py-2 text-sm", project.currentAssetId === asset.id ? "bg-fg text-bg" : "bg-surface text-muted")}
                  onClick={() => void restoreStudioAsset({ data: { id: project.id, assetId: asset.id } }).then(setProject)}
                >
                  {asset.role === "original" ? "Original" : `Version ${asset.versionN}`}
                </button>
              </li>
            ))}
          </ul>
        ) : null}
      </div>
    </div>
  );
}