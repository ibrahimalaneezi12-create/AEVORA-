import { useEffect, useState } from "react";
import { listStudioLibrary, type StudioLibraryItem } from "@/lib/studio";

type StudioLandingProps = {
  onCreatePhoto: () => void;
  onCreateVideo: () => void;
  onEditPhoto: () => void;
  onEditVideo: () => void;
  onOpenWriting: () => void;
  onOpenLibraryItem: (item: StudioLibraryItem) => void;
};

export function StudioLanding({
  onCreatePhoto,
  onCreateVideo,
  onEditPhoto,
  onEditVideo,
  onOpenWriting,
  onOpenLibraryItem,
}: StudioLandingProps) {
  const [items, setItems] = useState<StudioLibraryItem[] | null>(null);

  useEffect(() => {
    listStudioLibrary()
      .then(setItems)
      .catch(() => setItems([]));
  }, []);

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto px-6 py-12 md:px-12">
      <p className="text-sm font-medium tracking-wide text-accent">AEVORA Studio</p>
      <h1 className="font-display mt-4 max-w-[14ch] text-4xl leading-[1.06] tracking-tight md:text-6xl">
        Bring an idea to life.
      </h1>
      <p className="mt-5 max-w-md text-lg leading-relaxed text-muted">
        Make a still or a scene. Or change one you already have.
      </p>

      <section className="mt-14 max-w-3xl">
        <p className="text-xs font-medium tracking-[0.18em] text-subtle">CREATE</p>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <ModeButton title="Photo" line="Describe a still. AEVORA makes it." onClick={onCreatePhoto} primary />
          <ModeButton title="Video" line="Turn an idea into a scene." onClick={onCreateVideo} primary />
        </div>
      </section>

      <section className="mt-10 max-w-3xl">
        <p className="text-xs font-medium tracking-[0.18em] text-subtle">EDIT</p>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <ModeButton title="Photo" line="Upload a picture. Tell AEVORA what to change." onClick={onEditPhoto} />
          <ModeButton title="Video" line="Upload a short MP4. Change how it looks." onClick={onEditVideo} />
        </div>
      </section>

      <section className="mt-16 max-w-3xl">
        <p className="text-sm font-medium">Your creations</p>
        {items === null ? (
          <p className="mt-4 text-sm text-muted">Loading Studio</p>
        ) : items.length === 0 ? (
          <p className="mt-4 max-w-sm text-base leading-relaxed text-muted">
            Nothing here yet. Give AEVORA an idea, or bring a photo of your own.
          </p>
        ) : (
          <ul className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {items.slice(0, 8).map((item) => (
              <li key={`${item.source}-${item.id}`}>
                <button
                  type="button"
                  onClick={() => onOpenLibraryItem(item)}
                  className="flex min-h-24 w-full flex-col justify-end rounded-[1.5rem] bg-surface px-5 py-4 text-left transition-colors duration-150 hover:bg-surface-2"
                >
                  <span className="text-xs uppercase tracking-wide text-subtle">{item.kind}</span>
                  <span className="font-display mt-1 text-xl tracking-tight">{item.title}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <button type="button" onClick={onOpenWriting} className="mt-10 self-start min-h-11 text-sm text-muted hover:text-fg">
        Writing
      </button>
    </div>
  );
}

function ModeButton({
  title,
  line,
  onClick,
  primary,
}: {
  title: string;
  line: string;
  onClick: () => void;
  primary?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        primary
          ? "min-h-28 rounded-[1.75rem] bg-fg px-6 py-7 text-left text-bg transition-opacity duration-150 hover:opacity-95"
          : "min-h-28 rounded-[1.75rem] bg-surface px-6 py-7 text-left transition-colors duration-150 hover:bg-surface-2"
      }
    >
      <p className={`font-display text-2xl tracking-tight ${primary ? "text-bg" : "text-fg"}`}>{title}</p>
      <p className={`mt-2 text-sm leading-relaxed ${primary ? "text-bg/70" : "text-muted"}`}>{line}</p>
    </button>
  );
}