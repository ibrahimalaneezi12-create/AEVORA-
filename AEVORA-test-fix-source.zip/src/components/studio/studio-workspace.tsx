import { useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent } from "react";
import { ArrowUp, Mic, Plus } from "lucide-react";
import {
  getStudioCapabilities,
  getStudioProject,
  listStudioLibrary,
  restoreStudioAsset,
  runStudioTurn,
  pollStudioVideo,
  type StudioLibraryItem,
  type StudioProject,
  type StudioTurnResult,
} from "@/lib/studio";
import { getVideoProject, pollVideoRender, type VideoJob, type VideoProject } from "@/lib/video";
import { transcribeAudioBuffer } from "@/lib/stt";
import { PHOTO_ASPECTS, publicStudioError } from "@/lib/studio-format";
import {
  SCENE_DURATION_MAX,
  VIDEO_RESOLUTION_LABELS,
  VIDEO_RESOLUTIONS,
  aspectFrameClass,
  publicVideoError,
  type VideoResolution,
} from "@/lib/video-format";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Filter = "all" | "photos" | "videos";

type Attachment = {
  kind: "photo" | "video";
  dataUri: string;
  title: string;
};

function errorText(err: unknown): string {
  if (err instanceof Error) {
    const studio = publicStudioError(err.message);
    if (studio !== err.message) return studio;
    return publicVideoError(err.message);
  }
  return publicStudioError(null);
}

function fileToDataUri(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
    reader.onerror = () => reject(new Error("That file could not be read."));
    reader.readAsDataURL(file);
  });
}

export function StudioWorkspace({ onOpenWriting }: { onOpenWriting: () => void }) {
  const [prompt, setPrompt] = useState("");
  const [attachment, setAttachment] = useState<Attachment | null>(null);
  const [photo, setPhoto] = useState<StudioProject | null>(null);
  const [video, setVideo] = useState<VideoProject | null>(null);
  const [job, setJob] = useState<VideoJob | null>(null);
  const [speech, setSpeech] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [available, setAvailable] = useState<boolean | null>(null);
  const [library, setLibrary] = useState<StudioLibraryItem[] | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [advanced, setAdvanced] = useState(false);
  const [aspect, setAspect] = useState<(typeof PHOTO_ASPECTS)[number]>("16:9");
  const [durationSec, setDurationSec] = useState(8);
  const [videoResolution, setVideoResolution] = useState<VideoResolution>("720p");
  const [generateAudio, setGenerateAudio] = useState(true);
  const [savedNote, setSavedNote] = useState<string | null>(null);
  const [listening, setListening] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const refreshLibrary = useCallback(() => {
    listStudioLibrary()
      .then(setLibrary)
      .catch(() => setLibrary([]));
  }, []);

  useEffect(() => {
    refreshLibrary();
    getStudioCapabilities()
      .then((caps) => setAvailable(caps.available))
      .catch(() => setAvailable(false));
  }, [refreshLibrary]);

  const jobId = job?.id ?? null;
  const jobStatus = job?.status ?? null;
  const studioVideoId = photo?.kind === "video" ? photo.id : null;
  const studioVideoStatus = photo?.kind === "video" ? photo.status : null;

  useEffect(() => {
    if (!jobId || (jobStatus !== "processing" && jobStatus !== "queued")) return;
    let cancelled = false;
    const tick = async () => {
      try {
        const result = await pollVideoRender({ data: { id: jobId } });
        if (cancelled) return;
        setJob(result.job);
        setVideo(result.project);
        if (result.job.status === "completed") {
          setSpeech("The still is now a scene.");
          refreshLibrary();
        }
        if (result.job.status === "failed") {
          setError(publicVideoError(result.job.error));
        }
      } catch (err) {
        if (!cancelled) setError(errorText(err));
      }
    };
    const id = window.setInterval(() => void tick(), 3000);
    void tick();
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [jobId, jobStatus, refreshLibrary]);

  useEffect(() => {
    if (!studioVideoId || studioVideoStatus !== "processing") return;
    let cancelled = false;
    const tick = async () => {
      try {
        const next = await pollStudioVideo({ data: { id: studioVideoId } });
        if (cancelled) return;
        setPhoto(next);
        if (next.status === "completed") {
          setSpeech("Updated. The original clip is still here.");
          refreshLibrary();
        }
      } catch (err) {
        if (!cancelled) setError(errorText(err));
      }
    };
    const id = window.setInterval(() => void tick(), 3000);
    void tick();
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [studioVideoId, studioVideoStatus, refreshLibrary]);

  function applyTurn(result: StudioTurnResult) {
    setPhoto(result.photo);
    setVideo(result.video);
    setJob(result.job);
    setSpeech(result.speech);
    setPrompt("");
    setAttachment(null);
    setSavedNote(null);
    refreshLibrary();
  }

  async function onSend(e?: FormEvent) {
    e?.preventDefault();
    if (busy) return;
    const text = prompt.trim();
    if (!text && !attachment) return;
    setBusy(true);
    setError(null);
    setSavedNote(null);
    try {
      const result = await runStudioTurn({
        data: {
          prompt: text,
          attachment: attachment ?? undefined,
          currentPhotoId: photo?.kind === "photo" ? photo.id : undefined,
          currentVideoId: video?.id,
          currentStudioVideoId: photo?.kind === "video" ? photo.id : undefined,
          aspectRatio: aspect,
          photoResolution: "1k",
          videoResolution,
          durationSec,
          generateAudio,
        },
      });
      applyTurn(result);
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  async function runAction(nextPrompt: string) {
    setPrompt(nextPrompt);
    setBusy(true);
    setError(null);
    try {
      const result = await runStudioTurn({
        data: {
          prompt: nextPrompt,
          currentPhotoId: photo?.kind === "photo" ? photo.id : undefined,
          currentVideoId: video?.id,
          currentStudioVideoId: photo?.kind === "video" ? photo.id : undefined,
          aspectRatio: aspect,
          photoResolution: "1k",
          videoResolution,
          durationSec,
          generateAudio,
        },
      });
      applyTurn(result);
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  async function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const isVideo = file.type.includes("mp4") || file.type === "video/quicktime";
    const isImage = file.type.startsWith("image/");
    if (!isVideo && !isImage) {
      setError("Attach a JPEG, PNG, WebP, or a short MP4.");
      return;
    }
    if (isImage && file.size > 4_000_000) {
      setError("Keep photos under 4 MB.");
      return;
    }
    if (isVideo && file.size > 12_000_000) {
      setError("Keep clips under 12 MB.");
      return;
    }
    try {
      const dataUri = await fileToDataUri(file);
      setAttachment({ kind: isVideo ? "video" : "photo", dataUri, title: file.name });
      setError(null);
    } catch (err) {
      setError(errorText(err));
    }
  }

  function onComposerKey(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void onSend();
    }
  }

  async function toggleMic() {
    if (listening) {
      recorderRef.current?.stop();
      setListening(false);
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setError("Voice is not available in this browser.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunksRef.current.push(ev.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
        void blob.arrayBuffer().then(async (buf) => {
          const result = await transcribeAudioBuffer(new Uint8Array(buf), blob.type || "audio/webm");
          if (result.ok) setPrompt((prev) => (prev ? `${prev} ${result.text}` : result.text));
          else setError(result.error);
        });
      };
      recorderRef.current = recorder;
      recorder.start();
      setListening(true);
      setError(null);
    } catch {
      setError("Microphone access is needed to speak a prompt.");
    }
  }

  async function openLibrary(item: StudioLibraryItem) {
    setError(null);
    setSpeech(null);
    setJob(null);
    setAttachment(null);
    try {
      if (item.source === "video") {
        const next = await getVideoProject({ data: { id: item.id } });
        setVideo(next);
        setPhoto(null);
        return;
      }
      const next = await getStudioProject({ data: { id: item.id } });
      setPhoto(next);
      if (next.linkedVideoId) {
        try {
          setVideo(await getVideoProject({ data: { id: next.linkedVideoId } }));
        } catch {
          setVideo(null);
        }
      } else {
        setVideo(null);
      }
    } catch (err) {
      setError(errorText(err));
    }
  }

  function startNew() {
    setPhoto(null);
    setVideo(null);
    setJob(null);
    setSpeech(null);
    setPrompt("");
    setAttachment(null);
    setError(null);
    setSavedNote(null);
  }

  const processing =
    busy ||
    job?.status === "processing" ||
    job?.status === "queued" ||
    (photo?.kind === "video" && photo.status === "processing");
  const previewScene = video?.scenes.find((s) => s.hasMedia) ?? video?.scenes[0];
  const showingVideo = Boolean(previewScene?.hasMedia);
  const showingPhoto = Boolean(photo?.kind === "photo" && photo.currentAssetId);
  const showingStudioVideo = Boolean(photo?.kind === "video" && photo.currentAssetId);
  const hasResult = showingVideo || showingPhoto || showingStudioVideo || processing;
  const items = (library ?? []).filter((item) => {
    if (filter === "photos") return item.kind === "photo";
    if (filter === "videos") return item.kind === "video";
    return true;
  });

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto px-5 pb-4 pt-6 md:px-10">
        <div className="mx-auto flex w-full max-w-3xl flex-col">
          <div className="flex items-baseline justify-between gap-4">
            <p className="text-sm font-medium tracking-wide text-accent">AEVORA Studio</p>
            {hasResult ? (
              <button type="button" onClick={startNew} className="min-h-11 text-sm text-muted hover:text-fg">
                New
              </button>
            ) : null}
          </div>

          {!hasResult ? (
            <h1 className="font-display mt-6 max-w-[16ch] text-4xl leading-[1.06] tracking-tight md:text-6xl">
              What do you want to create?
            </h1>
          ) : (
            <h1 className="font-display mt-4 text-3xl tracking-tight md:text-4xl">
              {processing ? "Working." : speech || "Here it is."}
            </h1>
          )}

          {available === false ? (
            <p className="mt-4 text-sm text-caution" role="status">
              Grok is not connected. Nothing will be generated.
            </p>
          ) : null}

          <section className="mt-8" aria-live="polite">
            {processing && !showingVideo ? (
              <div className="flex min-h-72 flex-col items-center justify-center rounded-[1.75rem] bg-surface px-8 py-16 text-center">
                <p className="font-display text-2xl tracking-tight">
                  {job ? "Creating your scene" : busy ? "Working" : "Editing"}
                </p>
                <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted">
                  This can take a moment. Nothing is invented while it runs.
                </p>
              </div>
            ) : showingVideo && previewScene ? (
              <div className={cn("overflow-hidden rounded-[1.75rem] bg-surface", aspectFrameClass(video?.aspectRatio ?? aspect))}>
                <video className="size-full object-contain" controls playsInline src={`/api/video/media/${previewScene.id}`} />
              </div>
            ) : showingStudioVideo && photo?.currentAssetId ? (
              <div className="overflow-hidden rounded-[1.75rem] bg-surface">
                <video className="w-full object-contain" controls playsInline src={`/api/studio/media/${photo.currentAssetId}`} />
              </div>
            ) : showingPhoto && photo?.currentAssetId ? (
              <img
                src={`/api/studio/media/${photo.currentAssetId}`}
                alt={photo.title || "Studio photo"}
                className="w-full rounded-[1.75rem] bg-surface object-contain"
              />
            ) : (
              <div className="hidden md:flex min-h-40 items-end">
                <p className="max-w-md text-lg leading-relaxed text-muted">
                  Describe a still or a scene. Or attach something you already have.
                </p>
              </div>
            )}
          </section>

          {hasResult && !processing ? (
            <div className="mt-6 flex flex-wrap gap-2">
              {showingPhoto ? (
                <>
                  <Button type="button" variant="secondary" disabled={busy} onClick={() => setPrompt("Make it ")}>
                    Edit
                  </Button>
                  <Button type="button" disabled={busy} onClick={() => void runAction("Bring this to life.")}>
                    Bring to life
                  </Button>
                  <Button type="button" variant="secondary" disabled={busy} onClick={() => void runAction("Create another version.")}>
                    Create variation
                  </Button>
                </>
              ) : (
                <>
                  <Button type="button" variant="secondary" disabled={busy} onClick={() => setPrompt("Make it ")}>
                    Edit
                  </Button>
                  <Button type="button" variant="secondary" disabled={busy} onClick={() => void runAction("Create another version.")}>
                    Create variation
                  </Button>
                </>
              )}
              <Button
                type="button"
                variant="ghost"
                onClick={() => setSavedNote("Saved to your creations.")}
              >
                Save
              </Button>
            </div>
          ) : null}

          {savedNote ? (
            <p className="mt-3 text-sm text-ok" role="status">
              {savedNote}
            </p>
          ) : null}

          {photo && photo.kind === "photo" && photo.assets.length > 1 ? (
            <div className="mt-8">
              <p className="text-sm text-muted">Versions</p>
              <ul className="mt-3 flex flex-wrap gap-3">
                {photo.assets.map((asset) => (
                  <li key={asset.id}>
                    <button
                      type="button"
                      onClick={() =>
                        void restoreStudioAsset({ data: { id: photo.id, assetId: asset.id } }).then(setPhoto)
                      }
                      className={cn(
                        "overflow-hidden rounded-2xl",
                        photo.currentAssetId === asset.id ? "ring-2 ring-fg" : "",
                      )}
                    >
                      <img src={`/api/studio/media/${asset.id}`} alt={asset.role} className="size-16 object-cover" />
                    </button>
                    <span className="mt-1 block text-xs text-subtle">
                      {asset.role === "original" ? "Original" : `v${asset.versionN}`}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          {error ? (
            <p className="mt-6 text-sm text-danger" role="alert">
              {error}
            </p>
          ) : null}

          <div className="mt-10">
            <button
              type="button"
              className="min-h-11 text-sm text-muted hover:text-fg"
              onClick={() => setAdvanced((v) => !v)}
              aria-expanded={advanced}
            >
              {advanced ? "Hide advanced" : "Advanced"}
            </button>
            {advanced ? (
              <div className="mt-3 flex flex-col gap-4">
                <div className="flex flex-wrap gap-2" role="group" aria-label="Aspect">
                  {(["1:1", "16:9", "9:16"] as const).map((ratio) => (
                    <button
                      key={ratio}
                      type="button"
                      onClick={() => setAspect(ratio)}
                      className={cn(
                        "min-h-11 rounded-full px-4 text-sm",
                        aspect === ratio ? "bg-fg text-bg" : "bg-surface text-muted",
                      )}
                    >
                      {ratio === "1:1" ? "Square" : ratio === "16:9" ? "Landscape" : "Portrait"}
                    </button>
                  ))}
                </div>
                <label className="flex min-h-11 items-center gap-3 text-sm text-muted">
                  Duration
                  <input
                    type="range"
                    min={1}
                    max={SCENE_DURATION_MAX}
                    value={durationSec}
                    onChange={(e) => setDurationSec(Number(e.target.value))}
                  />
                  <span className="tabular-nums text-fg">{durationSec}s</span>
                </label>
                <div className="flex flex-wrap gap-2" role="group" aria-label="Quality">
                  {VIDEO_RESOLUTIONS.map((res) => (
                    <button
                      key={res}
                      type="button"
                      onClick={() => setVideoResolution(res)}
                      className={cn(
                        "min-h-11 rounded-full px-4 text-sm",
                        videoResolution === res ? "bg-fg text-bg" : "bg-surface text-muted",
                      )}
                    >
                      {VIDEO_RESOLUTION_LABELS[res]} {res}
                    </button>
                  ))}
                </div>
                <label className="flex min-h-11 items-center gap-3 text-sm text-muted">
                  Audio
                  <button
                    type="button"
                    role="switch"
                    aria-checked={generateAudio}
                    onClick={() => setGenerateAudio((v) => !v)}
                    className={cn("h-7 w-12 rounded-full", generateAudio ? "bg-accent" : "bg-surface-2")}
                  >
                    <span className={cn("block size-6 rounded-full bg-bg", generateAudio ? "translate-x-5" : "translate-x-0.5")} />
                  </button>
                </label>
                <p className="text-xs leading-relaxed text-subtle">
                  Native video is 15 seconds and 1080p at most. 4K, cuts, and slow motion are not offered.
                </p>
              </div>
            ) : null}
          </div>

          <section className="mt-16">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <p className="text-sm font-medium">Your creations</p>
              <div className="flex gap-1" role="tablist" aria-label="Filter creations">
                {(["all", "photos", "videos"] as const).map((id) => (
                  <button
                    key={id}
                    type="button"
                    role="tab"
                    aria-selected={filter === id}
                    onClick={() => setFilter(id)}
                    className={cn(
                      "min-h-11 rounded-full px-4 text-sm capitalize",
                      filter === id ? "bg-fg text-bg" : "text-muted hover:text-fg",
                    )}
                  >
                    {id}
                  </button>
                ))}
              </div>
            </div>
            {library === null ? (
              <p className="mt-4 text-sm text-muted">Loading</p>
            ) : items.length === 0 ? (
              <p className="mt-4 max-w-sm text-base leading-relaxed text-muted">
                Nothing here yet. Give AEVORA an idea, or attach a photo of your own.
              </p>
            ) : (
              <ul className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {items.slice(0, 8).map((item) => (
                  <li key={`${item.source}-${item.id}`}>
                    <button
                      type="button"
                      onClick={() => void openLibrary(item)}
                      className="flex min-h-24 w-full flex-col justify-end rounded-[1.5rem] bg-surface px-5 py-4 text-left transition-colors duration-150 hover:bg-surface-2"
                    >
                      <span className="text-xs uppercase tracking-wide text-subtle">{item.kind}</span>
                      <span className="font-display mt-1 text-xl tracking-tight">{item.title}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <button type="button" onClick={onOpenWriting} className="mt-8 min-h-11 text-sm text-muted hover:text-fg">
              Writing
            </button>
          </section>
        </div>
      </div>

      <form onSubmit={onSend} className="shrink-0 border-t border-border bg-bg px-4 py-3 md:px-10">
        <div className="mx-auto w-full max-w-3xl">
          {attachment ? (
            <div className="mb-3 flex items-center gap-3">
              {attachment.kind === "photo" ? (
                <img src={attachment.dataUri} alt="" className="size-12 rounded-xl object-cover" />
              ) : (
                <span className="text-sm text-muted">Clip attached</span>
              )}
              <button type="button" className="min-h-11 text-sm text-muted hover:text-fg" onClick={() => setAttachment(null)}>
                Remove
              </button>
            </div>
          ) : null}
          <div className="flex items-end gap-2 rounded-[1.75rem] bg-surface px-2 py-2">
            <input ref={fileRef} type="file" accept="image/*,video/mp4,video/quicktime" className="sr-only" onChange={onFile} />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Attach"
              onClick={() => fileRef.current?.click()}
            >
              <Plus className="size-5" />
            </Button>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={onComposerKey}
              rows={1}
              maxLength={2000}
              placeholder={available === false ? "Grok is not connected" : "Describe what you want…"}
              className="max-h-32 min-h-12 flex-1 resize-none bg-transparent px-2 py-3 text-base leading-relaxed outline-none placeholder:text-subtle"
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label={listening ? "Stop listening" : "Speak"}
              aria-pressed={listening}
              onClick={() => void toggleMic()}
            >
              <Mic className={cn("size-5", listening ? "text-accent" : "")} />
            </Button>
            <Button
              type="submit"
              size="icon"
              aria-label="Create"
              disabled={busy || (!prompt.trim() && !attachment) || available === false}
            >
              <ArrowUp className="size-5" />
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
