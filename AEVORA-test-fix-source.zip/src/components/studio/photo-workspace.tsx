import { useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import {
  animateStudioPhoto,
  createGeneratedPhoto,
  deleteStudioAsset,
  editStudioPhoto,
  getStudioCapabilities,
  getStudioProject,
  restoreStudioAsset,
  uploadStudioMedia,
  type StudioProject,
} from "@/lib/studio";
import { PHOTO_ASPECTS, publicStudioError } from "@/lib/studio-format";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function errorText(err: unknown): string {
  if (err instanceof Error) return publicStudioError(err.message);
  return publicStudioError(null);
}

export function PhotoWorkspace({
  mode,
  onBack,
  onOpenVideo,
  initialId,
}: {
  mode: "create" | "edit";
  onBack: () => void;
  onOpenVideo: () => void;
  initialId?: number;
}) {
  const [project, setProject] = useState<StudioProject | null>(null);
  const [prompt, setPrompt] = useState("");
  const [aspect, setAspect] = useState<(typeof PHOTO_ASPECTS)[number]>("1:1");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [available, setAvailable] = useState<boolean | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async (id: number) => {
    const next = await getStudioProject({ data: { id } });
    setProject(next);
  }, []);

  useEffect(() => {
    getStudioCapabilities()
      .then((caps) => setAvailable(caps.photoAvailable))
      .catch(() => setAvailable(false));
  }, []);

  useEffect(() => {
    if (!initialId) return;
    void load(initialId).catch((err) => setError(errorText(err)));
  }, [initialId, load]);

  async function onGenerate(e: FormEvent) {
    e.preventDefault();
    if (!prompt.trim() || busy) return;
    setBusy(true);
    setError(null);
    try {
      const next = await createGeneratedPhoto({ data: { prompt, aspectRatio: aspect } });
      setProject(next);
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  async function onEdit(e: FormEvent) {
    e.preventDefault();
    if (!project || !prompt.trim() || busy) return;
    setBusy(true);
    setError(null);
    try {
      const next = await editStudioPhoto({ data: { id: project.id, instruction: prompt } });
      setProject(next);
      setPrompt("");
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Use a JPEG, PNG, or WebP photo.");
      return;
    }
    if (file.size > 4_000_000) {
      setError("Keep photos under 4 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUri = typeof reader.result === "string" ? reader.result : "";
      setBusy(true);
      uploadStudioMedia({ data: { kind: "photo", dataUri, title: file.name } })
        .then((next) => {
          setProject(next);
          setError(null);
        })
        .catch((err) => setError(errorText(err)))
        .finally(() => setBusy(false));
    };
    reader.readAsDataURL(file);
  }

  async function onAnimate() {
    if (!project || busy) return;
    setBusy(true);
    setError(null);
    try {
      await animateStudioPhoto({ data: { id: project.id, prompt: prompt.trim() || undefined } });
      onOpenVideo();
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  const current = project?.currentAssetId;

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
      <header className="flex items-center justify-between px-5 pt-6 md:px-10">
        <button type="button" onClick={onBack} className="min-h-11 text-sm text-muted hover:text-fg">
          Studio
        </button>
        <p className="text-sm text-subtle">{mode === "create" ? "Create photo" : "Edit photo"}</p>
      </header>

      <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col px-5 pb-16 pt-6 md:px-10">
        <p className="text-sm font-medium tracking-wide text-accent">Photo</p>
        <h1 className="font-display mt-2 text-3xl tracking-tight md:text-5xl">
          {mode === "create" ? "Make a still." : "Change a picture you already have."}
        </h1>
        {available === false ? (
          <p className="mt-4 text-sm text-caution" role="status">
            Photo Studio is unavailable right now.
          </p>
        ) : null}

        <div className="mt-10 grid items-start gap-10 lg:grid-cols-2">
          <form onSubmit={project && (mode === "edit" || project.origin === "upload" || project.assets.some((a) => a.role === "edit")) ? onEdit : onGenerate}>
            {mode === "edit" && !project ? (
              <div>
                <input ref={fileRef} type="file" accept="image/*" capture="environment" className="sr-only" onChange={onFile} />
                <Button type="button" className="h-14 min-h-14" onClick={() => fileRef.current?.click()}>
                  Upload photo
                </Button>
                <p className="mt-3 text-sm text-muted">JPEG, PNG, or WebP. Under 4 MB. The original is never overwritten.</p>
              </div>
            ) : (
              <>
                <label htmlFor="photo-prompt" className="text-sm text-muted">
                  {project ? "What should change?" : "What do you want to see?"}
                </label>
                <textarea
                  id="photo-prompt"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={5}
                  maxLength={2000}
                  placeholder={project ? "Make the lighting darker…" : "A cinematic football photo at sunset…"}
                  className="mt-3 min-h-32 w-full rounded-[1.5rem] bg-surface px-5 py-4 text-base leading-relaxed outline-none focus-visible:ring-2 focus-visible:ring-accent/70"
                />
                {!project ? (
                  <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Aspect">
                    {PHOTO_ASPECTS.map((ratio) => (
                      <button
                        key={ratio}
                        type="button"
                        onClick={() => setAspect(ratio)}
                        className={cn(
                          "min-h-11 rounded-full px-4 text-sm",
                          aspect === ratio ? "bg-fg text-bg" : "bg-surface text-muted",
                        )}
                      >
                        {ratio}
                      </button>
                    ))}
                  </div>
                ) : null}
                <Button type="submit" className="mt-6 h-14 min-h-14 w-full max-w-xs" disabled={busy || !prompt.trim() || available === false}>
                  {busy ? "Working" : project ? "Apply edit" : "Generate"}
                </Button>
                {mode === "edit" && !project ? null : (
                  <input ref={fileRef} type="file" accept="image/*" className="sr-only" onChange={onFile} />
                )}
              </>
            )}
          </form>

          <section>
            {current ? (
              <img
                src={`/api/studio/media/${current}`}
                alt={project?.title || "Studio photo"}
                className="w-full rounded-[1.75rem] bg-surface object-contain"
              />
            ) : (
              <div className="flex min-h-72 items-center justify-center rounded-[1.75rem] bg-surface">
                <p className="px-6 text-sm text-muted">Your photo will appear here.</p>
              </div>
            )}
            {project?.currentAssetId && project.originalAssetId && project.currentAssetId !== project.originalAssetId ? (
              <p className="mt-3 text-sm text-muted">Original is still here. You can restore it.</p>
            ) : null}
          </section>
        </div>

        {error ? (
          <p className="mt-6 text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}

        {project ? (
          <div className="mt-10 flex flex-wrap gap-2">
            <Button type="button" variant="secondary" disabled={busy} onClick={() => void onAnimate()}>
              Bring to life
            </Button>
            {project.originalAssetId ? (
              <Button
                type="button"
                variant="ghost"
                onClick={() => void restoreStudioAsset({ data: { id: project.id, assetId: project.originalAssetId! } }).then(setProject)}
              >
                Restore original
              </Button>
            ) : null}
          </div>
        ) : null}

        {project && project.assets.length > 1 ? (
          <div className="mt-12">
            <p className="text-sm text-muted">Versions</p>
            <ul className="mt-4 flex flex-wrap gap-3">
              {project.assets.map((asset) => (
                <li key={asset.id}>
                  <button
                    type="button"
                    onClick={() => void restoreStudioAsset({ data: { id: project.id, assetId: asset.id } }).then(setProject)}
                    className={cn(
                      "overflow-hidden rounded-2xl",
                      project.currentAssetId === asset.id ? "ring-2 ring-fg" : "",
                    )}
                  >
                    <img src={`/api/studio/media/${asset.id}`} alt={asset.role} className="size-20 object-cover" />
                  </button>
                  {asset.role !== "original" ? (
                    <button
                      type="button"
                      className="mt-1 block text-xs text-muted hover:text-danger"
                      onClick={() => void deleteStudioAsset({ data: { id: project.id, assetId: asset.id } }).then(setProject)}
                    >
                      Remove
                    </button>
                  ) : (
                    <span className="mt-1 block text-xs text-subtle">Original</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>
    </div>
  );
}