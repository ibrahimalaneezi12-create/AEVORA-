import { useCallback, useEffect, useRef, useState } from "react";
import {
  ackNotificationAttempt,
  claimDueReminders,
  registerNotificationDevice,
  type ClaimedReminder,
} from "@/lib/reminders";

const DEVICE_KEY = "aegis.deviceKey";
const POLL_MS = 30_000;

function deviceKey(): string {
  if (typeof window === "undefined") return "";
  try {
    const existing = window.localStorage.getItem(DEVICE_KEY);
    if (existing && existing.length >= 8) return existing;
    const next =
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `dev-${Date.now()}`;
    window.localStorage.setItem(DEVICE_KEY, next);
    return next;
  } catch {
    return `dev-${Date.now()}`;
  }
}

function permissionState(): "default" | "granted" | "denied" {
  if (typeof Notification === "undefined") return "denied";
  if (Notification.permission === "granted") return "granted";
  if (Notification.permission === "denied") return "denied";
  return "default";
}

async function showOsNotification(item: ClaimedReminder): Promise<"delivered" | "skipped" | "failed"> {
  if (typeof Notification === "undefined") return "skipped";
  if (Notification.permission !== "granted") return "skipped";
  try {
    const n = new Notification(item.reminder.title, {
      body: item.reminder.body || "AEVORA reminder",
      tag: `aegis-reminder-${item.reminder.id}`,
      lang: item.reminder.locale,
    });
    n.onerror = () => undefined;
    return "delivered";
  } catch {
    return "failed";
  }
}

export function NotificationListener() {
  const [banner, setBanner] = useState<ClaimedReminder | null>(null);
  const keyRef = useRef("");
  const inflight = useRef(false);

  const tick = useCallback(async () => {
    if (inflight.current) return;
    inflight.current = true;
    try {
      const key = keyRef.current || deviceKey();
      keyRef.current = key;
      if (!key) return;
      const perm = permissionState();
      try {
        await registerNotificationDevice({
          data: {
            deviceKey: key,
            label: typeof navigator !== "undefined" ? navigator.userAgent.slice(0, 80) : "browser",
            permission: perm === "denied" ? "denied" : perm,
          },
        });
      } catch {
        // Device row is optional for in-app delivery.
      }
      const claimed = await claimDueReminders({ data: { deviceKey: key } });
      for (const item of claimed) {
        const status = await showOsNotification(item);
        setBanner(item);
        try {
          await ackNotificationAttempt({
            data: {
              reminderId: item.reminder.id,
              attemptId: item.attemptId,
              status,
              error: status === "failed" ? "Notification could not display." : "",
            },
          });
        } catch {
          // Claim already moved the row; retry on next tick.
        }
      }
    } catch {
      // Stay quiet; next visibility/poll retries.
    } finally {
      inflight.current = false;
    }
  }, []);

  useEffect(() => {
    keyRef.current = deviceKey();
    void tick();
    const id = window.setInterval(() => void tick(), POLL_MS);
    const onVis = () => {
      if (document.visibilityState === "visible") void tick();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [tick]);

  if (!banner) return null;
  return (
    <div
      role="status"
      data-reminder-banner="true"
      className="pointer-events-auto absolute inset-x-3 top-3 z-20 rounded-md border border-caution/40 bg-surface px-3 py-2 text-sm text-fg shadow-sm md:inset-x-auto md:end-4 md:max-w-sm"
    >
      <p className="font-medium">{banner.reminder.title}</p>
      {banner.reminder.body ? (
        <p className="mt-0.5 text-xs text-muted">{banner.reminder.body}</p>
      ) : null}
      <button
        type="button"
        className="mt-2 text-xs text-muted underline"
        onClick={() => setBanner(null)}
      >
        Dismiss
      </button>
    </div>
  );
}
