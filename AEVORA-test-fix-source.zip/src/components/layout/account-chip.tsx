import { useState } from "react";
import { signOut } from "@/lib/auth/client";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { clearPreviewSessionToken } from "@/lib/preview-session";
import { cn } from "@/lib/utils";

export function AccountChip({ compact = false }: { compact?: boolean }) {
  const user = useCurrentUser();
  const [signingOut, setSigningOut] = useState(false);
  if (!user) return null;
  const label = user.displayName ?? user.primaryEmail ?? "Account";

  async function leave() {
    setSigningOut(true);
    try {
      await signOut("/login");
    } catch {
      clearPreviewSessionToken();
      window.location.assign("/login");
    }
  }

  return (
    <div className={cn("flex items-center gap-2", compact && "justify-end")}>
      <span className="grid h-8 w-8 place-items-center rounded-full bg-surface-2 text-sm font-medium text-fg">
        {label.charAt(0).toUpperCase()}
      </span>
      {compact ? null : <span className="min-w-0 truncate text-sm font-medium">{label}</span>}
      <button
        type="button"
        disabled={signingOut}
        onClick={() => void leave()}
        className="cursor-pointer text-sm text-muted underline-offset-4 hover:text-fg hover:underline disabled:cursor-wait"
      >
        {signingOut ? "Signing out…" : "Sign out"}
      </button>
    </div>
  );
}
