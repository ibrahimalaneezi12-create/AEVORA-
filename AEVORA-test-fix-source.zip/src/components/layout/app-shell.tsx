import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  BookMarked,
  Briefcase,
  Flag,
  Home,
  LineChart,
  MessageSquare,
  PenLine,
  Settings,
} from "lucide-react";
import { AegisMark } from "@/components/brand/aegis-mark";
import { NotificationListener } from "@/components/layout/notification-listener";
import { AccountChip } from "@/components/layout/account-chip";
import {
  isWorkspaceChatHash,
  workspaceChatHash,
  workspaceChatPath,
  workspaceFromPathname,
} from "@/lib/chat-workspace";
import { cn } from "@/lib/utils";

type AppPath =
  | "/app"
  | "/app/chat"
  | "/app/memory"
  | "/app/goals"
  | "/app/reminders"
  | "/app/calendar"
  | "/app/mail"
  | "/app/create"
  | "/app/activity"
  | "/app/business"
  | "/app/invest"
  | "/app/settings";

type NavItem = {
  to: AppPath;
  label: string;
  icon: typeof Home;
  enabled: boolean;
  mobile?: boolean;
};

const NAV: NavItem[] = [
  { to: "/app", label: "Home", icon: Home, enabled: true },
  { to: "/app/chat", label: "Main Chat", icon: MessageSquare, enabled: true },
  { to: "/app/memory", label: "Memory", icon: BookMarked, enabled: true, mobile: false },
  { to: "/app/goals", label: "Plans", icon: Flag, enabled: true, mobile: false },
  { to: "/app/business", label: "Business", icon: Briefcase, enabled: true },
  { to: "/app/invest", label: "Invest", icon: LineChart, enabled: true },
  { to: "/app/create", label: "Studio", icon: PenLine, enabled: true, mobile: false },
  { to: "/app/settings", label: "Settings", icon: Settings, enabled: true },
];

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="h-dvh overflow-hidden bg-bg text-fg md:flex">
      <aside className="hidden h-full w-60 shrink-0 flex-col px-4 py-6 md:flex">
        <Link to="/app" className="mb-8 flex items-center gap-3 px-2">
          <AegisMark className="size-8" />
          <span className="font-display text-xl tracking-tight">AEVORA</span>
        </Link>
        <nav className="flex flex-1 flex-col gap-8 overflow-y-auto" aria-label="Main">
          <div className="flex flex-col gap-1">
            {NAV.filter((item) => item.to === "/app" || item.to === "/app/chat").map((item) => (
              <NavLink key={item.label} item={item} />
            ))}
          </div>
          <div className="flex flex-col gap-1">
            {NAV.filter((item) => item.to === "/app/memory" || item.to === "/app/goals").map((item) => (
              <NavLink key={item.label} item={item} />
            ))}
          </div>
          <div className="flex flex-col gap-1">
            {NAV.filter(
              (item) => item.to === "/app/business" || item.to === "/app/invest" || item.to === "/app/create",
            ).map((item) => (
              <NavLink key={item.label} item={item} />
            ))}
          </div>
          <div className="mt-auto flex flex-col gap-1">
            {NAV.filter((item) => item.to === "/app/settings").map((item) => (
              <NavLink key={item.label} item={item} />
            ))}
          </div>
        </nav>
        <div className="px-1 pt-6">
          <AccountChip />
        </div>
      </aside>

      <div className="flex h-full min-w-0 flex-1 flex-col">
        <div className="relative">
          <NotificationListener />
        </div>
        <header className="flex items-center justify-between gap-3 px-4 py-3 md:hidden">
          <Link to="/app" className="flex min-w-0 items-center gap-2">
            <AegisMark className="size-8 shrink-0" />
            <span className="font-display text-lg tracking-tight">AEVORA</span>
          </Link>
          <div className="flex min-w-0 justify-end overflow-hidden">
            <AccountChip compact />
          </div>
        </header>
        <div className="flex min-h-0 flex-1 flex-col overflow-hidden pb-[5.5rem] md:pb-0">{children}</div>
        <nav
          className="fixed inset-x-0 bottom-0 z-10 flex bg-bg/90 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur-md md:hidden"
          aria-label="Primary"
        >
          {NAV.filter((item) => item.enabled && item.mobile !== false).map((item) => (
            <NavLink key={item.label} item={item} mobile />
          ))}
        </nav>
      </div>
    </div>
  );
}

function NavLink({ item, mobile }: { item: NavItem; mobile?: boolean }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hash = useRouterState({ select: (s) => s.location.hash });
  const workspace = workspaceFromPathname(pathname);
  const inWorkspaceChat = isWorkspaceChatHash(hash);

  const target =
    item.to === "/app/chat" && workspace !== "main"
      ? { to: workspaceChatPath(workspace), hash: workspaceChatHash(workspace), label: "Chat" }
      : { to: item.to, hash: "", label: item.label };

  const active =
    item.to === "/app"
      ? pathname === "/app" || pathname === "/app/"
      : item.to === "/app/chat"
        ? workspace !== "main"
          ? inWorkspaceChat
          : pathname === "/app/chat" || pathname.startsWith("/app/chat/")
        : item.to === "/app/business" || item.to === "/app/invest"
          ? pathname === item.to && !inWorkspaceChat
          : pathname === item.to;
  const Icon = item.icon;
  const className = cn(
    "flex items-center gap-3 rounded-full px-3 text-sm transition-colors duration-150",
    mobile
      ? "h-12 min-h-12 flex-1 flex-col justify-center gap-1 px-1 text-[11px]"
      : "h-11 min-h-11",
    item.enabled
      ? active
        ? "bg-surface text-fg shadow-soft"
        : "text-muted hover:bg-surface-2/70 hover:text-fg"
      : "cursor-not-allowed text-subtle",
  );

  if (!item.enabled) {
    return (
      <span className={className} title="Opens in a later step" aria-disabled="true">
        <Icon className="size-4 shrink-0" strokeWidth={1.75} />
        {target.label}
      </span>
    );
  }

  return (
    <Link
      to={target.to}
      hash={target.hash}
      className={className}
      aria-current={active ? "page" : undefined}
    >
      <Icon className="size-4 shrink-0" strokeWidth={1.75} />
      {target.label}
    </Link>
  );
}

export function AppShellSkeleton() {
  return (
    <div className="h-dvh overflow-hidden bg-bg md:flex">
      <aside className="hidden h-full w-60 shrink-0 md:block" />
      <div className="flex-1 animate-pulse bg-surface/40" />
    </div>
  );
}
