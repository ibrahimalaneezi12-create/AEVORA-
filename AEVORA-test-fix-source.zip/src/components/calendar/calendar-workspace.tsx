import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { CalendarDays } from "lucide-react";
import { cancelCalendarEvent, createCalendarEvent, getCalendarStatus, listCalendarEvents, type CalendarConnection, type CalendarEvent } from "@/lib/calendar";
import { getEntitlement, planDisplayName, type Entitlement } from "@/lib/entitlements";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) return "Sign in to see your calendar.";
  if (err instanceof Error && err.message) return err.message;
  return "The calendar could not be loaded.";
}

function whenLabel(iso: string): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return iso;
  return new Date(t).toLocaleString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function dayKey(iso: string): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return "Unscheduled";
  return new Date(t).toLocaleDateString(undefined, {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
}

export function CalendarWorkspace() {
  const [rows, setRows] = useState<CalendarEvent[] | null>(null);
  const [status, setStatus] = useState<CalendarConnection | null>(null);
  const [plan, setPlan] = useState<Entitlement | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [startAt, setStartAt] = useState("");
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);

  const refresh = useCallback(() => {
    listCalendarEvents()
      .then((list) => {
        setRows(list);
        setError(null);
      })
      .catch((err) => setError(errorText(err)));
    getCalendarStatus()
      .then(setStatus)
      .catch(() => setStatus({ connected: false, status: "connection_error", detail: "Google Calendar is not connected." }));
    getEntitlement()
      .then(setPlan)
      .catch(() => setPlan(null));
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  async function onCreate(e: FormEvent) {
    e.preventDefault();
    if (!title.trim() || !startAt) return;
    setSaving(true);
    setError(null);
    try {
      await createCalendarEvent({
        data: {
          title: title.trim(),
          location: location.trim() || undefined,
          startAt: new Date(startAt).toISOString(),
        },
      });
      setTitle("");
      setLocation("");
      setStartAt("");
      refresh();
    } catch (err) {
      setError(errorText(err));
    } finally {
      setSaving(false);
    }
  }

  async function onCancel(id: number) {
    if (busyId) return;
    setBusyId(id);
    setError(null);
    try {
      await cancelCalendarEvent({ data: { id } });
      refresh();
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusyId(null);
    }
  }

  const grouped = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const row of rows ?? []) {
      const key = dayKey(row.startAt);
      const list = map.get(key) ?? [];
      list.push(row);
      map.set(key, list);
    }
    return [...map.entries()];
  }, [rows]);

  return (
    <main className="mx-auto w-full max-w-3xl min-h-0 flex-1 overflow-y-auto px-5 py-10 md:px-8">
      <p className="text-sm font-medium text-accent">Calendar</p>
      <h1 className="font-display mt-2 text-3xl tracking-tight">What’s next</h1>
      <p className="mt-3 max-w-xl text-base leading-relaxed text-muted">
        Your AEVORA calendar. Google is read-only when connected. Writes wait for your say.
      </p>

      <section className="mt-8" aria-label="Google Calendar">
        <div className="flex items-start gap-2">
          <CalendarDays className="mt-0.5 size-4 shrink-0 text-subtle" strokeWidth={1.75} />
          <div>
            <p className="text-sm font-medium">Google Calendar</p>
            <p className="mt-1 text-sm leading-relaxed text-muted">
              {status?.detail ?? "Checking connection."}
            </p>
            {status && !status.connected ? (
              <p className="mt-1 text-xs text-subtle">
                AEVORA will not invent Google events. Connect Google in this keep to read them.
              </p>
            ) : null}
          </div>
        </div>
      </section>

      {plan && !plan.fullAccess ? (
        <p className="mt-6 rounded-lg border border-border bg-surface p-5 text-sm leading-relaxed text-muted">
          This keep is on {planDisplayName(plan.plan)}. Calendar writes are not
          included. Chat, memory, and reminders still work.
        </p>
      ) : (
        <form onSubmit={onCreate} className="mt-6 rounded-lg border border-border bg-surface p-5">
          <h2 className="text-sm font-medium">Add an event</h2>
          <div className="mt-4 flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="cal-title">Title</Label>
              <Input
                id="cal-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                maxLength={120}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="cal-location">Place</Label>
              <Input
                id="cal-location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                maxLength={200}
                placeholder="Optional"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="cal-start">Starts</Label>
              <Input
                id="cal-start"
                type="datetime-local"
                value={startAt}
                onChange={(e) => setStartAt(e.target.value)}
                required
              />
            </div>
            <Button type="submit" disabled={saving || !title.trim() || !startAt}>
              {saving ? "Saving" : "Add to calendar"}
            </Button>
          </div>
        </form>
      )}

      {error ? (
        <p className="mt-4 text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}

      {rows && rows.length === 0 ? (
        <p className="mt-8 text-sm leading-relaxed text-muted">
          No upcoming events yet.{" "}
          <Link to="/app/chat" className="text-fg underline-offset-4 hover:underline">
            Ask AEVORA in chat
          </Link>
          .
        </p>
      ) : null}

      {grouped.length > 0 ? (
        <div className="mt-8 flex flex-col gap-6">
          {grouped.map(([day, items]) => (
            <section key={day} aria-label={day}>
              <h2 className="text-xs font-medium uppercase tracking-[0.14em] text-subtle">{day}</h2>
              <ul className="mt-2 flex flex-col gap-2">
                {items.map((row) => (
                  <li key={row.id} className="rounded-lg border border-border bg-surface p-4">
                    <p className="text-sm font-medium">{row.title}</p>
                    <p className="mt-1 text-xs text-muted">
                      {whenLabel(row.startAt)}
                      {row.location ? ` · ${row.location}` : ""}
                      {row.recurrence !== "once" ? ` · ${row.recurrence}` : ""}
                    </p>
                    {row.notes ? <p className="mt-2 text-sm leading-relaxed text-muted">{row.notes}</p> : null}
                    <div className="mt-3">
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        disabled={busyId === row.id}
                        onClick={() => void onCancel(row.id)}
                      >
                        Cancel event
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      ) : null}
    </main>
  );
}
