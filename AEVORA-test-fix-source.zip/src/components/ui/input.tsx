import { type InputHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...props }, ref) {
    return (
      <input
        ref={ref}
        className={cn(
          "h-12 min-h-12 w-full rounded-2xl border border-border bg-surface px-4 text-sm text-fg placeholder:text-subtle",
          "transition-[border-color,box-shadow] duration-150 ease-out",
          "focus-visible:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50",
          "disabled:opacity-40",
          className,
        )}
        {...props}
      />
    );
  },
);
