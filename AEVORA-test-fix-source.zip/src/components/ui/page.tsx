import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Page({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <main
      className={cn(
        "mx-auto w-full max-w-2xl min-h-0 flex-1 overflow-y-auto px-5 py-10 md:px-8",
        className,
      )}
    >
      {children}
    </main>
  );
}

export function PageHeader({
  kicker,
  title,
  lede,
}: {
  kicker?: string;
  title: string;
  lede?: string;
}) {
  return (
    <header className="max-w-xl">
      {kicker ? (
        <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-subtle">{kicker}</p>
      ) : null}
      <h1 className={cn("font-display tracking-tight", kicker ? "mt-2 text-3xl md:text-[2.6rem]" : "text-3xl md:text-[2.6rem]")}>
        {title}
      </h1>
      {lede ? <p className="mt-3 text-base leading-relaxed text-muted">{lede}</p> : null}
    </header>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-subtle">{children}</p>
  );
}

export function EmptyNote({ children }: { children: ReactNode }) {
  return <p className="mt-6 max-w-md text-sm leading-relaxed text-muted">{children}</p>;
}
