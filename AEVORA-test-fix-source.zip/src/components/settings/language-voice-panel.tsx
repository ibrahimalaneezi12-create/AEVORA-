import { useState } from "react";
import { APP_LOCALES, LOCALE_LABELS, applyDocumentLocale, localeLabel, type AppLocale } from "@/lib/locale";
import { voiceCopyFor } from "@/lib/voice-format";
import { CURATED_VOICES, resolveTtsVoiceId } from "@/lib/tts-format";
import { speakAudio } from "@/lib/tts";
import { splitSpeakableSentences } from "@/lib/speech-normalize";
import { applyTheme } from "@/lib/theme";
import { updateProfile, type Profile } from "@/lib/profile";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export function LanguageVoicePanel({
  profile,
  onSaved,
}: {
  profile: Profile;
  onSaved: (next: Profile) => void;
}) {
  const [locale, setLocale] = useState<AppLocale>(profile.locale);
  const [fallbackLanguage, setFallbackLanguage] = useState<AppLocale>(profile.fallbackLanguage);
  const [voiceEnabled, setVoiceEnabled] = useState(profile.voiceEnabled);
  const [voiceName, setVoiceName] = useState(profile.voiceName);
  const [detectLanguage, setDetectLanguage] = useState(profile.detectLanguage);
  const [voiceSpeed, setVoiceSpeed] = useState(profile.voiceSpeed);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const copy = voiceCopyFor(locale);

  async function save(partial?: {
    locale?: AppLocale;
    fallbackLanguage?: AppLocale;
    voiceEnabled?: boolean;
    voiceName?: string;
    detectLanguage?: boolean;
    voiceSpeed?: number;
  }) {
    setSaving(true);
    setError(null);
    setSaved(false);
    const nextLocale = partial?.locale ?? locale;
    const nextFallback = partial?.fallbackLanguage ?? fallbackLanguage;
    const nextEnabled = partial?.voiceEnabled ?? voiceEnabled;
    const nextName = partial?.voiceName ?? voiceName;
    const nextDetect = partial?.detectLanguage ?? detectLanguage;
    const nextSpeed = partial?.voiceSpeed ?? voiceSpeed;
    try {
      const next = await updateProfile({
        data: {
          displayName: profile.displayName ?? "",
          bio: profile.bio,
          timezone: profile.timezone,
          theme: profile.theme,
          locale: nextLocale,
          fallbackLanguage: nextFallback,
          voiceEnabled: nextEnabled,
          voiceName: nextName,
          detectLanguage: nextDetect,
          voiceSpeed: nextSpeed,
        },
      });
      setLocale(next.locale);
      setFallbackLanguage(next.fallbackLanguage);
      setVoiceEnabled(next.voiceEnabled);
      setVoiceName(next.voiceName);
      setDetectLanguage(next.detectLanguage);
      setVoiceSpeed(next.voiceSpeed);
      applyDocumentLocale(next.locale);
      applyTheme(next.theme);
      onSaved(next);
      setSaved(true);
    } catch (err) {
      if (err instanceof Error && /unauthorized/i.test(err.message)) {
        setError("Sign in to save your profile.");
      } else {
        setError("Could not save. Try once more.");
      }
    } finally {
      setSaving(false);
    }
  }

  async function preview() {
    const sample =
      locale === "ar" ? "أنا أيجيس. هذا الصوت المحدد." : "This is AEVORA. This is the selected voice.";
    const voiceId = resolveTtsVoiceId(voiceName);
    try {
      const result = await speakAudio({
        text: splitSpeakableSentences(sample)[0] ?? sample,
        voiceId,
        locale,
        speed: voiceSpeed,
      });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      const audio = new Audio(URL.createObjectURL(new Blob([result.audio], { type: result.mime })));
      audio.setAttribute("playsinline", "true");
      await audio.play();
    } catch {
      setError("Voice preview could not play.");
    }
  }

  return (
    <section className="mt-12 border-t border-border pt-8" aria-labelledby="language-voice-heading">
      <h2 id="language-voice-heading" className="font-display text-2xl tracking-tight">
        Language and voice
      </h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Voice and language are how you talk to AEVORA. They do not change what it
        is allowed to do.
      </p>

      <div className="mt-6 flex flex-col gap-5">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="preferred-language">Preferred language</Label>
          <select
            id="preferred-language"
            data-locale-select="true"
            value={locale}
            onChange={(e) => {
              const value = e.target.value;
              setLocale(value);
              setSaved(false);
              applyDocumentLocale(value);
              void save({ locale: value });
            }}
            className="h-11 min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg focus-visible:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50"
          >
            {APP_LOCALES.map((value) => {
              const label = LOCALE_LABELS[value] ?? localeLabel(value);
              return (
                <option key={value} value={value}>
                  {label.native} ({label.english})
                </option>
              );
            })}
          </select>
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="fallback-language">Fallback language</Label>
          <select
            id="fallback-language"
            value={fallbackLanguage}
            onChange={(e) => {
              const value = e.target.value;
              setFallbackLanguage(value);
              setSaved(false);
              void save({ fallbackLanguage: value });
            }}
            className="h-11 min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg focus-visible:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50"
          >
            {APP_LOCALES.map((value) => {
              const label = LOCALE_LABELS[value] ?? localeLabel(value);
              return (
                <option key={value} value={value}>
                  {label.english}
                </option>
              );
            })}
          </select>
        </div>

        <label className="flex min-h-11 items-center gap-3 text-sm text-fg">
          <input
            type="checkbox"
            checked={detectLanguage}
            onChange={(e) => {
              setDetectLanguage(e.target.checked);
              setSaved(false);
              void save({ detectLanguage: e.target.checked });
            }}
            className="size-4 accent-accent"
          />
          Detect language from what I say
        </label>

        <label className="flex min-h-11 items-center gap-3 text-sm text-fg">
          <input
            type="checkbox"
            checked={voiceEnabled}
            onChange={(e) => {
              setVoiceEnabled(e.target.checked);
              setSaved(false);
              void save({ voiceEnabled: e.target.checked });
            }}
            className="size-4 accent-accent"
          />
          Enable voice
        </label>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="voice-name">Voice</Label>
          <select
            id="voice-name"
            value={resolveTtsVoiceId(voiceName)}
            disabled={!voiceEnabled}
            onChange={(e) => {
              setVoiceName(e.target.value);
              setSaved(false);
              void save({ voiceName: e.target.value });
            }}
            className="h-11 min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg focus-visible:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50"
          >
            {CURATED_VOICES.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name} — {v.style}
              </option>
            ))}
          </select>
          <p className="text-xs text-muted">
            These are conversational voices. Intelligence does not change when you switch.
          </p>
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="voice-speed">Speaking speed</Label>
          <input
            id="voice-speed"
            type="range"
            min={0.7}
            max={1.5}
            step={0.1}
            value={voiceSpeed}
            disabled={!voiceEnabled}
            onChange={(e) => {
              const value = Number(e.target.value);
              setVoiceSpeed(value);
              setSaved(false);
              void save({ voiceSpeed: value });
            }}
            className="h-11 accent-accent"
          />
          <p className="text-xs tabular-nums text-muted">{voiceSpeed.toFixed(1)}×</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="secondary"
            disabled={!voiceEnabled || saving}
            onClick={preview}
          >
            {copy.preview}
          </Button>
          {saving ? <p className="text-xs text-muted">Saving</p> : null}
          {saved ? (
            <p className="text-xs text-muted" role="status">
              Saved.
            </p>
          ) : null}
        </div>
        {error ? (
          <p className="text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}
      </div>
    </section>
  );
}
