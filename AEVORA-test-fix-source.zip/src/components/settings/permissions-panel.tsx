import { useEffect, useState } from "react";
import {
  CONFIRM_FLOORS,
  getPermissionSettings,
  updatePermissionSettings,
  type ConfirmFloor,
  type PermissionSettings,
} from "@/lib/permissions";
import { listedTools } from "@/lib/orchestrator/catalog";
import { LevelBadge } from "@/components/permissions/level-badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { PermissionLevel } from "@/lib/orchestrator/types";

const FLOOR_COPY: Record<ConfirmFloor, { label: string; hint: string }> = {
  safe: {
    label: "As classified",
    hint: "Use the catalog. Default.",
  },
  review: {
    label: "At least Review",
    hint: "Safe tools confirm as Review.",
  },
  approval: {
    label: "At least Approval",
    hint: "Safe and Review confirm as Approval.",
  },
};

const LEVEL_COPY: Record<PermissionLevel, string> = {
  safe: "Compact confirm in chat. Still needs Approve.",
  review: "Card plus Activity. Still needs Approve.",
  approval: "Full confirmation page. Still needs Approve.",
  restricted: "Never runs. No override.",
};

export function PermissionsPanel() {
  const [settings, setSettings] = useState<PermissionSettings | null>(null);
  const [floor, setFloor] = useState<ConfirmFloor>("safe");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    getPermissionSettings()
      .then((row) => {
        if (cancelled) return;
        setSettings(row);
        setFloor(row.confirmFloor);
      })
      .catch((err) => {
        if (cancelled) return;
        if (err instanceof Error && /unauthorized/i.test(err.message)) {
          setLoadError("Sign in to manage permissions.");
        } else {
          setLoadError("Could not load permissions.");
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function onSave() {
    if (saving) return;
    setSaving(true);
    setSaveError(null);
    setSaved(false);
    try {
      const next = await updatePermissionSettings({ data: { confirmFloor: floor } });
      setSettings(next);
      setFloor(next.confirmFloor);
      setSaved(true);
    } catch (err) {
      if (err instanceof Error && /unauthorized/i.test(err.message)) {
        setSaveError("Sign in to save permissions.");
      } else {
        setSaveError("Could not save. Try once more.");
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="mt-12 border-t border-border pt-10" aria-label="Permissions">
      <h2 className="font-display text-2xl tracking-tight">Permissions</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        You can make confirmation louder. You cannot make it quieter than the
        catalog. Restricted actions stay blocked. Nothing runs without Approve.
      </p>

      {loadError ? (
        <p className="mt-6 text-sm text-danger" role="alert">
          {loadError}
        </p>
      ) : !settings ? (
        <div className="mt-6 space-y-3" aria-hidden="true">
          <div className="h-11 animate-pulse rounded-md bg-surface" />
          <div className="h-24 animate-pulse rounded-md bg-surface" />
        </div>
      ) : (
        <div className="mt-6 flex flex-col gap-6">
          <fieldset>
            <legend className="text-xs font-medium text-muted">Confirmation floor</legend>
            <div className="mt-2 grid gap-2 sm:grid-cols-3">
              {CONFIRM_FLOORS.map((value) => {
                const selected = floor === value;
                return (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => {
                      setFloor(value);
                      setSaved(false);
                    }}
                    className={cn(
                      "flex min-h-11 flex-col items-start justify-center rounded-md border px-3 py-2 text-left transition-colors duration-150",
                      selected
                        ? "border-border-strong bg-surface-2 text-fg"
                        : "border-border bg-surface text-muted hover:text-fg",
                    )}
                  >
                    <span className="text-sm font-medium">{FLOOR_COPY[value].label}</span>
                    <span className="text-xs text-subtle">{FLOOR_COPY[value].hint}</span>
                  </button>
                );
              })}
            </div>
          </fieldset>

          <div className="rounded-lg border border-border bg-surface p-5">
            <h3 className="text-sm font-medium text-fg">Auto-run</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              Off. It cannot be turned on. AEVORA never executes because a
              setting, a timer, or a chat reply said yes.
            </p>
            <p className="mt-2 text-xs uppercase tracking-[0.14em] text-subtle">
              Frozen
            </p>
          </div>

          <div>
            <h3 className="text-sm font-medium text-fg">Catalog</h3>
            <p className="mt-1 text-xs leading-relaxed text-subtle">
              Declared levels. The model cannot change these.
            </p>
            <ul className="mt-3 flex flex-col gap-2">
              {listedTools().map((tool) => (
                <li
                  key={tool.id}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-border bg-surface px-3 py-3"
                >
                  <div className="min-w-0">
                    <p className="text-sm text-fg">{tool.displayName}</p>
                    <p className="text-xs text-subtle">{tool.description}</p>
                  </div>
                  <LevelBadge level={tool.permissionLevel} />
                </li>
              ))}
            </ul>
            <ul className="mt-4 flex flex-col gap-1">
              {(["safe", "review", "approval", "restricted"] as const).map((level) => (
                <li key={level} className="flex flex-wrap items-baseline gap-2 text-xs text-muted">
                  <LevelBadge level={level} />
                  <span>{LEVEL_COPY[level]}</span>
                </li>
              ))}
            </ul>
          </div>

          {saveError ? (
            <p className="text-sm text-danger" role="alert">
              {saveError}
            </p>
          ) : null}
          {saved ? (
            <p className="text-sm text-muted" role="status">
              Permissions saved.
            </p>
          ) : null}
          <Button type="button" onClick={() => void onSave()} disabled={saving} className="w-full sm:w-auto">
            {saving ? "Saving" : "Save permissions"}
          </Button>
        </div>
      )}
    </section>
  );
}
