import { useState } from "react";
import { updateProfile, type Profile } from "@/lib/profile";
import {
  RESPONSE_STYLES,
  RESPONSE_STYLE_COPY,
  formatHourLabel,
  type ResponseStyle,
} from "@/lib/profile-format";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

const HOURS = Array.from({ length: 24 }, (_, i) => i);

export function KeepPreferencesPanel({
  profile,
  onSaved,
}: {
  profile: Profile;
  onSaved: (next: Profile) => void;
}) {
  const [pulseEnabled, setPulseEnabled] = useState(profile.pulseEnabled);
  const [responseStyle, setResponseStyle] = useState<ResponseStyle>(profile.responseStyle);
  const [quietStart, setQuietStart] = useState<string>(
    profile.quietHoursStart == null ? "" : String(profile.quietHoursStart),
  );
  const [quietEnd, setQuietEnd] = useState<string>(
    profile.quietHoursEnd == null ? "" : String(profile.quietHoursEnd),
  );
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function persist(partial: {
    pulseEnabled?: boolean;
    responseStyle?: ResponseStyle;
    quietHoursStart?: number | null;
    quietHoursEnd?: number | null;
  }) {
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      const next = await updateProfile({
        data: {
          displayName: profile.displayName ?? "",
          bio: profile.bio,
          timezone: profile.timezone,
          theme: profile.theme,
          locale: profile.locale,
          fallbackLanguage: profile.fallbackLanguage,
          voiceEnabled: profile.voiceEnabled,
          voiceName: profile.voiceName,
          detectLanguage: profile.detectLanguage,
          voiceSpeed: profile.voiceSpeed,
          pulseEnabled: partial.pulseEnabled ?? pulseEnabled,
          notifyReminders: profile.notifyReminders,
          notifyPulse: profile.notifyPulse,
          responseStyle: partial.responseStyle ?? responseStyle,
          quietHoursStart:
            partial.quietHoursStart !== undefined
              ? partial.quietHoursStart
              : quietStart === ""
                ? null
                : Number(quietStart),
          quietHoursEnd:
            partial.quietHoursEnd !== undefined
              ? partial.quietHoursEnd
              : quietEnd === ""
                ? null
                : Number(quietEnd),
        },
      });
      setPulseEnabled(next.pulseEnabled);
      setResponseStyle(next.responseStyle);
      setQuietStart(next.quietHoursStart == null ? "" : String(next.quietHoursStart));
      setQuietEnd(next.quietHoursEnd == null ? "" : String(next.quietHoursEnd));
      onSaved(next);
      setSaved(true);
    } catch (err) {
      if (err instanceof Error && /unauthorized/i.test(err.message)) {
        setError("Sign in to save your profile.");
      } else {
        setError("Could not save. Try once more.");
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="mt-12 border-t border-border pt-8" aria-labelledby="keep-prefs-heading">
      <h2 id="keep-prefs-heading" className="font-display text-2xl tracking-tight">
        Pulse and tone
      </h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Pulse only uses what is already in the keep. It will not invent urgency
        or run actions.
      </p>

      <div className="mt-6 flex flex-col gap-5">
        <label className="flex min-h-11 items-center gap-3 text-sm text-fg">
          <input
            type="checkbox"
            checked={pulseEnabled}
            onChange={(e) => {
              setPulseEnabled(e.target.checked);
              setSaved(false);
              void persist({ pulseEnabled: e.target.checked });
            }}
            className="size-4 accent-accent"
          />
          Enable Pulse
        </label>

        <fieldset>
          <legend className="text-xs font-medium text-muted">Reply style</legend>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {RESPONSE_STYLES.map((value) => {
              const selected = responseStyle === value;
              return (
                <button
                  key={value}
                  type="button"
                  aria-pressed={selected}
                  onClick={() => {
                    setResponseStyle(value);
                    setSaved(false);
                    void persist({ responseStyle: value });
                  }}
                  className={cn(
                    "flex min-h-11 flex-col items-start justify-center rounded-md border px-3 py-2 text-left transition-colors duration-150",
                    selected
                      ? "border-border-strong bg-surface-2 text-fg"
                      : "border-border bg-surface text-muted hover:text-fg",
                  )}
                >
                  <span className="text-sm font-medium">{RESPONSE_STYLE_COPY[value].label}</span>
                  <span className="text-xs text-subtle">{RESPONSE_STYLE_COPY[value].hint}</span>
                </button>
              );
            })}
          </div>
        </fieldset>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="quiet-start">Quiet hours start</Label>
            <select
              id="quiet-start"
              value={quietStart}
              onChange={(e) => {
                const value = e.target.value;
                setQuietStart(value);
                setSaved(false);
                void persist({
                  quietHoursStart: value === "" ? null : Number(value),
                  quietHoursEnd: quietEnd === "" ? null : Number(quietEnd),
                });
              }}
              className="h-11 min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg focus-visible:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50"
            >
              <option value="">Off</option>
              {HOURS.map((hour) => (
                <option key={hour} value={hour}>
                  {formatHourLabel(hour)}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="quiet-end">Quiet hours end</Label>
            <select
              id="quiet-end"
              value={quietEnd}
              onChange={(e) => {
                const value = e.target.value;
                setQuietEnd(value);
                setSaved(false);
                void persist({
                  quietHoursStart: quietStart === "" ? null : Number(quietStart),
                  quietHoursEnd: value === "" ? null : Number(value),
                });
              }}
              className="h-11 min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg focus-visible:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50"
            >
              <option value="">Off</option>
              {HOURS.map((hour) => (
                <option key={hour} value={hour}>
                  {formatHourLabel(hour)}
                </option>
              ))}
            </select>
          </div>
        </div>
        <p className="text-xs text-subtle">Both bounds are required. A lone bound is treated as off.</p>

        {saving ? <p className="text-xs text-muted">Saving</p> : null}
        {saved ? (
          <p className="text-xs text-muted" role="status">
            Saved.
          </p>
        ) : null}
        {error ? (
          <p className="text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}
      </div>
    </section>
  );
}
