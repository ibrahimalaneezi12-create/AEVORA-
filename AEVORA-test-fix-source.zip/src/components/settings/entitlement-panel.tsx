import { useEffect, useState } from "react";
import { getEntitlement, type Entitlement } from "@/lib/entitlements";
import { planDisplayName } from "@/lib/entitlements-format";

export function EntitlementPanel() {
  const [row, setRow] = useState<Entitlement | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getEntitlement()
      .then(setRow)
      .catch(() => setError("Could not load your plan."));
  }, []);

  return (
    <section className="mt-12 border-t border-border pt-8" aria-labelledby="plan-heading">
      <h2 id="plan-heading" className="font-display text-2xl tracking-tight">
        Plan
      </h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Your plan is decided on the server. It never bypasses confirmation or
        lets one keep see another.
      </p>
      {error ? (
        <p className="mt-4 text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
      {row ? (
        <div className="mt-5 rounded-lg border border-border bg-surface p-5" data-entitlement-plan={row.plan}>
          <p className="text-xs uppercase tracking-[0.16em] text-subtle">Current</p>
          <p className="mt-2 font-display text-2xl tracking-tight">
            {planDisplayName(row.plan)}
          </p>
          <p className="mt-1 text-sm text-muted">{row.price}</p>
          {row.plan === "founder" ? (
            <p className="mt-3 text-sm leading-relaxed text-muted">
              Founder access is full product use at £0. Security, confirmation,
              and the tool registry still apply. No broker is connected, so
              investment orders stay off.
            </p>
          ) : (
            <p className="mt-3 text-sm leading-relaxed text-muted">
              Checkout is not connected. This keep stays on the plan granted
              on the server. Free covers personal AEVORA plus basic Business and
              Invest. Plus adds live research and investment copilot proposals.
              Pro is the business manager and the investment operator. No broker
              is connected, so no order can run, and no business system is being
              watched in the background.
            </p>
          )}
        </div>
      ) : null}
    </section>
  );
}
