import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Check, Pencil, Plus, RotateCcw, Trash2 } from "lucide-react";
import {
  GOAL_DESC_MAX,
  GOAL_STATUSES,
  GOAL_TITLE_MAX,
  TASK_NOTES_MAX,
  TASK_STATUSES,
  TASK_TITLE_MAX,
  createGoal,
  createTask,
  deleteGoal,
  deleteTask,
  listGoalsPage,
  updateGoal,
  updateTask,
  type Goal,
  type GoalStatus,
  type Task,
  type TaskStatus,
} from "@/lib/goals";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

const GOAL_COPY: Record<GoalStatus, string> = {
  active: "Active",
  paused: "Paused",
  done: "Done",
  archived: "Archived",
};

const TASK_COPY: Record<TaskStatus, string> = {
  todo: "To do",
  doing: "Doing",
  done: "Done",
  cancelled: "Cancelled",
};

type GoalDraft = {
  title: string;
  description: string;
  status: GoalStatus;
  targetDate: string;
};

type TaskDraft = {
  title: string;
  notes: string;
  status: TaskStatus;
  dueDate: string;
  goalId: number | null;
};

const EMPTY_GOAL: GoalDraft = {
  title: "",
  description: "",
  status: "active",
  targetDate: "",
};

const EMPTY_TASK: TaskDraft = {
  title: "",
  notes: "",
  status: "todo",
  dueDate: "",
  goalId: null,
};

function errorText(err: unknown, kind: "goal" | "task"): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) {
    return "Sign in to manage goals and tasks.";
  }
  if (err instanceof Error && /not found/i.test(err.message)) {
    return kind === "goal" ? "That goal was not found." : "That task was not found.";
  }
  return "The request did not complete. Try once more.";
}

export function GoalsWorkspace() {
  const [goals, setGoals] = useState<Goal[] | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [goalEditing, setGoalEditing] = useState<"new" | number | null>(null);
  const [goalDraft, setGoalDraft] = useState<GoalDraft>(EMPTY_GOAL);
  const [taskEditing, setTaskEditing] = useState<"new" | number | null>(null);
  const [taskDraft, setTaskDraft] = useState<TaskDraft>(EMPTY_TASK);

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [deletingGoalId, setDeletingGoalId] = useState<number | null>(null);
  const [deletingTaskId, setDeletingTaskId] = useState<number | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    listGoalsPage()
      .then((page) => {
        setGoals(page.goals);
        setTasks(page.tasks);
        setLoadError(null);
      })
      .catch((err) => {
        setLoadError(errorText(err, "goal"));
      });
  }, []);

  function closeForms() {
    setGoalEditing(null);
    setTaskEditing(null);
    setGoalDraft(EMPTY_GOAL);
    setTaskDraft(EMPTY_TASK);
    setSaveError(null);
  }

  function openNewGoal() {
    setTaskEditing(null);
    setGoalEditing("new");
    setGoalDraft(EMPTY_GOAL);
    setSaveError(null);
  }

  function openEditGoal(row: Goal) {
    setTaskEditing(null);
    setGoalEditing(row.id);
    setGoalDraft({
      title: row.title,
      description: row.description,
      status: row.status,
      targetDate: row.targetDate ?? "",
    });
    setSaveError(null);
  }

  function openNewTask(goalId: number | null) {
    setGoalEditing(null);
    setTaskEditing("new");
    setTaskDraft({ ...EMPTY_TASK, goalId });
    setSaveError(null);
  }

  function openEditTask(row: Task) {
    setGoalEditing(null);
    setTaskEditing(row.id);
    setTaskDraft({
      title: row.title,
      notes: row.notes,
      status: row.status,
      dueDate: row.dueDate ?? "",
      goalId: row.goalId,
    });
    setSaveError(null);
  }

  async function onSaveGoal(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    setSaveError(null);
    try {
      const payload = {
        title: goalDraft.title,
        description: goalDraft.description,
        status: goalDraft.status,
        targetDate: goalDraft.targetDate || null,
      };
      const savedRow =
        goalEditing === "new"
          ? await createGoal({ data: payload })
          : await updateGoal({ data: { id: goalEditing as number, ...payload } });
      setGoals((prev) => {
        const rest = (prev ?? []).filter((g) => g.id !== savedRow.id);
        return [savedRow, ...rest];
      });
      closeForms();
    } catch (err) {
      setSaveError(errorText(err, "goal"));
    } finally {
      setSaving(false);
    }
  }

  async function onSaveTask(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    setSaveError(null);
    try {
      const payload = {
        title: taskDraft.title,
        notes: taskDraft.notes,
        status: taskDraft.status,
        dueDate: taskDraft.dueDate || null,
        goalId: taskDraft.goalId,
      };
      const savedRow =
        taskEditing === "new"
          ? await createTask({ data: payload })
          : await updateTask({ data: { id: taskEditing as number, ...payload } });
      setTasks((prev) => {
        const rest = prev.filter((t) => t.id !== savedRow.id);
        return [...rest, savedRow].sort((a, b) => a.sortOrder - b.sortOrder || a.id - b.id);
      });
      closeForms();
    } catch (err) {
      setSaveError(errorText(err, "task"));
    } finally {
      setSaving(false);
    }
  }

  async function setGoalStatus(row: Goal, status: GoalStatus) {
    const key = `goal-${row.id}`;
    if (busyId) return;
    setBusyId(key);
    try {
      const savedRow = await updateGoal({
        data: {
          id: row.id,
          title: row.title,
          description: row.description,
          status,
          targetDate: row.targetDate,
        },
      });
      setGoals((prev) => (prev ?? []).map((g) => (g.id === savedRow.id ? savedRow : g)));
    } catch (err) {
      setLoadError(errorText(err, "goal"));
    } finally {
      setBusyId(null);
    }
  }

  async function setTaskStatus(row: Task, status: TaskStatus) {
    const key = `task-${row.id}`;
    if (busyId) return;
    setBusyId(key);
    try {
      const savedRow = await updateTask({
        data: {
          id: row.id,
          title: row.title,
          notes: row.notes,
          status,
          dueDate: row.dueDate,
          goalId: row.goalId,
        },
      });
      setTasks((prev) => prev.map((t) => (t.id === savedRow.id ? savedRow : t)));
    } catch (err) {
      setLoadError(errorText(err, "task"));
    } finally {
      setBusyId(null);
    }
  }

  async function onConfirmDeleteGoal(id: number) {
    const key = `goal-${id}`;
    if (busyId) return;
    setBusyId(key);
    try {
      await deleteGoal({ data: { id } });
      setGoals((prev) => (prev ?? []).filter((g) => g.id !== id));
      setTasks((prev) =>
        prev.map((t) => (t.goalId === id ? { ...t, goalId: null } : t)),
      );
      if (goalEditing === id) closeForms();
      setDeletingGoalId(null);
    } catch (err) {
      setLoadError(errorText(err, "goal"));
    } finally {
      setBusyId(null);
    }
  }

  async function onConfirmDeleteTask(id: number) {
    const key = `task-${id}`;
    if (busyId) return;
    setBusyId(key);
    try {
      await deleteTask({ data: { id } });
      setTasks((prev) => prev.filter((t) => t.id !== id));
      if (taskEditing === id) closeForms();
      setDeletingTaskId(null);
    } catch (err) {
      setLoadError(errorText(err, "task"));
    } finally {
      setBusyId(null);
    }
  }

  const inbox = tasks.filter((t) => t.goalId == null);
  const loaded = goals !== null;

  return (
    <main className="mx-auto flex w-full max-w-2xl min-h-0 flex-1 flex-col overflow-y-auto px-5 py-10 md:px-8">
      <p className="text-sm font-medium text-accent">Plans</p>
      <h1 className="font-display mt-2 text-3xl tracking-tight">What you’re working toward</h1>
      <p className="mt-3 max-w-xl text-base leading-relaxed text-muted">
        The aim, the current work, and the next action. Large missions start in chat.
      </p>
      <p className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm text-subtle">
        <Link to="/app/calendar" className="hover:text-fg">Calendar</Link>
        <Link to="/app/reminders" className="hover:text-fg">Reminders</Link>
        <Link to="/app/mail" className="hover:text-fg">Mail</Link>
        <Link to="/app/activity" className="hover:text-fg">Activity</Link>
      </p>

      <div className="mt-6 flex flex-wrap gap-2">
        <Button type="button" onClick={openNewGoal} disabled={goalEditing === "new"}>
          <Plus className="size-4" strokeWidth={1.75} />
          Add goal
        </Button>
        <Button
          type="button"
          variant="secondary"
          onClick={() => openNewTask(null)}
          disabled={taskEditing === "new"}
        >
          <Plus className="size-4" strokeWidth={1.75} />
          Add task
        </Button>
      </div>

      {goalEditing !== null ? (
        <form
          onSubmit={onSaveGoal}
          className="mt-6 flex flex-col gap-5 rounded-lg border border-border bg-surface p-5"
          aria-label={goalEditing === "new" ? "New goal" : "Edit goal"}
        >
          <Field label="Title" htmlFor="goal-title">
            <Input
              id="goal-title"
              value={goalDraft.title}
              onChange={(e) => setGoalDraft((d) => ({ ...d, title: e.target.value }))}
              maxLength={GOAL_TITLE_MAX}
              placeholder="What you are working toward"
            />
          </Field>
          <Field label="Description" htmlFor="goal-description">
            <Textarea
              id="goal-description"
              value={goalDraft.description}
              onChange={(e) =>
                setGoalDraft((d) => ({ ...d, description: e.target.value }))
              }
              maxLength={GOAL_DESC_MAX}
              rows={3}
              placeholder="Optional"
            />
          </Field>
          <fieldset>
            <legend className="text-xs font-medium text-muted">Status</legend>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {GOAL_STATUSES.map((value) => {
                const selected = goalDraft.status === value;
                return (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => setGoalDraft((d) => ({ ...d, status: value }))}
                    className={cn(
                      "flex min-h-11 items-center justify-center rounded-md border px-2 py-2 text-sm transition-colors duration-150",
                      selected
                        ? "border-border-strong bg-surface-2 text-fg"
                        : "border-border bg-bg text-muted hover:text-fg",
                    )}
                  >
                    {GOAL_COPY[value]}
                  </button>
                );
              })}
            </div>
          </fieldset>
          <Field label="Target date" htmlFor="goal-target">
            <Input
              id="goal-target"
              type="date"
              value={goalDraft.targetDate}
              onChange={(e) =>
                setGoalDraft((d) => ({ ...d, targetDate: e.target.value }))
              }
            />
          </Field>
          {saveError ? (
            <p className="text-sm text-danger" role="alert">
              {saveError}
            </p>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <Button type="submit" disabled={saving || !goalDraft.title.trim()}>
              {saving ? "Saving" : goalEditing === "new" ? "Save goal" : "Save changes"}
            </Button>
            <Button type="button" variant="secondary" onClick={closeForms} disabled={saving}>
              Cancel
            </Button>
          </div>
        </form>
      ) : null}

      {taskEditing !== null ? (
        <form
          onSubmit={onSaveTask}
          className="mt-6 flex flex-col gap-5 rounded-lg border border-border bg-surface p-5"
          aria-label={taskEditing === "new" ? "New task" : "Edit task"}
        >
          <Field label="Title" htmlFor="task-title">
            <Input
              id="task-title"
              value={taskDraft.title}
              onChange={(e) => setTaskDraft((d) => ({ ...d, title: e.target.value }))}
              maxLength={TASK_TITLE_MAX}
              placeholder="A single piece of work"
            />
          </Field>
          <Field label="Notes" htmlFor="task-notes">
            <Textarea
              id="task-notes"
              value={taskDraft.notes}
              onChange={(e) => setTaskDraft((d) => ({ ...d, notes: e.target.value }))}
              maxLength={TASK_NOTES_MAX}
              rows={3}
              placeholder="Optional"
            />
          </Field>
          <Field label="Linked goal" htmlFor="task-goal">
            <select
              id="task-goal"
              value={taskDraft.goalId ?? ""}
              onChange={(e) =>
                setTaskDraft((d) => ({
                  ...d,
                  goalId: e.target.value ? Number(e.target.value) : null,
                }))
              }
              className="h-11 min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg focus-visible:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50"
            >
              <option value="">No goal — Inbox</option>
              {(goals ?? []).map((g) => (
                <option key={g.id} value={g.id}>
                  {g.title}
                </option>
              ))}
            </select>
          </Field>
          <fieldset>
            <legend className="text-xs font-medium text-muted">Status</legend>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {TASK_STATUSES.map((value) => {
                const selected = taskDraft.status === value;
                return (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => setTaskDraft((d) => ({ ...d, status: value }))}
                    className={cn(
                      "flex min-h-11 items-center justify-center rounded-md border px-2 py-2 text-sm transition-colors duration-150",
                      selected
                        ? "border-border-strong bg-surface-2 text-fg"
                        : "border-border bg-bg text-muted hover:text-fg",
                    )}
                  >
                    {TASK_COPY[value]}
                  </button>
                );
              })}
            </div>
          </fieldset>
          <Field label="Due date" htmlFor="task-due">
            <Input
              id="task-due"
              type="date"
              value={taskDraft.dueDate}
              onChange={(e) => setTaskDraft((d) => ({ ...d, dueDate: e.target.value }))}
            />
          </Field>
          {saveError ? (
            <p className="text-sm text-danger" role="alert">
              {saveError}
            </p>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <Button type="submit" disabled={saving || !taskDraft.title.trim()}>
              {saving ? "Saving" : taskEditing === "new" ? "Save task" : "Save changes"}
            </Button>
            <Button type="button" variant="secondary" onClick={closeForms} disabled={saving}>
              Cancel
            </Button>
          </div>
        </form>
      ) : null}

      {loadError ? (
        <p className="mt-6 text-sm text-danger" role="alert">
          {loadError}
        </p>
      ) : null}

      {!loaded && !loadError ? (
        <div className="mt-8 space-y-3" aria-hidden="true">
          <div className="h-24 animate-pulse rounded-lg bg-surface" />
          <div className="h-24 animate-pulse rounded-lg bg-surface" />
        </div>
      ) : loaded && goals.length === 0 && tasks.length === 0 && goalEditing === null && taskEditing === null ? (
        <p className="mt-8 max-w-md text-sm leading-relaxed text-muted">
          Nothing yet. Add a goal, then a task, and link them when it helps.
        </p>
      ) : loaded ? (
        <div className="mt-8 flex flex-col gap-4">
          {goals.map((goal) => {
            const linked = tasks.filter((t) => t.goalId === goal.id);
            return (
              <article
                key={goal.id}
                className="rounded-lg border border-border bg-surface p-5"
                aria-label={`Goal: ${goal.title}`}
              >
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs uppercase tracking-[0.14em] text-subtle">
                    {GOAL_COPY[goal.status]}
                  </span>
                  {goal.targetDate ? (
                    <span className="text-xs text-subtle">{goal.targetDate}</span>
                  ) : null}
                </div>
                <h2 className="mt-3 text-sm font-medium text-fg">{goal.title}</h2>
                {goal.description ? (
                  <p className="mt-1 text-sm leading-relaxed text-muted">{goal.description}</p>
                ) : null}
                <div className="mt-4 flex flex-wrap gap-2">
                  {goal.status === "done" ? (
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      disabled={busyId === `goal-${goal.id}`}
                      onClick={() => void setGoalStatus(goal, "active")}
                      aria-label={`Reopen ${goal.title}`}
                    >
                      <RotateCcw className="size-4" strokeWidth={1.75} />
                      Reopen
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      disabled={busyId === `goal-${goal.id}`}
                      onClick={() => void setGoalStatus(goal, "done")}
                      aria-label={`Mark ${goal.title} done`}
                    >
                      <Check className="size-4" strokeWidth={1.75} />
                      Mark done
                    </Button>
                  )}
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => openEditGoal(goal)}
                    aria-label={`Edit goal ${goal.title}`}
                  >
                    <Pencil className="size-4" strokeWidth={1.75} />
                    Edit
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => openNewTask(goal.id)}
                    aria-label={`Add task to ${goal.title}`}
                  >
                    <Plus className="size-4" strokeWidth={1.75} />
                    Add task
                  </Button>
                  {deletingGoalId === goal.id ? (
                    <>
                      <Button
                        type="button"
                        variant="secondary"
                        size="sm"
                        className="border-danger/40 text-danger"
                        disabled={busyId === `goal-${goal.id}`}
                        onClick={() => void onConfirmDeleteGoal(goal.id)}
                        aria-label={`Confirm delete goal ${goal.title}`}
                      >
                        <Trash2 className="size-4" strokeWidth={1.75} />
                        Confirm delete
                      </Button>
                      <Button type="button" variant="ghost" size="sm" onClick={() => setDeletingGoalId(null)}>
                        Cancel
                      </Button>
                    </>
                  ) : (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeletingGoalId(goal.id)}
                      aria-label={`Delete goal ${goal.title}`}
                    >
                      <Trash2 className="size-4" strokeWidth={1.75} />
                      Delete
                    </Button>
                  )}
                </div>
                {linked.length > 0 ? (
                  <ul className="mt-4 flex flex-col gap-2 border-t border-border pt-4">
                    {linked.map((task) => (
                      <li key={task.id}>
                        <TaskRow
                          task={task}
                          goalTitle={goal.title}
                          busy={busyId === `task-${task.id}`}
                          deleting={deletingTaskId === task.id}
                          onDone={() =>
                            void setTaskStatus(
                              task,
                              task.status === "done" ? "todo" : "done",
                            )
                          }
                          onEdit={() => openEditTask(task)}
                          onAskDelete={() => setDeletingTaskId(task.id)}
                          onCancelDelete={() => setDeletingTaskId(null)}
                          onConfirmDelete={() => void onConfirmDeleteTask(task.id)}
                        />
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-4 text-xs text-subtle">No tasks linked yet.</p>
                )}
              </article>
            );
          })}

          <section aria-label="Inbox">
            <h2 className="text-sm font-medium text-fg">Inbox</h2>
            <p className="mt-1 text-xs leading-relaxed text-subtle">
              Tasks with no goal. Link them when you know the aim.
            </p>
            {inbox.length === 0 ? (
              <p className="mt-3 text-sm text-muted">Inbox is empty.</p>
            ) : (
              <ul className="mt-3 flex flex-col gap-2">
                {inbox.map((task) => (
                  <li key={task.id}>
                    <div className="rounded-lg border border-border bg-surface p-4">
                      <TaskRow
                        task={task}
                        busy={busyId === `task-${task.id}`}
                        deleting={deletingTaskId === task.id}
                        onDone={() =>
                          void setTaskStatus(
                            task,
                            task.status === "done" ? "todo" : "done",
                          )
                        }
                        onEdit={() => openEditTask(task)}
                        onAskDelete={() => setDeletingTaskId(task.id)}
                        onCancelDelete={() => setDeletingTaskId(null)}
                        onConfirmDelete={() => void onConfirmDeleteTask(task.id)}
                      />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      ) : null}
    </main>
  );
}

function TaskRow({
  task,
  goalTitle,
  busy,
  deleting,
  onDone,
  onEdit,
  onAskDelete,
  onCancelDelete,
  onConfirmDelete,
}: {
  task: Task;
  goalTitle?: string;
  busy: boolean;
  deleting: boolean;
  onDone: () => void;
  onEdit: () => void;
  onAskDelete: () => void;
  onCancelDelete: () => void;
  onConfirmDelete: () => void;
}) {
  return (
    <article aria-label={`Task: ${task.title}`}>
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs uppercase tracking-[0.14em] text-subtle">
          {TASK_COPY[task.status]}
        </span>
        {task.dueDate ? <span className="text-xs text-subtle">{task.dueDate}</span> : null}
        {goalTitle ? (
          <span className="text-xs text-subtle">Linked to {goalTitle}</span>
        ) : null}
      </div>
      <p className="mt-2 text-sm font-medium text-fg">{task.title}</p>
      {task.notes ? (
        <p className="mt-1 text-sm leading-relaxed text-muted">{task.notes}</p>
      ) : null}
      <div className="mt-3 flex flex-wrap gap-2">
        <Button
          type="button"
          variant="secondary"
          size="sm"
          disabled={busy}
          onClick={onDone}
          aria-label={
            task.status === "done" ? `Reopen ${task.title}` : `Mark ${task.title} done`
          }
        >
          {task.status === "done" ? (
            <RotateCcw className="size-4" strokeWidth={1.75} />
          ) : (
            <Check className="size-4" strokeWidth={1.75} />
          )}
          {task.status === "done" ? "Reopen" : "Mark done"}
        </Button>
        <Button type="button" variant="secondary" size="sm" onClick={onEdit} aria-label={`Edit task ${task.title}`}>
          <Pencil className="size-4" strokeWidth={1.75} />
          Edit
        </Button>
        {deleting ? (
          <>
            <Button
              type="button"
              variant="secondary"
              size="sm"
              className="border-danger/40 text-danger"
              disabled={busy}
              onClick={onConfirmDelete}
              aria-label={`Confirm delete task ${task.title}`}
            >
              <Trash2 className="size-4" strokeWidth={1.75} />
              Confirm delete
            </Button>
            <Button type="button" variant="ghost" size="sm" onClick={onCancelDelete}>
              Cancel
            </Button>
          </>
        ) : (
          <Button type="button" variant="ghost" size="sm" onClick={onAskDelete} aria-label={`Delete task ${task.title}`}>
            <Trash2 className="size-4" strokeWidth={1.75} />
            Delete
          </Button>
        )}
      </div>
    </article>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
    </div>
  );
}
