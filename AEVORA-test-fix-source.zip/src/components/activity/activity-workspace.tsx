import { useCallback, useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ScrollText, Shield } from "lucide-react";
import {
  ACTIVITY_LEVEL_FILTERS,
  encodeCursor,
  listActivity,
  type ActivityEvent,
  type ActivityLevelFilter,
  type ActivityPage,
  type ActivityPending,
} from "@/lib/audit";
import { relativeLabel } from "@/lib/dashboard-format";
import { LevelBadge } from "@/components/permissions/level-badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const LEVEL_COPY: Record<ActivityLevelFilter, string> = {
  all: "All",
  safe: "Safe",
  review: "Review",
  approval: "Approval",
  restricted: "Restricted",
};

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) {
    return "Sign in to read activity.";
  }
  return "Activity could not be loaded. Try once more.";
}

function EventLink({ event }: { event: ActivityEvent }) {
  if (event.entityType === "proposed_action" && event.entityId) {
    return (
      <Button asChild variant="secondary" size="sm">
        <Link to="/app/approvals/$id" params={{ id: event.entityId }}>
          Open confirmation
        </Link>
      </Button>
    );
  }
  if (event.entityType === "memory") {
    return (
      <Button asChild variant="secondary" size="sm">
        <Link to="/app/memory">Open Memory</Link>
      </Button>
    );
  }
  if (event.entityType === "goal" || event.entityType === "task") {
    return (
      <Button asChild variant="secondary" size="sm">
        <Link to="/app/goals">Open Goals</Link>
      </Button>
    );
  }
  if (event.entityType === "permission_settings") {
    return (
      <Button asChild variant="secondary" size="sm">
        <Link to="/app/settings">Open Settings</Link>
      </Button>
    );
  }
  return null;
}

export function ActivityWorkspace() {
  const [level, setLevel] = useState<ActivityLevelFilter>("all");
  const [page, setPage] = useState<ActivityPage | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [nowMs, setNowMs] = useState(() => Date.now());

  const load = useCallback(async (nextLevel: ActivityLevelFilter) => {
    setLoading(true);
    setLoadError(null);
    setPage((prev) =>
      prev ? { ...prev, items: [], nextCursor: null } : null,
    );
    try {
      const result = await listActivity({ data: { level: nextLevel } });
      setPage(result);
      setNowMs(Date.now());
    } catch (err) {
      setLoadError(errorText(err));
      setPage(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load(level);
  }, [level, load]);

  async function onLoadMore() {
    if (!page?.nextCursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const more = await listActivity({
        data: { level, cursor: encodeCursor(page.nextCursor) },
      });
      setPage({
        items: [...page.items, ...more.items],
        nextCursor: more.nextCursor,
        pending: more.pending,
        pendingTotal: more.pendingTotal,
      });
    } catch (err) {
      setLoadError(errorText(err));
    } finally {
      setLoadingMore(false);
    }
  }

  const items = page?.items ?? [];
  const pending = page?.pending ?? [];
  const empty = !loading && items.length === 0 && !loadError;

  return (
    <main className="mx-auto flex w-full max-w-2xl min-h-0 flex-1 flex-col overflow-y-auto px-5 py-10 md:px-8">
      <p className="text-sm font-medium text-accent">Activity</p>
      <h1 className="font-display mt-2 text-3xl tracking-tight">What AEVORA did</h1>
      <p className="mt-3 max-w-xl text-base leading-relaxed text-muted">
        Every proposal, confirmation, and change. This log cannot be edited.
      </p>

      {loadError ? (
        <div className="mt-8 flex flex-col gap-3">
          <p className="text-sm text-danger" role="alert">
            {loadError}
          </p>
          <Button type="button" variant="secondary" onClick={() => void load(level)}>
            Try again
          </Button>
        </div>
      ) : null}

      <PendingPanel items={pending} total={page?.pendingTotal ?? 0} nowMs={nowMs} />

      <div
        className="mt-8 flex flex-wrap gap-2"
        role="tablist"
        aria-label="Filter by confirmation level"
      >
        {ACTIVITY_LEVEL_FILTERS.map((value) => {
          const active = level === value;
          return (
            <button
              key={value}
              type="button"
              role="tab"
              aria-selected={active}
              className={cn(
                "inline-flex min-h-11 items-center rounded-full border px-3 text-sm transition-colors duration-150",
                active
                  ? "border-fg bg-fg text-bg"
                  : "border-border bg-surface text-muted hover:border-border-strong hover:text-fg",
              )}
              onClick={() => setLevel(value)}
            >
              {LEVEL_COPY[value]}
            </button>
          );
        })}
      </div>

      {loading && items.length === 0 && !loadError ? (
        <div className="mt-8 space-y-3" aria-hidden="true">
          <div className="h-20 animate-pulse rounded-md bg-surface" />
          <div className="h-20 animate-pulse rounded-md bg-surface" />
          <div className="h-20 animate-pulse rounded-md bg-surface" />
        </div>
      ) : null}

      {empty ? (
        <p className="mt-8 text-sm leading-relaxed text-muted">
          {level === "all"
            ? "Nothing recorded yet. Confirm an action, or add a memory — it will show here."
            : "Nothing at this confirmation level."}
        </p>
      ) : null}

      {items.length > 0 ? (
        <ol className="mt-8 flex flex-col gap-2" aria-label="Activity" aria-busy={loading}>
          {items.map((item) => (
            <li key={item.id}>
              <EventCard event={item} nowMs={nowMs} />
            </li>
          ))}
        </ol>
      ) : null}

      {page?.nextCursor ? (
        <div className="mt-6">
          <Button
            type="button"
            variant="secondary"
            onClick={() => void onLoadMore()}
            disabled={loadingMore}
          >
            {loadingMore ? "Loading" : "Load earlier"}
          </Button>
        </div>
      ) : null}
    </main>
  );
}

function PendingPanel({
  items,
  total,
  nowMs,
}: {
  items: ActivityPending[];
  total: number;
  nowMs: number;
}) {
  const waiting = items.length > 0;
  return (
    <section
      aria-label="Waiting for confirmation"
      className={cn(
        "mt-8 rounded-lg border bg-surface p-5",
        waiting ? "border-caution/40" : "border-border",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <Shield className="size-4 text-muted" strokeWidth={1.75} />
          <h2 className="text-sm font-medium text-fg">Waiting for confirmation</h2>
        </div>
        {waiting ? (
          <span className="text-xs uppercase tracking-[0.14em] text-subtle">
            {total} waiting
          </span>
        ) : null}
      </div>
      {waiting ? (
        <ul className="mt-4 flex flex-col gap-2">
          {items.map((item) => (
            <li key={item.id}>
              <article
                className="rounded-md border border-border bg-bg p-4"
                aria-label={`Proposed action: ${item.title}`}
              >
                <div className="flex flex-wrap items-center gap-2">
                  <LevelBadge level={item.permissionLevel} />
                  <span className="text-xs uppercase tracking-[0.14em] text-subtle">
                    Pending
                  </span>
                  <span className="text-xs text-subtle">{relativeLabel(item.createdAt, nowMs)}</span>
                </div>
                <h3 className="mt-3 text-sm font-medium text-fg">{item.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted">{item.summary}</p>
                <p className="mt-3 text-xs leading-relaxed text-subtle">
                  {item.displayName}. Nothing will run until you confirm.
                </p>
                <div className="mt-3">
                  <Button asChild size="sm">
                    <Link to="/app/approvals/$id" params={{ id: String(item.id) }}>
                      Review this action
                    </Link>
                  </Button>
                </div>
              </article>
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-3 text-sm leading-relaxed text-muted">Nothing waiting.</p>
      )}
    </section>
  );
}

function EventCard({ event, nowMs }: { event: ActivityEvent; nowMs: number }) {
  return (
    <article
      className="rounded-md border border-border bg-surface p-4"
      aria-label={`${event.title}: ${event.detail || event.action}`}
    >
      <div className="flex flex-wrap items-center gap-2">
        {event.permissionLevel ? (
          <LevelBadge level={event.permissionLevel} />
        ) : (
          <span className="inline-flex items-center gap-1 text-xs uppercase tracking-[0.14em] text-subtle">
            <ScrollText className="size-3.5" strokeWidth={1.75} />
            {event.actorLabel}
          </span>
        )}
        {event.permissionLevel ? (
          <span className="text-xs uppercase tracking-[0.14em] text-subtle">{event.actorLabel}</span>
        ) : null}
        <span className="text-xs text-subtle">{relativeLabel(event.createdAt, nowMs)}</span>
      </div>
      <h3 className="mt-3 text-sm font-medium text-fg">{event.title}</h3>
      {event.detail ? (
        <p className="mt-1 text-sm leading-relaxed text-muted">{event.detail}</p>
      ) : null}
      <div className="mt-3">
        <EventLink event={event} />
      </div>
    </article>
  );
}
