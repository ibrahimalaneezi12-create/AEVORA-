import { cn } from "@/lib/utils";

export function AegisMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-8", className)}
      aria-hidden="true"
    >
      <circle cx="16" cy="16" r="15" className="fill-surface-2" />
      <path
        d="M16 6.8 L24.4 11.2 V18.4 C24.4 23 20.8 26.1 16 27.3 C11.2 26.1 7.6 23 7.6 18.4 V11.2 Z"
        className="fill-none stroke-accent"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <path
        d="M16 12.4 V20.6"
        className="stroke-fg"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}
