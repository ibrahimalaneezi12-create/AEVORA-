import { useCallback, useEffect, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { listCreations, saveCreation, type Creation } from "@/lib/creation";
import { getEntitlement, planDisplayName, type Entitlement } from "@/lib/entitlements";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { StudioWorkspace } from "@/components/studio/studio-workspace";

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) return "Sign in to see your writing.";
  if (err instanceof Error && err.message) return err.message;
  return "Writing could not be loaded.";
}

export function CreationWorkspace() {
  const [writing, setWriting] = useState(false);

  if (writing) {
    return <WritingSurface onBack={() => setWriting(false)} />;
  }

  return <StudioWorkspace onOpenWriting={() => setWriting(true)} />;
}

function WritingSurface({ onBack }: { onBack: () => void }) {
  const [rows, setRows] = useState<Creation[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [plan, setPlan] = useState<Entitlement | null>(null);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [editing, setEditing] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  const refresh = useCallback(() => {
    listCreations()
      .then((list) => {
        setRows(list);
        setError(null);
      })
      .catch((err) => setError(errorText(err)));
    getEntitlement()
      .then(setPlan)
      .catch(() => setPlan(null));
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  async function onSave(e: FormEvent) {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;
    setSaving(true);
    setError(null);
    try {
      await saveCreation({
        data: {
          id: editing ?? undefined,
          title: title.trim(),
          body: body.trim(),
          kind: "note",
        },
      });
      setTitle("");
      setBody("");
      setEditing(null);
      refresh();
    } catch (err) {
      setError(errorText(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-0 flex-1 overflow-y-auto px-5 py-8 md:px-10">
      <button type="button" onClick={onBack} className="min-h-11 text-sm text-muted hover:text-fg">
        Studio
      </button>
      <p className="mt-8 text-sm font-medium tracking-wide text-accent">Writing</p>
      <h1 className="font-display mt-2 text-3xl tracking-tight">Keep a draft</h1>
      {plan && !plan.fullAccess ? (
        <p className="mt-8 text-sm leading-relaxed text-muted">
          Saved writing is not included on {planDisplayName(plan.plan)}.
        </p>
      ) : (
        <form onSubmit={onSave} className="mt-8 max-w-xl">
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="create-title">Title</Label>
              <Input id="create-title" value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={120} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="create-body">Body</Label>
              <Textarea id="create-body" value={body} onChange={(e) => setBody(e.target.value)} required rows={8} />
            </div>
            <div className="flex flex-wrap gap-2">
              <Button type="submit" disabled={saving || !title.trim() || !body.trim()}>
                {saving ? "Saving" : editing ? "Update" : "Save writing"}
              </Button>
              {editing ? (
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => {
                    setEditing(null);
                    setTitle("");
                    setBody("");
                  }}
                >
                  Cancel edit
                </Button>
              ) : null}
            </div>
          </div>
        </form>
      )}
      {error ? (
        <p className="mt-4 text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
      {rows && rows.length === 0 ? (
        <p className="mt-8 text-sm text-muted">
          No saved writing yet.{" "}
          <Link to="/app/chat" className="text-fg underline-offset-4 hover:underline">
            Ask AEVORA to draft something
          </Link>
          .
        </p>
      ) : null}
      {rows && rows.length > 0 ? (
        <ul className="mt-8 flex max-w-xl flex-col gap-2">
          {rows.map((row) => (
            <li key={row.id}>
              <button
                type="button"
                className="w-full rounded-[1.5rem] bg-surface px-5 py-4 text-left hover:bg-surface-2"
                onClick={() => {
                  setEditing(row.id);
                  setTitle(row.title);
                  setBody(row.body);
                }}
              >
                <p className="text-sm font-medium">{row.title}</p>
                <p className="mt-2 line-clamp-3 text-sm text-muted">{row.body}</p>
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
