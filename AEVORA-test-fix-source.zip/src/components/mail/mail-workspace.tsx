import { useCallback, useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Mail } from "lucide-react";
import { getMailStatus, listEmailDrafts, type EmailDraft, type MailConnection } from "@/lib/mail";
import { Button } from "@/components/ui/button";

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) return "Sign in to see mail.";
  if (err instanceof Error && err.message) return err.message;
  return "Drafts could not be loaded.";
}

export function MailWorkspace() {
  const [rows, setRows] = useState<EmailDraft[] | null>(null);
  const [status, setStatus] = useState<MailConnection | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [openId, setOpenId] = useState<number | null>(null);

  const refresh = useCallback(() => {
    listEmailDrafts()
      .then((list) => {
        setRows(list);
        setError(null);
      })
      .catch((err) => setError(errorText(err)));
    getMailStatus()
      .then(setStatus)
      .catch(() => setStatus({ connected: false, status: "connection_error", detail: "Gmail is not connected." }));
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const drafts = (rows ?? []).filter((row) => row.status === "draft");
  const rest = (rows ?? []).filter((row) => row.status !== "draft");

  return (
    <main className="mx-auto w-full max-w-3xl min-h-0 flex-1 overflow-y-auto px-5 py-10 md:px-8">
      <p className="text-sm font-medium text-accent">Mail</p>
      <h1 className="font-display mt-2 text-3xl tracking-tight">Drafts until you approve</h1>
      <p className="mt-3 max-w-xl text-base leading-relaxed text-muted">
        AEVORA can draft here. Sending always needs your approval.
      </p>

      <section className="mt-8" aria-label="Gmail">
        <div className="flex items-start gap-2">
          <Mail className="mt-0.5 size-4 shrink-0 text-subtle" strokeWidth={1.75} />
          <div>
            <p className="text-sm font-medium">Gmail</p>
            <p className="mt-1 text-sm leading-relaxed text-muted">
              {status?.detail ?? "Checking connection."}
            </p>
            {status && !status.connected ? (
              <p className="mt-1 text-xs text-subtle">
                If you ask AEVORA to send, it will keep the draft and tell you Gmail is not connected.
              </p>
            ) : null}
          </div>
        </div>
      </section>

      {error ? (
        <p className="mt-6 text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}

      {rows && rows.length === 0 ? (
        <p className="mt-8 text-sm leading-relaxed text-muted">
          No drafts yet.{" "}
          <Link to="/app/chat" className="text-fg underline-offset-4 hover:underline">
            Ask AEVORA to draft one
          </Link>
          .
        </p>
      ) : null}

      {drafts.length > 0 ? (
        <section className="mt-8" aria-label="Open drafts">
          <h2 className="text-xs font-medium uppercase tracking-[0.14em] text-subtle">Open drafts</h2>
          <ul className="mt-2 flex flex-col gap-2">
            {drafts.map((row) => (
              <DraftCard
                key={row.id}
                row={row}
                open={openId === row.id}
                onToggle={() => setOpenId(openId === row.id ? null : row.id)}
              />
            ))}
          </ul>
        </section>
      ) : null}

      {rest.length > 0 ? (
        <section className="mt-8" aria-label="Earlier mail">
          <h2 className="text-xs font-medium uppercase tracking-[0.14em] text-subtle">Earlier</h2>
          <ul className="mt-2 flex flex-col gap-2">
            {rest.map((row) => (
              <DraftCard
                key={row.id}
                row={row}
                open={openId === row.id}
                onToggle={() => setOpenId(openId === row.id ? null : row.id)}
              />
            ))}
          </ul>
        </section>
      ) : null}
    </main>
  );
}

function DraftCard({
  row,
  open,
  onToggle,
}: {
  row: EmailDraft;
  open: boolean;
  onToggle: () => void;
}) {
  return (
    <li className="rounded-lg border border-border bg-surface p-4">
      <p className="text-xs uppercase tracking-[0.14em] text-subtle">{row.status}</p>
      <p className="mt-1 text-sm font-medium">{row.subject}</p>
      <p className="mt-1 text-xs text-muted">To {row.toAddress}</p>
      {row.status === "failed" && row.error ? (
        <p className="mt-2 text-sm text-danger">{row.error}</p>
      ) : null}
      {open ? (
        <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-muted">{row.body}</p>
      ) : row.body ? (
        <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted">{row.body}</p>
      ) : null}
      <div className="mt-3 flex flex-wrap gap-2">
        <Button type="button" variant="secondary" size="sm" onClick={onToggle}>
          {open ? "Hide" : "Read"}
        </Button>
        {row.status === "draft" ? (
          <Button asChild variant="secondary" size="sm">
            <Link to="/app/chat">Ask AEVORA to send</Link>
          </Button>
        ) : null}
      </div>
    </li>
  );
}
