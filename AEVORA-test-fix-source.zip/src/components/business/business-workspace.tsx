import { useEffect, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import {
  listBusinessPage,
  type Business,
  type BusinessManagerReport,
  type BusinessNote,
} from "@/lib/business";
import { listBusinessLinks, type BusinessLink } from "@/lib/links";
import { linkStatusLabel } from "@/lib/links-format";
import { connectHubspot, connectShopify, disconnectHubspot, disconnectOAuth, disconnectShopify, startBusinessOAuth, testBusinessLink } from "@/lib/providers";
import type { BusinessExperiment } from "@/lib/business";
import type { BusinessMonitorDecision } from "@/lib/entitlements-format";
import { safeGateLoginUrl } from "@/lib/providers/gate-peek";
import { workspaceDraftKey } from "@/lib/chat-workspace";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) {
    return "Sign in to see your business.";
  }
  return "AEVORA could not load this page. Try once more.";
}

function safeOutbound(url: string, hosts: string[]): boolean {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:" && hosts.includes(parsed.hostname);
  } catch {
    return false;
  }
}

function seedChat(draft: string) {
  try {
    sessionStorage.setItem(workspaceDraftKey("business"), draft);
  } catch {
    /* private mode */
  }
}

export function BusinessWorkspace() {
  const [manager, setManager] = useState<BusinessManagerReport | null>(null);
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [notes, setNotes] = useState<BusinessNote[]>([]);
  const [monitor, setMonitor] = useState<BusinessMonitorDecision | null>(null);
  const [links, setLinks] = useState<BusinessLink[] | null>(null);
  const [experiments, setExperiments] = useState<BusinessExperiment[]>([]);
  const [hello, setHello] = useState("");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [hubToken, setHubToken] = useState("");
  const [shop, setShop] = useState("");
  const [shopToken, setShopToken] = useState("");
  const [linkError, setLinkError] = useState<string | null>(null);
  const [linkNote, setLinkNote] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function refreshLinks() {
    return listBusinessLinks()
      .then(setLinks)
      .catch(() => setLinks([]));
  }

  useEffect(() => {
    listBusinessPage()
      .then((page) => {
        setManager(page.manager);
        setBusinesses(page.businesses);
        setNotes(page.notes);
        setMonitor(page.monitor);
        setExperiments(page.experiments);
        setLoadError(null);
      })
      .catch((err) => setLoadError(errorText(err)));
    void refreshLinks();
    const params = new URLSearchParams(window.location.search);
    const link = params.get("link");
    if (link === "google_ads" || link === "quickbooks") setLinkNote("That provider accepted the login.");
    else if (link === "denied") setLinkNote("The provider did not authorize the login. Nothing was saved.");
    else if (link === "failed") setLinkNote("The provider login did not finish. Nothing was saved.");
    const hour = new Date().getHours();
    setHello(hour < 12 ? "Good morning." : hour < 18 ? "Good afternoon." : "Good evening.");
  }, []);

  async function onHubspot(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setLinkError(null);
    try {
      const result = await connectHubspot({ data: { token: hubToken } });
      setHubToken("");
      if (!result.ok) setLinkError(result.error);
      await refreshLinks();
    } catch {
      setHubToken("");
      setLinkError("HubSpot could not be checked. Nothing was saved.");
    } finally {
      setBusy(false);
    }
  }

  async function onShopify(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setLinkError(null);
    try {
      const result = await connectShopify({ data: { shop, token: shopToken } });
      setShopToken("");
      if (!result.ok) setLinkError(result.error);
      await refreshLinks();
    } catch {
      setShopToken("");
      setLinkError("Shopify could not be checked. Nothing was saved.");
    } finally {
      setBusy(false);
    }
  }

  async function onDisconnect(id: string) {
    setBusy(true);
    setLinkError(null);
    try {
      if (id === "crm") await disconnectHubspot();
      if (id === "shop") await disconnectShopify();
      if (id === "ads") await disconnectOAuth({ data: { provider: "google_ads" } });
      if (id === "books") await disconnectOAuth({ data: { provider: "quickbooks" } });
      await refreshLinks();
    } catch {
      setLinkError("That connection could not be removed.");
    } finally {
      setBusy(false);
    }
  }

  async function onTest(id: "gmail" | "calendar" | "crm" | "shop" | "ads" | "books" | "inventory") {
    setBusy(true);
    setLinkError(null);
    try {
      const result = await testBusinessLink({ data: { id } });
      setLinkNote(result.detail);
      await refreshLinks();
    } catch {
      setLinkError("That connection could not be checked.");
    } finally {
      setBusy(false);
    }
  }

  async function onGate(link: BusinessLink) {
    const url = safeGateLoginUrl(link.loginUrl);
    if (url) {
      window.open(url, "_blank", "noopener,noreferrer");
      setLinkNote(`${link.name} sign-in was opened. Nothing is connected until that provider accepts it.`);
      setLinkError(null);
      return;
    }
    setBusy(true);
    setLinkError(null);
    try {
      const id = link.id === "calendar" ? "calendar" : "gmail";
      const result = await testBusinessLink({ data: { id } });
      setLinkError(
        `${link.name} is not connected. ${result.detail} Approve it on the published app's connector gate. This page will not start a second Google login.`,
      );
      await refreshLinks();
    } catch {
      setLinkError(`${link.name} could not be checked. Nothing was connected.`);
    } finally {
      setBusy(false);
    }
  }

  function onInventoryConnect() {
    setLinkError(null);
    setLinkNote("Inventory is read from Shopify. Connect the shop below. No stock number is invented.");
    document.getElementById("shop-host")?.focus();
  }

  async function onOAuth(provider: "google_ads" | "quickbooks") {
    setBusy(true);
    setLinkError(null);
    try {
      const result = await startBusinessOAuth({ data: { provider } });
      if (!result.ok) {
        setLinkError(result.error);
        return;
      }
      const host = provider === "google_ads" ? "accounts.google.com" : "appcenter.intuit.com";
      if (!safeOutbound(result.url, [host])) {
        setLinkError("That login address was refused. Nothing was sent.");
        return;
      }
      window.location.assign(result.url);
    } catch {
      setLinkError("That login could not be started. Nothing was sent.");
    } finally {
      setBusy(false);
    }
  }

  const onFile = [
    ...businesses.map((b) => b.name),
    ...notes.map((n) => n.title),
  ].slice(0, 6);

  return (
    <main
      data-context="business"
      className="mx-auto flex w-full max-w-xl min-h-0 flex-1 flex-col justify-center overflow-y-auto px-6 py-12 md:px-8"
    >
      <p className="text-sm font-medium text-accent">Business</p>
      {hello ? <p className="font-display mt-3 text-2xl tracking-tight">{hello}</p> : null}
      <h1 className="font-display mt-2 text-4xl leading-[1.08] tracking-tight">How’s the business?</h1>
      <p className="mt-4 max-w-md text-lg leading-relaxed text-muted">
        Ask in plain language. AEVORA uses only what you saved or a source that actually answered.
      </p>

      <div className="mt-8">
        <Button asChild className="h-14 min-h-14 px-8 text-base">
          <Link to="/app/business" hash="chat" onClick={() => seedChat("How's the business?")}>
            Business chat
          </Link>
        </Button>
      </div>
      <p className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted">
        <Link to="/app/business" hash="chat" className="hover:text-fg" onClick={() => seedChat("What needs my attention in the business?")}>
          What needs me
        </Link>
        <Link to="/app/business" hash="chat" className="hover:text-fg" onClick={() => seedChat("Find opportunities in the business.")}>
          Find opportunities
        </Link>
        <Link to="/app/business" hash="chat" className="hover:text-fg" onClick={() => seedChat("Give me the business morning brief.")}>
          Morning brief
        </Link>
        <Link to="/app/business" hash="chat" className="hover:text-fg" onClick={() => seedChat("Why is this happening in the business?")}>
          Why is this happening?
        </Link>
      </p>

      {loadError ? (
        <p className="mt-8 text-sm text-danger" role="alert">
          {loadError}
        </p>
      ) : null}

      {manager === null && !loadError ? (
        <div className="mt-12 h-12 w-48 animate-pulse bg-surface/70" aria-hidden="true" />
      ) : null}

      {manager?.empty ? (
        <p className="mt-10 max-w-md text-sm leading-relaxed text-muted">
          Nothing is saved yet. Name the business in chat and AEVORA will ask before it stores anything.
        </p>
      ) : null}

      {manager && !manager.empty && monitor?.deeper ? (
        <div className="mt-12 flex max-w-md flex-col gap-8">
          {manager.sections.map((section) => (
            <section key={section.id} aria-label={section.title}>
              <h2 className="text-sm font-medium text-fg">{section.title}</h2>
              <ul className="mt-2 flex flex-col gap-1">
                {section.lines.map((line) => (
                  <li key={line} className="text-sm leading-relaxed text-muted">
                    {line}
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      ) : null}

      {manager && !manager.empty && monitor && !monitor.deeper && onFile.length > 0 ? (
        <section className="mt-12 max-w-md" aria-label="On file">
          <h2 className="text-sm font-medium text-fg">On file</h2>
          <ul className="mt-2 flex flex-col gap-1">
            {onFile.map((line) => (
              <li key={line} className="text-sm leading-relaxed text-muted">
                {line}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {experiments.length > 0 ? (
        <section className="mt-12 max-w-md" aria-label="Experiments">
          <h2 className="text-sm font-medium text-fg">Experiments</h2>
          <ul className="mt-2 flex flex-col gap-3">
            {experiments.map((item) => (
              <li key={item.id} className="text-sm leading-relaxed text-muted">
                <span className="text-fg">{item.hypothesis}</span>
                {` · ${item.metric} · ${item.windowDays} days · ${item.status === "recorded" ? "result you wrote" : "no result yet"}`}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="mt-12 max-w-md" aria-label="Connections">
        <h2 className="text-sm font-medium text-fg">Connections</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Only a source that answers is used. Nothing here is watched in the background.
        </p>
        {links === null ? (
          <div className="mt-4 h-10 w-40 animate-pulse bg-surface/70" aria-hidden="true" />
        ) : (
          <ul className="mt-4 flex flex-col gap-3">
            {links.map((link) => (
              <li key={link.id} className="text-sm leading-relaxed">
                <span className="text-fg">{link.name}</span>
                <span className="text-muted"> · {linkStatusLabel(link.status)}</span>
                <span className="mt-0.5 block text-muted">{link.detail}</span>
                {link.lastCheckedAt ? (
                  <span className="mt-0.5 block text-muted">Last checked {link.lastCheckedAt.slice(0, 16).replace("T", " ")} UTC</span>
                ) : null}
                <div className="mt-2 flex flex-wrap gap-2">
                  {link.connect === "gate" ? (
                    <Button type="button" className="min-h-12" disabled={busy} onClick={() => void onGate(link)}>
                      Connect {link.name}
                    </Button>
                  ) : null}
                  {link.connect === "oauth" ? (
                    <Button
                      type="button"
                      className="min-h-12"
                      disabled={busy}
                      onClick={() => void onOAuth(link.id === "books" ? "quickbooks" : "google_ads")}
                    >
                      Connect {link.name}
                    </Button>
                  ) : null}
                  {link.connect === "shopify" ? (
                    <Button type="button" className="min-h-12" disabled={busy} onClick={onInventoryConnect}>
                      Connect through Shopify
                    </Button>
                  ) : null}
                  <Button type="button" variant="secondary" className="min-h-12" disabled={busy} onClick={() => void onTest(link.id as "gmail" | "calendar" | "crm" | "shop" | "ads" | "books" | "inventory")}>
                    Test connection
                  </Button>
                  {(link.id === "crm" || link.id === "shop" || link.id === "ads" || link.id === "books") &&
                  link.status !== "not_connected" &&
                  link.status !== "not_configured" &&
                  link.status !== "provider_unavailable" ? (
                    <Button type="button" variant="secondary" className="min-h-12" disabled={busy} onClick={() => void onDisconnect(link.id)}>
                      Disconnect
                    </Button>
                  ) : null}
                </div>
                {(link.id === "gmail" || link.id === "calendar") && (link.status === "connected" || link.status === "authorization_required") ? (
                  <p className="mt-2 text-muted">Authorization is held by the connector gate. This page cannot revoke it.</p>
                ) : null}
                {link.id === "crm" && link.status !== "connected" ? (
                  <form className="mt-2 flex flex-col gap-2" onSubmit={(event) => void onHubspot(event)}>
                    <Label htmlFor="hubspot-token">HubSpot private-app token</Label>
                    <Input id="hubspot-token" type="password" autoComplete="off" value={hubToken} onChange={(event) => setHubToken(event.target.value)} />
                    <Button type="submit" className="min-h-12 w-fit" disabled={busy || hubToken.length < 8}>
                      {busy ? "Checking HubSpot…" : "Connect HubSpot"}
                    </Button>
                  </form>
                ) : null}
                {link.id === "shop" && link.status !== "connected" ? (
                  <form className="mt-2 flex flex-col gap-2" onSubmit={(event) => void onShopify(event)}>
                    <Label htmlFor="shop-host">Shop</Label>
                    <Input id="shop-host" autoComplete="off" value={shop} onChange={(event) => setShop(event.target.value)} placeholder="store.myshopify.com" />
                    <Label htmlFor="shop-token">Admin token</Label>
                    <Input id="shop-token" type="password" autoComplete="off" value={shopToken} onChange={(event) => setShopToken(event.target.value)} />
                    <Button type="submit" className="min-h-12 w-fit" disabled={busy || shopToken.length < 8 || shop.length < 3}>
                      {busy ? "Checking Shopify…" : "Connect Shopify"}
                    </Button>
                  </form>
                ) : null}
              </li>
            ))}
          </ul>
        )}
        {linkNote ? <p className="mt-3 text-sm text-muted">{linkNote}</p> : null}
        {linkError ? (
          <p className="mt-3 text-sm text-danger" role="alert">
            {linkError}
          </p>
        ) : null}
      </section>

      <p className="mt-12 max-w-md text-xs leading-relaxed text-subtle">
        {monitor?.reason ?? "Background monitoring is not connected."}
      </p>
    </main>
  );
}