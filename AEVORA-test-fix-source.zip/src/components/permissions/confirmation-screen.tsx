import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";
import {
  approveProposal,
  denyProposal,
  getProposal,
  type ProposalConfirmView,
} from "@/lib/confirm";
import { workspaceThreadLink } from "@/lib/chat-workspace";
import { LevelBadge } from "@/components/permissions/level-badge";
import { DecisionControls } from "@/components/permissions/decision-controls";
import { Button } from "@/components/ui/button";

function errorText(err: unknown): string {
  if (err instanceof Error && /unauthorized/i.test(err.message)) {
    return "Sign in to confirm this action.";
  }
  if (err instanceof Error) return err.message;
  return "This action could not be loaded.";
}

function statusCopy(view: ProposalConfirmView): string {
  if (view.status === "pending") {
    return "Nothing will run until you approve. Leaving does not run it.";
  }
  if (view.status === "denied") return "Denied. Nothing ran.";
  if (view.status === "executed") return view.result || "Executed.";
  if (view.status === "failed") return view.error || "This action failed.";
  if (view.status === "approved") return "Approved. Waiting to finish.";
  return view.status;
}

export function ConfirmationScreen({ id }: { id: number | null }) {
  const [view, setView] = useState<ProposalConfirmView | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) {
      setView(null);
      setLoadError("Proposal not found.");
      return;
    }
    let cancelled = false;
    setLoadError(null);
    setActionError(null);
    setView(null);
    getProposal({ data: { id } })
      .then((row) => {
        if (!cancelled) setView(row);
      })
      .catch((err) => {
        if (!cancelled) setLoadError(errorText(err));
      });
    return () => {
      cancelled = true;
    };
  }, [id]);

  async function decide(kind: "approve" | "deny") {
    if (!view || busy) return;
    setBusy(true);
    setActionError(null);
    try {
      const next =
        kind === "approve"
          ? await approveProposal({ data: { id: view.id } })
          : await denyProposal({ data: { id: view.id } });
      setView(next);
    } catch (err) {
      setActionError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  const backTo = view?.conversationId
    ? workspaceThreadLink(view.workspace ?? "main", view.conversationId)
    : { to: "/app" as const, hash: "" as const, params: undefined };

  return (
    <main className="mx-auto w-full max-w-xl min-h-0 flex-1 overflow-y-auto px-5 py-8 md:px-8">
      <Link
        to={backTo.to}
        params={backTo.params}
        hash={backTo.hash}
        className="inline-flex min-h-11 items-center gap-2 text-sm text-muted hover:text-fg"
      >
        <ChevronLeft className="size-4" strokeWidth={1.75} />
        {view?.conversationId ? "Back to chat" : "Back to AEVORA"}
      </Link>

      <p className="mt-8 text-sm font-medium text-accent">Needs your say</p>

      {loadError ? (
        <div className="mt-4 flex flex-col gap-3">
          <h1 className="font-display text-3xl tracking-tight">Not found</h1>
          <p className="text-sm leading-relaxed text-muted" role="alert">
            {loadError}
          </p>
          <Button asChild variant="secondary" className="w-fit">
            <Link to="/app">Open AEVORA</Link>
          </Button>
        </div>
      ) : !view ? (
        <div className="mt-8 space-y-3" aria-hidden="true">
          <div className="h-10 animate-pulse rounded-md bg-surface" />
          <div className="h-24 animate-pulse rounded-md bg-surface" />
          <div className="h-11 animate-pulse rounded-md bg-surface" />
        </div>
      ) : (
        <article aria-label={`Confirm action: ${view.title}`}>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <LevelBadge level={view.permissionLevel} />
            <span className="text-xs uppercase tracking-[0.14em] text-subtle">
              {view.status}
            </span>
          </div>
          <h1 className="font-display mt-3 text-3xl tracking-tight">{view.title}</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">{view.summary}</p>
          <p className="mt-3 text-xs leading-relaxed text-subtle">{view.displayName}</p>

          {view.payloadPreview.length > 0 ? (
            <dl className="mt-6 divide-y divide-border rounded-md border border-border bg-surface">
              {view.payloadPreview.map((line) => (
                <div key={line.label} className="grid gap-1 px-4 py-3 sm:grid-cols-[8rem_1fr] sm:gap-4">
                  <dt className="text-xs uppercase tracking-[0.14em] text-subtle">{line.label}</dt>
                  <dd className="text-sm leading-relaxed break-words text-fg">{line.value}</dd>
                </div>
              ))}
            </dl>
          ) : (
            <p className="mt-6 text-sm leading-relaxed text-muted">
              No extra details on this action.
            </p>
          )}

          <p className="mt-6 text-sm leading-relaxed text-muted">{statusCopy(view)}</p>

          {view.blockedReason ? (
            <p className="mt-3 text-sm text-danger" role="alert">
              {view.blockedReason}
            </p>
          ) : null}
          {actionError ? (
            <p className="mt-3 text-sm text-danger" role="alert">
              {actionError}
            </p>
          ) : null}
          {view.status === "failed" && view.error ? (
            <p className="mt-3 text-sm text-danger" role="alert">
              {view.error}
            </p>
          ) : null}

          <DecisionControls
            canApprove={view.canApprove}
            canDeny={view.canDeny}
            busy={busy}
            onApprove={() => void decide("approve")}
            onDeny={() => void decide("deny")}
          />
        </article>
      )}
    </main>
  );
}
