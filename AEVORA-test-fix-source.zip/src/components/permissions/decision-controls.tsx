import { Button } from "@/components/ui/button";

export function DecisionControls({
  canApprove,
  canDeny,
  busy,
  onApprove,
  onDeny,
}: {
  canApprove: boolean;
  canDeny: boolean;
  busy: boolean;
  onApprove: () => void;
  onDeny: () => void;
}) {
  if (!canApprove && !canDeny) return null;
  return (
    <div className="mt-4 flex flex-wrap gap-2">
      {canApprove ? (
        <Button type="button" onClick={onApprove} disabled={busy} className="min-h-11">
          Approve
        </Button>
      ) : null}
      {canDeny ? (
        <Button
          type="button"
          variant="secondary"
          onClick={onDeny}
          disabled={busy}
          className="min-h-11"
        >
          Deny
        </Button>
      ) : null}
    </div>
  );
}
