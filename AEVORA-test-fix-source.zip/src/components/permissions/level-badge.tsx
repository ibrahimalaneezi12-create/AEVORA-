import type { PermissionLevel } from "@/lib/orchestrator/types";
import { cn } from "@/lib/utils";

const COPY: Record<PermissionLevel, string> = {
  safe: "Safe",
  review: "Review",
  approval: "Approval",
  restricted: "Restricted",
};

export function LevelBadge({ level }: { level: PermissionLevel }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium",
        level === "safe" && "border-border text-muted",
        level === "review" && "border-caution/40 text-caution",
        level === "approval" && "border-caution/60 text-caution",
        level === "restricted" && "border-danger/40 text-danger",
      )}
    >
      {COPY[level]}
    </span>
  );
}
