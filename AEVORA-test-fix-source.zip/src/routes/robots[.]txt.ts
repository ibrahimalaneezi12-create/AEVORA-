import { createFileRoute } from "@tanstack/react-router";
import { env } from "@/lib/env.server";
import { publicSiteOrigin, robotsTxt } from "@/lib/seo";

export const Route = createFileRoute("/robots.txt")({
  server: {
    handlers: {
      GET: async () => {
        const body = robotsTxt(publicSiteOrigin(env("BETTER_AUTH_URL")));
        return new Response(body, {
          headers: {
            "content-type": "text/plain; charset=utf-8",
            "cache-control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
