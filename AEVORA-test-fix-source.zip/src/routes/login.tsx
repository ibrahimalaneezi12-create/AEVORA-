import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { createFileRoute, Link, Navigate, useNavigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { capturePreviewSessionToken } from "@/lib/preview-session";
import { AegisMark } from "@/components/brand/aegis-mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { robotsDirective } from "@/lib/seo";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — AEVORA" },
      { name: "description", content: "Sign in to your private AEVORA keep." },
      { name: "robots", content: robotsDirective("/login") },
    ],
  }),
  component: Login,
});

function Login() {
  const { user, isPending } = useCurrentUserState();

  if (isPending) {
    return (
      <main className="grid min-h-dvh place-items-center bg-bg px-6">
        <div className="h-64 w-full max-w-sm animate-pulse rounded-xl bg-surface" />
      </main>
    );
  }

  if (user) {
    return <Navigate to="/app" />;
  }

  return (
    <main className="grid min-h-dvh place-items-center bg-bg px-5 py-12 text-fg">
      <div className="w-full max-w-sm">
        <Link to="/" className="mb-10 flex items-center gap-3">
          <AegisMark />
          <span className="font-display text-xl tracking-tight">AEVORA</span>
        </Link>
        <h1 className="font-display text-4xl tracking-tight">Welcome back</h1>
        <p className="mt-3 text-base leading-relaxed text-muted">
          Your steward is private. Sign in to continue.
        </p>
        <EmailAuthForm />
        <div className="my-6 flex items-center gap-3 text-xs text-subtle">
          <span className="h-px flex-1 bg-border" />
          or
          <span className="h-px flex-1 bg-border" />
        </div>
        <SocialAuth />
      </div>
    </main>
  );
}

function SocialAuth() {
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [previewHost, setPreviewHost] = useState(false);

  useEffect(() => {
    setPreviewHost(window.location.hostname.endsWith(".grok-sandbox.com"));
  }, []);

  async function onProvider(providerId: string) {
    setError(null);
    setBusy(true);
    try {
      await signIn(providerId, {
        callbackURL: "/app",
        errorCallbackURL: "/login",
      });
    } catch (err) {
      setError(
        err instanceof Error && err.message.trim()
          ? err.message
          : "Google or X sign-in did not complete. Try once more.",
      );
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-2">
      {GROK_PROVIDERS.map((p) => (
        <Button
          key={p.providerId}
          type="button"
          variant="secondary"
          className="w-full"
          disabled={busy}
          onClick={() => void onProvider(p.providerId)}
        >
          Continue with {p.label}
        </Button>
      ))}
      {previewHost ? (
        <p className="text-xs leading-relaxed text-subtle">
          Live preview only. Safari may ask for one extra tap in the popup so the
          sign-in cookie stays first-party. Production Google sign-in is a single
          click on the AEVORA site.
        </p>
      ) : null}
      {error ? (
        <p className="text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

function normalizeEmail(value: string): string {
  return value.trim().toLowerCase();
}

function authErrorMessage(message: string | undefined, mode: "signin" | "signup"): string {
  const raw = (message ?? "").trim();
  if (/invalid origin/i.test(raw)) {
    return "This sign-in request was blocked. Open AEVORA from its own keep and try again.";
  }
  if (/invalid email or password/i.test(raw)) {
    return mode === "signin"
      ? "Email or password did not match."
      : "Could not create the account with those details.";
  }
  if (/user already exists|already exists/i.test(raw)) {
    return "An account with that email already exists. Sign in instead.";
  }
  return raw || (mode === "signup" ? "Could not create the account." : "Could not sign in.");
}

function EmailAuthForm() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    const emailValue = normalizeEmail(email);
    try {
      if (mode === "signup") {
        const { data, error: err } = await authClient.signUp.email({
          name: name.trim(),
          email: emailValue,
          password,
        });
        if (err) {
          setError(authErrorMessage(err.message, "signup"));
          return;
        }
        capturePreviewSessionToken(data && "token" in data ? (data.token as string) : null);
      } else {
        const { data, error: err } = await authClient.signIn.email({
          email: emailValue,
          password,
        });
        if (err) {
          setError(authErrorMessage(err.message, "signin"));
          return;
        }
        capturePreviewSessionToken(data?.token);
      }
      await authClient.getSession();
      try {
        const { getOrCreateProfile } = await import("@/lib/profile");
        await getOrCreateProfile();
      } catch {
        // Layout retries on /app. Do not block sign-in on a keep write.
      }
      await navigate({ to: "/app" });
    } catch {
      setError("The request did not complete. Try once more.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="mt-6 flex flex-col gap-3">
      {mode === "signup" ? (
        <Field label="Name" htmlFor="auth-name">
          <Input
            id="auth-name"
            name="name"
            autoComplete="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            maxLength={80}
          />
        </Field>
      ) : null}
      <Field label="Email" htmlFor="auth-email">
        <Input
          id="auth-email"
          name="email"
          type="email"
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </Field>
      <Field label="Password" htmlFor="auth-password">
        <Input
          id="auth-password"
          name="password"
          type="password"
          autoComplete={mode === "signup" ? "new-password" : "current-password"}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={8}
        />
      </Field>
      {error ? (
        <p className="text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
      <Button type="submit" className="mt-1 w-full" disabled={busy}>
        {busy ? "Please wait" : mode === "signup" ? "Create account" : "Sign in"}
      </Button>
      <button
        type="button"
        className="text-center text-sm text-muted hover:text-fg"
        onClick={() => {
          setError(null);
          setMode((m) => (m === "signin" ? "signup" : "signin"));
        }}
      >
        {mode === "signin" ? "Create an account" : "Have an account? Sign in"}
      </button>
    </form>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
    </div>
  );
}
