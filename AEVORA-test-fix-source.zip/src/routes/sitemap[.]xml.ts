import { createFileRoute } from "@tanstack/react-router";
import { env } from "@/lib/env.server";
import { publicSiteOrigin, sitemapXml } from "@/lib/seo";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const body = sitemapXml(publicSiteOrigin(env("BETTER_AUTH_URL")));
        return new Response(body, {
          headers: {
            "content-type": "application/xml; charset=utf-8",
            "cache-control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
