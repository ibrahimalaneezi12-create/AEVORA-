import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { SignedOut } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { AegisMark } from "@/components/brand/aegis-mark";
import { Button } from "@/components/ui/button";
import { robotsDirective } from "@/lib/seo";

const TITLE = "AEVORA — a private personal AI";
const DESCRIPTION =
  "AEVORA is one private AI for personal life, business, and investing. It remembers what you save, and it does not act until you confirm.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { name: "robots", content: robotsDirective("/") },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          name: "AEVORA",
          applicationCategory: "LifestyleApplication",
          description: DESCRIPTION,
          operatingSystem: "Web",
        }),
      },
    ],
  }),
  component: Home,
});

function Home() {
  const { user, isPending } = useCurrentUserState();

  if (!isPending && user) {
    return <Navigate to="/app" />;
  }

  return <Landing />;
}

function Landing() {
  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="flex items-center justify-between gap-3 px-5 py-5 md:px-10">
        <div className="flex items-center gap-3">
          <AegisMark />
          <p className="font-display text-xl tracking-tight">AEVORA</p>
        </div>
        <SignedOut>
          <Button asChild variant="secondary" size="sm">
            <Link to="/login">Sign in</Link>
          </Button>
        </SignedOut>
      </header>

      <main className="mx-auto flex w-full max-w-2xl flex-col px-5 pb-10 pt-16 md:px-8 md:pt-24">
        <p className="text-sm font-medium tracking-wide text-accent">Your personal AI</p>
        <h1 className="font-display mt-5 max-w-[13ch] text-4xl leading-[1.05] tracking-tight md:text-6xl">
          Nothing happens without you.
        </h1>
        <p className="mt-6 max-w-md text-lg leading-relaxed text-muted">
          Talk. Type. Remember. Plan. AEVORA stays private, and never acts until you say so.
        </p>
        <div className="mt-12 min-h-12">
          <SignedOut>
            <Button asChild className="min-h-12 px-7 text-base">
              <Link to="/login">Talk to AEVORA</Link>
            </Button>
          </SignedOut>
        </div>
      </main>

      <section id="what" className="mx-auto w-full max-w-2xl px-5 pb-8 md:px-8">
        <h2 className="font-display text-3xl tracking-tight">What AEVORA is</h2>
        <p className="mt-4 text-base leading-relaxed text-muted">
          AEVORA is one personal AI. You talk to it. It uses the memory you saved, and it asks before it changes anything.
          Business, Invest, and Studio are the same steward with different work, not separate products.
        </p>
      </section>

      <section id="who" className="mx-auto w-full max-w-2xl px-5 py-8 md:px-8">
        <h2 className="font-display text-3xl tracking-tight">Who it is for</h2>
        <p className="mt-4 text-base leading-relaxed text-muted">
          One person who wants an assistant that can remember, plan, look after a business, and research investments
          without acting on its own.
        </p>
      </section>

      <section id="does" className="mx-auto w-full max-w-2xl px-5 py-8 md:px-8">
        <h2 className="font-display text-3xl tracking-tight">What it does</h2>
        <ul className="mt-4 flex flex-col gap-3 text-base leading-relaxed text-muted">
          <li>Main Chat is the personal assistant: memory, plans, reminders, and research.</li>
          <li id="business">Business chat is the business manager. It uses only records you saved or a source that actually answered.</li>
          <li id="invest">Invest chat is the investment manager. It does not invent a price, a balance, or a fill.</li>
          <li id="studio">Studio makes and edits photos and video from Main Chat when the model provider is available.</li>
        </ul>
      </section>

      <section id="privacy" className="mx-auto w-full max-w-2xl px-5 py-8 md:px-8">
        <h2 className="font-display text-3xl tracking-tight">Privacy</h2>
        <p className="mt-4 text-base leading-relaxed text-muted">
          Conversations, memory, business records, and the portfolio stay on your account. Another account cannot open them.
          Public questions do not load that private book. This page is public. The signed-in keep is not indexed.
        </p>
      </section>

      <section id="permissions" className="mx-auto w-full max-w-2xl px-5 pb-24 pt-8 md:px-8">
        <h2 className="font-display text-3xl tracking-tight">Permissions</h2>
        <p className="mt-4 text-base leading-relaxed text-muted">
          AEVORA proposes a consequential action and waits. You confirm it. The assistant cannot approve its own action.
          Nothing here is a guaranteed return, and billing is not offered from this page.
        </p>
      </section>
    </div>
  );
}
