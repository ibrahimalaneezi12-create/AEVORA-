import { createFileRoute, useRouterState } from "@tanstack/react-router";
import { BusinessWorkspace } from "@/components/business/business-workspace";
import { ChatWorkspace } from "@/components/chat/chat-workspace";

export const Route = createFileRoute("/app/business")({
  component: BusinessPage,
});

function BusinessPage() {
  const hash = useRouterState({ select: (s) => s.location.hash.replace(/^#/, "") });
  if (hash === "chat" || hash.startsWith("chat/")) {
    return (
      <main className="flex min-h-0 flex-1 flex-col">
        <ChatWorkspace workspace="business" />
      </main>
    );
  }
  return <BusinessWorkspace />;
}