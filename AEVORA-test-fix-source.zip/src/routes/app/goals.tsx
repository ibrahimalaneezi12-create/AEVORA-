import { createFileRoute } from "@tanstack/react-router";
import { GoalsWorkspace } from "@/components/goals/goals-workspace";

export const Route = createFileRoute("/app/goals")({
  component: GoalsPage,
});

function GoalsPage() {
  return <GoalsWorkspace />;
}
