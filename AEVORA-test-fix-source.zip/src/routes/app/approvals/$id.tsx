import { createFileRoute } from "@tanstack/react-router";
import { ConfirmationScreen } from "@/components/permissions/confirmation-screen";

export const Route = createFileRoute("/app/approvals/$id")({
  component: ApprovalPage,
});

function parseId(raw: string): number | null {
  const n = Number.parseInt(raw, 10);
  if (!Number.isInteger(n) || n < 1 || String(n) !== raw) return null;
  return n;
}

function ApprovalPage() {
  const { id } = Route.useParams();
  return <ConfirmationScreen id={parseId(id)} />;
}
