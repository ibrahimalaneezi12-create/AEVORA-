import { createFileRoute, useRouterState } from "@tanstack/react-router";
import { InvestWorkspace } from "@/components/invest/invest-workspace";
import { ChatWorkspace } from "@/components/chat/chat-workspace";

export const Route = createFileRoute("/app/invest")({
  component: InvestPage,
});

function InvestPage() {
  const hash = useRouterState({ select: (s) => s.location.hash.replace(/^#/, "") });
  if (hash === "chat" || hash.startsWith("chat/")) {
    return (
      <main className="flex min-h-0 flex-1 flex-col">
        <ChatWorkspace workspace="invest" />
      </main>
    );
  }
  return <InvestWorkspace />;
}