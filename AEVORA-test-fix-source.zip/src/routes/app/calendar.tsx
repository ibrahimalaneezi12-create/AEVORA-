import { createFileRoute } from "@tanstack/react-router";
import { CalendarWorkspace } from "@/components/calendar/calendar-workspace";

export const Route = createFileRoute("/app/calendar")({
  component: CalendarPage,
});

function CalendarPage() {
  return <CalendarWorkspace />;
}
