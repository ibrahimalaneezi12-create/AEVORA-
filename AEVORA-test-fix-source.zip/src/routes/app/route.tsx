import { useEffect } from "react";
import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { AppShell, AppShellSkeleton } from "@/components/layout/app-shell";
import { getOrCreateProfile } from "@/lib/profile";
import { applyTheme } from "@/lib/theme";
import { applyDocumentLocale } from "@/lib/locale";
import { AegisMark } from "@/components/brand/aegis-mark";
import { Button } from "@/components/ui/button";

import { robotsDirective } from "@/lib/seo";

export const Route = createFileRoute("/app")({
  head: () => ({
    meta: [
      { name: "robots", content: robotsDirective("/app") },
    ],
  }),
  component: AppLayout,
});

function AppLayout() {
  const { user, isPending } = useCurrentUserState();

  useEffect(() => {
    if (!user) return;
    void getOrCreateProfile()
      .then((profile) => {
        applyTheme(profile.theme);
        applyDocumentLocale(profile.locale);
      })
      .catch(() => undefined);
  }, [user]);

  if (isPending) return <AppShellSkeleton />;
  if (!user) {
    return (
      <>
        <RedirectToSignIn />
        <main className="grid min-h-dvh place-items-center bg-bg px-6 text-fg">
          <div className="w-full max-w-sm">
            <div className="mb-6 flex items-center gap-3">
              <AegisMark />
              <span className="font-display text-lg tracking-tight">AEVORA</span>
            </div>
            <h1 className="font-display text-2xl tracking-tight">Sign in</h1>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              Your steward is private. Sign in to enter the keep.
            </p>
            <Button asChild className="mt-6 w-full">
              <Link to="/login">Sign in</Link>
            </Button>
          </div>
        </main>
      </>
    );
  }
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
