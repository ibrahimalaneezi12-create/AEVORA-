import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  getOrCreateProfile,
  updateProfile,
  PROFILE_THEMES,
  type Profile,
  type ProfileTheme,
} from "@/lib/profile";
import { applyTheme } from "@/lib/theme";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { PermissionsPanel } from "@/components/settings/permissions-panel";
import { LanguageVoicePanel } from "@/components/settings/language-voice-panel";
import { KeepPreferencesPanel } from "@/components/settings/keep-preferences-panel";
import { EntitlementPanel } from "@/components/settings/entitlement-panel";
import { applyDocumentLocale } from "@/lib/locale";

export const Route = createFileRoute("/app/settings")({
  component: SettingsPage,
});

const TIMEZONES = [
  "UTC",
  "Africa/Cairo",
  "Africa/Johannesburg",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "America/New_York",
  "America/Sao_Paulo",
  "America/Toronto",
  "Asia/Dubai",
  "Asia/Kolkata",
  "Asia/Shanghai",
  "Asia/Singapore",
  "Asia/Tokyo",
  "Australia/Sydney",
  "Europe/Berlin",
  "Europe/Istanbul",
  "Europe/London",
  "Europe/Paris",
  "Pacific/Auckland",
];

const THEME_COPY: Record<ProfileTheme, { label: string; hint: string }> = {
  system: { label: "System", hint: "Follow the device" },
  dark: { label: "Evening", hint: "Warm dark" },
  light: { label: "Day", hint: "Ivory paper" },
};

function SettingsPage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [timezone, setTimezone] = useState("UTC");
  const [theme, setTheme] = useState<ProfileTheme>("system");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    getOrCreateProfile()
      .then((row) => {
        if (cancelled) return;
        setProfile(row);
        setDisplayName(row.displayName ?? "");
        setBio(row.bio);
        setTimezone(row.timezone || "UTC");
        setTheme(row.theme);
        applyTheme(row.theme);
        applyDocumentLocale(row.locale);
      })
      .catch(() => {
        if (!cancelled) setLoadError("Could not load your profile.");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const zones = useMemo(() => {
    if (timezone && !TIMEZONES.includes(timezone)) {
      return [timezone, ...TIMEZONES];
    }
    return TIMEZONES;
  }, [timezone]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setSaveError(null);
    setSaved(false);
    setSaving(true);
    try {
      const next = await updateProfile({
        data: { displayName, bio, timezone, theme },
      });
      setProfile(next);
      applyTheme(next.theme);
      setSaved(true);
    } catch (err) {
      if (err instanceof Error && /unauthorized/i.test(err.message)) {
        setSaveError("Sign in to save your profile.");
      } else {
        setSaveError("Could not save. Try once more.");
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="mx-auto w-full max-w-xl flex-1 overflow-y-auto px-5 py-10 md:px-8">
      <p className="text-sm font-medium text-accent">Settings</p>
      <h1 className="font-display mt-2 text-3xl tracking-tight">How AEVORA knows you</h1>
      <p className="mt-3 text-base leading-relaxed text-muted">
        Profile, look, language, voice, and when AEVORA may act.
      </p>

      {loadError ? (
        <p className="mt-8 text-sm text-danger" role="alert">
          {loadError}
        </p>
      ) : !profile ? (
        <div className="mt-8 space-y-3" aria-hidden="true">
          <div className="h-11 animate-pulse rounded-md bg-surface" />
          <div className="h-24 animate-pulse rounded-md bg-surface" />
          <div className="h-11 animate-pulse rounded-md bg-surface" />
        </div>
      ) : (
        <form onSubmit={onSubmit} className="mt-8 flex flex-col gap-5">
          <p className="text-sm font-medium text-fg">Profile</p>
          <Field label="Display name" htmlFor="profile-name">
            <Input
              id="profile-name"
              name="displayName"
              autoComplete="nickname"
              value={displayName}
              onChange={(e) => {
                setDisplayName(e.target.value);
                setSaved(false);
              }}
              maxLength={80}
              placeholder="How AEVORA should greet you"
            />
          </Field>
          <Field label="Bio" htmlFor="profile-bio">
            <Textarea
              id="profile-bio"
              name="bio"
              value={bio}
              onChange={(e) => {
                setBio(e.target.value);
                setSaved(false);
              }}
              maxLength={500}
              rows={4}
              placeholder="A short note about you"
            />
          </Field>
          <Field label="Timezone" htmlFor="profile-timezone">
            <select
              id="profile-timezone"
              name="timezone"
              value={timezone}
              onChange={(e) => {
                setTimezone(e.target.value);
                setSaved(false);
              }}
              className="h-11 min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm text-fg focus-visible:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50"
            >
              {zones.map((z) => (
                <option key={z} value={z}>
                  {z}
                </option>
              ))}
            </select>
          </Field>
          <fieldset>
            <legend className="text-sm font-medium text-fg">Appearance</legend>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {PROFILE_THEMES.map((value) => {
                const selected = theme === value;
                return (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => {
                      setTheme(value);
                      setSaved(false);
                      applyTheme(value);
                    }}
                    className={cn(
                      "flex min-h-12 flex-col items-start justify-center rounded-2xl border px-3 py-2 text-left transition-colors duration-150",
                      selected
                        ? "border-border-strong bg-surface-2 text-fg"
                        : "border-border bg-surface text-muted hover:text-fg",
                    )}
                  >
                    <span className="text-sm font-medium">{THEME_COPY[value].label}</span>
                    <span className="text-xs text-subtle">{THEME_COPY[value].hint}</span>
                  </button>
                );
              })}
            </div>
          </fieldset>
          {saveError ? (
            <p className="text-sm text-danger" role="alert">
              {saveError}
            </p>
          ) : null}
          {saved ? (
            <p className="text-sm text-muted" role="status">
              Saved.
            </p>
          ) : null}
          <Button type="submit" disabled={saving} className="w-full sm:w-auto">
            {saving ? "Saving" : "Save"}
          </Button>
        </form>
      )}

      <div className="mt-12">
        <p className="text-sm font-medium text-fg">Permissions</p>
        <PermissionsPanel />
      </div>
      {profile ? (
        <div className="mt-12">
          <p className="text-sm font-medium text-fg">Language & voice</p>
          <LanguageVoicePanel profile={profile} onSaved={setProfile} />
        </div>
      ) : null}
      {profile ? (
        <div className="mt-12">
          <p className="text-sm font-medium text-fg">Pulse</p>
          <KeepPreferencesPanel profile={profile} onSaved={setProfile} />
        </div>
      ) : null}
      <div className="mt-12">
        <p className="text-sm font-medium text-fg">Plan</p>
        <EntitlementPanel />
      </div>
    </main>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
    </div>
  );
}
