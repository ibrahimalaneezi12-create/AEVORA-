import { createFileRoute } from "@tanstack/react-router";
import { MemoryWorkspace } from "@/components/memory/memory-workspace";

export const Route = createFileRoute("/app/memory")({
  component: MemoryPage,
});

function MemoryPage() {
  return <MemoryWorkspace />;
}
