import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/app/chat/")({
  component: ChatIndex,
});

function ChatIndex() {
  return null;
}
