import { createFileRoute, Outlet } from "@tanstack/react-router";
import { ChatWorkspace } from "@/components/chat/chat-workspace";

export const Route = createFileRoute("/app/chat")({
  component: ChatLayout,
});

function ChatLayout() {
  return (
    <main className="flex min-h-0 flex-1 flex-col">
      <ChatWorkspace />
      <Outlet />
    </main>
  );
}
