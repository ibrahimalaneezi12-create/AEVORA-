import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/app/chat/$id")({
  component: ChatConversation,
});

function ChatConversation() {
  return null;
}
