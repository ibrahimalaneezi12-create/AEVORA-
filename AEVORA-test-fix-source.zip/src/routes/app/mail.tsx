import { createFileRoute } from "@tanstack/react-router";
import { MailWorkspace } from "@/components/mail/mail-workspace";

export const Route = createFileRoute("/app/mail")({
  component: MailPage,
});

function MailPage() {
  return <MailWorkspace />;
}
