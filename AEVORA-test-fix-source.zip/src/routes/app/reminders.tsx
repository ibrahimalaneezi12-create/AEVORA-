import { createFileRoute } from "@tanstack/react-router";
import { RemindersWorkspace } from "@/components/reminders/reminders-workspace";

export const Route = createFileRoute("/app/reminders")({
  component: RemindersPage,
});

function RemindersPage() {
  return <RemindersWorkspace />;
}
