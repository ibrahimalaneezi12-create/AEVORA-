import { createFileRoute } from "@tanstack/react-router";
import { DashboardWorkspace } from "@/components/dashboard/dashboard-workspace";

export const Route = createFileRoute("/app/")({
  component: DashboardPage,
});

function DashboardPage() {
  return <DashboardWorkspace />;
}
