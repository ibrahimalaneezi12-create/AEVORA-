import { createFileRoute } from "@tanstack/react-router";
import { CreationWorkspace } from "@/components/creation/creation-workspace";

export const Route = createFileRoute("/app/create")({
  component: CreatePage,
});

function CreatePage() {
  return <CreationWorkspace />;
}
