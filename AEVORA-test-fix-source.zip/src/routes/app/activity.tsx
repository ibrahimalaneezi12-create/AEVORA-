import { createFileRoute } from "@tanstack/react-router";
import { ActivityWorkspace } from "@/components/activity/activity-workspace";

export const Route = createFileRoute("/app/activity")({
  component: ActivityPage,
});

function ActivityPage() {
  return <ActivityWorkspace />;
}
