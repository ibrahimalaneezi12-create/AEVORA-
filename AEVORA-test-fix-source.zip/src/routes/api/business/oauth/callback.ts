import { createFileRoute } from "@tanstack/react-router";
import { assertSameSiteRequest } from "@/lib/auth/isolation.server";
import { requireUserId } from "@/lib/auth/verify.server";

function back(result: string): Response {
  return new Response(null, {
    status: 302,
    headers: { location: `/app/business?link=${encodeURIComponent(result)}` },
  });
}

export const Route = createFileRoute("/api/business/oauth/callback")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          assertSameSiteRequest();
        } catch {
          return back("failed");
        }
        const url = new URL(request.url);
        const error = url.searchParams.get("error");
        if (error) return back("denied");
        const code = url.searchParams.get("code") ?? "";
        const state = url.searchParams.get("state") ?? "";
        const realmId = url.searchParams.get("realmId") ?? "";
        if (!code || !state) return back("failed");
        let userId = "";
        try {
          userId = await requireUserId();
        } catch {
          return back("failed");
        }
        const { completeOAuthForUser } = await import("@/lib/providers.server");
        const result = await completeOAuthForUser({ sessionUserId: userId, state, code, realmId });
        return back(result.ok ? result.provider : "failed");
      },
    },
  },
});
