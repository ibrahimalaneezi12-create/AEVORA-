import { createFileRoute } from "@tanstack/react-router";
import { getSessionUser } from "@/lib/auth/verify.server";
import { assertSameSiteRequest } from "@/lib/auth/isolation.server";
import { PRIVATE_HTTP_HEADERS, GENERIC_NOT_FOUND } from "@/lib/privacy";
import { ownedStudioAsset } from "@/lib/studio";

export const Route = createFileRoute("/api/studio/media/$id")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        try {
          assertSameSiteRequest();
        } catch {
          return Response.json({ error: "Forbidden" }, { status: 403, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        const user = await getSessionUser();
        if (!user) {
          return Response.json({ error: "Unauthorized" }, { status: 401, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        const id = Number(params.id);
        if (!Number.isInteger(id) || id < 1) {
          return Response.json({ error: GENERIC_NOT_FOUND }, { status: 404, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        const owned = await ownedStudioAsset(user.id, id);
        if (!owned) {
          return Response.json({ error: GENERIC_NOT_FOUND }, { status: 404, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        void request;
        const copy = new Uint8Array(owned.bytes.byteLength);
        copy.set(owned.bytes);
        return new Response(copy, {
          status: 200,
          headers: {
            ...PRIVATE_HTTP_HEADERS,
            "Content-Type": owned.mime,
            "Content-Disposition": "inline",
          },
        });
      },
    },
  },
});