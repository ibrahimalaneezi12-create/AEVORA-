import { createFileRoute } from "@tanstack/react-router";
import { getSessionUser } from "@/lib/auth/verify.server";
import { assertSameSiteRequest } from "@/lib/auth/isolation.server";
import { STT_MAX_BYTES } from "@/lib/stt-format";
import { PRIVATE_HTTP_HEADERS } from "@/lib/privacy";

export const Route = createFileRoute("/api/stt")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          assertSameSiteRequest();
        } catch {
          return Response.json({ error: "Forbidden" }, { status: 403 });
        }
        const authHeader = request.headers.get("Authorization");
        const bearer = authHeader?.toLowerCase().startsWith("bearer ")
          ? authHeader.slice(7).trim()
          : undefined;
        const user = await getSessionUser(bearer);
        if (!user) {
          return Response.json({ error: "Unauthorized" }, { status: 401, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        const mime = (request.headers.get("content-type") || "audio/wav").split(";")[0]?.trim() || "audio/wav";
        const locale = request.headers.get("x-aegis-locale")?.trim() || "";
        const buf = new Uint8Array(await request.arrayBuffer());
        if (buf.byteLength < 64) {
          return Response.json({ ok: false, error: "I did not catch that. Try again." });
        }
        if (buf.byteLength > STT_MAX_BYTES) {
          return Response.json({ ok: false, error: "That was too long to transcribe." }, { status: 413 });
        }
        const { transcribeAudioBytes } = await import("@/lib/stt.server");
        const result = await transcribeAudioBytes({ bytes: buf, mime, locale });
        return Response.json(result, { headers: { ...PRIVATE_HTTP_HEADERS } });
      },
    },
  },
});
