import { createFileRoute } from "@tanstack/react-router";
import { getSessionUser } from "@/lib/auth/verify.server";
import { assertSameSiteRequest } from "@/lib/auth/isolation.server";
import { TTS_TEXT_MAX } from "@/lib/tts-format";
import { PRIVATE_HTTP_HEADERS } from "@/lib/privacy";

type TtsBody = {
  text?: string;
  voiceId?: string;
  locale?: string;
  speed?: number;
};

export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          assertSameSiteRequest();
        } catch {
          return Response.json({ error: "Forbidden" }, { status: 403 });
        }
        const authHeader = request.headers.get("Authorization");
        const bearer = authHeader?.toLowerCase().startsWith("bearer ")
          ? authHeader.slice(7).trim()
          : undefined;
        const user = await getSessionUser(bearer);
        if (!user) {
          return Response.json({ error: "Unauthorized" }, { status: 401 });
        }
        let body: TtsBody = {};
        try {
          body = (await request.json()) as TtsBody;
        } catch {
          return Response.json({ error: "Nothing to speak." }, { status: 400 });
        }
        const text = typeof body.text === "string" ? body.text.trim() : "";
        if (!text) return Response.json({ error: "Nothing to speak." }, { status: 400 });
        if (text.length > TTS_TEXT_MAX) {
          return Response.json({ error: "That is too long to speak." }, { status: 400 });
        }
        const { synthesizeSpeechBytes } = await import("@/lib/tts.server");
        const result = await synthesizeSpeechBytes({
          text,
          voiceId: typeof body.voiceId === "string" ? body.voiceId : undefined,
          locale: typeof body.locale === "string" ? body.locale : undefined,
          speed: typeof body.speed === "number" ? body.speed : undefined,
        });
        if (!result.ok) {
          return Response.json(
            { ok: false, error: result.error, unavailable: result.unavailable, ttsMs: result.ttsMs },
            { status: result.unavailable ? 503 : 400 },
          );
        }
        const copy = new Uint8Array(result.audio.byteLength);
        copy.set(result.audio);
        return new Response(copy, {
          status: 200,
          headers: {
            "Content-Type": result.mime,
            "X-Aegis-Tts-Ms": String(result.ttsMs),
            "X-Aegis-Voice-Id": result.voiceId,
            "Cache-Control": PRIVATE_HTTP_HEADERS["Cache-Control"],
            Pragma: PRIVATE_HTTP_HEADERS.Pragma,
            Vary: PRIVATE_HTTP_HEADERS.Vary,
          },
        });
      },
    },
  },
});
