import { createFileRoute } from "@tanstack/react-router";
import { getSessionUser } from "@/lib/auth/verify.server";
import { assertSameSiteRequest } from "@/lib/auth/isolation.server";
import { elapsedMs, markFirstToken } from "@/lib/latency-format";
import { PRIVATE_HTTP_HEADERS } from "@/lib/privacy";
import { parseChatWorkspace } from "@/lib/chat-workspace";

type StreamBody = {
  content?: string;
  conversationId?: number;
  workspace?: unknown;
};

function sse(event: string, data: unknown): string {
  return `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
}

export const Route = createFileRoute("/api/chat/stream")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          assertSameSiteRequest();
        } catch {
          return new Response(JSON.stringify({ error: "Forbidden" }), {
            status: 403,
            headers: { "Content-Type": "application/json" },
          });
        }

        const authHeader = request.headers.get("Authorization");
        const bearer = authHeader?.toLowerCase().startsWith("bearer ")
          ? authHeader.slice(7).trim()
          : undefined;
        const user = await getSessionUser(bearer);
        if (!user) {
          return new Response(JSON.stringify({ error: "Unauthorized" }), {
            status: 401,
            headers: { "Content-Type": "application/json" },
          });
        }

        let body: StreamBody = {};
        try {
          body = (await request.json()) as StreamBody;
        } catch {
          return new Response(JSON.stringify({ error: "Say something first." }), {
            status: 400,
            headers: { "Content-Type": "application/json" },
          });
        }
        const content = typeof body.content === "string" ? body.content.trim() : "";
        if (!content) {
          return new Response(JSON.stringify({ error: "Say something first." }), {
            status: 400,
            headers: { "Content-Type": "application/json" },
          });
        }
        if (content.length > 4000) {
          return new Response(JSON.stringify({ error: "That message is too long." }), {
            status: 400,
            headers: { "Content-Type": "application/json" },
          });
        }
        const conversationId =
          typeof body.conversationId === "number" && Number.isInteger(body.conversationId) && body.conversationId > 0
            ? body.conversationId
            : undefined;

        const stream = new ReadableStream({
          async start(controller) {
            const encoder = new TextEncoder();
            const send = (event: string, data: unknown) => {
              controller.enqueue(encoder.encode(sse(event, data)));
            };
            const { tryBeginTurn, endTurn, prepareOwnedTurn, finalizeOwnedTurn, isTurnPrep, currentTurnGeneration, isCurrentTurn } = await import(
              "@/lib/chat-turn.server"
            );
            if (!tryBeginTurn(user.id, true)) {
              send("error", { error: "AEVORA is already answering. Wait for this reply." });
              controller.close();
              return;
            }
            const generation = currentTurnGeneration(user.id);
            send("status", { text: "thinking" });
            try {
              const prepared = await prepareOwnedTurn(
                user.id,
                content,
                conversationId,
                parseChatWorkspace(body.workspace),
              );
              if (!isCurrentTurn(user.id, generation)) {
                controller.close();
                return;
              }
              if (!isTurnPrep(prepared)) {
                send("error", {
                  error: prepared.ok === false ? prepared.error : "Could not start the turn.",
                  unavailable: prepared.ok === false ? prepared.unavailable : undefined,
                  conversation: prepared.ok === false ? prepared.conversation : null,
                  userMessage: prepared.ok === false ? prepared.userMessage : null,
                });
                controller.close();
                return;
              }
              send("meta", {
                conversationId: prepared.conversation.id,
                userMessage: prepared.userMessage,
                title: prepared.conversation.title,
              });
              if (prepared.extra.fastReply) {
                const reply = prepared.extra.fastReply;
                send("delta", { text: reply });
                const result = await finalizeOwnedTurn(user.id, prepared, reply, [], markFirstToken(prepared.startedAt, 0));
                if (!result.ok) {
                  send("error", {
                    error: result.error,
                    unavailable: result.unavailable,
                    conversation: prepared.conversation,
                    userMessage: prepared.userMessage,
                  });
                  return;
                }
                send("done", {
                  conversation: result.conversation,
                  userMessage: result.userMessage,
                  assistantMessage: result.assistantMessage,
                  proposals: result.proposals,
                  rejected: result.rejected,
                  citations: result.citations,
                  latency: result.latency,
                  completeMs: elapsedMs(prepared.startedAt),
                });
                return;
              }
              const { streamTurn } = await import("@/lib/ai/complete.server");
              let raw = "";
              let citations: string[] = [];
              let firstTokenMs: number | null = null;
              for await (const event of streamTurn(
                prepared.history.map((m) => ({ role: m.role, content: m.content })),
                prepared.extra,
              )) {
                if (!isCurrentTurn(user.id, generation)) {
                  controller.close();
                  return;
                }
                if (event.type === "status") {
                  send("status", { text: event.text });
                  continue;
                }
                if (event.type === "delta") {
                  if (firstTokenMs == null) firstTokenMs = markFirstToken(prepared.startedAt, null);
                  raw += event.text;
                  send("delta", { text: event.text });
                  continue;
                }
                if (event.type === "error") {
                  send("error", {
                    error: event.error,
                    unavailable: event.unavailable,
                    conversation: prepared.conversation,
                    userMessage: prepared.userMessage,
                  });
                  controller.close();
                  return;
                }
                raw = event.text;
                citations = event.citations;
              }
              if (!isCurrentTurn(user.id, generation)) {
                return;
              }
              const result = await finalizeOwnedTurn(user.id, prepared, raw, citations, firstTokenMs);
              if (!result.ok) {
                send("error", {
                  error: result.error,
                  unavailable: result.unavailable,
                  conversation: prepared.conversation,
                  userMessage: prepared.userMessage,
                });
                controller.close();
                return;
              }
              send("done", {
                conversation: result.conversation,
                userMessage: result.userMessage,
                assistantMessage: result.assistantMessage,
                proposals: result.proposals,
                rejected: result.rejected,
                citations: result.citations,
                latency: result.latency,
                completeMs: elapsedMs(prepared.startedAt),
              });
            } catch (err) {
              const message = err instanceof Error ? err.message : "The request did not complete.";
              send("error", { error: /unauthorized/i.test(message) ? "Unauthorized" : message });
            } finally {
              if (isCurrentTurn(user.id, generation)) endTurn(user.id);
              controller.close();
            }
          },
        });

        return new Response(stream, {
          status: 200,
          headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": PRIVATE_HTTP_HEADERS["Cache-Control"],
            Pragma: PRIVATE_HTTP_HEADERS.Pragma,
            Vary: PRIVATE_HTTP_HEADERS.Vary,
            Connection: "keep-alive",
          },
        });
      },
    },
  },
});
