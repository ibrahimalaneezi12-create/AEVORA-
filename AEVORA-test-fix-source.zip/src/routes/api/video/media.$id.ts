import { createFileRoute } from "@tanstack/react-router";
import { getSessionUser } from "@/lib/auth/verify.server";
import { assertSameSiteRequest } from "@/lib/auth/isolation.server";
import { PRIVATE_HTTP_HEADERS, GENERIC_NOT_FOUND } from "@/lib/privacy";
import { ownedVideoMedia } from "@/lib/video";
import { fetchOwnedMediaBytes } from "@/lib/video-provider.server";

export const Route = createFileRoute("/api/video/media/$id")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        try {
          assertSameSiteRequest();
        } catch {
          return Response.json({ error: "Forbidden" }, { status: 403, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        const user = await getSessionUser();
        if (!user) {
          return Response.json({ error: "Unauthorized" }, { status: 401, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        const id = Number(params.id);
        if (!Number.isInteger(id) || id < 1) {
          return Response.json({ error: GENERIC_NOT_FOUND }, { status: 404, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        const owned = await ownedVideoMedia(user.id, id);
        if (!owned) {
          return Response.json({ error: GENERIC_NOT_FOUND }, { status: 404, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        const file = await fetchOwnedMediaBytes(owned.url);
        if (!file) {
          return Response.json({ error: "Media is no longer available." }, { status: 410, headers: { ...PRIVATE_HTTP_HEADERS } });
        }
        void request;
        const copy = new Uint8Array(file.bytes.byteLength);
        copy.set(file.bytes);
        return new Response(copy, {
          status: 200,
          headers: {
            ...PRIVATE_HTTP_HEADERS,
            "Content-Type": file.mime,
            "Content-Disposition": "inline",
          },
        });
      },
    },
  },
});
