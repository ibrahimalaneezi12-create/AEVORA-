import { createFileRoute } from "@tanstack/react-router";
import { auth } from "@/lib/auth/server";
import { requestForAuthBroker } from "@/lib/auth-public-request";
import { rewriteOAuthCallbackForPopup } from "@/lib/auth/popup.server";

function logOAuthCallback(request: Request, response: Response): void {
  const url = new URL(request.url);
  if (!url.pathname.includes("/oauth2/callback/")) return;
  const location = response.headers.get("location") ?? "";
  let error: string | null = null;
  try {
    error = location ? new URL(location, url.origin).searchParams.get("error") : null;
  } catch {
    error = null;
  }
  const cookies =
    typeof response.headers.getSetCookie === "function" ? response.headers.getSetCookie() : [];
  const cookieHeader = request.headers.get("cookie") ?? "";
  const cookieNames = cookieHeader
    .split(";")
    .map((part) => part.trim().split("=")[0])
    .filter((name) => name.length > 0);
  console.info(
    "[aegis-oauth]",
    JSON.stringify({
      status: response.status,
      origin: url.origin,
      hasCode: url.searchParams.has("code"),
      hasState: url.searchParams.has("state"),
      hasSessionCookie: cookies.some((c) => c.startsWith("__Host-grok-auth.session_token=")),
      hasStateCookie: cookieNames.some(
        (name) =>
          name === "grok-auth.state" ||
          name === "grok-auth.oauth_state" ||
          name === "__Host-grok-auth.state" ||
          name === "__Host-grok-auth.oauth_state" ||
          name === "better-auth.state" ||
          name === "better-auth.oauth_state",
      ),
      cookieNames,
      error,
    }),
  );
}

export const Route = createFileRoute("/api/auth/$")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const req = requestForAuthBroker(request);
        const res = await auth.handler(req);
        logOAuthCallback(req, res);
        return rewriteOAuthCallbackForPopup(req, res);
      },
      POST: ({ request }) => auth.handler(requestForAuthBroker(request)),
    },
  },
});
