import { catalogLevel, isChatReply, isExecutable } from "./catalog.ts";
import type { ClassifiedProposal, ParsedProposal } from "./types.ts";
import { effectiveLevel, type ConfirmFloor } from "../permissions-format.ts";

/**
 * Map a parsed proposal to a permission level from the allowlist, then apply
 * the user's confirmation floor. The model cannot choose or upgrade a level.
 * A quieter floor never lowers the catalog.
 */
export function classifyProposal(
  item: ParsedProposal,
  floor: ConfirmFloor = "safe",
): ClassifiedProposal | null {
  if (isChatReply(item.toolId)) return null;

  const catalog = catalogLevel(item.toolId);
  if (catalog === "restricted" || !isExecutable(item.toolId)) {
    return {
      ...item,
      permissionLevel: "restricted",
      accepted: false,
      reason: item.toolId.startsWith("external.")
        ? "External actions are not allowed."
        : "This action is restricted.",
    };
  }

  return {
    ...item,
    permissionLevel: effectiveLevel(catalog, floor),
    accepted: true,
    reason: "pending",
  };
}

export function classifyAll(
  items: ParsedProposal[],
  floor: ConfirmFloor = "safe",
): ClassifiedProposal[] {
  const out: ClassifiedProposal[] = [];
  for (const item of items) {
    const classified = classifyProposal(item, floor);
    if (classified) out.push(classified);
  }
  return out;
}
