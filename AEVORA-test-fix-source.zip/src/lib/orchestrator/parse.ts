import { z } from "zod";
import {
  MAX_PAYLOAD_BYTES,
  MAX_PROPOSALS_PER_TURN,
  MAX_SUMMARY,
  MAX_TITLE,
  type ParsedProposal,
} from "./types.ts";

const BLOCK =
  /<<<aegis-proposals\s*([\s\S]*?)\s*>>>/gi;
const FENCE = /```aegis-proposals\s*([\s\S]*?)```/gi;

const itemSchema = z.object({
  tool_id: z
    .string()
    .trim()
    .min(1)
    .max(64)
    .regex(/^[a-z][a-z0-9._]*$/),
  title: z.string().trim().min(1).max(MAX_TITLE),
  summary: z.string().trim().min(1).max(MAX_SUMMARY),
  payload: z.record(z.string(), z.unknown()).optional(),
});

export type ParseProposalsResult = {
  speech: string;
  proposals: ParsedProposal[];
};

function extractBlocks(raw: string): { speech: string; bodies: string[] } {
  const bodies: string[] = [];
  const stripped = raw
    .replace(BLOCK, (_, body: string) => {
      bodies.push(body);
      return "\n";
    })
    .replace(FENCE, (_, body: string) => {
      bodies.push(body);
      return "\n";
    });
  const speech = stripped.replace(/\n{3,}/g, "\n\n").trim();
  return { speech, bodies };
}

function asObjectArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object" && "proposals" in value) {
    const inner = (value as { proposals: unknown }).proposals;
    if (Array.isArray(inner)) return inner;
  }
  if (value && typeof value === "object") return [value];
  return [];
}

function unwrapJson(body: string): string {
  let text = body.trim();
  const fenced = text.match(/^```(?:json)?\s*([\s\S]*?)```$/i);
  if (fenced?.[1]) text = fenced[1].trim();
  return text;
}

function parseBody(body: string): ParsedProposal[] {
  let parsed: unknown;
  try {
    parsed = JSON.parse(unwrapJson(body));
  } catch {
    return [];
  }
  const out: ParsedProposal[] = [];
  for (const item of asObjectArray(parsed)) {
    const result = itemSchema.safeParse(item);
    if (!result.success) continue;
    const payload = result.data.payload ?? {};
    let encoded: string;
    try {
      encoded = JSON.stringify(payload);
    } catch {
      continue;
    }
    if (encoded.length > MAX_PAYLOAD_BYTES) continue;
    out.push({
      toolId: result.data.tool_id,
      title: result.data.title,
      summary: result.data.summary,
      payload,
    });
    if (out.length >= MAX_PROPOSALS_PER_TURN) break;
  }
  return out;
}

/**
 * Split assistant text into visible speech and structured proposals.
 * Malformed blocks are dropped, never executed. Caps at MAX_PROPOSALS_PER_TURN.
 */
export function parseProposals(raw: string): ParseProposalsResult {
  if (!raw || typeof raw !== "string") return { speech: "", proposals: [] };
  const { speech, bodies } = extractBlocks(raw);
  const proposals: ParsedProposal[] = [];
  for (const body of bodies) {
    for (const item of parseBody(body)) {
      proposals.push(item);
      if (proposals.length >= MAX_PROPOSALS_PER_TURN) {
        return { speech, proposals };
      }
    }
  }
  return { speech, proposals };
}

export function fallbackSpeech(speech: string, hadProposals: boolean): string {
  if (speech.trim()) return speech.trim();
  if (hadProposals) {
    return "I have something to propose. It will not run until you confirm.";
  }
  return "";
}
