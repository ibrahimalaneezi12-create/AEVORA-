import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { planTurn } from "./plan.ts";

function block(inner: string, speech = "I can save that."): string {
  return `${speech}\n\n<<<aegis-proposals\n${inner}\n>>>\n`;
}

describe("planTurn", () => {
  it("accepts a Review tool as pending, not executed", () => {
    const r = planTurn(
      block(
        JSON.stringify([
          {
            tool_id: "memory.save",
            title: "Save tea preference",
            summary: "Remember that you drink tea.",
            payload: { body: "Prefers tea" },
            permission_level: "safe",
          },
        ]),
      ),
    );
    assert.equal(r.accepted.length, 1);
    assert.equal(r.rejected.length, 0);
    assert.equal(r.accepted[0]?.permissionLevel, "review");
    assert.equal(r.accepted[0]?.accepted, true);
    assert.equal(r.speech.includes("<<<"), false);
    assert.equal(r.speech.includes("memory.save"), false);
    assert.equal("execute" in r, false);
  });

  it("rejects Restricted tools and does not accept them", () => {
    const r = planTurn(
      block(
        JSON.stringify([
          {
            tool_id: "permission.update",
            title: "Turn on auto-run",
            summary: "Loosen permissions",
          },
        ]),
      ),
    );
    assert.equal(r.accepted.length, 0);
    assert.equal(r.rejected.length, 1);
    assert.equal(r.rejected[0]?.permissionLevel, "restricted");
    assert.equal(r.rejected[0]?.accepted, false);
    assert.match(r.speech, /restricted/i);
  });

  it("rejects unregistered and external ids", () => {
    const r = planTurn(
      block(
        JSON.stringify([
          {
            tool_id: "shell.exec",
            title: "Run a shell",
            summary: "Not allowed",
          },
          {
            tool_id: "external.email",
            title: "Send email",
            summary: "Not allowed",
          },
        ]),
      ),
    );
    assert.equal(r.accepted.length, 0);
    assert.equal(r.rejected.length, 2);
  });

  it("skips chat.reply so speech is not queued as a tool", () => {
    const r = planTurn(
      block(
        JSON.stringify([
          {
            tool_id: "chat.reply",
            title: "Reply",
            summary: "Just talking",
          },
        ]),
      ),
    );
    assert.equal(r.accepted.length, 0);
    assert.equal(r.rejected.length, 0);
  });

  it("keeps a valid neighbour when a Restricted item is mixed in", () => {
    const r = planTurn(
      block(
        JSON.stringify([
          {
            tool_id: "task.create",
            title: "Add a task",
            summary: "Buy tea",
          },
          {
            tool_id: "external.pay",
            title: "Pay a bill",
            summary: "Not allowed",
          },
        ]),
      ),
    );
    assert.equal(r.accepted.length, 1);
    assert.equal(r.accepted[0]?.toolId, "task.create");
    assert.equal(r.rejected.length, 1);
  });

  it("returns speech only when there is no block", () => {
    const r = planTurn("Just a reply.");
    assert.equal(r.speech, "Just a reply.");
    assert.equal(r.accepted.length, 0);
    assert.equal(r.rejected.length, 0);
  });

  it("stores a Review tool as Approval when the floor is raised", () => {
    const r = planTurn(
      block(
        JSON.stringify([
          {
            tool_id: "memory.save",
            title: "Save tea preference",
            summary: "Remember that you drink tea.",
          },
        ]),
      ),
      "approval",
    );
    assert.equal(r.accepted.length, 1);
    assert.equal(r.accepted[0]?.permissionLevel, "approval");
    assert.equal("execute" in r, false);
  });

  it("does not loosen an Approval tool when the floor is safe", () => {
    const r = planTurn(
      block(
        JSON.stringify([
          {
            tool_id: "memory.delete",
            title: "Delete a memory",
            summary: "Remove a keep",
            permission_level: "safe",
          },
        ]),
      ),
      "safe",
    );
    assert.equal(r.accepted[0]?.permissionLevel, "approval");
  });
});
