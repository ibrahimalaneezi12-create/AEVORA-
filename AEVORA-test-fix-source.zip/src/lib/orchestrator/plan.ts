import { classifyAll } from "./classify.ts";
import { fallbackSpeech, parseProposals } from "./parse.ts";
import type { ClassifiedProposal } from "./types.ts";
import type { ConfirmFloor } from "../permissions-format.ts";

export type TurnPlan = {
  speech: string;
  accepted: ClassifiedProposal[];
  rejected: ClassifiedProposal[];
};

/**
 * Pure turn plan: parse, classify with the user's floor, strip the block.
 * Does not touch the database and does not execute anything.
 */
export function planTurn(raw: string, floor: ConfirmFloor = "safe"): TurnPlan {
  const parsed = parseProposals(raw);
  const classified = classifyAll(parsed.proposals, floor);
  const accepted: ClassifiedProposal[] = [];
  const rejected: ClassifiedProposal[] = [];
  for (const item of classified) {
    if (item.accepted) accepted.push(item);
    else rejected.push(item);
  }
  let speech = fallbackSpeech(parsed.speech, parsed.proposals.length > 0);
  if (rejected.length > 0) {
    const notes = rejected.map((r) => r.reason).join(" ");
    speech = speech ? `${speech}\n\n${notes}` : notes;
  }
  return { speech, accepted, rejected };
}
