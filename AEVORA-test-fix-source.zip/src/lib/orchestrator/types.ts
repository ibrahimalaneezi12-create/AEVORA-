export const PERMISSION_LEVELS = ["safe", "review", "approval", "restricted"] as const;
export type PermissionLevel = (typeof PERMISSION_LEVELS)[number];

export const PROPOSAL_STATUSES = [
  "pending",
  "approved",
  "denied",
  "executed",
  "failed",
  "cancelled",
] as const;
export type ProposalStatus = (typeof PROPOSAL_STATUSES)[number];

export type ToolDefinition = {
  id: string;
  displayName: string;
  description: string;
  permissionLevel: PermissionLevel;
  enabled: boolean;
};

export type ParsedProposal = {
  toolId: string;
  title: string;
  summary: string;
  payload: Record<string, unknown>;
};

export type ClassifiedProposal = ParsedProposal & {
  permissionLevel: PermissionLevel;
  accepted: boolean;
  reason: string;
};

export type ProposedActionView = {
  id: number;
  conversationId: number | null;
  toolId: string;
  displayName: string;
  permissionLevel: PermissionLevel;
  title: string;
  summary: string;
  status: ProposalStatus;
  createdAt: string;
};

export type RejectedProposalView = {
  toolId: string;
  title: string;
  reason: string;
};

export type ApplyTurnResult = {
  speech: string;
  proposals: ProposedActionView[];
  rejected: RejectedProposalView[];
};

export const MAX_PROPOSALS_PER_TURN = 3;
export const MAX_PAYLOAD_BYTES = 4096;
export const MAX_TITLE = 80;
export const MAX_SUMMARY = 280;
