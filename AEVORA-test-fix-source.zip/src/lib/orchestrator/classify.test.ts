import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { classifyProposal } from "./classify.ts";
import { catalogLevel, registerTool } from "./catalog.ts";
import type { ParsedProposal } from "./types.ts";

function item(toolId: string): ParsedProposal {
  return {
    toolId,
    title: "Title",
    summary: "Summary",
    payload: {},
  };
}

describe("classifyProposal", () => {
  it("maps reminder.create to review and reminder.cancel to approval", () => {
    assert.equal(classifyProposal(item("reminder.create"))?.permissionLevel, "review");
    assert.equal(classifyProposal(item("reminder.create"))?.accepted, true);
    assert.equal(classifyProposal(item("reminder.cancel"))?.permissionLevel, "approval");
    assert.equal(classifyProposal(item("goal.update"))?.permissionLevel, "review");
  });

  it("maps memory.search to safe", () => {
    assert.equal(classifyProposal(item("memory.search"))?.permissionLevel, "safe");
  });

  it("maps memory.delete to approval", () => {
    assert.equal(classifyProposal(item("memory.delete"))?.permissionLevel, "approval");
  });

  it("skips chat.reply", () => {
    assert.equal(classifyProposal(item("chat.reply")), null);
  });

  it("rejects unregistered ids as restricted", () => {
    const r = classifyProposal(item("shell.exec"));
    assert.equal(r?.permissionLevel, "restricted");
    assert.equal(r?.accepted, false);
  });

  it("rejects external.* as restricted", () => {
    const r = classifyProposal(item("external.email"));
    assert.equal(r?.accepted, false);
    assert.equal(r?.permissionLevel, "restricted");
  });

  it("rejects permission.update as restricted", () => {
    const r = classifyProposal(item("permission.update"));
    assert.equal(r?.accepted, false);
    assert.equal(r?.permissionLevel, "restricted");
  });

  it("never upgrades approval to safe", () => {
    assert.equal(catalogLevel("memory.delete"), "approval");
    assert.notEqual(catalogLevel("memory.delete"), "safe");
    assert.notEqual(catalogLevel("profile.update"), "review");
  });

  it("tightens Review to Approval when the floor is approval", () => {
    const r = classifyProposal(item("memory.save"), "approval");
    assert.equal(r?.permissionLevel, "approval");
    assert.equal(r?.accepted, true);
  });

  it("tightens Safe to Review when the floor is review", () => {
    const r = classifyProposal(item("memory.search"), "review");
    assert.equal(r?.permissionLevel, "review");
    assert.equal(r?.accepted, true);
  });

  it("does not loosen Approval when the floor is safe", () => {
    const r = classifyProposal(item("memory.delete"), "safe");
    assert.equal(r?.permissionLevel, "approval");
    assert.equal(r?.accepted, true);
  });

  it("still rejects Restricted when the floor is approval", () => {
    const r = classifyProposal(item("permission.update"), "approval");
    assert.equal(r?.permissionLevel, "restricted");
    assert.equal(r?.accepted, false);
  });

  it("rejects a registered tool that has no handler as restricted", () => {
    registerTool({
      id: "test.step14.classify.nohandler",
      displayName: "No handler",
      description: "Missing handler",
      permissionLevel: "review",
      enabled: true,
    });
    const r = classifyProposal(item("test.step14.classify.nohandler"));
    assert.equal(r?.permissionLevel, "restricted");
    assert.equal(r?.accepted, false);
  });
});
