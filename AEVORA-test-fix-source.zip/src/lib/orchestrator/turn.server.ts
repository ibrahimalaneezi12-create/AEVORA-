import { getSql } from "@/lib/db";
import { appendAudit } from "../audit.ts";
import { displayNameFor } from "./catalog.ts";
import { planTurn } from "./plan.ts";
import type {
  PermissionLevel,
  ProposalStatus,
  ProposedActionView,
  RejectedProposalView,
} from "./types.ts";
import type { ConfirmFloor } from "../permissions-format.ts";

type ActionRow = {
  id: unknown;
  conversation_id: unknown;
  tool_id: string;
  permission_level: string;
  title: string;
  summary: string;
  status: string;
  created_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

function asLevel(value: string): PermissionLevel {
  if (value === "safe" || value === "review" || value === "approval" || value === "restricted") {
    return value;
  }
  return "restricted";
}

function asStatus(value: string): ProposalStatus {
  if (
    value === "pending" ||
    value === "approved" ||
    value === "denied" ||
    value === "executed" ||
    value === "failed" ||
    value === "cancelled"
  ) {
    return value;
  }
  return "pending";
}

function mapAction(row: ActionRow): ProposedActionView | null {
  const id = asId(row.id);
  if (!id) return null;
  const conversationId = asId(row.conversation_id);
  return {
    id,
    conversationId: conversationId || null,
    toolId: row.tool_id,
    displayName: displayNameFor(row.tool_id),
    permissionLevel: asLevel(row.permission_level),
    title: row.title,
    summary: row.summary,
    status: asStatus(row.status),
    createdAt: toIso(row.created_at),
  };
}

async function conversationOwned(userId: string, conversationId: number): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    select id from conversations
    where id = ${conversationId} and user_id = ${userId}
  `;
  return Boolean(rows[0]);
}

async function writeAudit(
  userId: string,
  action: string,
  entityType: string,
  entityId: string,
  permissionLevel: PermissionLevel | null,
  detail: string,
): Promise<void> {
  await appendAudit({
    userId,
    actor: "assistant",
    action,
    entityType,
    entityId,
    permissionLevel,
    detail,
  });
}

async function insertPending(
  userId: string,
  conversationId: number,
  toolId: string,
  level: PermissionLevel,
  title: string,
  summary: string,
  payloadJson: string,
): Promise<ProposedActionView | null> {
  const sql = await getSql();
  const rows = await sql<ActionRow>`
    insert into proposed_actions (
      user_id, conversation_id, tool_id, permission_level, title, summary, payload_json, status
    )
    values (
      ${userId},
      ${conversationId},
      ${toolId},
      ${level},
      ${title},
      ${summary},
      ${payloadJson},
      ${"pending"}
    )
    returning id, conversation_id, tool_id, permission_level, title, summary, status, created_at
  `;
  return rows[0] ? mapAction(rows[0]) : null;
}

async function confirmFloorFor(userId: string): Promise<ConfirmFloor> {
  try {
    const { loadPermissionPolicy } = await import("../permissions.ts");
    return (await loadPermissionPolicy(userId)).confirmFloor;
  } catch {
    return "safe";
  }
}

export async function listOwnProposals(
  userId: string,
  conversationId: number,
): Promise<ProposedActionView[]> {
  const sql = await getSql();
  const rows = await sql<ActionRow>`
    select id, conversation_id, tool_id, permission_level, title, summary, status, created_at
    from proposed_actions
    where user_id = ${userId} and conversation_id = ${conversationId}
    order by id asc
  `;
  const out: ProposedActionView[] = [];
  for (const row of rows) {
    const mapped = mapAction(row);
    if (mapped) out.push(mapped);
  }
  return out;
}

/**
 * Parse assistant text, store accepted proposals as pending, reject Restricted.
 * Never executes. Never loosens a catalog level. Scoped to the verified user.
 */
export async function applyAssistantTurn(
  userId: string,
  conversationId: number,
  rawAssistantText: string,
  userText?: string,
): Promise<{
  speech: string;
  proposals: ProposedActionView[];
  rejected: RejectedProposalView[];
}> {
  const floor = await confirmFloorFor(userId);
  const planned = planTurn(rawAssistantText, floor);
  if (userText) {
    try {
      const { shouldSuppressMutatingProposals, isMutatingToolId, brokerOrderAllowed } = await import(
        "@/lib/intent-format"
      );
      const allowOrder = brokerOrderAllowed(userText);
      const droppedOrders = planned.accepted.filter((item) => item.toolId === "broker.order" && !allowOrder);
      planned.accepted = planned.accepted.filter((item) => item.toolId !== "broker.order" || allowOrder);
      for (const item of droppedOrders) {
        planned.rejected.push({
          ...item,
          accepted: false,
          permissionLevel: "restricted",
          reason: "An order is prepared only when you ask to invest or trade. Nothing was sent.",
        });
      }
      if (shouldSuppressMutatingProposals(userText)) {
        const dropped = planned.accepted.filter((item) => isMutatingToolId(item.toolId));
        planned.accepted = planned.accepted.filter((item) => !isMutatingToolId(item.toolId));
        for (const item of dropped) {
          planned.rejected.push({
            ...item,
            accepted: false,
            permissionLevel: "restricted",
            reason: "Conversation is not an action.",
          });
        }
      }
    } catch {
      // Intent filter is a guard. Classification still fail-closes Restricted.
    }
  }
  const rejected: RejectedProposalView[] = planned.rejected.map((item) => ({
    toolId: item.toolId,
    title: item.title,
    reason: item.reason,
  }));
  const stored: ProposedActionView[] = [];

  if (planned.accepted.length === 0 && planned.rejected.length === 0) {
    return { speech: planned.speech || rawAssistantText.trim(), proposals: [], rejected };
  }

  const owned = await conversationOwned(userId, conversationId);
  if (!owned) {
    return { speech: planned.speech || rawAssistantText.trim(), proposals: [], rejected: [] };
  }

  try {
    const { syncToolCatalog } = await import("../tools/registry.ts");
    await syncToolCatalog();
  } catch {
    // In-code catalog still classifies. Execute fail-closes if the table is empty.
  }

  for (const item of planned.rejected) {
    try {
      await writeAudit(
        userId,
        "proposal.rejected",
        "tool",
        item.toolId,
        "restricted",
        item.reason,
      );
    } catch {
      // Chat must still save even if audit insert fails.
    }
  }

  for (const item of planned.accepted) {
    let payloadJson = "{}";
    try {
      payloadJson = JSON.stringify(item.payload);
    } catch {
      payloadJson = "{}";
    }

    try {
      const row = await insertPending(
        userId,
        conversationId,
        item.toolId,
        item.permissionLevel,
        item.title,
        item.summary,
        payloadJson,
      );
      if (row) {
        stored.push(row);
        await writeAudit(
          userId,
          "proposal.created",
          "proposed_action",
          String(row.id),
          item.permissionLevel,
          `${item.toolId}: ${item.title}`,
        );
      }
    } catch {
      // Skip this proposal; do not fail the chat turn.
    }
  }

  return { speech: planned.speech, proposals: stored, rejected };
}

export async function persistableAssistant(
  userId: string,
  conversationId: number,
  rawAssistantText: string,
  userText?: string,
): Promise<{
  speech: string;
  proposals: ProposedActionView[];
  rejected: RejectedProposalView[];
}> {
  const planned = planTurn(rawAssistantText);
  try {
    const applied = await applyAssistantTurn(userId, conversationId, rawAssistantText, userText);
    const proposals = await listOwnProposals(userId, conversationId);
    return {
      speech: applied.speech || planned.speech,
      proposals,
      rejected: applied.rejected,
    };
  } catch {
    return {
      speech: planned.speech,
      proposals: [],
      rejected: [],
    };
  }
}
