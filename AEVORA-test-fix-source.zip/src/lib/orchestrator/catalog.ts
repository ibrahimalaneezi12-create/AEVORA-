/**
 * Orchestrator-facing catalog API. Implementation lives in `src/lib/tools/`
 * so future capabilities register in one place.
 */
export {
  catalogLevel,
  displayNameFor,
  isChatReply,
  isExecutable,
  isValidToolId,
  listedTools,
  lookupTool,
  registerTool,
  canRunTool,
} from "../tools/definitions.ts";
