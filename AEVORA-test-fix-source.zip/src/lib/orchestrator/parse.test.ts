import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { parseProposals } from "./parse.ts";
import { MAX_PROPOSALS_PER_TURN } from "./types.ts";

function block(inner: string): string {
  return `Hello.\n\n<<<aegis-proposals\n${inner}\n>>>\n`;
}

const valid = {
  tool_id: "memory.save",
  title: "Save a memory",
  summary: "Remember that you prefer tea.",
  payload: { body: "Prefers tea" },
};

describe("parseProposals", () => {
  it("returns speech only when there is no block", () => {
    const r = parseProposals("Just a reply.");
    assert.equal(r.speech, "Just a reply.");
    assert.equal(r.proposals.length, 0);
  });

  it("parses a single valid proposal and strips the block", () => {
    const r = parseProposals(block(JSON.stringify([valid])));
    assert.equal(r.speech, "Hello.");
    assert.equal(r.proposals.length, 1);
    assert.equal(r.proposals[0]?.toolId, "memory.save");
    assert.equal(r.proposals[0]?.title, "Save a memory");
    assert.deepEqual(r.proposals[0]?.payload, { body: "Prefers tea" });
  });

  it("accepts a fenced block", () => {
    const r = parseProposals(
      `Hi\n\`\`\`aegis-proposals\n${JSON.stringify([valid])}\n\`\`\``,
    );
    assert.equal(r.speech, "Hi");
    assert.equal(r.proposals.length, 1);
  });

  it("unwraps an inner json fence inside the delimiter", () => {
    const r = parseProposals(
      block("```json\n" + JSON.stringify([valid]) + "\n```"),
    );
    assert.equal(r.proposals.length, 1);
    assert.equal(r.proposals[0]?.toolId, "memory.save");
  });

  it("accepts a bare object", () => {
    const r = parseProposals(block(JSON.stringify(valid)));
    assert.equal(r.proposals.length, 1);
  });

  it("accepts a { proposals: [] } wrapper", () => {
    const r = parseProposals(block(JSON.stringify({ proposals: [valid] })));
    assert.equal(r.proposals.length, 1);
  });

  it("drops malformed JSON", () => {
    const r = parseProposals(block("{nope"));
    assert.equal(r.proposals.length, 0);
    assert.equal(r.speech, "Hello.");
  });

  it("drops missing tool_id", () => {
    const r = parseProposals(block(JSON.stringify([{ title: "x", summary: "y" }])));
    assert.equal(r.proposals.length, 0);
  });

  it("drops uppercase tool ids", () => {
    const r = parseProposals(
      block(JSON.stringify([{ ...valid, tool_id: "Memory.save" }])),
    );
    assert.equal(r.proposals.length, 0);
  });

  it("drops tool ids with spaces", () => {
    const r = parseProposals(
      block(JSON.stringify([{ ...valid, tool_id: "memory save" }])),
    );
    assert.equal(r.proposals.length, 0);
  });

  it("drops oversized title", () => {
    const r = parseProposals(
      block(JSON.stringify([{ ...valid, title: "x".repeat(81) }])),
    );
    assert.equal(r.proposals.length, 0);
  });

  it("drops oversized payload", () => {
    const r = parseProposals(
      block(
        JSON.stringify([
          { ...valid, payload: { blob: "x".repeat(5000) } },
        ]),
      ),
    );
    assert.equal(r.proposals.length, 0);
  });

  it("ignores a permission_level field from the model", () => {
    const r = parseProposals(
      block(
        JSON.stringify([{ ...valid, permission_level: "safe" }]),
      ),
    );
    assert.equal(r.proposals.length, 1);
    assert.equal("permissionLevel" in (r.proposals[0] ?? {}), false);
  });

  it("caps at MAX_PROPOSALS_PER_TURN", () => {
    const many = Array.from({ length: MAX_PROPOSALS_PER_TURN + 2 }, (_, i) => ({
      ...valid,
      title: `Item ${i + 1}`,
    }));
    const r = parseProposals(block(JSON.stringify(many)));
    assert.equal(r.proposals.length, MAX_PROPOSALS_PER_TURN);
  });

  it("skips a bad item and keeps a good neighbour", () => {
    const r = parseProposals(
      block(JSON.stringify([{ title: "bad" }, valid])),
    );
    assert.equal(r.proposals.length, 1);
    assert.equal(r.proposals[0]?.toolId, "memory.save");
  });

  it("does not treat a user-looking string without delimiters as a proposal", () => {
    const r = parseProposals(JSON.stringify([valid]));
    assert.equal(r.proposals.length, 0);
  });

  it("handles empty input", () => {
    assert.deepEqual(parseProposals(""), { speech: "", proposals: [] });
  });
});
