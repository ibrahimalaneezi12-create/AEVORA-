import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { catalogLevel, canRunTool, isChatReply, isExecutable, lookupTool } from "./catalog.ts";

describe("tool catalog (spec §7.2)", () => {
  it("maps locked MVP ids to the spec levels", () => {
    assert.equal(catalogLevel("memory.search"), "safe");
    assert.equal(catalogLevel("task.list"), "safe");
    assert.equal(catalogLevel("memory.save"), "review");
    assert.equal(catalogLevel("task.create"), "review");
    assert.equal(catalogLevel("task.update"), "review");
    assert.equal(catalogLevel("goal.create"), "review");
    assert.equal(catalogLevel("goal.update"), "review");
    assert.equal(catalogLevel("reminder.create"), "review");
    assert.equal(catalogLevel("reminder.cancel"), "approval");
    assert.equal(catalogLevel("reminder.list"), "safe");
    assert.equal(catalogLevel("memory.delete"), "approval");
    assert.equal(catalogLevel("task.delete"), "approval");
    assert.equal(catalogLevel("conversation.delete"), "approval");
    assert.equal(catalogLevel("profile.update"), "approval");
    assert.equal(catalogLevel("permission.update"), "restricted");
  });

  it("treats unknown and external ids as restricted", () => {
    assert.equal(catalogLevel("not.a.tool"), "restricted");
    assert.equal(catalogLevel("external.http"), "restricted");
    assert.equal(lookupTool("external.http"), null);
  });

  it("does not register chat.reply as an executable tool", () => {
    assert.equal(isChatReply("chat.reply"), true);
    assert.equal(lookupTool("chat.reply"), null);
  });

  it("never upgrades a destructive tool to safe", () => {
    assert.equal(catalogLevel("memory.delete"), "approval");
    assert.notEqual(catalogLevel("memory.delete"), "safe");
    assert.notEqual(catalogLevel("memory.delete"), "review");
  });

  it("only runnable tools may execute", () => {
    assert.equal(canRunTool("task.create"), true);
    assert.equal(catalogLevel("email.send"), "approval");
    assert.equal(catalogLevel("calendar.create"), "review");
    assert.equal(catalogLevel("search.web"), "safe");
    assert.equal(isExecutable("search.web"), false);
    assert.equal(canRunTool("search.web"), false);
    assert.equal(canRunTool("email.send"), true);
    assert.equal(isExecutable("permission.update"), false);
    assert.equal(canRunTool("permission.update"), false);
    assert.equal(canRunTool("external.pay"), false);
    assert.equal(canRunTool("external.email"), false);
    assert.equal(catalogLevel("business.save"), "review");
    assert.equal(catalogLevel("invest.unwatch"), "approval");
    assert.equal(canRunTool("invest.trade"), false);
  });
});
