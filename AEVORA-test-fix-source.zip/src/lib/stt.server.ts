/**
 * Server-only xAI speech-to-text. Dynamic-import from createServerFn handlers.
 */
import { filenameForMime, parseTranscriptBody, STT_MAX_BYTES, STT_MODEL } from "./stt-format.ts";
import { readXaiApiKey, xaiBaseUrl } from "./ai/xai-env.server.ts";

export type TranscribeResult =
  | { ok: true; text: string; sttMs: number }
  | { ok: false; error: string; unavailable?: boolean; sttMs?: number };

export async function transcribeAudioBytes(opts: {
  bytes: Uint8Array;
  mime?: string;
  locale?: string;
}): Promise<TranscribeResult> {
  const apiKey = readXaiApiKey();
  if (!apiKey) {
    return { ok: false, unavailable: true, error: "Voice is not available here." };
  }
  const bytes = opts.bytes;
  if (bytes.byteLength < 64) {
    return { ok: false, error: "I did not catch that. Try again." };
  }
  if (bytes.byteLength > STT_MAX_BYTES) {
    return { ok: false, error: "That was too long to transcribe." };
  }
  const mime = (opts.mime || "audio/wav").split(";")[0]?.trim() || "audio/wav";
  const language = (opts.locale || "").split(/[-_]/)[0]?.toLowerCase() || "";
  const started = Date.now();
  try {
    const copy = new Uint8Array(bytes.byteLength);
    copy.set(bytes);
    const form = new FormData();
    form.append("model", STT_MODEL);
    form.append("file", new Blob([copy], { type: mime }), filenameForMime(mime));
    if (language) form.append("language", language);
    const res = await fetch(`${xaiBaseUrl()}/stt`, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}` },
      body: form,
    });
    const sttMs = Date.now() - started;
    if (!res.ok) {
      return { ok: false, error: `Voice could not be transcribed (${res.status}).`, sttMs };
    }
    const body = (await res.json()) as unknown;
    const text = parseTranscriptBody(body);
    if (!text) return { ok: false, error: "I did not catch that. Try again.", sttMs };
    return { ok: true, text, sttMs };
  } catch {
    return { ok: false, error: "Voice could not be reached.", sttMs: Date.now() - started };
  }
}

export async function transcribeSpeech(opts: {
  audioBase64: string;
  mime?: string;
  locale?: string;
}): Promise<TranscribeResult> {
  let bytes: Buffer;
  try {
    bytes = Buffer.from(opts.audioBase64, "base64");
  } catch {
    return { ok: false, error: "That recording could not be read." };
  }
  return transcribeAudioBytes({
    bytes: new Uint8Array(bytes),
    mime: opts.mime,
    locale: opts.locale,
  });
}
