import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  detectLocale,
  dirFor,
  resolveLocale,
  resolveTurnLocale,
  speechLangFor,
} from "./locale.ts";
import { listedLanguages, registerLanguage } from "./languages.ts";

describe("resolveLocale", () => {
  it("accepts registered languages and falls back otherwise", () => {
    assert.equal(resolveLocale("en"), "en");
    assert.equal(resolveLocale("ar"), "ar");
    assert.equal(resolveLocale("fr"), "fr");
    assert.equal(resolveLocale("es"), "es");
    assert.equal(resolveLocale("xx"), "en");
    assert.equal(resolveLocale(""), "en");
  });
});

describe("dirFor / speechLangFor", () => {
  it("is rtl for Arabic and Hebrew and ltr for English and Spanish", () => {
    assert.equal(dirFor("ar"), "rtl");
    assert.equal(dirFor("he"), "rtl");
    assert.equal(dirFor("en"), "ltr");
    assert.equal(dirFor("es"), "ltr");
    assert.equal(speechLangFor("ar"), "ar-SA");
    assert.equal(speechLangFor("en"), "en-US");
    assert.equal(speechLangFor("es"), "es-ES");
  });
});

describe("detectLocale", () => {
  it("detects Arabic, English, mixed, and empty", () => {
    assert.equal(detectLocale("وش عندي بكرة؟"), "ar");
    assert.equal(detectLocale("What's on my schedule today?"), "en");
    assert.equal(detectLocale("ذكّرني tomorrow at 7 PM أذاكر"), null);
    assert.equal(detectLocale("Remind me tomorrow أذاكر calculus"), null);
    assert.equal(detectLocale("12345"), null);
    assert.equal(detectLocale("שלום"), "he");
  });
});

describe("resolveTurnLocale", () => {
  it("uses detection when enabled and preferred otherwise", () => {
    assert.equal(
      resolveTurnLocale({ preferred: "en", detect: true, text: "طيب، وش عندي بكرة؟" }),
      "ar",
    );
    assert.equal(
      resolveTurnLocale({ preferred: "ar", detect: false, text: "What's on today?" }),
      "ar",
    );
  });
});

describe("language registry", () => {
  it("lists more than English and Arabic and can register another language", () => {
    const codes = listedLanguages().map((l) => l.code);
    assert.ok(codes.includes("en"));
    assert.ok(codes.includes("ar"));
    assert.ok(codes.includes("es"));
    assert.ok(codes.includes("zh"));
    registerLanguage({
      code: "test-lang",
      englishName: "Test",
      nativeName: "Test",
      dir: "ltr",
      speech: "en-US",
      dateLocale: "en",
    });
    assert.equal(resolveLocale("test-lang"), "test-lang");
  });
});
