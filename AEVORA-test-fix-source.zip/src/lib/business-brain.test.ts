import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { businessBriefSpeech, businessHealthSpeech, competitorSpeech, departmentFromQuery, departmentSpeech, executiveBriefSpeech, investigateBusiness, opportunitiesFromRecords, weeklyReviewSpeech } from "./business-brain.ts";
import type { BusinessNote } from "./business-format.ts";

const note = (partial: Partial<BusinessNote> & Pick<BusinessNote, "kind" | "title">): BusinessNote => ({
  id: partial.id ?? 1,
  businessId: 1,
  kind: partial.kind,
  title: partial.title,
  body: partial.body ?? "",
  createdAt: "2026-09-22T00:00:00.000Z",
  updatedAt: "2026-09-22T00:00:00.000Z",
});

describe("business brain", () => {
  it("does not invent revenue when nothing is connected", () => {
    const speech = businessHealthSpeech({
      businesses: [{ id: 1, name: "North", offer: "", audience: "", notes: "", createdAt: "", updatedAt: "" }],
      notes: [],
      sources: [
        { id: "books", label: "Accounting", category: "Finance", connected: false, detail: "Not available" },
      ],
    });
    assert.match(speech, /cannot be calculated|not connected|not watching/i);
    assert.equal(/£\d|\$\d/.test(speech), false);
  });

  it("separates missing sources from confirmed causes", () => {
    const result = investigateBusiness("Why did sales drop?", [note({ kind: "risk", title: "Campaign changed" })], []);
    assert.equal(result.hypotheses.length, 0);
    assert.match(result.speech, /will not treat a guess as the cause/i);
    assert.match(result.speech, /not confirmed explanations/i);
    assert.match(result.speech, /No accounting or sales source/i);
  });

  it("only lists opportunities that were saved", () => {
    const empty = opportunitiesFromRecords([], []);
    assert.equal(empty.items.length, 0);
    const found = opportunitiesFromRecords([note({ id: 4, kind: "opportunity", title: "Call the unused leads", body: "They asked last month." })], []);
    assert.equal(found.items.length, 1);
    assert.equal(found.items[0]?.evidence, "Saved note #4.");
    assert.match(found.items[0]?.impact ?? "", /Not estimated/);
  });

  it("morning brief does not invent sales", () => {
    const speech = businessBriefSpeech("morning", {
      businesses: [],
      notes: [],
      sources: [],
    });
    assert.match(speech, /not produced by a background job/i);
    assert.match(speech, /will not fill in sales/i);
    assert.equal(/£\d|\$\d/.test(speech), false);
    const weekly = weeklyReviewSpeech({ businesses: [], notes: [], sources: [] });
    assert.match(weekly, /not a calculated report/i);
    assert.match(weekly, /not running in the background/i);
  });

  it("builds an executive brief only from records and named gaps", () => {
    const empty = executiveBriefSpeech({ businesses: [], notes: [], sources: [] });
    assert.match(empty, /don't have a business/i);
    assert.equal(/£\d|\$\d/.test(empty), false);
    const speech = executiveBriefSpeech({
      businesses: [{ id: 1, name: "North", offer: "", audience: "", notes: "", createdAt: "", updatedAt: "" }],
      notes: [
        note({ id: 2, kind: "opportunity", title: "Repeat order" }),
        note({ id: 3, kind: "risk", title: "Supplier delay" }),
      ],
      sources: [],
      pendingTitles: ["Save the decision"],
    });
    assert.match(speech, /Health: North/);
    assert.match(speech, /Going well/);
    assert.match(speech, /not estimated/i);
    assert.match(speech, /No cause is confirmed/);
    assert.match(speech, /Decisions needed: Save the decision/);
    assert.match(speech, /will not fill in sales/i);
    assert.doesNotMatch(speech, /revenue is|customers grew|I have been monitoring/i);
    assert.equal(/£\d|\$\d/.test(speech), false);
  });

  it("refuses department metrics when that source is absent", () => {
    assert.equal(departmentFromQuery("Why did sales drop?"), "sales");
    assert.equal(departmentFromQuery("How's the business?"), null);
    assert.match(departmentSpeech("sales", [], []), /will not estimate/i);
    assert.match(departmentSpeech("finance", [], []), /were not calculated/i);
    assert.match(departmentSpeech("marketing", [], []), /were not read/i);
    const customers = departmentSpeech("customers", [note({ kind: "customer", title: "Ada" })], []);
    assert.match(customers, /Ada/);
    assert.match(customers, /not a count/i);
    assert.match(departmentSpeech("operations", [], []), /will not invent capacity/i);
    assert.equal(/£\d|\$\d/.test(departmentSpeech("sales", [], [])), false);
    assert.equal(departmentFromQuery("What is our business strategy?"), "strategy");
    assert.match(departmentSpeech("strategy", [], []), /will not invent a plan/i);
    assert.match(departmentSpeech("strategy", [note({ kind: "decision", title: "Hold price" })], []), /Hold price/);
    assert.match(competitorSpeech([]), /will not invent market share/i);
    assert.match(competitorSpeech([note({ kind: "competitor", title: "North rival" })]), /North rival/);
  });
});
