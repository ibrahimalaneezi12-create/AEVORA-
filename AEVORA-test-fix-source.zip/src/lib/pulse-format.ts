export const PULSE_SEVERITIES = ["info", "attention"] as const;
export type PulseSeverity = (typeof PULSE_SEVERITIES)[number];

export const PULSE_STANCES = ["information", "suggestion", "action"] as const;
export type PulseStance = (typeof PULSE_STANCES)[number];

export type PulseSuggestion = {
  id: string;
  kind: string;
  title: string;
  body: string;
  severity: PulseSeverity;
  stance: PulseStance;
  relatedType: string;
  relatedId: string;
};

export type PulseSnapshot = {
  generatedAt: string;
  enabled: boolean;
  quiet: boolean;
  suggestions: PulseSuggestion[];
};

export function emptyPulse(enabled: boolean, now = new Date(), quiet = false): PulseSnapshot {
  return {
    generatedAt: now.toISOString(),
    enabled,
    quiet,
    suggestions: [],
  };
}

export function inQuietHours(
  hour: number,
  start: number | null | undefined,
  end: number | null | undefined,
): boolean {
  if (start == null || end == null) return false;
  if (!Number.isInteger(start) || !Number.isInteger(end)) return false;
  if (start === end) return false;
  if (start < end) return hour >= start && hour < end;
  return hour >= start || hour < end;
}
