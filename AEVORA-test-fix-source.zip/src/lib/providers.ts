import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";

const hubspotInput = z.object({ token: z.string().trim().min(8).max(256) }).strict();
const shopifyInput = z
  .object({
    shop: z.string().trim().min(3).max(80),
    token: z.string().trim().min(8).max(256),
  })
  .strict();

export const connectHubspot = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => hubspotInput.parse(input))
  .handler(async ({ context, data }) => {
    const { connectHubspotForUser } = await import("./providers.server");
    return connectHubspotForUser(context.userId, data.token);
  });

export const connectShopify = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => shopifyInput.parse(input))
  .handler(async ({ context, data }) => {
    const { connectShopifyForUser } = await import("./providers.server");
    return connectShopifyForUser(context.userId, data.shop, data.token);
  });

export const disconnectHubspot = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { disconnectProviderForUser } = await import("./providers.server");
    return disconnectProviderForUser(context.userId, "hubspot");
  });

export const disconnectShopify = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { disconnectProviderForUser } = await import("./providers.server");
    return disconnectProviderForUser(context.userId, "shopify");
  });

const oauthInput = z.object({ provider: z.enum(["google_ads", "quickbooks"]) }).strict();
const testInput = z.object({ id: z.enum(["gmail", "calendar", "crm", "shop", "ads", "books", "inventory"]) }).strict();

export const startBusinessOAuth = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => oauthInput.parse(input))
  .handler(async ({ context, data }) => {
    const { startOAuthForUser } = await import("./providers.server");
    return startOAuthForUser(context.userId, data.provider);
  });

export const disconnectOAuth = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => oauthInput.parse(input))
  .handler(async ({ context, data }) => {
    const { disconnectProviderForUser } = await import("./providers.server");
    return disconnectProviderForUser(context.userId, data.provider);
  });

export const testBusinessLink = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => testInput.parse(input))
  .handler(async ({ context, data }) => {
    const userId = context.userId;
    if (data.id === "gmail") {
      const { peekGmailConnection } = await import("./mail");
      const peek = await peekGmailConnection();
      return { ok: peek.connected, detail: peek.detail };
    }
    if (data.id === "calendar") {
      const { peekGoogleCalendar } = await import("./calendar");
      const peek = await peekGoogleCalendar();
      return { ok: peek.connected, detail: peek.detail };
    }
    if (data.id === "crm") {
      const { readHubspotForUser } = await import("./providers.server");
      const hub = await readHubspotForUser(userId);
      return { ok: hub.connected && !hub.error, detail: hub.error || (hub.connected ? "HubSpot answered." : "HubSpot is not connected.") };
    }
    if (data.id === "shop" || data.id === "inventory") {
      const { readShopifyProductsForUser, readShopifyForUser } = await import("./providers.server");
      const orders = await readShopifyForUser(userId);
      const products = await readShopifyProductsForUser(userId);
      if (!orders.connected) {
        return {
          ok: false,
          detail:
            data.id === "inventory"
              ? "Shopify is not connected. Inventory is not being read."
              : "Shopify is not connected. Orders are not being read.",
        };
      }
      if (orders.error) return { ok: false, detail: orders.error };
      if (data.id === "inventory") {
        return {
          ok: products.connected && !products.error && products.products.some((product) => product.inventory !== null),
          detail: products.error || (products.products.some((product) => product.inventory !== null) ? "Shopify returned stock quantities." : "Shopify answered, but stock quantities were not returned."),
        };
      }
      return { ok: true, detail: products.error ? `Orders answered. Products: ${products.error}` : "Shopify answered." };
    }
    const { readAdsForUser, readBooksForUser } = await import("./providers.server");
    const result = data.id === "ads" ? await readAdsForUser(userId) : await readBooksForUser(userId);
    return { ok: result.connected && !/not connected|not being|did not return|could not be reached|not configured/i.test(result.speech), detail: result.speech };
  });
