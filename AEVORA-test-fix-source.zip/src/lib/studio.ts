import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { GENERIC_NOT_FOUND } from "@/lib/privacy";
import type { ToolHandler } from "@/lib/tools/types";
import { createVideoProjectForUser, editVideoProjectForUser, startRenderForUser } from "@/lib/video";
import type { VideoJob, VideoProject } from "@/lib/video";
import { classifyStudioIntent, studioSpeechFor, type StudioAction } from "@/lib/studio-intent";
import {
  PHOTO_MAX_BYTES,
  PHOTO_MODEL,
  PHOTO_PROMPT_MAX,
  PHOTO_TITLE_MAX,
  STUDIO_CAPABILITIES,
  VIDEO_EDIT_MAX_BYTES,
  VIDEO_EDIT_MODEL,
  asPhotoAspect,
  classifyVideoEdit,
  isAllowedPhotoMime,
  isAllowedVideoMime,
  parseDataUri,
  titleFromPrompt,
  type AssetRole,
  type StudioAssetView,
  type StudioKind,
  type StudioLibraryItem,
  type StudioOrigin,
  type StudioProject,
} from "@/lib/studio-format";

export { STUDIO_CAPABILITIES };
export type { StudioProject, StudioLibraryItem };

const promptPayload = z.object({
  prompt: z.string().min(1).max(PHOTO_PROMPT_MAX),
  aspectRatio: z.enum(["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3"]).optional(),
  resolution: z.enum(["1k", "2k"]).optional(),
});

const uploadPayload = z.object({
  kind: z.enum(["photo", "video"]),
  dataUri: z.string().min(32).max(VIDEO_EDIT_MAX_BYTES * 2),
  title: z.string().max(PHOTO_TITLE_MAX).optional(),
});

const idPayload = z.object({ id: z.number().int().positive() });

const editPayload = z.object({
  id: z.number().int().positive(),
  instruction: z.string().min(1).max(PHOTO_PROMPT_MAX),
});

const restorePayload = z.object({
  id: z.number().int().positive(),
  assetId: z.number().int().positive(),
});

const animatePayload = z.object({
  id: z.number().int().positive(),
  prompt: z.string().min(1).max(PHOTO_PROMPT_MAX).optional(),
});

type ProjectRow = {
  id: unknown;
  kind: string;
  origin: string;
  title: string;
  prompt: string;
  status: string;
  aspect_ratio: string;
  current_asset_id: unknown;
  original_asset_id: unknown;
  linked_video_id: unknown;
  created_at: unknown;
  updated_at: unknown;
};

type AssetRow = {
  id: unknown;
  role: string;
  version_n: unknown;
  mime: string;
  prompt: string;
  created_at: unknown;
};

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function mapAsset(row: AssetRow): StudioAssetView | null {
  const id = asId(row.id);
  if (!id) return null;
  return {
    id,
    role: row.role as AssetRole,
    versionN: Number(row.version_n) || 1,
    mime: row.mime,
    prompt: row.prompt || "",
    createdAt: toIso(row.created_at),
  };
}

async function loadAssets(userId: string, projectId: number): Promise<StudioAssetView[]> {
  const sql = await getSql();
  const rows = await sql<AssetRow>`
    select id, role, version_n, mime, prompt, created_at
    from studio_assets
    where user_id = ${userId} and project_id = ${projectId}
    order by version_n asc, id asc
  `;
  return rows.map(mapAsset).filter((row): row is StudioAssetView => Boolean(row));
}

async function loadProject(userId: string, projectId: number): Promise<StudioProject | null> {
  const sql = await getSql();
  const rows = await sql<ProjectRow>`
    select id, kind, origin, title, prompt, status, aspect_ratio, current_asset_id, original_asset_id,
           linked_video_id, created_at, updated_at
    from studio_projects
    where id = ${projectId} and user_id = ${userId}
  `;
  const row = rows[0];
  if (!row) return null;
  return {
    id: asId(row.id),
    kind: row.kind as StudioKind,
    origin: row.origin as StudioOrigin,
    title: row.title,
    prompt: row.prompt,
    status: row.status,
    aspectRatio: row.aspect_ratio,
    currentAssetId: asId(row.current_asset_id) || null,
    originalAssetId: asId(row.original_asset_id) || null,
    linkedVideoId: asId(row.linked_video_id) || null,
    assets: await loadAssets(userId, asId(row.id)),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

async function insertAsset(
  userId: string,
  projectId: number,
  role: AssetRole,
  versionN: number,
  dataUri: string,
  prompt: string,
): Promise<number> {
  const parsed = parseDataUri(dataUri);
  if (!parsed) throw new Error("That file could not be read.");
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    insert into studio_assets (project_id, user_id, role, version_n, mime, payload, prompt)
    values (
      ${projectId}, ${userId}, ${role}, ${versionN}, ${parsed.mime}, ${dataUri}, ${prompt.slice(0, PHOTO_PROMPT_MAX)}
    )
    returning id
  `;
  const id = asId(rows[0]?.id);
  if (!id) throw new Error("File could not be saved.");
  return id;
}

async function payloadFor(userId: string, assetId: number): Promise<string | null> {
  const sql = await getSql();
  const rows = await sql<{ payload: string }>`
    select payload from studio_assets where id = ${assetId} and user_id = ${userId}
  `;
  return rows[0]?.payload ?? null;
}

async function recordUsage(userId: string, jobId: number | null, model: string, operation: string, status: string) {
  const sql = await getSql();
  await sql`
    insert into studio_usage (user_id, job_id, model, operation, status)
    values (${userId}, ${jobId}, ${model}, ${operation}, ${status})
  `;
}

async function nextVersion(userId: string, projectId: number): Promise<number> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`
    select coalesce(max(version_n), 0)::int as n from studio_assets
    where user_id = ${userId} and project_id = ${projectId}
  `;
  return (rows[0]?.n ?? 0) + 1;
}

export const getStudioCapabilities = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async () => {
    const { imageProviderAvailable } = await import("@/lib/image-provider.server");
    const { videoProviderAvailable } = await import("@/lib/video-provider.server");
    return {
      ...STUDIO_CAPABILITIES,
      available: imageProviderAvailable() || videoProviderAvailable(),
      photoAvailable: imageProviderAvailable(),
      videoAvailable: videoProviderAvailable(),
    };
  });

export const listStudioLibrary = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<StudioLibraryItem[]> => {
    const sql = await getSql();
    const photos = await sql<{ id: unknown; title: string; status: string; updated_at: unknown }>`
      select id, title, status, updated_at from studio_projects
      where user_id = ${context.userId}
      order by updated_at desc
      limit 40
    `;
    const videos = await sql<{ id: unknown; title: string; status: string; updated_at: unknown }>`
      select id, title, status, updated_at from video_projects
      where user_id = ${context.userId}
      order by updated_at desc
      limit 40
    `;
    const items: StudioLibraryItem[] = [
      ...photos.map((row) => ({
        id: asId(row.id),
        source: "studio" as const,
        kind: "photo" as const,
        title: row.title,
        status: row.status,
        updatedAt: toIso(row.updated_at),
      })),
      ...videos.map((row) => ({
        id: asId(row.id),
        source: "video" as const,
        kind: "video" as const,
        title: row.title,
        status: row.status,
        updatedAt: toIso(row.updated_at),
      })),
    ].filter((row) => row.id > 0);
    items.sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1));
    return items.slice(0, 40);
  });

export const getStudioProject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idPayload.parse(input))
  .handler(async ({ context, data }): Promise<StudioProject> => {
    const project = await loadProject(context.userId, data.id);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
  });

export const createGeneratedPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => promptPayload.parse(input))
  .handler(async ({ context, data }): Promise<StudioProject> => {
    return generatePhotoForUser(context.userId, data);
  });

async function generatePhotoForUser(
  userId: string,
  data: { prompt: string; aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3" | "3:4" | "3:2" | "2:3"; resolution?: "1k" | "2k" },
  existingId?: number,
): Promise<StudioProject> {
    const { generatePhoto } = await import("@/lib/image-provider.server");
    const result = await generatePhoto({
      prompt: data.prompt,
      aspectRatio: asPhotoAspect(data.aspectRatio),
      resolution: data.resolution ?? "1k",
    });
    if (!result.ok) throw new Error(result.error);
    const sql = await getSql();
    if (existingId) {
      const current = await loadProject(userId, existingId);
      if (!current || current.kind !== "photo") throw new Error(GENERIC_NOT_FOUND);
      const version = await nextVersion(userId, current.id);
      const assetId = await insertAsset(userId, current.id, "generated", version, result.dataUri, data.prompt);
      await sql`
        update studio_projects
        set current_asset_id = ${assetId}, status = ${"completed"},
            prompt = ${data.prompt.slice(0, PHOTO_PROMPT_MAX)}, updated_at = now()
        where id = ${current.id} and user_id = ${userId}
      `;
      await recordUsage(userId, null, PHOTO_MODEL, "photo.generate", "completed");
      const project = await loadProject(userId, current.id);
      if (!project) throw new Error(GENERIC_NOT_FOUND);
      return project;
    }
    const rows = await sql<{ id: unknown }>`
      insert into studio_projects (user_id, kind, origin, title, prompt, status, aspect_ratio)
      values (
        ${userId}, ${"photo"}, ${"generate"},
        ${titleFromPrompt(data.prompt).slice(0, PHOTO_TITLE_MAX)},
        ${data.prompt.slice(0, PHOTO_PROMPT_MAX)},
        ${"completed"},
        ${asPhotoAspect(data.aspectRatio)}
      )
      returning id
    `;
    const projectId = asId(rows[0]?.id);
    if (!projectId) throw new Error("Photo could not be saved.");
    const assetId = await insertAsset(userId, projectId, "generated", 1, result.dataUri, data.prompt);
    await sql`
      update studio_projects
      set current_asset_id = ${assetId}, original_asset_id = ${assetId}, updated_at = now()
      where id = ${projectId} and user_id = ${userId}
    `;
    await recordUsage(userId, null, PHOTO_MODEL, "photo.generate", "completed");
    const project = await loadProject(userId, projectId);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
  }

export const uploadStudioMedia = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => uploadPayload.parse(input))
  .handler(async ({ context, data }): Promise<StudioProject> => {
    return uploadStudioMediaForUser(context.userId, data);
  });

async function uploadStudioMediaForUser(
  userId: string,
  data: { kind: "photo" | "video"; dataUri: string; title?: string },
): Promise<StudioProject> {
  const parsed = parseDataUri(data.dataUri);
  if (!parsed) throw new Error("That file could not be read.");
  if (data.kind === "photo") {
    if (!isAllowedPhotoMime(parsed.mime)) throw new Error("Use a JPEG, PNG, or WebP photo.");
    if (parsed.bytes > PHOTO_MAX_BYTES) throw new Error("Keep photos under 4 MB.");
  } else {
    if (!isAllowedVideoMime(parsed.mime)) throw new Error("Use an MP4 clip under 8.7 seconds.");
    if (parsed.bytes > VIDEO_EDIT_MAX_BYTES) throw new Error("Keep clips under 12 MB.");
  }
  const sql = await getSql();
  const title = (data.title || (data.kind === "photo" ? "Uploaded photo" : "Uploaded clip")).slice(0, PHOTO_TITLE_MAX);
  const rows = await sql<{ id: unknown }>`
    insert into studio_projects (user_id, kind, origin, title, prompt, status, aspect_ratio)
    values (
      ${userId}, ${data.kind}, ${"upload"}, ${title}, ${""}, ${"draft"},
      ${data.kind === "photo" ? "1:1" : "16:9"}
    )
    returning id
  `;
  const projectId = asId(rows[0]?.id);
  if (!projectId) throw new Error("Upload could not be saved.");
  const assetId = await insertAsset(userId, projectId, "original", 1, data.dataUri, "");
  await sql`
    update studio_projects
    set current_asset_id = ${assetId}, original_asset_id = ${assetId}, updated_at = now()
    where id = ${projectId} and user_id = ${userId}
  `;
  const project = await loadProject(userId, projectId);
  if (!project) throw new Error(GENERIC_NOT_FOUND);
  return project;
}

export const editStudioPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => editPayload.parse(input))
  .handler(async ({ context, data }): Promise<StudioProject> => {
    return editPhotoForUser(context.userId, data);
  });

async function editPhotoForUser(userId: string, data: { id: number; instruction: string }): Promise<StudioProject> {
    const current = await loadProject(userId, data.id);
    if (!current || current.kind !== "photo") throw new Error(GENERIC_NOT_FOUND);
    const sourceId = current.currentAssetId;
    if (!sourceId) throw new Error("Add a photo first.");
    const source = await payloadFor(userId, sourceId);
    if (!source) throw new Error(GENERIC_NOT_FOUND);
    const { editPhoto } = await import("@/lib/image-provider.server");
    const result = await editPhoto({ prompt: data.instruction, imageDataUri: source });
    if (!result.ok) throw new Error(result.error);
    const version = await nextVersion(userId, current.id);
    const assetId = await insertAsset(userId, current.id, "edit", version, result.dataUri, data.instruction);
    const sql = await getSql();
    await sql`
      update studio_projects
      set current_asset_id = ${assetId}, status = ${"completed"}, prompt = ${data.instruction.slice(0, PHOTO_PROMPT_MAX)}, updated_at = now()
      where id = ${current.id} and user_id = ${userId}
    `;
    await recordUsage(userId, null, PHOTO_MODEL, "photo.edit", "completed");
    const project = await loadProject(userId, current.id);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
}

export const restoreStudioAsset = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => restorePayload.parse(input))
  .handler(async ({ context, data }): Promise<StudioProject> => {
    const sql = await getSql();
    const rows = await sql<{ id: unknown }>`
      select id from studio_assets
      where id = ${data.assetId} and project_id = ${data.id} and user_id = ${context.userId}
    `;
    if (!rows[0]) throw new Error(GENERIC_NOT_FOUND);
    await sql`
      update studio_projects
      set current_asset_id = ${data.assetId}, updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
    `;
    const project = await loadProject(context.userId, data.id);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
  });

export const deleteStudioAsset = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => restorePayload.parse(input))
  .handler(async ({ context, data }): Promise<StudioProject> => {
    const current = await loadProject(context.userId, data.id);
    if (!current) throw new Error(GENERIC_NOT_FOUND);
    if (current.originalAssetId === data.assetId) throw new Error("The original stays.");
    const sql = await getSql();
    const deleted = await sql`
      delete from studio_assets
      where id = ${data.assetId} and project_id = ${data.id} and user_id = ${context.userId} and role <> ${"original"}
      returning id
    `;
    if (!deleted[0]) throw new Error(GENERIC_NOT_FOUND);
    if (current.currentAssetId === data.assetId) {
      await sql`
        update studio_projects
        set current_asset_id = ${current.originalAssetId}, updated_at = now()
        where id = ${current.id} and user_id = ${context.userId}
      `;
    }
    const project = await loadProject(context.userId, current.id);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
  });

export const editStudioVideo = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => editPayload.parse(input))
  .handler(async ({ context, data }): Promise<StudioProject> => {
    return editVideoForUser(context.userId, data);
  });

async function editVideoForUser(userId: string, data: { id: number; instruction: string }): Promise<StudioProject> {
    const allowed = classifyVideoEdit(data.instruction);
    if (!allowed.ok) throw new Error(allowed.reason);
    const current = await loadProject(userId, data.id);
    if (!current || current.kind !== "video") throw new Error(GENERIC_NOT_FOUND);
    const sourceId = current.currentAssetId;
    if (!sourceId) throw new Error("Upload a clip first.");
    const source = await payloadFor(userId, sourceId);
    if (!source) throw new Error(GENERIC_NOT_FOUND);
    const { startVideoEdit } = await import("@/lib/video-provider.server");
    const started = await startVideoEdit({ prompt: data.instruction, videoDataUri: source });
    if (!started.ok) throw new Error(started.error);
    const sql = await getSql();
    await sql`
      insert into studio_jobs (project_id, user_id, kind, status, model, provider_job_id)
      values (
        ${current.id}, ${userId}, ${"video.edit"}, ${"processing"}, ${VIDEO_EDIT_MODEL}, ${started.requestId}
      )
    `;
    await sql`
      update studio_projects set status = ${"processing"}, prompt = ${data.instruction.slice(0, PHOTO_PROMPT_MAX)}, updated_at = now()
      where id = ${current.id} and user_id = ${userId}
    `;
    await recordUsage(userId, null, VIDEO_EDIT_MODEL, "video.edit", "processing");
    return pollStudioVideoForUser(userId, current.id);
}

async function pollStudioVideoForUser(userId: string, projectId: number): Promise<StudioProject> {
  const sql = await getSql();
  const jobs = await sql<{ id: unknown; provider_job_id: string }>`
    select id, provider_job_id from studio_jobs
    where project_id = ${projectId} and user_id = ${userId} and status = ${"processing"}
    order by created_at desc
    limit 1
  `;
  const job = jobs[0];
  if (!job) {
    const project = await loadProject(userId, projectId);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
  }
  const { pollVideoGeneration, fetchOwnedMediaBytes } = await import("@/lib/video-provider.server");
  const polled = await pollVideoGeneration(job.provider_job_id);
  if (!polled.ok) throw new Error(polled.error);
  if (polled.status === "pending" || polled.status === "processing") {
    const project = await loadProject(userId, projectId);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
  }
  if (polled.status === "failed" || polled.status === "expired") {
    const fail = polled.error;
    await sql`
      update studio_jobs set status = ${"failed"}, error = ${fail}, updated_at = now()
      where id = ${asId(job.id)} and user_id = ${userId}
    `;
    await sql`
      update studio_projects set status = ${"failed"}, updated_at = now()
      where id = ${projectId} and user_id = ${userId}
    `;
    throw new Error(fail);
  }
  if (polled.status !== "done") {
    const project = await loadProject(userId, projectId);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
  }
  const file = await fetchOwnedMediaBytes(polled.url);
  if (!file) throw new Error("Edited clip could not be saved.");
  const dataUri = `data:${file.mime};base64,${Buffer.from(file.bytes).toString("base64")}`;
  const version = await nextVersion(userId, projectId);
  const assetId = await insertAsset(userId, projectId, "edit", version, dataUri, "");
  await sql`
    update studio_jobs set status = ${"completed"}, updated_at = now()
    where id = ${asId(job.id)} and user_id = ${userId}
  `;
  await sql`
    update studio_projects
    set current_asset_id = ${assetId}, status = ${"completed"}, updated_at = now()
    where id = ${projectId} and user_id = ${userId}
  `;
  const project = await loadProject(userId, projectId);
  if (!project) throw new Error(GENERIC_NOT_FOUND);
  return project;
}

export const pollStudioVideo = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idPayload.parse(input))
  .handler(async ({ context, data }): Promise<StudioProject> => {
    return pollStudioVideoForUser(context.userId, data.id);
  });

export const animateStudioPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => animatePayload.parse(input))
  .handler(async ({ context, data }) => {
    return animatePhotoForUser(context.userId, data);
  });

async function animatePhotoForUser(
  userId: string,
  data: {
    id: number;
    prompt?: string;
    durationSec?: number;
    aspectRatio?: "16:9" | "9:16" | "1:1" | "4:3" | "3:4" | "3:2" | "2:3";
    resolution?: "480p" | "720p" | "1080p";
    generateAudio?: boolean;
  },
): Promise<{ photo: StudioProject; video: VideoProject; job: VideoJob }> {
  const current = await loadProject(userId, data.id);
  if (!current || current.kind !== "photo") throw new Error(GENERIC_NOT_FOUND);
  const sourceId = current.currentAssetId;
  if (!sourceId) throw new Error("Create a photo first.");
  const source = await payloadFor(userId, sourceId);
  if (!source) throw new Error(GENERIC_NOT_FOUND);
  const brief = data.prompt?.trim() || `Bring this photo to life. ${current.title}`;
  const video = await createVideoProjectForUser(userId, {
    brief,
    imageDataUrl: source,
    aspectRatio: data.aspectRatio ?? (current.aspectRatio === "9:16" ? "9:16" : "16:9"),
    resolution: data.resolution,
    durationSec: data.durationSec,
    generateAudio: data.generateAudio,
  });
  const started = await startRenderForUser(userId, { id: video.id, imageDataUrl: source });
  const sql = await getSql();
  await sql`
    update studio_projects
    set linked_video_id = ${video.id}, updated_at = now()
    where id = ${current.id} and user_id = ${userId}
  `;
  const photo = await loadProject(userId, current.id);
  if (!photo) throw new Error(GENERIC_NOT_FOUND);
  return { photo, video: started.project, job: started.job };
}

export async function ownedStudioAsset(
  userId: string,
  assetId: number,
): Promise<{ mime: string; bytes: Uint8Array } | null> {
  const sql = await getSql();
  const rows = await sql<{ payload: string; mime: string }>`
    select payload, mime from studio_assets where id = ${assetId} and user_id = ${userId}
  `;
  const row = rows[0];
  if (!row) return null;
  const parsed = parseDataUri(row.payload);
  if (!parsed) return null;
  const bytes = Uint8Array.from(Buffer.from(parsed.b64, "base64"));
  return { mime: row.mime || parsed.mime, bytes };
}

export const photoGenerateHandler: ToolHandler = async ({ userId, summary, payload }) => {
  const prompt =
    typeof payload === "object" && payload && "prompt" in payload
      ? String((payload as { prompt?: string }).prompt || "")
      : summary;
  const project = await generatePhotoForUser(userId, { prompt: prompt || summary });
  return `Photo saved as ${project.title}. Open Studio to refine it.`;
};

export const photoEditHandler: ToolHandler = async ({ userId, payload }) => {
  const parsed = editPayload.parse(payload);
  const project = await editPhotoForUser(userId, parsed);
  return `Edited ${project.title}. Original is unchanged.`;
};

export const videoEditHandler: ToolHandler = async ({ userId, payload }) => {
  const parsed = editPayload.parse(payload);
  const project = await editVideoForUser(userId, parsed);
  return project.status === "processing"
    ? "Video edit is processing. Open Studio to watch it finish."
    : `Edited ${project.title}. Original is unchanged.`;
};

export type StudioTurnResult = {
  speech: string;
  action: StudioAction;
  photo: StudioProject | null;
  video: VideoProject | null;
  job: VideoJob | null;
  processing: boolean;
};

const turnPayload = z.object({
  prompt: z.string().max(PHOTO_PROMPT_MAX),
  attachment: z
    .object({
      kind: z.enum(["photo", "video"]),
      dataUri: z.string().min(32).max(VIDEO_EDIT_MAX_BYTES * 2),
      title: z.string().max(PHOTO_TITLE_MAX).optional(),
    })
    .optional(),
  currentPhotoId: z.number().int().positive().optional(),
  currentVideoId: z.number().int().positive().optional(),
  currentStudioVideoId: z.number().int().positive().optional(),
  aspectRatio: z.enum(["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3"]).optional(),
  photoResolution: z.enum(["1k", "2k"]).optional(),
  videoResolution: z.enum(["480p", "720p", "1080p"]).optional(),
  durationSec: z.number().int().min(1).max(15).optional(),
  generateAudio: z.boolean().optional(),
});

function asVideoAspectSafe(
  value: string | undefined,
): "16:9" | "9:16" | "1:1" | "4:3" | "3:4" | "3:2" | "2:3" | undefined {
  if (
    value === "16:9" ||
    value === "9:16" ||
    value === "1:1" ||
    value === "4:3" ||
    value === "3:4" ||
    value === "3:2" ||
    value === "2:3"
  ) {
    return value;
  }
  return undefined;
}

export const runStudioTurn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => turnPayload.parse(input))
  .handler(async ({ context, data }): Promise<StudioTurnResult> => {
    return runStudioTurnForUser(context.userId, data);
  });

export async function runStudioTurnForUser(
  userId: string,
  data: z.infer<typeof turnPayload>,
): Promise<StudioTurnResult> {
  const prompt = data.prompt.trim();
  let photo: StudioProject | null = null;
  let uploadedKind: "photo" | "video" | null = null;
  if (data.currentPhotoId) {
    photo = await loadProject(userId, data.currentPhotoId);
  }
  if (data.attachment) {
    const uploaded = await uploadStudioMediaForUser(userId, data.attachment);
    uploadedKind = data.attachment.kind;
    if (uploaded.kind === "photo") photo = uploaded;
    else photo = uploaded;
  }
  const studioVideo = data.currentStudioVideoId
    ? await loadProject(userId, data.currentStudioVideoId)
    : uploadedKind === "video"
      ? photo
      : null;
  const intent = classifyStudioIntent({
    prompt,
    hasPhotoAttachment: uploadedKind === "photo",
    hasVideoAttachment: uploadedKind === "video",
    hasCurrentPhoto: Boolean(photo && photo.kind === "photo"),
    hasCurrentVideo: Boolean(data.currentVideoId || (studioVideo && studioVideo.kind === "video")),
    currentIsUploadedVideo: studioVideo?.origin === "upload" || uploadedKind === "video",
  });

  if (!prompt && !data.attachment && intent.action !== "photo.variation") {
    throw new Error("Describe what you want to create.");
  }

  try {
    switch (intent.action) {
      case "photo.generate": {
        const next = await generatePhotoForUser(userId, {
          prompt: prompt || "A calm, cinematic still.",
          aspectRatio: data.aspectRatio,
          resolution: data.photoResolution,
        });
        return {
          speech: studioSpeechFor(intent.action, next.title),
          action: intent.action,
          photo: next,
          video: null,
          job: null,
          processing: false,
        };
      }
      case "photo.variation": {
        const source = photo;
        if (!source || source.kind !== "photo") throw new Error("Create a photo first.");
        const next = await generatePhotoForUser(
          userId,
          {
            prompt: prompt || source.prompt || source.title,
            aspectRatio: data.aspectRatio ?? asPhotoAspect(source.aspectRatio),
            resolution: data.photoResolution,
          },
          source.id,
        );
        return {
          speech: studioSpeechFor(intent.action, next.title),
          action: intent.action,
          photo: next,
          video: null,
          job: null,
          processing: false,
        };
      }
      case "photo.edit": {
        const source = photo;
        if (!source || source.kind !== "photo") throw new Error("Add a photo first.");
        if (!prompt) {
          return {
            speech: "What should change?",
            action: intent.action,
            photo: source,
            video: null,
            job: null,
            processing: false,
          };
        }
        const next = await editPhotoForUser(userId, { id: source.id, instruction: prompt });
        return {
          speech: studioSpeechFor(intent.action, next.title),
          action: intent.action,
          photo: next,
          video: null,
          job: null,
          processing: false,
        };
      }
      case "photo.animate": {
        const source = photo;
        if (!source || source.kind !== "photo") throw new Error("Create a photo first.");
        const animated = await animatePhotoForUser(userId, {
          id: source.id,
          prompt: prompt || undefined,
          durationSec: data.durationSec,
          aspectRatio: asVideoAspectSafe(data.aspectRatio),
          resolution: data.videoResolution,
          generateAudio: data.generateAudio,
        });
        return {
          speech: studioSpeechFor(intent.action, animated.video.title, true),
          action: intent.action,
          photo: animated.photo,
          video: animated.video,
          job: animated.job,
          processing: animated.job.status === "processing" || animated.job.status === "queued",
        };
      }
      case "video.generate": {
        const image = photo?.kind === "photo" && photo.currentAssetId
          ? await payloadFor(userId, photo.currentAssetId)
          : null;
        const created = await createVideoProjectForUser(userId, {
          brief: prompt || "A calm cinematic establishing shot.",
          imageDataUrl: image ?? undefined,
          aspectRatio: asVideoAspectSafe(data.aspectRatio),
          resolution: data.videoResolution,
          durationSec: data.durationSec,
          generateAudio: data.generateAudio,
        });
        const started = await startRenderForUser(userId, {
          id: created.id,
          imageDataUrl: image ?? undefined,
        });
        return {
          speech: studioSpeechFor(intent.action, started.project.title, true),
          action: intent.action,
          photo,
          video: started.project,
          job: started.job,
          processing: true,
        };
      }
      case "video.variation": {
        const videoId = data.currentVideoId || photo?.linkedVideoId || null;
        if (videoId) {
          const refined = await editVideoProjectForUser(userId, {
            id: videoId,
            instruction: prompt || "Create another version.",
          });
          const image = photo?.kind === "photo" && photo.currentAssetId
            ? await payloadFor(userId, photo.currentAssetId)
            : null;
          const started = await startRenderForUser(userId, {
            id: refined.id,
            imageDataUrl: image ?? undefined,
          });
          return {
            speech: studioSpeechFor(intent.action, started.project.title, true),
            action: intent.action,
            photo,
            video: started.project,
            job: started.job,
            processing: true,
          };
        }
        const source = studioVideo;
        if (!source || source.kind !== "video") throw new Error("Create a scene first.");
        const next = await editVideoForUser(userId, {
          id: source.id,
          instruction: prompt || "Create another version.",
        });
        return {
          speech: studioSpeechFor(intent.action, next.title, next.status === "processing"),
          action: intent.action,
          photo: next,
          video: null,
          job: null,
          processing: next.status === "processing",
        };
      }
      case "video.edit": {
        const source = studioVideo;
        if (!source || source.kind !== "video") throw new Error("Upload a clip first.");
        if (!prompt) {
          return {
            speech: "Describe how the clip should look.",
            action: intent.action,
            photo: source,
            video: null,
            job: null,
            processing: false,
          };
        }
        const next = await editVideoForUser(userId, { id: source.id, instruction: prompt });
        return {
          speech: studioSpeechFor(intent.action, next.title, next.status === "processing"),
          action: intent.action,
          photo: next,
          video: null,
          job: null,
          processing: next.status === "processing",
        };
      }
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : "Something went wrong. Please try again.";
    throw new Error(message);
  }
}