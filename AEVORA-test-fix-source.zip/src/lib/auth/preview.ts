/**
 * Preview OAuth client configuration (server-only).
 *
 * Never commit or bake the shared preview client secret into source. Set
 * GROK_AUTH_CLIENT_SECRET through the preview host's managed secret store.
 * The broker must be configured with the matching value and restricted to the
 * expected preview callback hosts. If the secret is missing, preview OAuth is
 * intentionally unavailable rather than silently using a credential embedded
 * in this repository.
 */
export const PREVIEW_CLIENT_ID = "grok_preview";
export const PREVIEW_CLIENT_SECRET = process.env.GROK_AUTH_CLIENT_SECRET?.trim() ?? "";

/** The shared auth broker issuer (OIDC discovery lives under it). */
export const GROK_ISSUER_DEFAULT = "https://auth.grok.me";

/**
 * Host patterns whose callbacks the preview client accepts. Better Auth derives
 * the live preview's real origin from the request host and validates it against
 * this list (wildcard-matched), so the OAuth `redirect_uri` becomes the concrete
 * `https://<preview-host>/api/auth/oauth2/callback/...` the broker allows.
 */
export const PREVIEW_ALLOWED_HOSTS = ["*.grok-sandbox.com"] as const;
