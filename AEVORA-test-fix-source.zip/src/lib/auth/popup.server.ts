/**
 * Live-preview sign-in popup — server-only (NEVER import from the client).
 *
 * The sandbox preview runs the app in a partitioned iframe, so OAuth must happen
 * in a top-level popup (first-party cookies). This handler is the ENTIRE popup
 * document — no React shell:
 *
 *   Phase 1 (`?providerId=…`): start OAuth server-side, Set-Cookie the OAuth
 *     state on a same-origin 200 page, then JS-navigate to the broker. A 302
 *     straight to Google/the broker caused Chromium to drop the `better-auth.state`
 *     cookie, so the callback died with `state_security_mismatch` and the popup
 *     stayed on “Signing you in…”.
 *   Phase 2 (`?done=1`): after the broker round-trip, emit a tiny HTML page that
 *     posts the session token to the opener and closes. No SPA hydrate, no
 *     server-fn round-trip.
 *
 * Wired automatically by the Vite `authPopupPlugin` in `vite.config.ts` during
 * `npm run dev` (live preview). Do NOT create `src/routes/auth/popup.tsx` — a
 * React route here paints the full app shell in the popup. The opener lives in
 * `client.ts` (`signIn` → `openSignInPopup`).
 */
import { auth, SESSION_TOKEN_COOKIE } from "./server";
import { GROK_ISSUER_DEFAULT } from "./preview";
import { authBrokerHeaders } from "../auth-public-request";
import { cookieValueFromSetCookie } from "../oauth-callback-complete";
import { brokerHandoffHtml } from "../oauth-handoff-html";

/** Message shape the popup posts to the opener (must match `client.ts`). */
export type PopupMessage = {
  source: "grok-auth-popup";
  token: string | null;
  error?: string;
};

/** Same-origin backup channel — must match `client.ts`. */
export const AUTH_POPUP_CHANNEL = "grok-auth-popup";

/**
 * Handle `GET /auth/popup`. Invoked by the Vite `authPopupPlugin` (dev / live
 * preview). Do not re-export this from a React route file.
 */
export async function handleAuthPopupRequest(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const done = url.searchParams.get("done") === "1";

  if (done) {
    const errored = url.searchParams.has("error");
    const token = errored ? null : readCookie(request, SESSION_TOKEN_COOKIE);
    const errorCode = url.searchParams.get("error");
    const message: PopupMessage = {
      source: "grok-auth-popup",
      token,
      ...(errored
        ? { error: errorCode && errorCode !== "1" ? errorCode : "sign_in_failed" }
        : {}),
    };
    return new Response(completionHtml(message), {
      status: 200,
      headers: {
        "content-type": "text/html; charset=utf-8",
        "cache-control": "no-store",
      },
    });
  }

  const providerId = url.searchParams.get("providerId")?.trim();
  if (!providerId) {
    return new Response("Missing providerId", {
      status: 400,
      headers: { "content-type": "text/plain; charset=utf-8" },
    });
  }

  // Stay first-party for the callback so the session cookie lands in THIS popup.
  const back = `${url.origin}/auth/popup?done=1`;
  try {
    const apiRes = await auth.api.signInWithOAuth2({
      body: {
        providerId,
        callbackURL: back,
        errorCallbackURL: back,
      },
      // Normalized preview Host / X-Forwarded-* so authorize redirect_uri
      // matches the callback token exchange (invalid_grant otherwise).
      headers: authBrokerHeaders(request),
      asResponse: true,
    });

    if (!apiRes.ok) {
      const detail = await apiRes.text().catch(() => "");
      return completionResponse({
        source: "grok-auth-popup",
        token: null,
        error: detail || `oauth_init_failed_${apiRes.status}`,
      });
    }

    const body = (await apiRes.json().catch(() => null)) as {
      url?: string;
    } | null;
    const location = body?.url;
    if (!location) {
      return completionResponse({
        source: "grok-auth-popup",
        token: null,
        error: "oauth_init_missing_url",
      });
    }
    if (!brokerRedirectAllowed(location)) {
      return completionResponse({
        source: "grok-auth-popup",
        token: null,
        error: "oauth_init_untrusted_redirect",
      });
    }

    // Preview popup only: 200 + Set-Cookie, then browser-specific handoff.
    // Chromium auto-navigates; Safari gets a first-party tap so ITP keeps
    // the CSRF state cookie. Production never uses this handler.
    const headers = new Headers({
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store",
    });
    for (const cookie of apiRes.headers.getSetCookie()) {
      headers.append("set-cookie", cookie);
    }
    return new Response(brokerHandoffHtml(location), { status: 200, headers });
  } catch (err) {
    const message = err instanceof Error ? err.message : "oauth_init_threw";
    return completionResponse({
      source: "grok-auth-popup",
      token: null,
      error: message,
    });
  }
}

function safePopupErrorHint(error: string | undefined): string {
  if (!error || error === "1" || error === "sign_in_failed") return "";
  if (error === "oauth_code_verification_failed" || error === "invalid_grant") {
    return "Google completed, but AEVORA could not finish the sign-in handshake. Please try again.";
  }
  if (error.includes("state")) {
    return "The sign-in window expired or was interrupted. Please try again.";
  }
  return "";
}

function brokerRedirectAllowed(target: string): boolean {
  try {
    const u = new URL(target);
    const issuerRaw = (process.env.GROK_AUTH_ISSUER?.trim() || GROK_ISSUER_DEFAULT).replace(
      /\/+$/,
      "",
    );
    const allowed = new URL(issuerRaw);
    return u.protocol === "https:" && u.hostname === allowed.hostname;
  } catch {
    return false;
  }
}

function completionResponse(message: PopupMessage, extraCookies: string[] = []): Response {
  const headers = new Headers({
    "content-type": "text/html; charset=utf-8",
    "cache-control": "no-store",
  });
  for (const cookie of extraCookies) headers.append("set-cookie", cookie);
  return new Response(completionHtml(message), {
    status: 200,
    headers,
  });
}

/**
 * Safari drops Set-Cookie from a 302 onto the next request. If Better Auth
 * redirected to the popup completion URL, finish here instead: 200 HTML with
 * the session token taken from Set-Cookie (never put in the query string).
 */
export function rewriteOAuthCallbackForPopup(request: Request, response: Response): Response {
  const location = response.headers.get("location");
  if (!location) return response;
  let loc: URL;
  try {
    loc = new URL(location, new URL(request.url).origin);
  } catch {
    return response;
  }
  if (loc.pathname !== "/auth/popup" || loc.searchParams.get("done") !== "1") return response;

  const cookies =
    typeof response.headers.getSetCookie === "function" ? response.headers.getSetCookie() : [];
  const error = loc.searchParams.get("error");
  const token = error ? null : cookieValueFromSetCookie(cookies, SESSION_TOKEN_COOKIE);
  return completionResponse(
    {
      source: "grok-auth-popup",
      token,
      ...(error || !token
        ? { error: error && error !== "1" ? error : "sign_in_failed" }
        : {}),
    },
    cookies,
  );
}

/** Minimal HTML: postMessage the token to the opener and close. No React. */
function completionHtml(message: PopupMessage): string {
  const payload = JSON.stringify(message).replace(/</g, "\\u003c");
  const failed = Boolean(message.error) || !message.token;
  const hint = safePopupErrorHint(message.error);
  const label = failed
    ? "Sign-in did not complete. You can close this window and try again."
    : "Signing you in…";
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Signing in…</title>
<style>
  html,body{margin:0;min-height:100%;background:#0b0b0c;color:#a1a1aa;
    font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
  main{min-height:100vh;display:grid;place-items:center;padding:1.5rem;text-align:center}
  button{margin-top:1rem;background:#e8e4d9;color:#12141a;border:0;border-radius:8px;
    padding:.55rem 1rem;font:inherit;cursor:pointer}
</style>
</head>
<body>
<main>
  <p id="grok-auth-popup-status">${failed ? label : "Signing you in…"}</p>
  ${failed && hint ? `<p>${hint}</p>` : ""}
  ${failed ? "<p><button type=\"button\" id=\"grok-auth-popup-close\">Close</button></p>" : ""}
</main>
<script type="application/json" id="grok-auth-popup-msg">${payload}</script>
<script>
(function () {
  var el = document.getElementById("grok-auth-popup-msg");
  var msg = { source: "grok-auth-popup", token: null };
  try { if (el && el.textContent) msg = JSON.parse(el.textContent); } catch (e) {}
  function notify() {
    try {
      if (window.opener) window.opener.postMessage(msg, window.location.origin);
    } catch (e) {}
    try {
      var ch = new BroadcastChannel(${JSON.stringify(AUTH_POPUP_CHANNEL)});
      ch.postMessage(msg);
      ch.close();
    } catch (e) {}
  }
  notify();
  setTimeout(notify, 50);
  setTimeout(notify, 250);
  if (msg.token) {
    try { sessionStorage.setItem("grok-auth.bearer-token", msg.token); } catch (e) {}
  }
  if (window.opener) {
    try { window.close(); } catch (e) {}
  } else if (msg.token) {
    window.location.replace("/app");
  }
  var btn = document.getElementById("grok-auth-popup-close");
  if (btn) btn.addEventListener("click", function () { window.close(); });
  setTimeout(function () {
    var status = document.getElementById("grok-auth-popup-status");
    if (!status) return;
    if (window.opener && !window.closed && !msg.error) {
      status.textContent = "You can close this window.";
    }
  }, 600);
})();
</script>
</body>
</html>`;
}

/** Read a single cookie value from the request (handles `=` inside values). */
function readCookie(request: Request, name: string): string | null {
  const header = request.headers.get("cookie");
  if (!header) return null;
  for (const part of header.split(";")) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    const eq = trimmed.indexOf("=");
    if (eq <= 0) continue;
    if (trimmed.slice(0, eq) !== name) continue;
    const raw = trimmed.slice(eq + 1);
    try {
      return decodeURIComponent(raw);
    } catch {
      return raw;
    }
  }
  return null;
}
