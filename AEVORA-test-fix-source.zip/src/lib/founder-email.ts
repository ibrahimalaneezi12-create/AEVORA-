/**
 * Server-side founder identity. This is an account identifier, not a password.
 * Entitlements look up the authenticated Better Auth email; clients cannot
 * self-promote.
 */
export const FOUNDER_EMAIL = "ibrahimalaneezi12@gmail.com";

export function normalizeAccountEmail(value: string | null | undefined): string {
  return (value ?? "").trim().toLowerCase();
}

export function isFounderEmail(value: string | null | undefined): boolean {
  return normalizeAccountEmail(value) === FOUNDER_EMAIL;
}
