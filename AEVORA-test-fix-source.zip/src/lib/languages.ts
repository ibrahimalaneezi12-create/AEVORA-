/**
 * Global language registry. English and Arabic are the first two; any later
 * language is a catalog row, not a second brain. Detection, dir, and speech
 * tags live here. Reasoning, memory, tools, and identity do not.
 */

export type TextDir = "ltr" | "rtl";

export type LanguageMeta = {
  code: string;
  englishName: string;
  nativeName: string;
  dir: TextDir;
  speech: string;
  dateLocale: string;
};

const LANGUAGES: LanguageMeta[] = [
  { code: "en", englishName: "English", nativeName: "English", dir: "ltr", speech: "en-US", dateLocale: "en-US" },
  { code: "ar", englishName: "Arabic", nativeName: "العربية", dir: "rtl", speech: "ar-SA", dateLocale: "ar" },
  { code: "es", englishName: "Spanish", nativeName: "Español", dir: "ltr", speech: "es-ES", dateLocale: "es" },
  { code: "fr", englishName: "French", nativeName: "Français", dir: "ltr", speech: "fr-FR", dateLocale: "fr" },
  { code: "de", englishName: "German", nativeName: "Deutsch", dir: "ltr", speech: "de-DE", dateLocale: "de" },
  { code: "it", englishName: "Italian", nativeName: "Italiano", dir: "ltr", speech: "it-IT", dateLocale: "it" },
  { code: "pt", englishName: "Portuguese", nativeName: "Português", dir: "ltr", speech: "pt-PT", dateLocale: "pt" },
  { code: "pt-BR", englishName: "Portuguese (Brazil)", nativeName: "Português (Brasil)", dir: "ltr", speech: "pt-BR", dateLocale: "pt-BR" },
  { code: "tr", englishName: "Turkish", nativeName: "Türkçe", dir: "ltr", speech: "tr-TR", dateLocale: "tr" },
  { code: "ur", englishName: "Urdu", nativeName: "اردو", dir: "rtl", speech: "ur-PK", dateLocale: "ur" },
  { code: "hi", englishName: "Hindi", nativeName: "हिन्दी", dir: "ltr", speech: "hi-IN", dateLocale: "hi" },
  { code: "bn", englishName: "Bengali", nativeName: "বাংলা", dir: "ltr", speech: "bn-BD", dateLocale: "bn" },
  { code: "fa", englishName: "Persian", nativeName: "فارسی", dir: "rtl", speech: "fa-IR", dateLocale: "fa" },
  { code: "id", englishName: "Indonesian", nativeName: "Bahasa Indonesia", dir: "ltr", speech: "id-ID", dateLocale: "id" },
  { code: "ms", englishName: "Malay", nativeName: "Bahasa Melayu", dir: "ltr", speech: "ms-MY", dateLocale: "ms" },
  { code: "ja", englishName: "Japanese", nativeName: "日本語", dir: "ltr", speech: "ja-JP", dateLocale: "ja" },
  { code: "ko", englishName: "Korean", nativeName: "한국어", dir: "ltr", speech: "ko-KR", dateLocale: "ko" },
  { code: "zh", englishName: "Chinese", nativeName: "中文", dir: "ltr", speech: "zh-CN", dateLocale: "zh-CN" },
  { code: "ru", englishName: "Russian", nativeName: "Русский", dir: "ltr", speech: "ru-RU", dateLocale: "ru" },
  { code: "uk", englishName: "Ukrainian", nativeName: "Українська", dir: "ltr", speech: "uk-UA", dateLocale: "uk" },
  { code: "pl", englishName: "Polish", nativeName: "Polski", dir: "ltr", speech: "pl-PL", dateLocale: "pl" },
  { code: "nl", englishName: "Dutch", nativeName: "Nederlands", dir: "ltr", speech: "nl-NL", dateLocale: "nl" },
  { code: "sv", englishName: "Swedish", nativeName: "Svenska", dir: "ltr", speech: "sv-SE", dateLocale: "sv" },
  { code: "no", englishName: "Norwegian", nativeName: "Norsk", dir: "ltr", speech: "nb-NO", dateLocale: "nb" },
  { code: "da", englishName: "Danish", nativeName: "Dansk", dir: "ltr", speech: "da-DK", dateLocale: "da" },
  { code: "fi", englishName: "Finnish", nativeName: "Suomi", dir: "ltr", speech: "fi-FI", dateLocale: "fi" },
  { code: "he", englishName: "Hebrew", nativeName: "עברית", dir: "rtl", speech: "he-IL", dateLocale: "he" },
  { code: "th", englishName: "Thai", nativeName: "ไทย", dir: "ltr", speech: "th-TH", dateLocale: "th" },
  { code: "vi", englishName: "Vietnamese", nativeName: "Tiếng Việt", dir: "ltr", speech: "vi-VN", dateLocale: "vi" },
];

const BY_CODE = new Map(LANGUAGES.map((l) => [l.code.toLowerCase(), l]));

const ALIASES: Record<string, string> = {
  english: "en",
  en: "en",
  arabic: "ar",
  ar: "ar",
  عربى: "ar",
  العربية: "ar",
  عربي: "ar",
  spanish: "es",
  español: "es",
  espanol: "es",
  es: "es",
  french: "fr",
  français: "fr",
  francais: "fr",
  fr: "fr",
  german: "de",
  deutsch: "de",
  de: "de",
  italian: "it",
  italiano: "it",
  it: "it",
  portuguese: "pt",
  português: "pt",
  portugues: "pt",
  pt: "pt",
  brazilian: "pt-BR",
  "pt-br": "pt-BR",
  turkish: "tr",
  türkçe: "tr",
  turkce: "tr",
  tr: "tr",
  urdu: "ur",
  ur: "ur",
  hindi: "hi",
  हिन्दी: "hi",
  hi: "hi",
  bengali: "bn",
  bangla: "bn",
  bn: "bn",
  persian: "fa",
  farsi: "fa",
  فارسی: "fa",
  fa: "fa",
  indonesian: "id",
  id: "id",
  malay: "ms",
  ms: "ms",
  japanese: "ja",
  日本語: "ja",
  ja: "ja",
  korean: "ko",
  한국어: "ko",
  ko: "ko",
  chinese: "zh",
  中文: "zh",
  mandarin: "zh",
  zh: "zh",
  russian: "ru",
  русский: "ru",
  ru: "ru",
  ukrainian: "uk",
  українська: "uk",
  uk: "uk",
  polish: "pl",
  polski: "pl",
  pl: "pl",
  dutch: "nl",
  nederlands: "nl",
  nl: "nl",
  swedish: "sv",
  svenska: "sv",
  sv: "sv",
  norwegian: "no",
  norsk: "no",
  no: "no",
  danish: "da",
  dansk: "da",
  da: "da",
  finnish: "fi",
  suomi: "fi",
  fi: "fi",
  hebrew: "he",
  עברית: "he",
  he: "he",
  thai: "th",
  ไทย: "th",
  th: "th",
  vietnamese: "vi",
  "tiếng việt": "vi",
  vi: "vi",
};

export const DEFAULT_LOCALE = "en";

export function listedLanguages(): readonly LanguageMeta[] {
  return LANGUAGES;
}

export function lookupLanguage(code: string | null | undefined): LanguageMeta | null {
  if (!code) return null;
  const trimmed = code.trim();
  if (!trimmed) return null;
  const direct = BY_CODE.get(trimmed.toLowerCase());
  if (direct) return direct;
  const prefix = trimmed.split(/[-_]/)[0]?.toLowerCase();
  if (!prefix) return null;
  return BY_CODE.get(prefix) ?? null;
}

export function isLanguageCode(value: string | null | undefined): boolean {
  return lookupLanguage(value) !== null;
}

export function resolveLanguageCode(
  value: string | null | undefined,
  fallback: string = DEFAULT_LOCALE,
): string {
  return lookupLanguage(value)?.code ?? lookupLanguage(fallback)?.code ?? DEFAULT_LOCALE;
}

export function languageFromAlias(raw: string): string | null {
  const key = raw.trim().toLowerCase();
  if (!key) return null;
  const mapped = ALIASES[key];
  if (mapped) return lookupLanguage(mapped)?.code ?? null;
  return lookupLanguage(key)?.code ?? null;
}

export function dirForCode(code: string): TextDir {
  return lookupLanguage(code)?.dir ?? "ltr";
}

export function speechTagFor(code: string): string {
  return lookupLanguage(code)?.speech ?? "en-US";
}

export function englishNameFor(code: string): string {
  return lookupLanguage(code)?.englishName ?? "English";
}

/**
 * Register a later language without a rebuild of reasoning. Refuses duplicates.
 */
export function registerLanguage(meta: LanguageMeta): void {
  const code = meta.code.trim();
  if (!code || BY_CODE.has(code.toLowerCase())) {
    throw new Error("Language already registered.");
  }
  const row: LanguageMeta = {
    code,
    englishName: meta.englishName,
    nativeName: meta.nativeName,
    dir: meta.dir,
    speech: meta.speech,
    dateLocale: meta.dateLocale,
  };
  LANGUAGES.push(row);
  BY_CODE.set(code.toLowerCase(), row);
}

const SCRIPT = {
  arabic: /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/g,
  hebrew: /[\u0590-\u05FF]/g,
  cyrillic: /[\u0400-\u04FF]/g,
  hangul: /[\uAC00-\uD7AF]/g,
  hiragana: /[\u3040-\u309F]/g,
  katakana: /[\u30A0-\u30FF]/g,
  cjk: /[\u4E00-\u9FFF]/g,
  thai: /[\u0E00-\u0E7F]/g,
  devanagari: /[\u0900-\u097F]/g,
  bengali: /[\u0980-\u09FF]/g,
  latin: /[A-Za-zÀ-ÖØ-öø-ÿ]/g,
} as const;

function count(re: RegExp, text: string): number {
  return (text.match(re) ?? []).length;
}

/**
 * Script-first detection. Mixed scripts return null so the preferred locale
 * stays. Latin-only languages are left to the model unless the user switched.
 */
export function detectLanguageCode(text: string): string | null {
  const ar = count(SCRIPT.arabic, text);
  const he = count(SCRIPT.hebrew, text);
  const cy = count(SCRIPT.cyrillic, text);
  const ko = count(SCRIPT.hangul, text);
  const jaKana = count(SCRIPT.hiragana, text) + count(SCRIPT.katakana, text);
  const cjk = count(SCRIPT.cjk, text);
  const th = count(SCRIPT.thai, text);
  const hi = count(SCRIPT.devanagari, text);
  const bn = count(SCRIPT.bengali, text);
  const la = count(SCRIPT.latin, text);

  const scores: { code: string; n: number }[] = [
    { code: "ar", n: ar },
    { code: "he", n: he },
    { code: "ru", n: cy },
    { code: "ko", n: ko },
    { code: "ja", n: jaKana },
    { code: "zh", n: jaKana > 0 ? 0 : cjk },
    { code: "th", n: th },
    { code: "hi", n: hi },
    { code: "bn", n: bn },
    { code: "en", n: la },
  ];
  const present = scores.filter((s) => s.n > 0).sort((a, b) => b.n - a.n);
  if (present.length === 0) return null;
  if (present.length === 1) return present[0]!.code === "en" ? "en" : present[0]!.code;
  const [top, second] = present;
  if (!top || !second) return null;
  if (top.code === "en" || second.code === "en") {
    if (top.n > 0 && second.n > 0 && top.code !== second.code) return null;
  }
  if (second.n > 0 && second.n * 3 >= top.n) return null;
  return top.code;
}
