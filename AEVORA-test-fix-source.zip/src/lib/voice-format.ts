import { type AppLocale, speechLangFor } from "./locale.ts";

export const VOICE_STATES = [
  "idle",
  "permission",
  "listening",
  "user_speaking",
  "thinking",
  "speaking",
  "interrupted",
  "error",
  "disabled",
] as const;
export type VoiceState = (typeof VOICE_STATES)[number];

export const SILENCE_TIMEOUT_MS = 1400;
export const BARGE_IN_MIN_CHARS = 2;
export const VOICE_NAME_MAX = 120;

export type BrowserVoice = {
  name: string;
  lang: string;
  default?: boolean;
};

export function langMatches(voiceLang: string, locale: AppLocale): boolean {
  const want = speechLangFor(locale).toLowerCase();
  const got = (voiceLang || "").toLowerCase();
  if (!got) return false;
  if (got === want) return true;
  const prefix = locale.split(/[-_]/)[0]?.toLowerCase() || "en";
  return got === prefix || got.startsWith(`${prefix}-`);
}

export function listCompatibleVoices(
  voices: BrowserVoice[],
  locale: AppLocale,
): BrowserVoice[] {
  return voices.filter((v) => langMatches(v.lang, locale));
}

export function pickVoice(
  voices: BrowserVoice[],
  preferredName: string,
  locale: AppLocale,
): BrowserVoice | null {
  const name = preferredName.trim();
  const compatible = listCompatibleVoices(voices, locale);
  if (name) {
    const exactCompat = compatible.find((v) => v.name === name);
    if (exactCompat) return exactCompat;
  }
  const def = compatible.find((v) => v.default);
  if (def) return def;
  return compatible[0] ?? null;
}

export function voiceSupportsLocale(
  voice: BrowserVoice | null | undefined,
  locale: AppLocale,
): boolean {
  if (!voice) return false;
  return langMatches(voice.lang, locale);
}

export function echoGuard(heard: string, spoken: string): boolean {
  const a = heard.trim().toLowerCase();
  const b = spoken.trim().toLowerCase();
  if (a.length < 8 || b.length < 8) return false;
  if (b.startsWith(a)) return true;
  const head = b.slice(0, Math.min(32, b.length));
  return a.startsWith(head);
}

export const VOICE_COPY: Record<"en" | "ar", Record<string, string>> = {
  en: {
    idle: "Tap to talk",
    permission: "Allow the microphone to talk",
    listening: "Listening",
    user_speaking: "Hearing you",
    thinking: "AEVORA is thinking",
    speaking: "Speaking",
    interrupted: "Interrupted",
    error: "Voice ran into a problem",
    disabled: "Voice is off",
    stop: "Stop voice",
    start: "Start voice",
    retry: "Try microphone again",
    unsupported: "This browser cannot listen",
    denied: "Microphone is blocked",
    unavailable: "Microphone is unavailable",
    preview: "Preview voice",
    fallback: "Selected voice does not speak this language. Using a compatible voice.",
    continue: "Tap the mic to continue",
  },
  ar: {
    idle: "اضغط للتحدث",
    permission: "اسمح للميكروفون حتى نتحدث",
    listening: "أستمع",
    user_speaking: "أسمعك",
    thinking: "أفكر",
    speaking: "أتحدث",
    interrupted: "توقفت",
    error: "حدثت مشكلة في الصوت",
    disabled: "الصوت متوقف",
    stop: "إيقاف الصوت",
    start: "بدء الصوت",
    retry: "إعادة المحاولة",
    unsupported: "هذا المتصفح لا يستطيع الاستماع",
    denied: "الميكروفون محظور",
    unavailable: "الميكروفون غير متاح",
    preview: "معاينة الصوت",
    fallback: "الصوت المحدد لا يدعم هذه اللغة. سأستخدم صوتاً متوافقاً.",
    continue: "اضغط على الميكروفون للمتابعة",
  },
};

export function voiceCopyFor(locale: AppLocale): Record<string, string> {
  return locale === "ar" ? VOICE_COPY.ar : VOICE_COPY.en;
}
