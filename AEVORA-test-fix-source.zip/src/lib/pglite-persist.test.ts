import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  PGLITE_DATA_DIR,
  PGLITE_DUMP_PATH,
  PREVIEW_SESSION_STORAGE_KEY,
  previewDbHasFiles,
  previewDumpExists,
} from "./pglite-persist.ts";

describe("preview db persist paths", () => {
  it("keeps data under the workspace .data directory", () => {
    assert.match(PGLITE_DATA_DIR, /\.data[/\\]pglite$/);
    assert.match(PGLITE_DUMP_PATH, /\.data[/\\]pglite-dump\.tgz$/);
  });

  it("does not treat a missing directory as populated", () => {
    assert.equal(previewDbHasFiles("/tmp/aegis-no-such-pglite-dir"), false);
    assert.equal(previewDumpExists("/tmp/aegis-no-such-dump.tgz"), false);
  });

  it("uses the same bearer storage key as the auth client", () => {
    assert.equal(PREVIEW_SESSION_STORAGE_KEY, "grok-auth.bearer-token");
  });
});
