import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { emailDraftPayload, emailSendPayload } from "@/lib/confirm-format";
import { looksLikeEmail, mapEmailDraft, type EmailDraft, type EmailDraftRow } from "@/lib/mail-format";
import { ConnectorType } from "@/lib/app-data/types";
import type { LinkStatus } from "@/lib/links-format";
import { classifyGatePeek } from "@/lib/providers/gate-peek";
import type { ToolHandler } from "@/lib/tools/types";

export type { EmailDraft } from "@/lib/mail-format";
export { formatDraftsBlock } from "@/lib/mail-format";

const GMAIL_SEND = "gmail_send_email";
const GMAIL_SEARCH = "gmail_search_messages";

export const emailListHandler: ToolHandler = async ({ userId }) => {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`
    select count(*)::int as n from email_drafts where user_id = ${userId} and status = ${"draft"}
  `;
  const n = rows[0]?.n ?? 0;
  const drafts = n === 0 ? "No email drafts." : n === 1 ? "1 draft." : `${n} drafts.`;
  const gmail = await peekGmailInbox();
  return `${drafts} ${gmail.detail}`;
};

function extractMailLines(data: unknown): string[] {
  const out: string[] = [];
  const visit = (value: unknown) => {
    if (!value || out.length >= 5) return;
    if (Array.isArray(value)) {
      for (const item of value) visit(item);
      return;
    }
    if (typeof value === "object") {
      const rec = value as Record<string, unknown>;
      const subject = typeof rec.subject === "string" ? rec.subject : "";
      const from = typeof rec.from === "string" ? rec.from : typeof rec.sender === "string" ? rec.sender : "";
      if (subject) out.push(from ? `${from} — ${subject}` : subject);
      if ("messages" in rec) visit(rec.messages);
      if ("items" in rec) visit(rec.items);
    }
  };
  visit(data);
  return out;
}

export function formatGmailBlock(peek: { connected: boolean; detail: string; lines: string[] }): string {
  if (!peek.connected) return peek.detail;
  if (peek.lines.length === 0) return peek.detail;
  return `${peek.detail}\n${peek.lines.map((line) => `- ${line}`).join("\n")}`;
}

export const emailDraftHandler: ToolHandler = async ({ userId, payload, title: proposalTitle, summary }) => {
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "email");
  const parsed = emailDraftPayload.parse(payload);
  const toAddress = (parsed.to ?? "").trim();
  if (!toAddress || !looksLikeEmail(toAddress)) throw new Error("Add a valid recipient.");
  const subject = (parsed.subject ?? proposalTitle).trim();
  if (!subject) throw new Error("Add a subject.");
  const body = (parsed.body ?? summary).trim();
  if (!body) throw new Error("Add the message.");
  const sql = await getSql();
  const rows = await sql<EmailDraftRow>`
    insert into email_drafts (user_id, to_address, cc_address, subject, body, status)
    values (
      ${userId},
      ${toAddress},
      ${(parsed.cc ?? "").trim()},
      ${subject.slice(0, 200)},
      ${body.slice(0, 8000)},
      ${"draft"}
    )
    returning id, to_address, cc_address, subject, body, status, conversation_id, sent_at, error, created_at, updated_at
  `;
  const mapped = rows[0] ? mapEmailDraft(rows[0]) : null;
  if (!mapped) throw new Error("Draft could not be saved.");
  return `Draft ${mapped.id} ready for ${mapped.toAddress}. It has not been sent.`;
};

export const emailSendHandler: ToolHandler = async ({ userId, payload }) => {
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "email");
  const parsed = emailSendPayload.parse(payload);
  const sql = await getSql();
  const existing = await sql<EmailDraftRow>`
    select id, to_address, cc_address, subject, body, status, conversation_id, sent_at, error, created_at, updated_at
    from email_drafts
    where id = ${parsed.id} and user_id = ${userId}
  `;
  const draft = existing[0] ? mapEmailDraft(existing[0]) : null;
  if (!draft) throw new Error("Draft not found.");
  if (draft.status === "sent") throw new Error("That email was already sent.");

  let sent = false;
  let lastError = "Email is not connected. The draft was kept and nothing was sent.";
  try {
    const { callTool } = await import("@/lib/app-data/client.server");
    const result = await callTool(
      GMAIL_SEND,
      {
        to: draft.toAddress,
        cc: draft.ccAddress || undefined,
        subject: draft.subject,
        body: draft.body,
      },
      { connectorType: ConnectorType.Gmail },
    );
    if (result.ok) {
      sent = true;
    } else if (result.loginRequired) {
      lastError = "Gmail needs to be connected before I can send. Nothing was sent.";
    } else if (result.pending) {
      lastError = "Gmail is not ready in this keep yet. Nothing was sent.";
    } else {
      lastError = result.errorMessage
        ? `I could not send it. ${result.errorMessage} Nothing was sent.`
        : lastError;
    }
  } catch {
    sent = false;
  }

  if (sent) {
    await sql`
      update email_drafts
      set status = ${"sent"}, sent_at = now(), error = ${""}, updated_at = now()
      where id = ${draft.id} and user_id = ${userId}
    `;
    return `Sent to ${draft.toAddress}.`;
  }

  await sql`
    update email_drafts
    set status = ${"failed"}, error = ${lastError}, updated_at = now()
    where id = ${draft.id} and user_id = ${userId}
  `;
  throw new Error(lastError);
};

export const listEmailDrafts = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<EmailDraft[]> => {
    const sql = await getSql();
    const rows = await sql<EmailDraftRow>`
      select id, to_address, cc_address, subject, body, status, conversation_id, sent_at, error, created_at, updated_at
      from email_drafts
      where user_id = ${context.userId}
      order by updated_at desc
      limit 40
    `;
    const out: EmailDraft[] = [];
    for (const row of rows) {
      const mapped = mapEmailDraft(row);
      if (mapped) out.push(mapped);
    }
    return out;
  });

export async function listOwnDraftsForContext(userId: string): Promise<EmailDraft[]> {
  try {
    const sql = await getSql();
    const rows = await sql<EmailDraftRow>`
      select id, to_address, cc_address, subject, body, status, conversation_id, sent_at, error, created_at, updated_at
      from email_drafts
      where user_id = ${userId} and status = ${"draft"}
      order by updated_at desc
      limit 8
    `;
    const out: EmailDraft[] = [];
    for (const row of rows) {
      const mapped = mapEmailDraft(row);
      if (mapped) out.push(mapped);
    }
    return out;
  } catch {
    return [];
  }
}

export type MailConnection = {
  connected: boolean;
  status: LinkStatus;
  detail: string;
};

function mailFailure(err: unknown): { connected: false; status: LinkStatus; detail: string; lines: string[]; loginUrl: string; lastCheckedAt: string } {
  const checked = new Date().toISOString();
  const message = err instanceof Error ? err.message : "";
  if (/gate|not ready|connector/i.test(message)) {
    return { connected: false, status: "not_configured", detail: "Gmail is not configured in this keep yet. Nothing was read.", lines: [], loginUrl: "", lastCheckedAt: checked };
  }
  return { connected: false, status: "connection_error", detail: "Gmail could not be checked. Nothing was read.", lines: [], loginUrl: "", lastCheckedAt: checked };
}

export async function peekGmailInbox(): Promise<{
  connected: boolean;
  status: LinkStatus;
  detail: string;
  lines: string[];
  loginUrl: string;
  lastCheckedAt: string;
}> {
  const lastCheckedAt = new Date().toISOString();
  try {
    const { callTool } = await import("@/lib/app-data/client.server");
    const result = await callTool(
      GMAIL_SEARCH,
      { query: "in:inbox", maxResults: 5 },
      { connectorType: ConnectorType.Gmail },
    );
    const gate = classifyGatePeek("Gmail", result);
    if (!gate.connected) return { ...gate, lines: [], lastCheckedAt };
    const lines = extractMailLines(result.data);
    return {
      connected: true,
      status: "connected",
      detail: lines.length ? `Gmail connected. ${lines.length} recent inbox items.` : "Gmail is connected. Inbox is quiet.",
      lines,
      loginUrl: "",
      lastCheckedAt,
    };
  } catch (err) {
    return mailFailure(err);
  }
}

export async function peekGmailConnection(): Promise<{
  connected: boolean;
  status: LinkStatus;
  detail: string;
  loginUrl: string;
  lastCheckedAt: string;
}> {
  const peek = await peekGmailInbox();
  return { connected: peek.connected, status: peek.status, detail: peek.detail, loginUrl: peek.loginUrl, lastCheckedAt: peek.lastCheckedAt };
}

export const getMailStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async (): Promise<MailConnection> => peekGmailConnection());

