import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { FOUNDER_EMAIL, isFounderEmail, normalizeAccountEmail } from "./founder-email.ts";

describe("founder email", () => {
  it("matches only Ibrahim's account, ignoring case and padding", () => {
    assert.equal(isFounderEmail("  IbrahimAlaneezi12@Gmail.com "), true);
    assert.equal(isFounderEmail(FOUNDER_EMAIL), true);
  });

  it("does not make every other address a founder", () => {
    assert.equal(isFounderEmail("someone@gmail.com"), false);
    assert.equal(isFounderEmail("ibrahimalaneezi12@gmail.com.evil"), false);
    assert.equal(isFounderEmail(""), false);
    assert.equal(isFounderEmail(null), false);
  });

  it("normalizes for comparison without inventing an address", () => {
    assert.equal(normalizeAccountEmail("  A@B.COM "), "a@b.com");
    assert.equal(normalizeAccountEmail(undefined), "");
  });
});
