/**
 * Per-user HubSpot, Shopify, Google Ads, and QuickBooks links.
 * Tokens stay sealed. Account ids from the client are ignored.
 * Nothing is marked connected until that provider accepts the credential.
 */
import { appendAudit } from "@/lib/audit";
import { getSql } from "@/lib/db";
import type { LinkStatus } from "@/lib/links-format";
import {
  adsSpendSpeech,
  booksRevenueSpeech,
  exchangeGoogleCode,
  exchangeQuickBooksCode,
  googleAdsAuthorizeUrl,
  googleAdsSetup,
  isGoogleAdsReady,
  isQuickBooksReady,
  listGoogleAdsCustomers,
  openOAuthState,
  quickBooksAuthorizeUrl,
  quickBooksSetup,
  readQuickBooksCompany,
  readQuickBooksIncome,
  refreshOAuthToken,
  sealOAuthState,
  searchGoogleAdsSpend,
  type OAuthProvider,
  type TokenBundle,
} from "@/lib/providers/oauth.server";
import {
  HUBSPOT_CONTACTS_PATH,
  HUBSPOT_DEALS_PATH,
  hubspotCapabilities,
  hubspotRequest,
  parseHubspotContacts,
} from "@/lib/providers/hubspot.server";
import {
  normalizeShopHost,
  parseShopifyOrders,
  parseShopifyProducts,
  parseShopifyShop,
  shopifyCapabilities,
  shopifyOrdersPath,
  shopifyProductsPath,
  shopifyRequest,
  shopifyShopPath,
} from "@/lib/providers/shopify.server";
import { canSealSecrets, openSecret, sealSecret } from "@/lib/seal.server";
import type { BusinessLead, BusinessOrder } from "@/lib/business-records";
import type { ShopifyProduct } from "@/lib/providers/shopify.server";

export type ProviderName = "hubspot" | "shopify" | OAuthProvider;

type LinkRow = {
  user_id: string;
  provider: string;
  status: string;
  key_hint: string;
  sealed: string;
  capabilities: string;
  account_label: string;
  last_error: string;
  last_checked_at: Date | string | null;
};

export type PublicProvider = {
  provider: "hubspot" | "shopify";
  connected: boolean;
  status: LinkStatus;
  detail: string;
  capabilities: string[];
  accountLabel: string;
  lastCheckedAt: string;
};

export type OAuthLinkState = {
  connected: boolean;
  status: LinkStatus;
  detail: string;
  lastCheckedAt: string;
  available: boolean;
};

const RETRY = new Set(["connected", "authorization_required", "connection_error"]);

function hint(secret: string): string {
  return secret.slice(-4);
}

function caps(value: string): string[] {
  return value.split(",").map((part) => part.trim()).filter(Boolean);
}

function iso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string" && value) return value;
  return "";
}

function tokenKeys(sealed: string): { token: string; shop: string } | null {
  const plain = openSecret(sealed);
  if (!plain) return null;
  try {
    const parsed = JSON.parse(plain) as { token?: unknown; shop?: unknown };
    if (typeof parsed.token !== "string" || !parsed.token) return null;
    return { token: parsed.token, shop: typeof parsed.shop === "string" ? parsed.shop : "" };
  } catch {
    return null;
  }
}

function openBundle(sealed: string): TokenBundle | null {
  const plain = openSecret(sealed);
  if (!plain) return null;
  try {
    const parsed = JSON.parse(plain) as Partial<TokenBundle>;
    if (typeof parsed.accessToken !== "string" || !parsed.accessToken) return null;
    const environment = parsed.environment === "sandbox" || parsed.environment === "production" ? parsed.environment : "";
    const customerIds = Array.isArray(parsed.customerIds)
      ? parsed.customerIds.filter((id): id is string => typeof id === "string" && /^\d{1,20}$/.test(id))
      : [];
    return {
      accessToken: parsed.accessToken,
      refreshToken: typeof parsed.refreshToken === "string" ? parsed.refreshToken : "",
      expiresAt: typeof parsed.expiresAt === "number" ? parsed.expiresAt : 0,
      realmId: typeof parsed.realmId === "string" ? parsed.realmId : "",
      environment,
      customerIds,
    };
  } catch {
    return null;
  }
}

async function loadLink(userId: string, provider: ProviderName): Promise<LinkRow | null> {
  const sql = await getSql();
  const rows = await sql<LinkRow>`
    select user_id, provider, status, key_hint, sealed, capabilities, account_label, last_error, last_checked_at
    from provider_links
    where user_id = ${userId} and provider = ${provider}
    limit 1
  `;
  const row = rows[0];
  if (!row || row.user_id !== userId) return null;
  return row;
}

function hubDisconnected(): PublicProvider {
  return {
    provider: "hubspot",
    connected: false,
    status: "not_connected",
    detail: "HubSpot is not connected. Leads are not being read.",
    capabilities: [],
    accountLabel: "",
    lastCheckedAt: "",
  };
}

function shopDisconnected(): PublicProvider {
  return {
    provider: "shopify",
    connected: false,
    status: "not_connected",
    detail: "Shopify is not connected. Orders are not being read.",
    capabilities: [],
    accountLabel: "",
    lastCheckedAt: "",
  };
}

export async function publicProvider(userId: string, provider: "hubspot" | "shopify"): Promise<PublicProvider> {
  const row = await loadLink(userId, provider);
  if (!row) return provider === "hubspot" ? hubDisconnected() : shopDisconnected();
  const label = provider === "shopify" ? row.account_label : "";
  const checked = iso(row.last_checked_at);
  if (row.status === "authorization_required") {
    return {
      provider,
      connected: false,
      status: "authorization_required",
      detail:
        provider === "hubspot"
          ? "HubSpot needs authorization again. Leads are not being read."
          : "Shopify needs authorization again. Orders are not being read.",
      capabilities: [],
      accountLabel: label,
      lastCheckedAt: checked,
    };
  }
  if (row.status === "connection_error") {
    return {
      provider,
      connected: false,
      status: "connection_error",
      detail: row.last_error || (provider === "hubspot" ? "HubSpot could not be read." : "Shopify could not be read."),
      capabilities: [],
      accountLabel: label,
      lastCheckedAt: checked,
    };
  }
  if (row.status !== "connected") return provider === "hubspot" ? hubDisconnected() : shopDisconnected();
  return {
    provider,
    connected: true,
    status: "connected",
    detail:
      provider === "hubspot"
        ? "HubSpot is connected. Only returned contacts are used."
        : `Shopify is connected${label ? ` (${label})` : ""}. Only returned orders are used.`,
    capabilities: caps(row.capabilities),
    accountLabel: label,
    lastCheckedAt: checked,
  };
}

async function markProviderProblem(userId: string, provider: ProviderName, status: LinkStatus, error: string): Promise<void> {
  const sql = await getSql();
  await sql`
    update provider_links
    set status = ${status}, last_error = ${error.slice(0, 160)}, last_checked_at = now(), updated_at = now()
    where user_id = ${userId} and provider = ${provider}
  `;
}

async function markChecked(userId: string, provider: ProviderName, capabilities?: string[]): Promise<void> {
  const sql = await getSql();
  if (capabilities) {
    await sql`
      update provider_links
      set status = ${"connected"}, capabilities = ${capabilities.join(",")}, last_error = ${""}, last_checked_at = now(), updated_at = now()
      where user_id = ${userId} and provider = ${provider}
    `;
    return;
  }
  await sql`
    update provider_links
    set status = ${"connected"}, last_error = ${""}, last_checked_at = now(), updated_at = now()
    where user_id = ${userId} and provider = ${provider}
  `;
}

async function saveLink(opts: {
  userId: string;
  provider: ProviderName;
  sealed: string;
  hint: string;
  capabilities: string[];
  accountLabel: string;
}): Promise<void> {
  const sql = await getSql();
  await sql`
    insert into provider_links (
      user_id, provider, status, key_hint, sealed, capabilities, account_label, last_error, last_checked_at, updated_at
    )
    values (
      ${opts.userId},
      ${opts.provider},
      ${"connected"},
      ${opts.hint},
      ${opts.sealed},
      ${opts.capabilities.join(",")},
      ${opts.accountLabel},
      ${""},
      now(),
      now()
    )
    on conflict (user_id, provider) do update set
      status = excluded.status,
      key_hint = excluded.key_hint,
      sealed = excluded.sealed,
      capabilities = excluded.capabilities,
      account_label = excluded.account_label,
      last_error = ${""},
      last_checked_at = now(),
      updated_at = now()
  `;
}

function sealFailure(): { ok: false; error: string } {
  return { ok: false, error: "This keep cannot store a provider key safely yet. Nothing was saved." };
}

export async function connectHubspotForUser(
  userId: string,
  token: string,
): Promise<{ ok: true; capabilities: string[] } | { ok: false; error: string }> {
  if (!canSealSecrets()) return sealFailure();
  const sealed = sealSecret(JSON.stringify({ token }));
  if (!sealed) return sealFailure();
  const contacts = await hubspotRequest({ path: HUBSPOT_CONTACTS_PATH, token });
  if (!contacts.ok) return { ok: false, error: `${contacts.error} Nothing was saved.` };
  const deals = await hubspotRequest({ path: HUBSPOT_DEALS_PATH, token });
  const capabilities = hubspotCapabilities(true, deals.ok);
  await saveLink({ userId, provider: "hubspot", sealed, hint: hint(token), capabilities, accountLabel: "" });
  await appendAudit({ userId, actor: "user", action: "provider.connected", entityType: "provider", entityId: "hubspot", detail: "hubspot" });
  return { ok: true, capabilities };
}

export async function connectShopifyForUser(
  userId: string,
  shopInput: string,
  token: string,
): Promise<{ ok: true; capabilities: string[] } | { ok: false; error: string }> {
  const shop = normalizeShopHost(shopInput);
  if (!shop) return { ok: false, error: "Store address is not a Shopify shop. Nothing was saved." };
  if (!canSealSecrets()) return sealFailure();
  const sealed = sealSecret(JSON.stringify({ token, shop }));
  if (!sealed) return sealFailure();
  const shopCall = await shopifyRequest({ shop, path: shopifyShopPath(), token });
  if (!shopCall.ok) return { ok: false, error: `${shopCall.error} Nothing was saved.` };
  if (!parseShopifyShop(shopCall.body)) return { ok: false, error: "Shopify did not return a shop. Nothing was saved." };
  const orders = await shopifyRequest({ shop, path: shopifyOrdersPath(), token });
  const productsCall = await shopifyRequest({ shop, path: shopifyProductsPath(), token });
  const products = productsCall.ok ? parseShopifyProducts(productsCall.body) : [];
  const inventoryOk = products.some((product) => product.inventory !== null);
  const capabilities = shopifyCapabilities(true, orders.ok, productsCall.ok, inventoryOk);
  await saveLink({ userId, provider: "shopify", sealed, hint: hint(token), capabilities, accountLabel: shop });
  await appendAudit({ userId, actor: "user", action: "provider.connected", entityType: "provider", entityId: "shopify", detail: "shopify" });
  return { ok: true, capabilities };
}

export async function disconnectProviderForUser(userId: string, provider: ProviderName): Promise<{ ok: true }> {
  const sql = await getSql();
  await sql`delete from provider_links where user_id = ${userId} and provider = ${provider}`;
  await appendAudit({
    userId,
    actor: "user",
    action: "provider.disconnected",
    entityType: "provider",
    entityId: provider,
    detail: provider,
  });
  return { ok: true };
}

function readable(row: LinkRow | null, userId: string): row is LinkRow {
  return Boolean(row && row.user_id === userId && RETRY.has(row.status) && row.sealed);
}

export async function readHubspotForUser(userId: string): Promise<{ connected: boolean; leads: BusinessLead[]; error: string }> {
  const row = await loadLink(userId, "hubspot");
  if (!readable(row, userId)) return { connected: false, leads: [], error: "" };
  const stored = tokenKeys(row.sealed);
  if (!stored) return { connected: true, leads: [], error: "The saved CRM key could not be read. Reconnect." };
  const call = await hubspotRequest({ path: HUBSPOT_CONTACTS_PATH, token: stored.token });
  if (!call.ok) {
    await markProviderProblem(userId, "hubspot", call.status === 401 ? "authorization_required" : "connection_error", call.error);
    return { connected: true, leads: [], error: call.error };
  }
  await markChecked(userId, "hubspot");
  return { connected: true, leads: parseHubspotContacts(call.body), error: "" };
}

export async function readShopifyForUser(userId: string): Promise<{ connected: boolean; orders: BusinessOrder[]; error: string }> {
  const row = await loadLink(userId, "shopify");
  if (!readable(row, userId)) return { connected: false, orders: [], error: "" };
  const stored = tokenKeys(row.sealed);
  const shop = stored?.shop || row.account_label;
  if (!stored || !normalizeShopHost(shop)) return { connected: true, orders: [], error: "The saved store key could not be read. Reconnect." };
  const call = await shopifyRequest({ shop, path: shopifyOrdersPath(), token: stored.token });
  if (!call.ok) {
    await markProviderProblem(userId, "shopify", call.status === 401 ? "authorization_required" : "connection_error", call.error);
    return { connected: true, orders: [], error: call.error };
  }
  await markChecked(userId, "shopify");
  return { connected: true, orders: parseShopifyOrders(call.body), error: "" };
}

export async function readShopifyProductsForUser(
  userId: string,
): Promise<{ connected: boolean; products: ShopifyProduct[]; error: string }> {
  const row = await loadLink(userId, "shopify");
  if (!readable(row, userId)) return { connected: false, products: [], error: "" };
  const stored = tokenKeys(row.sealed);
  const shop = stored?.shop || row.account_label;
  if (!stored || !normalizeShopHost(shop)) return { connected: true, products: [], error: "The saved store key could not be read. Reconnect." };
  const call = await shopifyRequest({ shop, path: shopifyProductsPath(), token: stored.token });
  if (!call.ok) {
    if (call.status === 401) await markProviderProblem(userId, "shopify", "authorization_required", call.error);
    return { connected: true, products: [], error: call.error };
  }
  const products = parseShopifyProducts(call.body);
  const next = new Set(caps(row.capabilities));
  next.add("products.read");
  if (products.some((product) => product.inventory !== null)) next.add("inventory.read");
  else next.delete("inventory.read");
  await markChecked(userId, "shopify", [...next]);
  return { connected: true, products, error: "" };
}

async function storeBundle(
  userId: string,
  provider: OAuthProvider,
  token: TokenBundle,
  accountLabel: string,
  capabilities: string[],
): Promise<{ ok: true } | { ok: false; error: string }> {
  if (!canSealSecrets()) return { ok: false, error: "This keep cannot store that token safely yet. Nothing was saved." };
  const sealed = sealSecret(JSON.stringify(token));
  if (!sealed) return { ok: false, error: "This keep cannot store that token safely yet. Nothing was saved." };
  try {
    await saveLink({ userId, provider, sealed, hint: hint(token.accessToken), capabilities, accountLabel });
    return { ok: true };
  } catch {
    return { ok: false, error: "The login was accepted but could not be stored. Nothing was kept." };
  }
}

async function freshBundle(
  userId: string,
  provider: OAuthProvider,
  row: LinkRow,
): Promise<{ ok: true; token: TokenBundle } | { ok: false; error: string }> {
  const token = openBundle(row.sealed);
  if (!token) return { ok: false, error: "The saved login could not be read. Authorize again." };
  if (token.expiresAt > Date.now() + 60_000) return { ok: true, token };
  const refreshed = await refreshOAuthToken(provider, token);
  if (!refreshed.ok) {
    await markProviderProblem(
      userId,
      provider,
      refreshed.status === 401 ? "authorization_required" : "connection_error",
      refreshed.error,
    );
    return { ok: false, error: refreshed.error };
  }
  const stored = await storeBundle(userId, provider, refreshed.token, row.account_label, caps(row.capabilities));
  if (!stored.ok) return stored;
  return { ok: true, token: refreshed.token };
}

function adsNotConnected(): string {
  return "Google Ads is not connected. Spend is not being read.";
}

function booksNotConnected(): string {
  return "QuickBooks is not connected. Revenue is not being calculated.";
}

export async function oauthLinkState(userId: string, provider: OAuthProvider): Promise<OAuthLinkState> {
  const setup = provider === "google_ads" ? googleAdsSetup() : quickBooksSetup();
  const row = await loadLink(userId, provider);
  const lastCheckedAt = row ? iso(row.last_checked_at) : "";
  if (!("clientId" in setup)) {
    return { connected: false, status: "not_configured", detail: setup.detail, lastCheckedAt, available: false };
  }
  const missing = provider === "google_ads" ? adsNotConnected() : booksNotConnected();
  if (!row || !RETRY.has(row.status)) {
    return { connected: false, status: "not_connected", detail: missing, lastCheckedAt, available: true };
  }
  if (row.status === "authorization_required") {
    return {
      connected: false,
      status: "authorization_required",
      detail:
        provider === "google_ads"
          ? "Google Ads needs authorization again. Spend is not being read."
          : "QuickBooks needs authorization again. Revenue is not being calculated.",
      lastCheckedAt,
      available: true,
    };
  }
  if (row.status === "connection_error") {
    return {
      connected: false,
      status: "connection_error",
      detail: row.last_error || (provider === "google_ads" ? "Google Ads could not be read." : "QuickBooks could not be read."),
      lastCheckedAt,
      available: true,
    };
  }
  const label = row.account_label;
  return {
    connected: true,
    status: "connected",
    detail:
      provider === "google_ads"
        ? `Google Ads is connected${label ? ` (${label})` : ""}. Only campaigns it returns are used.`
        : `QuickBooks is connected${label ? ` (${label})` : ""}. Only figures it returns are used.`,
    lastCheckedAt,
    available: true,
  };
}

function unsaved(error: string): string {
  return /nothing was saved/i.test(error) ? error : `${error} Nothing was saved.`;
}

export async function startOAuthForUser(
  userId: string,
  provider: OAuthProvider,
): Promise<{ ok: true; url: string } | { ok: false; error: string }> {
  try {
    if (provider === "google_ads") {
      const setup = googleAdsSetup();
      if (!isGoogleAdsReady(setup)) return { ok: false, error: setup.detail };
      const state = sealOAuthState(userId, provider);
      if (!state) return { ok: false, error: "This keep cannot start that login safely yet. Nothing was sent." };
      return { ok: true, url: googleAdsAuthorizeUrl(setup, state) };
    }
    const setup = quickBooksSetup();
    if (!isQuickBooksReady(setup)) return { ok: false, error: setup.detail };
    const state = sealOAuthState(userId, provider);
    if (!state) return { ok: false, error: "This keep cannot start that login safely yet. Nothing was sent." };
    return { ok: true, url: quickBooksAuthorizeUrl(setup, state) };
  } catch (err) {
    const message = err instanceof Error ? err.message : "That login could not be started.";
    return { ok: false, error: message };
  }
}

export async function completeOAuthForUser(opts: {
  sessionUserId: string;
  state: string;
  code: string;
  realmId: string;
}): Promise<{ ok: true; provider: OAuthProvider } | { ok: false; error: string }> {
  const opened = openOAuthState(opts.state);
  if (!opened || opened.userId !== opts.sessionUserId) {
    return { ok: false, error: "That login did not match this session. Nothing was saved." };
  }
  if (opened.provider === "google_ads") {
    const setup = googleAdsSetup();
    if (!isGoogleAdsReady(setup)) return { ok: false, error: setup.detail };
    const exchanged = await exchangeGoogleCode(setup, opts.code);
    if (!exchanged.ok) return { ok: false, error: unsaved(exchanged.error) };
    const customers = await listGoogleAdsCustomers(setup, exchanged.token.accessToken);
    if (!customers.ok) return { ok: false, error: unsaved(customers.error) };
    const bundle: TokenBundle = { ...exchanged.token, customerIds: customers.customerIds };
    const label = customers.customerIds[0] ? `customers/${customers.customerIds[0]}` : "";
    const stored = await storeBundle(opts.sessionUserId, "google_ads", bundle, label, ["ads.read"]);
    if (!stored.ok) return stored;
    await appendAudit({
      userId: opts.sessionUserId,
      actor: "user",
      action: "provider.connected",
      entityType: "provider",
      entityId: "google_ads",
      detail: "google_ads",
    });
    return { ok: true, provider: "google_ads" };
  }
  const setup = quickBooksSetup();
  if (!isQuickBooksReady(setup)) return { ok: false, error: setup.detail };
  const exchanged = await exchangeQuickBooksCode(setup, opts.code, opts.realmId);
  if (!exchanged.ok) return { ok: false, error: unsaved(exchanged.error) };
  const company = await readQuickBooksCompany(exchanged.token);
  if (!company.ok) return { ok: false, error: unsaved(company.error) };
  const stored = await storeBundle(opts.sessionUserId, "quickbooks", exchanged.token, company.name.slice(0, 80), ["accounting.read"]);
  if (!stored.ok) return stored;
  await appendAudit({
    userId: opts.sessionUserId,
    actor: "user",
    action: "provider.connected",
    entityType: "provider",
    entityId: "quickbooks",
    detail: "quickbooks",
  });
  return { ok: true, provider: "quickbooks" };
}

export async function readAdsForUser(userId: string): Promise<{ connected: boolean; speech: string }> {
  const setup = googleAdsSetup();
  if (!isGoogleAdsReady(setup)) return { connected: false, speech: setup.detail };
  const row = await loadLink(userId, "google_ads");
  if (!readable(row, userId)) return { connected: false, speech: adsNotConnected() };
  const fresh = await freshBundle(userId, "google_ads", row);
  if (!fresh.ok) return { connected: true, speech: adsSpendSpeech([], fresh.error) };
  const listed = await listGoogleAdsCustomers(setup, fresh.token.accessToken);
  if (!listed.ok) {
    await markProviderProblem(userId, "google_ads", listed.status === 401 ? "authorization_required" : "connection_error", listed.error);
    return { connected: true, speech: adsSpendSpeech([], listed.error) };
  }
  const customerIds = listed.customerIds;
  if (customerIds.join(",") !== fresh.token.customerIds.join(",")) {
    await storeBundle(userId, "google_ads", { ...fresh.token, customerIds }, customerIds[0] ? `customers/${customerIds[0]}` : row.account_label, caps(row.capabilities));
  }
  if (customerIds.length === 0) {
    await markChecked(userId, "google_ads");
    return { connected: true, speech: "Google Ads accepted the login but returned no customer accounts. Spend is not calculated." };
  }
  const spend = await searchGoogleAdsSpend(setup, fresh.token.accessToken, customerIds[0] ?? "");
  if (!spend.ok) {
    await markProviderProblem(userId, "google_ads", spend.status === 401 ? "authorization_required" : "connection_error", spend.error);
    return { connected: true, speech: adsSpendSpeech([], spend.error) };
  }
  await markChecked(userId, "google_ads");
  const extra = customerIds.length > 1 ? ` ${customerIds.length} customer accounts were listed. Only the first was queried.` : "";
  return { connected: true, speech: `${adsSpendSpeech(spend.campaigns, "")}${extra}` };
}

export async function readBooksForUser(userId: string): Promise<{ connected: boolean; speech: string }> {
  const setup = quickBooksSetup();
  if (!isQuickBooksReady(setup)) return { connected: false, speech: setup.detail };
  const row = await loadLink(userId, "quickbooks");
  if (!readable(row, userId)) return { connected: false, speech: booksNotConnected() };
  const fresh = await freshBundle(userId, "quickbooks", row);
  if (!fresh.ok) return { connected: true, speech: booksRevenueSpeech(null, fresh.error, true) };
  const report = await readQuickBooksIncome(fresh.token);
  if (!report.ok) {
    await markProviderProblem(userId, "quickbooks", report.status === 401 ? "authorization_required" : "connection_error", report.error);
    return { connected: true, speech: booksRevenueSpeech(null, report.error, true) };
  }
  await markChecked(userId, "quickbooks");
  return { connected: true, speech: booksRevenueSpeech(report.income, "", true) };
}
