import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { inQuietHours } from "./pulse-format.ts";

describe("quiet hours", () => {
  it("handles overnight windows and equal start/end as off", () => {
    assert.equal(inQuietHours(23, 22, 7), true);
    assert.equal(inQuietHours(3, 22, 7), true);
    assert.equal(inQuietHours(10, 22, 7), false);
    assert.equal(inQuietHours(13, 12, 14), true);
    assert.equal(inQuietHours(12, 12, 12), false);
    assert.equal(inQuietHours(8, null, 22), false);
  });
});
