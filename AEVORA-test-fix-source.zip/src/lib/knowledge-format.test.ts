import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { decideKnowledge } from "./knowledge-format.ts";
import { classifyTurnIntent, intentWantsSearch, intentWantsResearch } from "./intent-format.ts";

describe("knowledge decision", () => {
  it("does not hard-code product names and still searches unknown entities", () => {
    assert.equal(decideKnowledge("What is Dola?").action, "search");
    assert.equal(decideKnowledge("what is dola").action, "search");
    assert.equal(decideKnowledge("Tell me about Perplexity").action, "search");
    assert.equal(decideKnowledge("Find out what Dola is.").action, "search");
    assert.equal(classifyTurnIntent("What is Dola?").kind, "search");
    assert.equal(intentWantsSearch(classifyTurnIntent("What is Dola?")), true);
  });

  it("keeps school topics and math on the model/fast path", () => {
    assert.equal(decideKnowledge("What is photosynthesis?").action, "answer");
    assert.equal(classifyTurnIntent("What is photosynthesis?").kind, "question");
    assert.equal(decideKnowledge("What is 17 times 24?").action, "calculate");
    assert.equal(intentWantsSearch(classifyTurnIntent("What is 17 times 24?")), false);
  });

  it("researches comparisons and searches current versions", () => {
    assert.equal(decideKnowledge("Compare Dola and ChatGPT.").action, "research");
    assert.equal(classifyTurnIntent("Compare Dola and ChatGPT.").kind, "research");
    assert.equal(intentWantsResearch(classifyTurnIntent("Compare Dola and ChatGPT.")), true);
    assert.equal(decideKnowledge("What is Dola?").action, "search");
    assert.equal(decideKnowledge("What is Claude?").action, "search");
    assert.equal(decideKnowledge("What is Gemini?").action, "search");
    assert.equal(decideKnowledge("What is Perplexity?").action, "search");
    assert.equal(decideKnowledge("What is Grok?").action, "search");
    assert.equal(decideKnowledge("What is Cursor?").action, "search");
    assert.equal(decideKnowledge("What is OpenAI?").action, "search");
    assert.equal(decideKnowledge("What is xAI?").action, "search");
    assert.equal(decideKnowledge("What is Nvidia?").action, "search");
    assert.equal(decideKnowledge("What is AMD?").action, "search");
    assert.equal(decideKnowledge("What is the latest version of Next.js?").action, "search");
    assert.equal(classifyTurnIntent("What is the latest version of Next.js?").kind, "search");
  });
});