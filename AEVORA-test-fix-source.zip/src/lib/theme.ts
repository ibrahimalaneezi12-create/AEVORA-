import type { ProfileTheme } from "@/lib/profile";

let media: MediaQueryList | null = null;
let onMedia: (() => void) | null = null;

function setThemeAttr(value: "light" | "dark") {
  if (typeof document === "undefined") return;
  document.documentElement.dataset.theme = value;
}

export function applyTheme(theme: ProfileTheme) {
  if (typeof window === "undefined") return;
  if (media && onMedia) {
    media.removeEventListener("change", onMedia);
    media = null;
    onMedia = null;
  }
  if (theme === "system") {
    media = window.matchMedia("(prefers-color-scheme: dark)");
    onMedia = () => setThemeAttr(media!.matches ? "dark" : "light");
    onMedia();
    media.addEventListener("change", onMedia);
    return;
  }
  setThemeAttr(theme);
}
