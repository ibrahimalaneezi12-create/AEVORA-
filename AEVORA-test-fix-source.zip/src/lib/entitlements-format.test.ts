import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  asEntitlementPlan,
  businessMonitorDecision,
  contextTierNote,
  investOperatorDecision,
  investWorkspaceLine,
  planAllowsFeature,
  planDisplayName,
  planHasFullAccess,
  planPriceLabel,
} from "./entitlements-format.ts";

describe("entitlement plans", () => {
  it("treats founder as full access at £0 without making it a security bypass flag", () => {
    assert.equal(asEntitlementPlan("founder"), "founder");
    assert.equal(planHasFullAccess("founder"), true);
    assert.equal(planPriceLabel("founder"), "£0");
    assert.equal(planDisplayName("founder"), "Founder");
    assert.equal(planAllowsFeature("founder", "search"), true);
    assert.equal(planAllowsFeature("founder", "email"), true);
  });

  it("keeps free on the keep and not on billed features", () => {
    assert.equal(planHasFullAccess("free"), false);
    assert.equal(planAllowsFeature("free", "chat"), true);
    assert.equal(planAllowsFeature("free", "memory"), true);
    assert.equal(planAllowsFeature("free", "search"), false);
    assert.equal(planAllowsFeature("free", "email"), false);
  });

  it("keeps Plus between Free and Pro without enabling execution", () => {
    assert.equal(planHasFullAccess("plus"), false);
    assert.equal(planAllowsFeature("plus", "search"), true);
    assert.equal(planAllowsFeature("plus", "businessBasic"), true);
    assert.equal(planAllowsFeature("plus", "businessManager"), false);
    assert.equal(planAllowsFeature("pro", "businessManager"), true);
    assert.equal(planAllowsFeature("plus", "investCopilot"), true);
    assert.equal(planAllowsFeature("plus", "investOperator"), false);
    assert.equal(planAllowsFeature("free", "search"), false);
    assert.equal(planAllowsFeature("free", "businessManager"), false);
    assert.equal(planDisplayName("plus"), "Plus");
    assert.equal(asEntitlementPlan("plus"), "plus");
  });

  it("does not invent a plan from junk input", () => {
    assert.equal(asEntitlementPlan("admin"), "free");
    assert.equal(asEntitlementPlan(""), "free");
  });

  it("keeps the manager and the operator honest", () => {
    assert.equal(businessMonitorDecision("free").deeper, false);
    assert.equal(businessMonitorDecision("free").monitoring, false);
    assert.equal(businessMonitorDecision("pro").deeper, true);
    assert.equal(businessMonitorDecision("pro").monitoring, false);
    assert.equal(businessMonitorDecision("pro").systemsConnected, false);
    assert.match(businessMonitorDecision("pro").reason, /background monitoring is not connected/i);
    assert.equal(investOperatorDecision("pro").canExecute, false);
    assert.match(contextTierNote("free", "invest"), /do not invent prices/i);
    assert.match(contextTierNote("plus", "invest"), /not an order/i);
    assert.match(contextTierNote("pro", "business"), /omit empty/i);
    assert.match(investWorkspaceLine("free"), /live market lookup is not included/i);
    assert.match(investWorkspaceLine("pro"), /approve the order/i);
  });
});
