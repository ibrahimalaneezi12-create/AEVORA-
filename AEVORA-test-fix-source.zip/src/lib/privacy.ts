/**
 * Private-by-default HTTP and ownership helpers.
 * Identity always comes from the authenticated session — never a client id.
 */

export const PRIVATE_HTTP_HEADERS = {
  "Cache-Control": "private, no-store, no-cache, must-revalidate",
  Pragma: "no-cache",
  Vary: "Cookie, Authorization",
} as const;

export const GENERIC_NOT_FOUND = "Not found.";

export function sessionOwns(sessionUserId: string, resourceUserId: string | null | undefined): boolean {
  if (!sessionUserId || !resourceUserId) return false;
  return sessionUserId === resourceUserId;
}

export function founderDoesNotBypassOwnership(opts: {
  sessionUserId: string;
  resourceUserId: string;
  isFounder: boolean;
}): boolean {
  if (opts.isFounder && opts.sessionUserId !== opts.resourceUserId) return false;
  return sessionOwns(opts.sessionUserId, opts.resourceUserId);
}

export function clientUserIdMustBeIgnored(
  sessionUserId: string,
  claimedUserId: string | null | undefined,
): string {
  void claimedUserId;
  return sessionUserId;
}
