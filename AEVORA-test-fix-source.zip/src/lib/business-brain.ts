/**
 * Business reasoning over records the user saved and connectors that actually
 * responded. Never invents revenue, customers, or a cause.
 */
import type { Business, BusinessNote } from "./business-format.ts";

export type SourceState = {
  id: string;
  label: string;
  category: string;
  connected: boolean;
  detail: string;
};

export type BusinessInvestigation = {
  facts: string[];
  hypotheses: string[];
  missing: string[];
  speech: string;
};

const MONEY_ASK = /\b(revenue|sales|profit|expense|expenses|cash|margin|cost|pipeline|customers?|conversion|ads?|campaign)\b/i;

export function missingBusinessSources(sources: SourceState[], question = ""): string[] {
  const missing: string[] = [];
  const accounting = sources.some((s) => s.category === "Finance" && s.connected);
  const sales = sources.some((s) => s.category === "Sales" && s.connected);
  if ((MONEY_ASK.test(question) || !question) && !accounting && !sales) {
    missing.push(
      "No accounting or sales source is connected, so revenue, expenses, and conversion cannot be calculated.",
    );
  }
  return missing;
}

export function investigateBusiness(
  question: string,
  notes: BusinessNote[],
  sources: SourceState[],
): BusinessInvestigation {
  const facts = notes.slice(0, 6).map((n) => `${n.kind}: ${n.title}`);
  const missing = missingBusinessSources(sources, question);
  const hypotheses: string[] = [];
  const connected = sources.filter((source) => source.connected).map((source) => source.label);
  const speech = [
    "Detective pass. This is not a background alert.",
    facts.length ? `What is on file: ${facts.join("; ")}.` : "Nothing about this is saved in the keep.",
    connected.length ? `Sources that answered: ${connected.join(", ")}.` : "No sales or accounting source answered.",
    missing.join(" "),
    "I will not name a cause, and I will not treat a guess as the cause. Correlation is not causation.",
    "On-file notes are records, not confirmed explanations.",
    "Next check: connect the source that holds this metric, or give me the figure. I will not fill it in.",
  ]
    .filter(Boolean)
    .join(" ");
  return { facts, hypotheses, missing, speech };
}

export type Opportunity = {
  what: string;
  why: string;
  evidence: string;
  impact: string;
  risks: string;
  next: string;
};

export function opportunitiesFromRecords(notes: BusinessNote[], sources: SourceState[]): {
  items: Opportunity[];
  speech: string;
} {
  const items: Opportunity[] = notes
    .filter((n) => n.kind === "opportunity")
    .slice(0, 4)
    .map((n) => ({
      what: n.title,
      why: n.body || "Saved as an opportunity. No extra reason was recorded.",
      evidence: `Saved note #${n.id}.`,
      impact: "Not estimated. No connected sales source supplied a figure.",
      risks: "Not recorded.",
      next: "Ask before acting on it.",
    }));
  if (items.length === 0) {
    const gap = missingBusinessSources(sources, "sales");
    return {
      items: [],
      speech: gap[0] ?? "No opportunity is saved, and nothing connected produced one.",
    };
  }
  return {
    items,
    speech: items
      .map(
        (item) =>
          `${item.what}. Why: ${item.why} Evidence: ${item.evidence} Impact: ${item.impact} Effort: not recorded. Risk: ${item.risks} Next: ${item.next}`,
      )
      .join(" "),
  };
}

export function businessHealthSpeech(opts: {
  businesses: Business[];
  notes: BusinessNote[];
  sources: SourceState[];
}): string {
  const missing = missingBusinessSources(opts.sources, "revenue");
  if (opts.businesses.length === 0 && opts.notes.length === 0) {
    return "I don't have a business on file yet, and no sales or accounting source is connected. I can't say how the business is doing.";
  }
  const name = opts.businesses[0]?.name;
  const risks = opts.notes.filter((n) => n.kind === "risk").map((n) => n.title);
  const decisions = opts.notes.filter((n) => n.kind === "decision").map((n) => n.title);
  return [
    name ? `${name} is the business on file.` : "A business identity is not saved.",
    risks.length ? `Needs attention: ${risks.join("; ")}.` : "",
    decisions.length ? `Decisions on file: ${decisions.join("; ")}.` : "",
    missing[0] ?? "",
    "AEVORA is not watching this in the background.",
  ]
    .filter(Boolean)
    .join(" ");
}

export function attentionSpeech(opts: {
  notes: BusinessNote[];
  sources: SourceState[];
}): string {
  const risks = opts.notes.filter((n) => n.kind === "risk").map((n) => n.title);
  const missing = missingBusinessSources(opts.sources, "sales");
  if (risks.length === 0) {
    return [
      "Nothing on file is marked as needing attention.",
      missing[0] ?? "",
      "This is not a live alert. AEVORA is not watching in the background.",
    ]
      .filter(Boolean)
      .join(" ");
  }
  return [
    `Saved risks: ${risks.join("; ")}.`,
    missing[0] ?? "",
    "These are notes you saved, not a confirmed live alert.",
  ]
    .filter(Boolean)
    .join(" ");
}

export function businessBriefSpeech(
  kind: "morning" | "evening",
  opts: {
    businesses: Business[];
    notes: BusinessNote[];
    sources: SourceState[];
  },
): string {
  const label = kind === "morning" ? "Morning brief" : "End of day";
  const missing = missingBusinessSources(opts.sources, "revenue");
  const risks = opts.notes.filter((n) => n.kind === "risk").map((n) => n.title);
  const decisions = opts.notes.filter((n) => n.kind === "decision").map((n) => n.title);
  const opportunities = opts.notes.filter((n) => n.kind === "opportunity").map((n) => n.title);
  return [
    `${label}, from what is saved. This was not produced by a background job.`,
    opts.businesses[0]?.name ? `Business on file: ${opts.businesses[0].name}.` : "No business identity is saved.",
    risks.length ? `Risks on file: ${risks.join("; ")}.` : "No risk is saved.",
    decisions.length ? `Decisions on file: ${decisions.join("; ")}.` : "",
    opportunities.length ? `Opportunities on file: ${opportunities.join("; ")}.` : "",
    missing[0] ?? "No sales or accounting figure was returned.",
    "I will not fill in sales, expenses, or customers.",
  ]
    .filter(Boolean)
    .join(" ");
}

export function weeklyReviewSpeech(opts: {
  businesses: Business[];
  notes: BusinessNote[];
  sources: SourceState[];
}): string {
  const brief = businessBriefSpeech("evening", opts);
  return `Weekly review, assembled now from saved records. It is not a calculated report and it was not running in the background. ${brief}`;
}

export type BusinessDepartment = "sales" | "marketing" | "customers" | "operations" | "finance" | "strategy";

export function departmentFromQuery(query: string): BusinessDepartment | null {
  if (/\b(finance|profit|expenses?|cash|margin|accounting)\b/i.test(query)) return "finance";
  if (/\b(marketing|advertis|ad spend|campaigns?)\b/i.test(query)) return "marketing";
  if (/\b(operations|inventory|fulfillment)\b/i.test(query)) return "operations";
  if (/\b(customers?|clients?)\b/i.test(query)) return "customers";
  if (/\b(sales|pipeline|conversion)\b/i.test(query)) return "sales";
  if (/\b(strategy|positioning|priorit(?:y|ies))\b/i.test(query)) return "strategy";
  return null;
}

function connectedLabels(sources: SourceState[], category: string): string[] {
  return sources.filter((source) => source.category === category && source.connected).map((source) => source.label);
}

/** Department answer from connection state and saved notes. Never estimates a metric. */
export function departmentSpeech(
  department: BusinessDepartment,
  notes: BusinessNote[],
  sources: SourceState[],
): string {
  if (department === "sales") {
    const sales = connectedLabels(sources, "Sales");
    if (sales.length === 0) {
      return "Sales is not connected. Pipeline, conversion, and revenue were not read. I will not estimate them.";
    }
    return `Sales sources that answered: ${sales.join(", ")}. Quote only what they returned this turn. A partial list is not a total.`;
  }
  if (department === "marketing") {
    const ads = connectedLabels(sources, "Marketing");
    if (ads.length === 0) {
      return "No advertising source is connected. Spend, clicks, and campaign results were not read. I will not estimate them.";
    }
    return `Advertising sources that answered: ${ads.join(", ")}. Quote only what they returned. Do not invent spend.`;
  }
  if (department === "finance") {
    const books = connectedLabels(sources, "Finance");
    if (books.length === 0) {
      return "No accounting source is connected. Profit, expenses, cash, and margin were not calculated.";
    }
    return `Accounting sources that answered: ${books.join(", ")}. Use only figures they returned. Do not estimate the rest.`;
  }
  if (department === "customers") {
    const crm = sources.find((source) => source.id === "crm" && source.connected);
    const saved = notes.filter((note) => note.kind === "customer").map((note) => note.title);
    if (!crm) {
      return [
        "No CRM is connected, so customer counts were not read.",
        saved.length
          ? `Customers you wrote down: ${saved.join("; ")}. That is not a count of all customers.`
          : "No customer note is saved.",
      ].join(" ");
    }
    return `CRM connected: ${crm.label}. Use only contacts returned this turn. Do not invent a total.`;
  }
  if (department === "strategy") {
    const saved = notes
      .filter((note) => note.kind === "decision" || note.kind === "opportunity")
      .map((note) => note.title);
    if (saved.length === 0) {
      return "No strategy is saved. I will not invent a plan, a goal, or a result.";
    }
    return `Strategy on file: ${saved.join("; ")}. These are notes you saved, not a measured plan. I will not invent a result.`;
  }
  const ops = sources.filter((source) => (source.id === "calendar" || source.id === "inventory") && source.connected);
  const process = notes.filter((note) => note.kind === "process").map((note) => note.title);
  if (ops.length === 0 && process.length === 0) {
    return "No operations source is connected, and no process is saved. I will not invent capacity or inventory.";
  }
  return [
    ops.length ? `Operations sources that answered: ${ops.map((source) => source.label).join(", ")}.` : "No operations source answered.",
    process.length ? `Processes you saved: ${process.join("; ")}.` : "",
    "I will not invent capacity or a stock count.",
  ]
    .filter(Boolean)
    .join(" ");
}

export function competitorSpeech(notes: BusinessNote[]): string {
  const saved = notes.filter((note) => note.kind === "competitor");
  if (saved.length === 0) {
    return "No competitor note is saved. Use only public sources retrieved this turn. I will not invent market share, their pricing, or their revenue.";
  }
  return `Competitor notes you saved: ${saved
    .slice(0, 4)
    .map((note) => note.title)
    .join("; ")}. Anything else has to come from sources retrieved this turn. I will not invent market share or their revenue.`;
}

/**
 * Executive brief. A section is omitted unless a record or a real gap supports it.
 * Never invents revenue, customers, or a cause.
 */
export function executiveBriefSpeech(opts: {
  businesses: Business[];
  notes: BusinessNote[];
  sources: SourceState[];
  pendingTitles?: string[];
  executedTitles?: string[];
}): string {
  const missing = missingBusinessSources(opts.sources, "revenue");
  const opportunities = opts.notes.filter((note) => note.kind === "opportunity").map((note) => note.title);
  const risks = opts.notes.filter((note) => note.kind === "risk").map((note) => note.title);
  const decisions = opts.notes.filter((note) => note.kind === "decision").map((note) => note.title);
  const executed = (opts.executedTitles ?? []).filter(Boolean);
  const pending = (opts.pendingTitles ?? []).filter(Boolean);
  if (
    opts.businesses.length === 0 &&
    opts.notes.length === 0 &&
    executed.length === 0 &&
    pending.length === 0
  ) {
    return "I don't have a business on file, and no sales or accounting source is connected. I can't say how the business is doing. I will not invent numbers.";
  }
  const name = opts.businesses[0]?.name;
  const lines = ["Business brief from records this turn. Not a background report."];
  lines.push(
    name
      ? `Health: ${name} is the business on file. ${missing[0] ?? "No sales or accounting figure beyond saved notes was returned."}`
      : `Health: a business identity is not saved. ${missing[0] ?? ""}`.trim(),
  );
  if (opportunities.length) {
    lines.push(`Going well, from notes you saved: ${opportunities.join("; ")}. These are not measured results.`);
    lines.push(`Opportunities: ${opportunities.join("; ")}. Impact: not estimated. Effort: not recorded.`);
  }
  if (risks.length) {
    lines.push(`Needs attention: ${risks.join("; ")}. Saved by you, not a live alert.`);
    lines.push(`Risks on file: ${risks.join("; ")}. No cause is confirmed.`);
  }
  if (decisions.length) lines.push(`Decisions on file: ${decisions.join("; ")}.`);
  if (executed.length) lines.push(`Work that actually happened: ${executed.join("; ")}.`);
  if (pending.length) lines.push(`Decisions needed: ${pending.join("; ")}. Nothing is saved until you approve.`);
  const next = pending[0]
    ? `Next: review “${pending[0]}” before anything else is saved.`
    : missing[0]
      ? "Next: connect the source that holds the metric, or tell me the figure. I will not fill it in."
      : "Next: say which part you want looked at.";
  lines.push(next);
  lines.push("I will not fill in sales, expenses, or customers.");
  return lines.filter(Boolean).join(" ");
}
