export const MEMORY_KINDS = [
  "fact",
  "preference",
  "person",
  "project",
  "decision",
] as const;
export type MemoryKind = (typeof MEMORY_KINDS)[number];

export const MEMORY_TITLE_MAX = 80;
export const MEMORY_BODY_MAX = 4000;
export const MEMORY_TAGS_MAX = 200;
export const MEMORY_LIST_LIMIT = 100;
export const MEMORY_RETRIEVE_LIMIT = 8;
export const MEMORY_CANDIDATE_LIMIT = 32;
export const MEMORY_CONTEXT_CHAR_BUDGET = 2400;

export type Memory = {
  id: number;
  kind: MemoryKind;
  title: string;
  body: string;
  tags: string;
  source: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
};

export type MemoryRow = {
  id: unknown;
  kind: string;
  title: string;
  body: string;
  tags: string;
  source: string;
  pinned: boolean;
  created_at: unknown;
  updated_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

function asKind(value: string): MemoryKind {
  return (MEMORY_KINDS as readonly string[]).includes(value)
    ? (value as MemoryKind)
    : "fact";
}

export function mapMemory(row: MemoryRow): Memory | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  return {
    id,
    kind: asKind(row.kind),
    title: row.title,
    body: row.body,
    tags: row.tags ?? "",
    source: row.source || "user",
    pinned: Boolean(row.pinned),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

/** Strip ILIKE wildcards so user text cannot broaden a search. */
export function sanitizeIlike(value: string): string {
  return value
    .replace(/[%_\\]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 80);
}

export function clipText(text: string, max: number): string {
  const t = text.replace(/\s+/g, " ").trim();
  if (t.length <= max) return t;
  return `${t.slice(0, Math.max(1, max - 1)).trimEnd()}…`;
}

const STOP = new Set([
  "the",
  "a",
  "an",
  "and",
  "or",
  "to",
  "of",
  "in",
  "on",
  "for",
  "my",
  "i",
  "me",
  "that",
  "this",
  "it",
  "is",
  "are",
  "was",
  "be",
  "at",
  "do",
  "what",
  "about",
  "remember",
  "forget",
  "please",
  "can",
  "you",
  "your",
  "we",
  "with",
  "from",
  "as",
  "if",
  "not",
  "no",
  "yes",
  "ok",
  "just",
  "have",
  "has",
  "will",
  "would",
  "should",
  "could",
  "did",
  "does",
  "how",
  "when",
  "where",
  "who",
  "which",
  "them",
  "they",
  "he",
  "she",
  "his",
  "her",
  "our",
  "so",
  "but",
  "than",
  "then",
  "too",
  "very",
  "remind",
  "make",
  "change",
  "actually",
  "prefer",
  "preferred",
  "like",
  "likes",
  "should",
  "tonight",
  "today",
  "work",
  "في",
  "من",
  "على",
  "أن",
  "انا",
  "أنا",
  "أنني",
  "هذا",
  "هذه",
  "ذلك",
  "إلى",
  "عن",
  "ما",
  "هل",
  "و",
  "يا",
]);

export function tokenize(text: string): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  const matches = text.toLowerCase().match(/[\p{L}\p{N}]{2,}/gu) ?? [];
  for (const raw of matches) {
    if (STOP.has(raw)) continue;
    if (seen.has(raw)) continue;
    seen.add(raw);
    out.push(raw);
  }
  return out;
}

export function tokensRelated(a: string, b: string): boolean {
  if (a === b) return true;
  if (a.length >= 4 && b.length >= 4 && (a.startsWith(b) || b.startsWith(a))) return true;
  return false;
}

function kindWeight(kind: MemoryKind): number {
  if (kind === "preference") return 8;
  if (kind === "decision") return 6;
  if (kind === "fact") return 5;
  if (kind === "project") return 4;
  return 3;
}

function fieldHits(fieldTokens: string[], queryTokens: string[]): number {
  let n = 0;
  for (const t of queryTokens) {
    if (fieldTokens.some((x) => tokensRelated(x, t))) n += 1;
  }
  return n;
}

export function scoreMemory(row: Memory, query: string): number {
  const tokens = tokenize(query);
  let score = row.pinned ? 12 : 0;
  score += kindWeight(row.kind);
  if (tokens.length === 0) return score;
  const titleHits = fieldHits(tokenize(row.title), tokens);
  const tagHits = fieldHits(tokenize(row.tags), tokens);
  const bodyHits = fieldHits(tokenize(row.body), tokens);
  const hits = titleHits + tagHits + bodyHits;
  if (hits === 0 && !row.pinned) return 0;
  score += titleHits * 6 + tagHits * 5 + bodyHits * 3 + hits * 2;
  return score;
}

export function rankMemories(
  rows: Memory[],
  query: string,
  limit = MEMORY_RETRIEVE_LIMIT,
): Memory[] {
  const tokens = tokenize(query);
  const scored = rows.map((row) => ({ row, score: scoreMemory(row, query) }));
  const kept = tokens.length
    ? scored.filter((s) => {
        if (s.row.pinned) return true;
        if (s.score <= 0) return false;
        const hay = tokenize(`${s.row.title} ${s.row.body} ${s.row.tags}`);
        return tokens.some((t) => hay.some((x) => tokensRelated(x, t)));
      })
    : scored;
  kept.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if (a.row.pinned !== b.row.pinned) return a.row.pinned ? -1 : 1;
    return b.row.updatedAt.localeCompare(a.row.updatedAt);
  });
  return kept.slice(0, limit).map((s) => s.row);
}

export function findConflictingPreference(
  existing: Memory[],
  incoming: { title: string; body: string },
): Memory | null {
  const title = incoming.title.trim().toLowerCase();
  const incomingTokens = tokenize(`${incoming.title} ${incoming.body}`);
  let best: { row: Memory; overlap: number } | null = null;
  for (const row of existing) {
    if (row.kind !== "preference") continue;
    if (title && row.title.trim().toLowerCase() === title) return row;
    const rowTokens = tokenize(`${row.title} ${row.body}`);
    let overlap = 0;
    for (const t of incomingTokens) {
      if (rowTokens.some((x) => tokensRelated(x, t))) overlap += 1;
    }
    const denom = Math.min(incomingTokens.length, rowTokens.length) || 1;
    const ratio = overlap / denom;
    if (overlap >= 2 && ratio >= 0.34) {
      if (!best || overlap > best.overlap) best = { row, overlap };
    }
  }
  return best?.row ?? null;
}

/**
 * Compact block for the model prompt. Includes ids so the model can propose
 * an update or delete. Caps total characters.
 */
export function formatMemoryBlock(rows: Memory[]): string {
  if (rows.length === 0) return "";
  const lines: string[] = [];
  let used = 0;
  for (const row of rows) {
    const pin = row.pinned ? " pinned" : "";
    const tags = row.tags.trim() ? ` [${clipText(row.tags, 40)}]` : "";
    const line = `- (#${row.id}${pin} ${row.kind}) ${clipText(row.title, 80)}: ${clipText(row.body, 280)}${tags}`;
    if (used + line.length + 1 > MEMORY_CONTEXT_CHAR_BUDGET) break;
    lines.push(line);
    used += line.length + 1;
  }
  return lines.join("\n");
}
