import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  buildSystemPrompt,
  capHistory,
  CHAT_COMPLETION_MODEL,
  completeTurn,
  parseSseDelta,
  SEARCH_COMPLETION_MODEL,
  selectRelevantHistory,
} from "./complete.server.ts";

describe("buildSystemPrompt", () => {
  it("omits the memory block when nothing was retrieved", () => {
    const prompt = buildSystemPrompt("");
    assert.equal(prompt.includes("<user-memory>"), false);
    assert.equal(prompt.includes("<assembled-context>"), false);
    assert.match(prompt, /private personal steward/);
    assert.match(prompt, /Reply in the user's current language/);
    assert.match(prompt, /Do not silent-save/);
    assert.match(prompt, /Never use profanity/);
    assert.match(prompt, /reminder.create/);
    assert.match(prompt, /business.save/);
    assert.match(prompt, /invest.watch/);
    assert.match(prompt, /No guaranteed returns/);
    assert.equal(prompt.includes("permission.update"), true);
    assert.match(prompt, /invest.trade/);
  });

  it("appends retrieved memories without claiming they were just saved", () => {
    const prompt = buildSystemPrompt(
      "- (#1 pinned preference) Tea preference: I drink black tea every morning.",
    );
    assert.match(prompt, /<assembled-context>/);
    assert.match(prompt, /black tea every morning/);
    assert.match(prompt, /persist across conversations/);
    assert.match(prompt, /Do not claim you saved a new memory/);
  });

  it("asks for Arabic replies when locale is ar", () => {
    const prompt = buildSystemPrompt("", "ar");
    assert.match(prompt, /preferred language is Arabic/);
    assert.equal(prompt.includes("<assembled-context>"), false);
  });

  it("asks for Spanish replies when locale is es", () => {
    const prompt = buildSystemPrompt("", "es");
    assert.match(prompt, /preferred language is Spanish/);
  });

  it("includes an intent note when provided", () => {
    const prompt = buildSystemPrompt("", "en", "Turn intent: conversation. Do not propose tools.");
    assert.match(prompt, /Turn intent: conversation/);
  });
});

describe("capHistory", () => {
  it("always keeps the newest message", () => {
    const kept = capHistory(
      [
        { role: "user", content: "a".repeat(20000) },
        { role: "assistant", content: "ok" },
        { role: "user", content: "latest" },
      ],
      10,
    );
    assert.equal(kept.at(-1)?.content, "latest");
    assert.ok(kept.length >= 1);
  });
});

describe("selectRelevantHistory", () => {
  it("keeps recent turns and older turns that mention the query", () => {
    const kept = selectRelevantHistory(
      [
        { role: "user", content: "We decided on the teal poster." },
        { role: "assistant", content: "Noted." },
        { role: "user", content: "Unrelated weather chat." },
        { role: "assistant", content: "ok" },
        { role: "user", content: "a" },
        { role: "assistant", content: "b" },
        { role: "user", content: "c" },
        { role: "assistant", content: "d" },
        { role: "user", content: "e" },
        { role: "assistant", content: "f" },
        { role: "user", content: "g" },
        { role: "assistant", content: "h" },
        { role: "user", content: "What did we decide about the poster?" },
      ],
      "What did we decide about the poster?",
    );
    assert.equal(kept.some((m) => m.content.includes("teal poster")), true);
    assert.equal(kept.at(-1)?.content.includes("poster"), true);
  });
});

describe("parseSseDelta", () => {
  it("reads streamed content and ignores done", () => {
    assert.equal(parseSseDelta('{"choices":[{"delta":{"content":"Hi"}}]}'), "Hi");
    assert.equal(parseSseDelta("[DONE]"), "");
    assert.equal(parseSseDelta("not-json"), "");
  });
});

describe("completeTurn without a key", () => {
  it("does not invent a reply when XAI_API_KEY is missing", async () => {
    const prev = process.env.XAI_API_KEY;
    delete process.env.XAI_API_KEY;
    try {
      const result = await completeTurn([{ role: "user", content: "Hello" }]);
      assert.equal(result.ok, false);
      if (result.ok) throw new Error("expected failure");
      assert.equal(result.unavailable, true);
      assert.match(result.error, /not connected/i);
      assert.doesNotMatch(result.error, /\b401\b|\b403\b|stack/i);
    } finally {
      if (prev === undefined) delete process.env.XAI_API_KEY;
      else process.env.XAI_API_KEY = prev;
    }
  });
});

describe("completion models", () => {
  it("uses the documented grok-4.5 model for chat and search", () => {
    assert.equal(CHAT_COMPLETION_MODEL, "grok-4.5");
    assert.equal(SEARCH_COMPLETION_MODEL, "grok-4.5");
  });
});
