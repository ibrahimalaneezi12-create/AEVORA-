/**
 * AEVORA intelligence router.
 *
 * One brain: the same system prompt, memory, tools, and permissions.
 * The router only chooses how hard this turn should think, then which
 * documented chat model to try. Users never pick a model.
 *
 * grok-4-fast / grok-4-fast-reasoning were retired from the xAI API on
 * 15 May 2026. Do not request them. Primary is grok-4.5 with documented
 * fallbacks grok-4 then grok-3. An env override may point at another
 * slug the production key actually has.
 */

export const INTELLIGENCE_LANES = ["fast", "deep"] as const;
export type IntelligenceLane = (typeof INTELLIGENCE_LANES)[number];

const DEEP_RE =
  /\b(compare|analy[sz]e|research|investigate|why does|explain in detail|help me (?:start|launch|build|fix|solve)|debug|implement|refactor|investment|thesis|what am i forgetting|what needs my (?:decision|attention)|what should i do now|check my business|plan my (?:week|month|quarter)|complex|step by step|trade[- ]?off|study plan|itinerary|competitor|watchlist|phishing|scam)\b/i;

const SIMPLE_RE =
  /^(?:hi|hello|hey(?: aegis)?|thanks|thank you|ok|okay|yes|no|good morning|good night)[.!?]?$/i;

export function classifyIntelligenceLane(
  query: string,
  extra?: { research?: boolean; searchMode?: "off" | "auto" | "on"; intentNote?: string },
): IntelligenceLane {
  if (extra?.research === true) return "deep";
  const text = query.trim();
  if (!text) return "fast";
  if (SIMPLE_RE.test(text)) return "fast";
  if (text.length > 480) return "deep";
  if (DEEP_RE.test(text)) return "deep";
  const note = extra?.intentNote?.toLowerCase() ?? "";
  if (/\bresearch\b|\breasoning\b|\bplanning\b|\bbusiness\b|\binvest\b|\bsafety\b/.test(note)) {
    return "deep";
  }
  if (extra?.searchMode === "on") return "deep";
  return "fast";
}

export function shouldEscalateToDeep(lane: IntelligenceLane, reply: string): boolean {
  if (lane === "deep") return false;
  const text = reply.trim();
  if (!text) return true;
  if (text.length < 24 && /\b(i don't know|i cannot|i can't|not sure)\b/i.test(text)) return true;
  return false;
}

export function maxTokensForLane(lane: IntelligenceLane, research = false): number {
  if (research) return 2000;
  return lane === "deep" ? 1400 : 800;
}

export function temperatureForLane(lane: IntelligenceLane, research = false): number {
  if (research) return 0.4;
  return lane === "deep" ? 0.55 : 0.5;
}