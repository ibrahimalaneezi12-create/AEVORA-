import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  classifyIntelligenceLane,
  maxTokensForLane,
  shouldEscalateToDeep,
  temperatureForLane,
} from "./router.ts";

describe("intelligence router", () => {
  it("sends greetings and simple questions to fast", () => {
    assert.equal(classifyIntelligenceLane("Hello"), "fast");
    assert.equal(classifyIntelligenceLane("What is photosynthesis?"), "fast");
    assert.equal(classifyIntelligenceLane("thanks"), "fast");
  });

  it("sends comparison, research, and planning to deep", () => {
    assert.equal(classifyIntelligenceLane("Compare Dola and GPT."), "deep");
    assert.equal(classifyIntelligenceLane("Help me plan my week."), "deep");
    assert.equal(classifyIntelligenceLane("Analyze this investment."), "deep");
    assert.equal(classifyIntelligenceLane("Help me start a business."), "deep");
    assert.equal(classifyIntelligenceLane("What am I forgetting?"), "deep");
    assert.equal(classifyIntelligenceLane("what am i forgetting this week"), "deep");
    assert.equal(classifyIntelligenceLane("Is this email phishing?"), "deep");
  });

  it("treats research extra as deep regardless of wording", () => {
    assert.equal(classifyIntelligenceLane("Hello", { research: true }), "deep");
    assert.equal(classifyIntelligenceLane("Look this up", { searchMode: "on" }), "deep");
  });

  it("escalates empty or helpless fast replies", () => {
    assert.equal(shouldEscalateToDeep("fast", ""), true);
    assert.equal(shouldEscalateToDeep("fast", "I don't know."), true);
    assert.equal(shouldEscalateToDeep("fast", "Aegis can help you plan that."), false);
    assert.equal(shouldEscalateToDeep("deep", ""), false);
  });

  it("caps tokens lower on the fast lane", () => {
    assert.equal(maxTokensForLane("fast"), 800);
    assert.equal(maxTokensForLane("deep"), 1400);
    assert.equal(maxTokensForLane("fast", true), 2000);
    assert.ok(temperatureForLane("deep") > 0);
  });
});
