/**
 * Server-only xAI credential read.
 *
 * Vite can statically replace `process.env.XAI_API_KEY` with `undefined` at
 * transform time if the var is unset during bundling. Bracket access keeps
 * the lookup dynamic so a key injected at process start (preview or deploy)
 * is actually seen.
 *
 * Never log the value. Never send it to the client.
 */

import type { IntelligenceLane } from "./router.ts";

export function readXaiApiKey(): string | null {
  const env = typeof process === "undefined" ? undefined : process.env;
  const raw = env ? env["XAI_API_KEY"] : undefined;
  const key = typeof raw === "string" ? raw.trim() : "";
  return key.length > 0 ? key : null;
}

export function xaiBaseUrl(): string {
  const env = typeof process === "undefined" ? undefined : process.env;
  const raw = env ? env["XAI_API_BASE_URL"] : undefined;
  const url = typeof raw === "string" ? raw.trim().replace(/\/$/, "") : "";
  return url || "https://api.x.ai/v1";
}

export type XaiAvailability = {
  available: boolean;
  reason: "ok" | "missing_key";
};

export function xaiAvailability(): XaiAvailability {
  return readXaiApiKey()
    ? { available: true, reason: "ok" }
    : { available: false, reason: "missing_key" };
}

/** Honest missing-key copy. Do not pretend a model answered. */
export const MISSING_XAI_KEY_ERROR = "Grok is not connected. Nothing was sent to a model.";

/** Documented latest general model. Do not invent names. */
export const PRIMARY_CHAT_MODEL = "grok-4.5";

/**
 * Documented fallbacks after grok-4.5. grok-4-fast was retired 15 May 2026
 * and must not be requested — a 403/404 on that slug is expected.
 */
const DOCUMENTED_FALLBACKS = ["grok-4.5", "grok-4", "grok-3"] as const;

export function chatModelCandidates(lane: IntelligenceLane = "deep"): string[] {
  const env = typeof process === "undefined" ? undefined : process.env;
  const preferredRaw =
    lane === "fast"
      ? env?.["XAI_FAST_MODEL"] || env?.["XAI_CHAT_MODEL"]
      : env?.["XAI_CHAT_MODEL"];
  const preferred = typeof preferredRaw === "string" ? preferredRaw.trim() : "";
  const list = [preferred, ...DOCUMENTED_FALLBACKS].filter((name) => name.length > 0);
  return [...new Set(list)];
}

export function shouldTryNextModel(status: number): boolean {
  return status === 403 || status === 404;
}

export type ProviderFailureCategory =
  | "model_access"
  | "model_not_found"
  | "unauthorized"
  | "rate_limited"
  | "bad_request"
  | "unavailable"
  | "unknown";

export type ProviderFailure = {
  status: number;
  category: ProviderFailureCategory;
  code: string | null;
  model: string;
};

function extractProviderCode(bodyText: string): string | null {
  const trimmed = bodyText.trim();
  if (!trimmed.startsWith("{")) return null;
  try {
    const json = JSON.parse(trimmed) as { code?: unknown; error?: unknown; type?: unknown };
    if (typeof json.code === "string" && json.code.trim()) return json.code.trim().slice(0, 80);
    if (typeof json.type === "string" && json.type.trim()) return json.type.trim().slice(0, 80);
    return null;
  } catch {
    return null;
  }
}

function extractProviderHint(bodyText: string): string {
  const trimmed = bodyText.trim();
  if (!trimmed) return "";
  try {
    const json = JSON.parse(trimmed) as { error?: unknown; message?: unknown };
    const err = json.error;
    if (typeof err === "string") return err.slice(0, 240);
    if (err && typeof err === "object" && typeof (err as { message?: unknown }).message === "string") {
      return String((err as { message: string }).message).slice(0, 240);
    }
    if (typeof json.message === "string") return json.message.slice(0, 240);
  } catch {
    return "";
  }
  return "";
}

export function classifyProviderFailure(status: number, bodyText: string, model: string): ProviderFailure {
  const hint = extractProviderHint(bodyText).toLowerCase();
  let category: ProviderFailureCategory = "unknown";
  if (status === 401) category = "unauthorized";
  else if (status === 429) category = "rate_limited";
  else if (status === 404 && /model/.test(hint)) category = "model_not_found";
  else if (status === 404) category = "model_not_found";
  else if (status === 403) {
    category =
      /model|access|entitlement|permission|does not have access|not exist/.test(hint)
        ? "model_access"
        : "model_access";
  } else if (status === 400 || status === 422) category = "bad_request";
  else if (status >= 500) category = "unavailable";
  return {
    status,
    category,
    code: extractProviderCode(bodyText),
    model,
  };
}

/**
 * Safe server log. Never logs the API key, Authorization header,
 * conversation text, or memories.
 */
export function logProviderFailure(kind: string, failure: ProviderFailure): void {
  const code = failure.code || "none";
  console.warn(
    `[aegis:${kind}] provider_status=${failure.status} category=${failure.category} code=${code} model=${failure.model}`,
  );
}

export function userFacingProviderError(status: number): string {
  if (status === 401 || status === 403) return "The AI is unavailable right now. Please try again.";
  if (status === 429) return "The model is busy. Try once more.";
  return "The AI is unavailable right now. Please try again.";
}

export function userFacingMediaError(_status: number): string {
  return "The AI is unavailable right now. Please try again.";
}
