import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { xaiAvailability } from "./xai-env.server.ts";

/** True when a server-only xAI key is present. Does not call the API. */
export const getAiStatus = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async (): Promise<{ available: boolean; reason: "ok" | "missing_key" }> => {
    return xaiAvailability();
  });