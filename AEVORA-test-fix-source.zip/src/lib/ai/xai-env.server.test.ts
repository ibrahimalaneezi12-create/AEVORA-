import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  readXaiApiKey,
  xaiAvailability,
  xaiBaseUrl,
  chatModelCandidates,
  PRIMARY_CHAT_MODEL,
  shouldTryNextModel,
  MISSING_XAI_KEY_ERROR,
  userFacingProviderError,
  classifyProviderFailure,
} from "./xai-env.server.ts";

describe("xai env", () => {
  it("treats a missing key as unavailable and never invents one", () => {
    const prev = process.env.XAI_API_KEY;
    delete process.env.XAI_API_KEY;
    try {
      assert.equal(readXaiApiKey(), null);
      assert.deepEqual(xaiAvailability(), { available: false, reason: "missing_key" });
      assert.match(MISSING_XAI_KEY_ERROR, /not connected/i);
      assert.doesNotMatch(MISSING_XAI_KEY_ERROR, /try again/i);
    } finally {
      if (prev === undefined) delete process.env.XAI_API_KEY;
      else process.env.XAI_API_KEY = prev;
    }
  });

  it("reads a present key at runtime via bracket access", () => {
    const prev = process.env.XAI_API_KEY;
    process.env.XAI_API_KEY = "  xai-test-not-a-real-key  ";
    try {
      assert.equal(readXaiApiKey(), "xai-test-not-a-real-key");
      assert.deepEqual(xaiAvailability(), { available: true, reason: "ok" });
    } finally {
      if (prev === undefined) delete process.env.XAI_API_KEY;
      else process.env.XAI_API_KEY = prev;
    }
  });

  it("defaults the API host to api.x.ai", () => {
    const prev = process.env.XAI_API_BASE_URL;
    delete process.env.XAI_API_BASE_URL;
    try {
      assert.equal(xaiBaseUrl(), "https://api.x.ai/v1");
    } finally {
      if (prev === undefined) delete process.env.XAI_API_BASE_URL;
      else process.env.XAI_API_BASE_URL = prev;
    }
  });

  it("uses grok-4.5 and retries 403/404 onto documented fallbacks", () => {
    const prev = process.env.XAI_CHAT_MODEL;
    delete process.env.XAI_CHAT_MODEL;
    try {
      assert.equal(PRIMARY_CHAT_MODEL, "grok-4.5");
      assert.deepEqual(chatModelCandidates(), ["grok-4.5", "grok-4", "grok-3"]);
      assert.equal(chatModelCandidates("fast")[0], "grok-4.5");
      assert.equal(chatModelCandidates().includes("grok-4-fast"), false);
      assert.equal(shouldTryNextModel(403), true);
      assert.equal(shouldTryNextModel(401), false);
      assert.match(userFacingProviderError(403), /unavailable/i);
      assert.equal(userFacingProviderError(403).includes("403"), false);
    } finally {
      if (prev === undefined) delete process.env.XAI_CHAT_MODEL;
      else process.env.XAI_CHAT_MODEL = prev;
    }
  });

  it("classifies provider failures without leaking secrets", () => {
    const denied = classifyProviderFailure(
      403,
      '{"code":"not-found","error":"The model grok-4.5 does not exist or your team t_abc does not have access to it."}',
      "grok-4.5",
    );
    assert.equal(denied.category, "model_access");
    assert.equal(denied.code, "not-found");
    assert.equal(denied.model, "grok-4.5");
    assert.equal(denied.status, 403);
    const limited = classifyProviderFailure(429, "{}", "grok-4.5");
    assert.equal(limited.category, "rate_limited");
  });
});
