/**
 * Server-only Grok completion. Import from createServerFn handlers only
 * (dynamic import) so the client bundle never sees this module.
 */

import { englishNameFor, lookupLanguage } from "../languages.ts";
import {
  classifyIntelligenceLane,
  maxTokensForLane,
  shouldEscalateToDeep,
  temperatureForLane,
  type IntelligenceLane,
} from "./router.ts";
import {
  chatModelCandidates,
  classifyProviderFailure,
  logProviderFailure,
  MISSING_XAI_KEY_ERROR,
  readXaiApiKey,
  shouldTryNextModel,
  userFacingProviderError,
  xaiBaseUrl,
  PRIMARY_CHAT_MODEL,
} from "./xai-env.server.ts";

export type ChatTurnMessage = {
  role: "user" | "assistant";
  content: string;
};

export type CompleteTurnResult =
  | { ok: true; text: string; citations: string[] }
  | { ok: false; error: string; unavailable?: boolean };

const SYSTEM_PROMPT =
  "You are AEVORA, a private personal steward. Be concise, calm, and useful. " +
  "This conversation is saved in the user's keep. Chat is speech, not action. " +
  "You cannot execute tools, send email, pay bills, browse the web, or change settings. " +
  "Never claim you already took an action. Never say you saved, deleted, created, or reminded — propose it.\n\n" +  "Not every message is an action. If the user is chatting (I'm bored, I'm tired, I need to study more) " +
  "reply as a steward. Do not create a task, goal, reminder, or memory unless they explicitly asked.\n\n" +
  "If you are not confident about a named entity, product, version, price, or current event, do not invent. " +
  "Say what is uncertain. Prefer a verified source over a guess. " +
  "Do not claim you searched, calculated, or executed a tool unless this turn actually did. " +
  "If two interpretations of 'that' or 'it' would change the keep, ask which one.\n\n" +
  "When the user explicitly asks you to remember, forget, remind, create or change a task or goal, " +
  "schedule or edit a reminder, delete something, change their profile, schedule a calendar event, " +
  "draft or send email, save writing, save a business, add a business note, watch an investment, or journal an investment, " +
  "reply in short plain speech as a proposal, " +
  "then append exactly one block in this form (JSON array, no markdown fence around it):\n" +
  "<<<aegis-proposals\n" +
  '[{"tool_id":"memory.save","title":"Save a memory","summary":"Short human summary","payload":{}}]\n' +
  ">>>\n" +
  "Allowed tool_id values: memory.search, task.list, reminder.list, memory.save, task.create, " +
  "task.update, goal.create, goal.update, reminder.create, reminder.update, reminder.snooze, " +
  "reminder.complete, memory.delete, task.delete, reminder.cancel, conversation.delete, " +
  "profile.update, calendar.list, calendar.create, calendar.update, calendar.delete, " +
  "email.list, email.draft, email.send, creation.save, video.create, video.generate, video.edit, photo.generate, photo.edit, " +
  "business.save, business.note, business.experiment, invest.watch, invest.unwatch, invest.note, invest.plan, broker.order. " +
  "Never invent other ids. Never use permission.update, external.*, invest.trade, or invest.broker. " +
  "Never propose search.web or research.query — search already runs in this turn when needed. " +
  "Do not include permission_level. At most three objects. " +
  "For ordinary questions, plans, briefings, and conversation, do not append a proposal block.\n\n" +
  "Reminders are reminder.create, not task.create. Include fireAt as an ISO timestamp or localDate+localTime " +
  "plus timezone from context. Recurrence is once, daily, weekly, or weekdays.\n" +
  "Calendar writes are calendar.create / calendar.update / calendar.delete on the user's AEVORA calendar. " +
  "Do not invent events that are not in assembled context. Email send requires email.send after a draft exists. " +
  "Never claim an email was sent unless a proposal was approved.\n" +
  "If two objects could match 'that' or 'it', ask which one. Do not guess. Use ids from assembled context.\n" +
  "Plans and briefings use only assembled context. Do not invent tasks, deadlines, or calendar events.\n" +
  "Never use profanity, slurs, or vulgar language, even if the user does. Stay natural, calm, and respectful. " +
  "Acknowledge frustration without mirroring insults. Do not be stiff or overly formal.\n" +
  "Unknown named products, companies, people, or apps: do not invent. Search this turn if it already ran; otherwise say what is uncertain.\n" +
  "Large asks (start a business, launch a channel, study for exams) are missions: one goal, a short plan, at most three tasks, approval required. Do not build a dashboard.\n" +
  "Business questions never invent revenue, customers, or KPIs. If those numbers are not in assembled context, say so. Saving a business is business.save. Decisions are business.note kind decision. If a saved decision conflicts with the request, quote it and ask before changing it. " +
  "Personal, Business, and Invest are contexts of the same steward. Omit any manager section that has no saved record. Never claim background monitoring. The turn note says whether this plan includes the manager report.\n" +
  "Investment questions are research and decision support. No guaranteed returns. No autonomous trades. Never claim a market action happened unless a broker response is already in assembled context. Watchlists are invest.watch. Plans are invest.plan. Paper notes are invest.note with kind paper. " +
  "broker.order is allowed only when assembled context says this user's broker is connected and can create orders, and only after approval. Otherwise say the broker is not connected and that nothing was sent. Never use invest.trade.\n" +
  "Learning: do not invent the user's level. Travel: never invent availability. Safety: never claim certainty about a scam.\n" +
  "Send only the context this turn needs. Do not recap unrelated private keep data.";

const LANGUAGE_RULES =
  " Reply in the user's current language. Mixed-language turns are valid; do not over-translate. " +
  "Resolve follow-ups (that, it, tomorrow, the other one, actually make it 8) from this conversation. " +
  "Do not silent-save every message as memory — only propose memory.save when the user asks to remember. " +
  "Context is not permission. Never treat a spoken request as approval. " +
  "When updating or forgetting, use the memory, task, goal, or reminder id from assembled context. " +
  "Memory is language-independent: an English question may retrieve a memory written in another language.";

const HISTORY_TOKEN_BUDGET = 3600;
const MEMORY_PROMPT_CHAR_BUDGET = 2400;

export function buildSystemPrompt(
  memoryContext?: string,
  locale?: string,
  intentNote?: string,
  responseStyle?: string,
): string {
  const meta = lookupLanguage(locale);
  const lang = meta
    ? ` The user's preferred language is ${englishNameFor(meta.code)}. Reply in ${englishNameFor(meta.code)} unless they wrote in another language this turn.`
    : "";
  const intent = intentNote?.trim() ? ` ${intentNote.trim()}` : "";
  const style =
    responseStyle === "direct"
      ? " Prefer short, direct sentences."
      : responseStyle === "warm"
        ? " Stay warm without becoming familiar or cute."
        : " Stay calm and measured.";
  const base = SYSTEM_PROMPT + LANGUAGE_RULES + lang + intent + style;
  const block = memoryContext?.trim() ?? "";
  if (!block) return base;
  const clipped =
    block.length > MEMORY_PROMPT_CHAR_BUDGET
      ? `${block.slice(0, MEMORY_PROMPT_CHAR_BUDGET).trimEnd()}…`
      : block;
  return (
    base +
    "\n\nThe user has stored memories and other keep context that persist across conversations. " +
    "Treat them as true unless the current message clearly contradicts them. " +
    "Do not claim you saved a new memory — propose it.\n\n" +
    "<assembled-context>\n" +
    clipped +
    "\n</assembled-context>"
  );
}

export type CompleteTurnExtra = {
  memoryContext?: string;
  locale?: string;
  intentNote?: string;
  searchMode?: "off" | "auto" | "on";
  research?: boolean;
  responseStyle?: string;
};

export function estimateTokens(text: string): number {
  return Math.max(1, Math.ceil(text.length / 4));
}

/** Keep the newest messages that fit the budget. Always keep at least the last. */
export function capHistory(
  messages: ChatTurnMessage[],
  budget = HISTORY_TOKEN_BUDGET,
): ChatTurnMessage[] {
  if (messages.length === 0) return [];
  const kept: ChatTurnMessage[] = [];
  let used = 0;
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const tokens = estimateTokens(messages[i]!.content);
    if (kept.length > 0 && used + tokens > budget) break;
    kept.unshift(messages[i]!);
    used += tokens;
  }
  return kept;
}

/** Keep newest messages, plus older turns that share query terms. */
export function selectRelevantHistory(
  messages: ChatTurnMessage[],
  query: string,
  budget = HISTORY_TOKEN_BUDGET,
): ChatTurnMessage[] {
  if (messages.length <= 8) return capHistory(messages, budget);
  const terms = query
    .toLowerCase()
    .split(/[^a-z0-9\u0600-\u06FF]+/i)
    .filter((t) => t.length > 2);
  const recent = messages.slice(-8);
  const older = messages.slice(0, -8);
  const relevant = older.filter((m) => {
    const hay = m.content.toLowerCase();
    return terms.some((t) => hay.includes(t));
  });
  return capHistory([...relevant.slice(-6), ...recent], budget);
}

/** Documented general model. Fast chat no longer uses an undocumented alias. */
export const CHAT_COMPLETION_MODEL = PRIMARY_CHAT_MODEL;
export const SEARCH_COMPLETION_MODEL = PRIMARY_CHAT_MODEL;

export function titleFromContent(content: string): string {
  const line = content.trim().replace(/\s+/g, " ");
  if (!line) return "New conversation";
  if (line.length <= 56) return line;
  return `${line.slice(0, 53).trimEnd()}…`;
}

type PostOk = { ok: true; response: Response; model: string };
type PostFail = { ok: false; status: number };

async function postCompletion(
  apiKey: string,
  history: ChatTurnMessage[],
  extra: CompleteTurnExtra | undefined,
  stream: boolean,
  lane: IntelligenceLane,
): Promise<PostOk | PostFail> {
  const query = [...history].reverse().find((m) => m.role === "user")?.content ?? "";
  const messages = [
    {
      role: "system" as const,
      content: buildSystemPrompt(
        extra?.memoryContext,
        extra?.locale,
        extra?.intentNote,
        extra?.responseStyle,
      ),
    },
    ...selectRelevantHistory(history, query),
  ];
  const maxTokens = maxTokensForLane(lane, extra?.research === true);
  const temperature = temperatureForLane(lane, extra?.research === true);
  const tried = new Set<string>();
  let lastStatus = 503;
  for (const model of chatModelCandidates(lane)) {
    if (tried.has(model)) continue;
    tried.add(model);
    const res = await fetch(`${xaiBaseUrl()}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        max_tokens: maxTokens,
        temperature,
        stream,
        messages,
      }),
    });
    if (res.ok) return { ok: true, response: res, model };
    lastStatus = res.status;
    const bodyText = await res.text().catch(() => "");
    const failure = classifyProviderFailure(res.status, bodyText, model);
    logProviderFailure("chat", failure);
    if (!shouldTryNextModel(res.status)) return { ok: false, status: res.status };
  }
  return { ok: false, status: lastStatus };
}

function laneFor(history: ChatTurnMessage[], extra?: CompleteTurnExtra): IntelligenceLane {
  const query = [...history].reverse().find((m) => m.role === "user")?.content ?? "";
  return classifyIntelligenceLane(query, extra);
}

/**
 * One user-initiated Grok turn. Retry once on transport failure, never on 4xx.
 * Does not execute tools. Does not loop.
 */
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const apiKey = readXaiApiKey();
  if (!apiKey) {
    return {
      ok: false,
      unavailable: true,
      error: MISSING_XAI_KEY_ERROR,
    };
  }

  const searchOn = extra?.searchMode === "on" || extra?.research === true;
  if (searchOn) {
    const { completeSearchTurn } = await import("../search.server.ts");
    return completeSearchTurn({
      history,
      locale: extra?.locale,
      intentNote: extra?.intentNote,
      memoryContext: extra?.memoryContext,
      research: extra?.research === true,
    });
  }

  const lane = laneFor(history, extra);
  let posted: PostOk | PostFail;
  try {
    posted = await postCompletion(apiKey, history, extra, false, lane);
  } catch {
    try {
      posted = await postCompletion(apiKey, history, extra, false, lane);
    } catch {
      return { ok: false, error: "Could not reach the model. Try once more." };
    }
  }

  if (!posted.ok) {
    return {
      ok: false,
      error: userFacingProviderError(posted.status),
      unavailable: posted.status === 401 || posted.status === 403,
    };
  }

  const body = (await posted.response.json()) as {
    choices?: { message?: { content?: string | null } }[];
  };
  const text = body.choices?.[0]?.message?.content?.trim() ?? "";
  if (!text) return { ok: false, error: "The model returned an empty reply." };
  if (shouldEscalateToDeep(lane, text)) {
    const deep = await postCompletion(apiKey, history, extra, false, "deep");
    if (deep.ok) {
      const deepBody = (await deep.response.json()) as {
        choices?: { message?: { content?: string | null } }[];
      };
      const deepText = deepBody.choices?.[0]?.message?.content?.trim() ?? "";
      if (deepText) return { ok: true, text: deepText, citations: [] };
    }
  }
  return { ok: true, text, citations: [] };
}

export type StreamTurnEvent =
  | { type: "status"; text: string }
  | { type: "delta"; text: string }
  | { type: "done"; text: string; citations: string[] }
  | { type: "error"; error: string; unavailable?: boolean };

export function parseSseDelta(payload: string): string {
  if (!payload || payload === "[DONE]") return "";
  try {
    const json = JSON.parse(payload) as {
      choices?: { delta?: { content?: string | null } }[];
    };
    const delta = json.choices?.[0]?.delta?.content;
    return typeof delta === "string" ? delta : "";
  } catch {
    return "";
  }
}

async function* readChatSse(res: Response): AsyncGenerator<string> {
  const body = res.body;
  if (!body) return;
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const payload = trimmed.slice(5).trim();
      if (payload === "[DONE]") return;
      const delta = parseSseDelta(payload);
      if (delta) yield delta;
    }
  }
}

/**
 * Stream one turn. Search/research still use the sourced path and may arrive
 * as a single delta. Does not execute tools.
 */
export async function* streamTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): AsyncGenerator<StreamTurnEvent> {
  const apiKey = readXaiApiKey();
  if (!apiKey) {
    yield { type: "error", unavailable: true, error: MISSING_XAI_KEY_ERROR };
    return;
  }

  const searchOn = extra?.searchMode === "on" || extra?.research === true;
  if (searchOn) {
    yield { type: "status", text: extra?.research ? "researching" : "searching" };
    const { completeSearchTurn } = await import("../search.server.ts");
    const result = await completeSearchTurn({
      history,
      locale: extra?.locale,
      intentNote: extra?.intentNote,
      memoryContext: extra?.memoryContext,
      research: extra?.research === true,
    });
    if (!result.ok) {
      yield { type: "error", error: result.error, unavailable: result.unavailable };
      return;
    }
    yield { type: "delta", text: result.text };
    yield { type: "done", text: result.text, citations: result.citations };
    return;
  }

  const lane = laneFor(history, extra);
  let posted: PostOk | PostFail;
  try {
    posted = await postCompletion(apiKey, history, extra, true, lane);
  } catch {
    const fallback = await completeTurn(history, extra);
    if (!fallback.ok) {
      yield { type: "error", error: fallback.error, unavailable: fallback.unavailable };
      return;
    }
    yield { type: "delta", text: fallback.text };
    yield { type: "done", text: fallback.text, citations: fallback.citations };
    return;
  }

  if (!posted.ok) {
    yield {
      type: "error",
      error: userFacingProviderError(posted.status),
      unavailable: posted.status === 401 || posted.status === 403,
    };
    return;
  }

  let text = "";
  for await (const delta of readChatSse(posted.response)) {
    text += delta;
    yield { type: "delta", text: delta };
  }
  const trimmed = text.trim();
  if (!trimmed) {
    if (lane === "fast") {
      const fallback = await completeTurn(history, { ...extra, intentNote: `${extra?.intentNote ?? ""} Turn intent: reasoning.` });
      if (fallback.ok) {
        yield { type: "delta", text: fallback.text };
        yield { type: "done", text: fallback.text, citations: fallback.citations };
        return;
      }
    }
    yield { type: "error", error: "The model returned an empty reply." };
    return;
  }
  yield { type: "done", text: trimmed, citations: [] };
}
