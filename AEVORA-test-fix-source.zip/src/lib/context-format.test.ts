import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { assemblePromptBlock, languageFooter } from "./context-format.ts";
import type { Memory } from "./memory-format.ts";

function mem(partial: Partial<Memory> & Pick<Memory, "id" | "title" | "body">): Memory {
  return {
    kind: "preference",
    tags: "",
    source: "user",
    pinned: false,
    createdAt: "2026-09-17T00:00:00.000Z",
    updatedAt: "2026-09-17T00:00:00.000Z",
    ...partial,
  };
}

describe("assemblePromptBlock", () => {
  it("includes memory ids, goals, tasks, pending, and language without dumping empty sections", () => {
    const block = assemblePromptBlock({
      locale: "en",
      memories: [
        mem({
          id: 12,
          title: "Study time",
          body: "I prefer studying after dinner.",
        }),
      ],
      goals: [{ id: 3, title: "Pass exams", targetDate: "2026-10-01" }],
      tasks: [{ id: 8, title: "Study calculus", dueDate: "2026-09-18", status: "todo", dueKind: "today" }],
      pending: [{ id: 4, title: "Save a memory", permissionLevel: "review" }],
    });
    assert.match(block, /#12/);
    assert.match(block, /<user-memory>/);
    assert.match(block, /<active-goals>/);
    assert.match(block, /#3/);
    assert.match(block, /<open-tasks>/);
    assert.match(block, /#8 today/);
    assert.match(block, /<pending-actions>/);
    assert.match(block, /waiting for your Approve/);
    assert.match(block, /Language: English \(en\)/);
    assert.match(block, /Context is not permission/);
  });

  it("omits empty sections", () => {
    const block = assemblePromptBlock({
      locale: "ar",
      memories: [],
      goals: [],
      tasks: [],
      pending: [],
    });
    assert.equal(block.includes("<user-memory>"), false);
    assert.equal(block.includes("<active-goals>"), false);
    assert.match(block, /العربية \(ar\)/);
  });
});

describe("languageFooter", () => {
  it("mentions follow-ups and ids", () => {
    assert.match(languageFooter("en"), /Follow-ups/);
    assert.match(languageFooter("en"), /memory\/task\/goal\/reminder id/);
    assert.match(languageFooter("en"), /Do not invent business revenue/);
  });
});
