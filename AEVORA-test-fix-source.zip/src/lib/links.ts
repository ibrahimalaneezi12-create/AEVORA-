import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { peekGoogleCalendar } from "@/lib/calendar";
import { peekGmailConnection } from "@/lib/mail";
import { businessLinks, type BusinessLink, type LinkStatus } from "@/lib/links-format";

export type { BusinessLink, LinkStatus };

function gateStatus(value: { connected: boolean; status?: LinkStatus }): LinkStatus {
  if (value.status) return value.status;
  return value.connected ? "connected" : "not_connected";
}

export async function listBusinessLinkStates(userId = ""): Promise<BusinessLink[]> {
  const [gmail, calendar, hubspot, shopify, ads, books] = await Promise.all([
    peekGmailConnection().catch(() => ({
      connected: false,
      status: "connection_error" as const,
      detail: "Gmail could not be checked.",
      loginUrl: "",
      lastCheckedAt: "",
    })),
    peekGoogleCalendar().catch(() => ({
      connected: false,
      status: "connection_error" as const,
      detail: "Google Calendar could not be checked.",
      lines: [] as string[],
      loginUrl: "",
      lastCheckedAt: "",
    })),
    userId
      ? import("@/lib/providers.server")
          .then((mod) => mod.publicProvider(userId, "hubspot"))
          .catch(() => null)
      : Promise.resolve(null),
    userId
      ? import("@/lib/providers.server")
          .then((mod) => mod.publicProvider(userId, "shopify"))
          .catch(() => null)
      : Promise.resolve(null),
    userId
      ? import("@/lib/providers.server")
          .then((mod) => mod.oauthLinkState(userId, "google_ads"))
          .catch(() => null)
      : Promise.resolve(null),
    userId
      ? import("@/lib/providers.server")
          .then((mod) => mod.oauthLinkState(userId, "quickbooks"))
          .catch(() => null)
      : Promise.resolve(null),
  ]);
  const inventory = !shopify || shopify.status === "not_connected"
    ? {
        connected: false,
        status: "provider_unavailable" as const,
        detail: "Inventory is read from Shopify. No other inventory provider is registered, so stock is not being read.",
        lastCheckedAt: shopify?.lastCheckedAt ?? "",
      }
    : !shopify.connected
      ? {
          connected: false,
          status: shopify.status,
          detail: `Inventory is read from Shopify. ${shopify.detail}`,
          lastCheckedAt: shopify.lastCheckedAt,
        }
      : shopify.capabilities.includes("inventory.read")
      ? {
          connected: true,
          status: "connected" as const,
          detail: "Stock quantities come from Shopify. Only quantities it returned on the last check are used.",
          lastCheckedAt: shopify.lastCheckedAt,
        }
      : {
          connected: false,
          status: "not_connected" as const,
          detail: "Shopify is connected, but it did not return stock quantities. Nothing was estimated.",
          lastCheckedAt: shopify.lastCheckedAt,
        };
  return businessLinks({
    gmail: gmail.connected,
    gmailDetail: gmail.detail,
    gmailStatus: gateStatus(gmail),
    gmailChecked: gmail.lastCheckedAt,
    gmailLoginUrl: gmail.loginUrl,
    calendar: calendar.connected,
    calendarDetail: calendar.detail,
    calendarStatus: gateStatus(calendar),
    calendarChecked: calendar.lastCheckedAt,
    calendarLoginUrl: calendar.loginUrl,
    hubspot: hubspot
      ? { connected: hubspot.connected, status: hubspot.status, detail: hubspot.detail, lastCheckedAt: hubspot.lastCheckedAt }
      : undefined,
    shopify: shopify
      ? { connected: shopify.connected, status: shopify.status, detail: shopify.detail, lastCheckedAt: shopify.lastCheckedAt }
      : undefined,
    ads: ads ?? undefined,
    books: books ?? undefined,
    inventory,
  });
}

export const listBusinessLinks = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<BusinessLink[]> => listBusinessLinkStates(context.userId));
