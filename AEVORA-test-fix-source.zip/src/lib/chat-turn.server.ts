/**
 * Server-only chat turn. Used by sendChatMessage and the stream route.
 * Never import from client components.
 */
import { getSql } from "@/lib/db";
import type { ProposedActionView, RejectedProposalView } from "@/lib/orchestrator/types";
import { elapsedMs, shouldExposeLatency, type TurnLatency } from "@/lib/latency-format";
import { parseChatWorkspace, workspaceIntentNote, type ChatWorkspaceId } from "@/lib/chat-workspace";

export const CHAT_MESSAGE_MAX = 4000;
export const DEFAULT_CONVERSATION_TITLE = "New conversation";

export type Conversation = {
  id: number;
  title: string;
  workspace: ChatWorkspaceId;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
};

export type ChatMessage = {
  id: number;
  conversationId: number;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
};

export type OwnedTurnResult =
  | {
      ok: true;
      conversation: Conversation;
      userMessage: ChatMessage;
      assistantMessage: ChatMessage;
      proposals: ProposedActionView[];
      rejected: RejectedProposalView[];
      citations: string[];
      latency: TurnLatency | null;
    }
  | {
      ok: false;
      error: string;
      unavailable?: boolean;
      conversation: Conversation | null;
      userMessage: ChatMessage | null;
      assistantMessage: null;
      proposals: ProposedActionView[];
      rejected: RejectedProposalView[];
      citations: string[];
      latency: TurnLatency | null;
    };

const completing = new Set<string>();
const turnGeneration = new Map<string, number>();

type ConversationRow = {
  id: unknown;
  title: string;
  workspace?: unknown;
  archived: boolean;
  created_at: unknown;
  updated_at: unknown;
};

type MessageRow = {
  id: unknown;
  conversation_id: unknown;
  role: string;
  content: string;
  created_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

function mapConversation(row: ConversationRow): Conversation {
  return {
    id: asPositiveInt(row.id),
    title: row.title || DEFAULT_CONVERSATION_TITLE,
    workspace: parseChatWorkspace(row.workspace),
    archived: Boolean(row.archived),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function mapMessage(row: MessageRow): ChatMessage | null {
  if (row.role !== "user" && row.role !== "assistant") return null;
  const id = asPositiveInt(row.id);
  const conversationId = asPositiveInt(row.conversation_id);
  if (!id || !conversationId) return null;
  return {
    id,
    conversationId,
    role: row.role,
    content: row.content,
    createdAt: toIso(row.created_at),
  };
}

async function readConversation(userId: string, id: number): Promise<Conversation | null> {
  const sql = await getSql();
  const rows = await sql<ConversationRow>`
    select id, title, workspace, archived, created_at, updated_at
    from conversations
    where id = ${id} and user_id = ${userId}
  `;
  return rows[0] ? mapConversation(rows[0]) : null;
}

async function insertConversation(userId: string, workspace: ChatWorkspaceId): Promise<Conversation> {
  const sql = await getSql();
  const rows = await sql<ConversationRow>`
    insert into conversations (user_id, workspace)
    values (${userId}, ${workspace})
    returning id, title, workspace, archived, created_at, updated_at
  `;
  const row = rows[0];
  if (!row) throw new Error("Conversation could not be created.");
  return mapConversation(row);
}

async function touchConversation(userId: string, id: number, title: string): Promise<Conversation | null> {
  const sql = await getSql();
  const rows = await sql<ConversationRow>`
    update conversations
    set title = ${title}, updated_at = now()
    where id = ${id} and user_id = ${userId}
    returning id, title, workspace, archived, created_at, updated_at
  `;
  return rows[0] ? mapConversation(rows[0]) : null;
}

async function readMessages(userId: string, conversationId: number): Promise<ChatMessage[]> {
  const sql = await getSql();
  const rows = await sql<MessageRow>`
    select id, conversation_id, role, content, created_at
    from messages
    where user_id = ${userId} and conversation_id = ${conversationId}
    order by id asc
  `;
  const out: ChatMessage[] = [];
  for (const row of rows) {
    const mapped = mapMessage(row);
    if (mapped) out.push(mapped);
  }
  return out;
}

async function insertMessage(
  userId: string,
  conversationId: number,
  role: "user" | "assistant",
  content: string,
  tokenCount: number,
): Promise<ChatMessage> {
  const sql = await getSql();
  const rows = await sql<MessageRow>`
    insert into messages (user_id, conversation_id, role, content, token_count)
    values (${userId}, ${conversationId}, ${role}, ${content}, ${tokenCount})
    returning id, conversation_id, role, content, created_at
  `;
  const mapped = rows[0] ? mapMessage(rows[0]) : null;
  if (!mapped) throw new Error("Message could not be saved.");
  return mapped;
}

function fail(
  error: string,
  extra: {
    unavailable?: boolean;
    conversation?: Conversation | null;
    userMessage?: ChatMessage | null;
    latency?: TurnLatency | null;
  } = {},
): OwnedTurnResult {
  return {
    ok: false,
    error,
    unavailable: extra.unavailable,
    conversation: extra.conversation ?? null,
    userMessage: extra.userMessage ?? null,
    assistantMessage: null,
    proposals: [],
    rejected: [],
    citations: [],
    latency: extra.latency ?? null,
  };
}

export type TurnPrep = {
  conversation: Conversation;
  userMessage: ChatMessage;
  history: ChatMessage[];
  extra: {
    memoryContext: string;
    locale?: string;
    intentNote?: string;
    searchMode: "off" | "on";
    research: boolean;
    responseStyle?: string;
    fastReply?: string;
  };
  nextTitle: string;
  startedAt: number;
};

async function assembleTurnExtra(
  userId: string,
  content: string,
  workspace: ChatWorkspaceId = "main",
): Promise<{
  extra: TurnPrep["extra"];
  denied?: string;
}> {
  const { classifyTurnIntent, intentPromptLine, intentWantsResearch, intentWantsSearch, providerContextFlags } =
    await import("@/lib/intent-format");
  const intent = classifyTurnIntent(content);
  let intentNote = intentPromptLine(intent);
  let searchMode: "off" | "on" = intentWantsSearch(intent, content) ? "on" : "off";
  let research = intentWantsResearch(intent, content);
  const flags = providerContextFlags(intent, content);
  if (workspace === "business") flags.business = true;
  if (workspace === "invest") flags.invest = true;
  const scopeNote = workspaceIntentNote(workspace);
  if (scopeNote) intentNote = `${intentNote} ${scopeNote}`.trim();
  let locale: string | undefined;

  try {
    const { answerFact } = await import("@/lib/facts");
    const sql = await getSql();
    const rows = await sql<{ timezone: string | null; locale: string | null }>`
      select timezone, locale from profiles where user_id = ${userId} limit 1
    `;
    const fact = answerFact(content, {
      now: new Date(),
      timeZone: rows[0]?.timezone || "UTC",
      locale: rows[0]?.locale || undefined,
    });
    if (fact) {
      return {
        extra: {
          memoryContext: "",
          locale: rows[0]?.locale || locale,
          intentNote,
          searchMode: "off",
          research: false,
          responseStyle: "direct",
          fastReply: fact.text,
        },
      };
    }
  } catch {
    /* fall through to full assemble */
  }

  if (intent.kind === "language_switch" && intent.language) {
    const sql = await getSql();
    await sql`
      update profiles
      set locale = ${intent.language}, updated_at = now()
      where user_id = ${userId}
    `;
    locale = intent.language;
    void import("@/lib/audit")
      .then(({ appendAudit }) =>
        appendAudit({
          userId,
          actor: "user",
          action: "profile.locale",
          entityType: "profile",
          entityId: userId,
          permissionLevel: "review",
          detail: `locale=${intent.language}`,
        }),
      )
      .catch(() => undefined);
  }

  if (intent.kind === "business" || intent.kind === "invest" || searchMode === "on") {
    try {
      const { entitlementFor, planAllowsFeature, featureDeniedMessage, contextTierNote } = await import(
        "@/lib/entitlements"
      );
      const ent = await entitlementFor(userId);
      if (searchMode === "on") {
        const feature = research ? "research" : "search";
        if (!planAllowsFeature(ent.plan, feature)) {
          if (intent.kind === "business" || intent.kind === "invest") {
            searchMode = "off";
            research = false;
          } else {
            return {
              extra: { memoryContext: "", locale, intentNote, searchMode, research, responseStyle: "calm" },
              denied: featureDeniedMessage(ent.plan, feature),
            };
          }
        }
      }
      if (intent.kind === "business" || intent.kind === "invest") {
        intentNote = `${intentNote} ${contextTierNote(ent.plan, intent.kind)}`;
      }
    } catch {
      // Entitlement read failed — still try the keep. Do not pretend a lookup ran.
      if (intent.kind === "business" || intent.kind === "invest") {
        searchMode = "off";
        research = false;
      }
    }
    if (intent.kind === "invest") {
      try {
        const { publicBroker } = await import("@/lib/broker.server");
        const { brokerStatusNote } = await import("@/lib/invest-brain");
        const link = await publicBroker(userId);
        intentNote = `${intentNote} ${brokerStatusNote({
          connected: link.connected,
          mode: link.mode,
          accountStatus: link.accountStatus,
          capabilities: link.capabilities,
          error: link.error,
        })}`;
      } catch {
        intentNote = `${intentNote} Broker status could not be read this turn. Do not invent a connection or a balance.`;
      }
    }
  }

  if (workspace === "invest" && intent.kind !== "invest") {
    try {
      const { publicBroker } = await import("@/lib/broker.server");
      const { brokerStatusNote } = await import("@/lib/invest-brain");
      const link = await publicBroker(userId);
      intentNote = `${intentNote} ${brokerStatusNote({
        connected: link.connected,
        mode: link.mode,
        accountStatus: link.accountStatus,
        capabilities: link.capabilities,
        error: link.error,
      })}`;
    } catch {
      intentNote = `${intentNote} Broker status could not be read this turn. Do not invent a connection or a balance.`;
    }
  }

  try {
    const { assembleContext } = await import("@/lib/context");
    const assembled = await assembleContext(userId, {
      query: content,
      includeCalendar: flags.calendar,
      includeMail: flags.mail,
      includeKeep: flags.keep,
      includeBusiness: flags.business,
      includeInvest: flags.invest,
    });
    return {
      extra: {
        memoryContext: assembled.promptBlock,
        locale: locale ?? assembled.locale,
        intentNote,
        searchMode,
        research,
        responseStyle: assembled.responseStyle,
      },
    };
  } catch {
    try {
      const { retrieveMemories, formatMemoryBlock } = await import("@/lib/memory");
      return {
        extra: {
          memoryContext: formatMemoryBlock(await retrieveMemories(userId, content)),
          locale,
          intentNote,
          searchMode,
          research,
          responseStyle: "calm",
        },
      };
    } catch {
      return {
        extra: { memoryContext: "", locale, intentNote, searchMode, research, responseStyle: "calm" },
      };
    }
  }
}


export async function prepareOwnedTurn(
  userId: string,
  content: string,
  conversationId?: number,
  workspace: ChatWorkspaceId = "main",
): Promise<TurnPrep | OwnedTurnResult> {
  const startedAt = Date.now();
  let conversation: Conversation | null;
  if (conversationId) {
    conversation = await readConversation(userId, conversationId);
    if (!conversation || conversation.workspace !== workspace) throw new Error("Conversation not found.");
  } else {
    conversation = await insertConversation(userId, workspace);
  }

  const { estimateTokens, titleFromContent } = await import("@/lib/ai/complete.server");
  const nextTitle =
    conversation.title === DEFAULT_CONVERSATION_TITLE ? titleFromContent(content) : conversation.title;

  const [userMessage, historyBefore, assembled, touched] = await Promise.all([
    insertMessage(userId, conversation.id, "user", content, estimateTokens(content)),
    readMessages(userId, conversation.id),
    assembleTurnExtra(userId, content, workspace),
    nextTitle !== conversation.title
      ? touchConversation(userId, conversation.id, nextTitle)
      : Promise.resolve(conversation),
  ]);
  conversation = touched ?? conversation;
  const history = [...historyBefore.filter((m) => m.id !== userMessage.id), userMessage];
  if (assembled.denied) {
    return fail(assembled.denied, { conversation, userMessage });
  }

  return {
    conversation,
    userMessage,
    history,
    extra: assembled.extra,
    nextTitle,
    startedAt,
  };
}

export async function finalizeOwnedTurn(
  userId: string,
  prep: TurnPrep,
  rawText: string,
  citations: string[],
  firstTokenMs: number | null,
): Promise<OwnedTurnResult> {
  const { estimateTokens } = await import("@/lib/ai/complete.server");
  const { sanitizeAegisText } = await import("@/lib/personality");
  let speech = sanitizeAegisText(rawText);
  let proposals: ProposedActionView[] = [];
  let rejected: RejectedProposalView[] = [];
  try {
    const { persistableAssistant } = await import("@/lib/orchestrator/turn.server");
    const applied = await persistableAssistant(
      userId,
      prep.conversation.id,
      rawText,
      prep.userMessage.content,
    );
    speech = sanitizeAegisText(applied.speech);
    proposals = applied.proposals;
    rejected = applied.rejected;
  } catch {
    const { planTurn } = await import("@/lib/orchestrator/plan");
    speech = planTurn(rawText).speech || rawText;
  }

  const assistantMessage = await insertMessage(
    userId,
    prep.conversation.id,
    "assistant",
    speech,
    estimateTokens(speech),
  );
  const conversation =
    (await touchConversation(userId, prep.conversation.id, prep.nextTitle)) ?? prep.conversation;
  const latency: TurnLatency | null = shouldExposeLatency()
    ? {
        firstTokenMs,
        completeMs: elapsedMs(prep.startedAt),
        search: prep.extra.searchMode === "on",
      }
    : null;
  return {
    ok: true,
    conversation,
    userMessage: prep.userMessage,
    assistantMessage,
    proposals,
    rejected,
    citations,
    latency,
  };
}

export function tryBeginTurn(userId: string, steal = false): boolean {
  if (completing.has(userId) && !steal) return false;
  turnGeneration.set(userId, (turnGeneration.get(userId) ?? 0) + 1);
  completing.add(userId);
  return true;
}

export function currentTurnGeneration(userId: string): number {
  return turnGeneration.get(userId) ?? 0;
}

export function isCurrentTurn(userId: string, generation: number): boolean {
  return turnGeneration.get(userId) === generation;
}

export function endTurn(userId: string): void {
  completing.delete(userId);
}

export function isTurnPrep(value: TurnPrep | OwnedTurnResult): value is TurnPrep {
  return "history" in value && "extra" in value && "startedAt" in value;
}

export async function executeOwnedTurn(opts: {
  userId: string;
  content: string;
  conversationId?: number;
  workspace?: ChatWorkspaceId;
}): Promise<OwnedTurnResult> {
  if (!tryBeginTurn(opts.userId)) {
    return fail("AEVORA is already answering. Wait for this reply.");
  }
  try {
    const prepared = await prepareOwnedTurn(
      opts.userId,
      opts.content,
      opts.conversationId,
      opts.workspace ?? "main",
    );
    if (!isTurnPrep(prepared)) return prepared;
    if (prepared.extra.fastReply) {
      return finalizeOwnedTurn(opts.userId, prepared, prepared.extra.fastReply, [], elapsedMs(prepared.startedAt));
    }
    const { completeTurn } = await import("@/lib/ai/complete.server");
    const result = await completeTurn(
      prepared.history.map((m) => ({ role: m.role, content: m.content })),
      prepared.extra,
    );
    if (!result.ok) {
      return fail(result.error, {
        unavailable: result.unavailable,
        conversation: prepared.conversation,
        userMessage: prepared.userMessage,
        latency: shouldExposeLatency()
          ? { firstTokenMs: null, completeMs: elapsedMs(prepared.startedAt), search: prepared.extra.searchMode === "on" }
          : null,
      });
    }
    return finalizeOwnedTurn(opts.userId, prepared, result.text, result.citations, elapsedMs(prepared.startedAt));
  } finally {
    endTurn(opts.userId);
  }
}

export async function retryOwnedTurn(
  userId: string,
  conversationId: number,
  workspace: ChatWorkspaceId = "main",
): Promise<OwnedTurnResult> {
  if (!tryBeginTurn(userId)) {
    return fail("AEVORA is already answering. Wait for this reply.");
  }
  try {
    const conversation = await readConversation(userId, conversationId);
    if (!conversation || conversation.workspace !== workspace) throw new Error("Conversation not found.");
    const history = await readMessages(userId, conversation.id);
    const last = history[history.length - 1];
    if (!last || last.role !== "user") {
      return fail("Nothing to retry.", { conversation });
    }
    const assembled = await assembleTurnExtra(userId, last.content, conversation.workspace);
    if (assembled.denied) {
      return fail(assembled.denied, { conversation, userMessage: last });
    }
    const prep: TurnPrep = {
      conversation,
      userMessage: last,
      history,
      extra: assembled.extra,
      nextTitle: conversation.title,
      startedAt: Date.now(),
    };
    if (prep.extra.fastReply) {
      return finalizeOwnedTurn(userId, prep, prep.extra.fastReply, [], elapsedMs(prep.startedAt));
    }
    const { completeTurn } = await import("@/lib/ai/complete.server");
    const result = await completeTurn(
      history.map((m) => ({ role: m.role, content: m.content })),
      prep.extra,
    );
    if (!result.ok) {
      return fail(result.error, {
        unavailable: result.unavailable,
        conversation,
        userMessage: last,
      });
    }
    return finalizeOwnedTurn(userId, prep, result.text, result.citations, elapsedMs(prep.startedAt));
  } finally {
    endTurn(userId);
  }
}


