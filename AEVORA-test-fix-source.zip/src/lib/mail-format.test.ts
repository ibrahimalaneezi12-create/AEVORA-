import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { formatDraftsBlock, looksLikeEmail, mapEmailDraft } from "./mail-format.ts";

describe("email drafts", () => {
  it("requires a real recipient and maps a draft", () => {
    assert.equal(looksLikeEmail("not-an-email"), false);
    assert.equal(looksLikeEmail("ibrahim@example.com"), true);
    const row = mapEmailDraft({
      id: 2,
      to_address: "ibrahim@example.com",
      cc_address: "",
      subject: "Hello",
      body: "Hi",
      status: "draft",
      conversation_id: null,
      sent_at: null,
      error: "",
      created_at: "2026-09-18T00:00:00.000Z",
      updated_at: "2026-09-18T00:00:00.000Z",
    });
    assert.equal(row?.status, "draft");
    assert.equal(row?.toAddress, "ibrahim@example.com");
    assert.match(formatDraftsBlock([row!]), /Hello/);
    assert.equal(formatDraftsBlock([]), "");
  });
});
