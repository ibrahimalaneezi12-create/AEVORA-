import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  elapsedMs,
  emptyVoiceLatencyMarks,
  formatVoiceGapRows,
  formatVoiceLatencyRows,
  formatVoiceLatencyValue,
  markFirstToken,
  shouldExposeVoiceDiag,
} from "./latency-format.ts";

describe("latency marks", () => {
  it("never goes negative and records first token once", () => {
    assert.equal(elapsedMs(1000, 1000), 0);
    assert.equal(elapsedMs(1000, 900), 0);
    assert.equal(markFirstToken(0, null), elapsedMs(0));
    assert.equal(markFirstToken(0, 12), 12);
  });
});

describe("voice T2–T11 diagnostic", () => {
  it("includes T0 through T11 and never invents a number for a missing mark", () => {
    const rows = formatVoiceLatencyRows(emptyVoiceLatencyMarks());
    assert.deepEqual(
      rows.map((r) => r.id),
      ["T0", "T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9", "T10", "T11"],
    );
    assert.ok(rows.every((r) => r.value.startsWith("unavailable")));
  });

  it("reports elapsed ms from the origin when both timestamps exist", () => {
    assert.equal(formatVoiceLatencyValue(1000, 1420), "420 ms");
    assert.equal(formatVoiceLatencyValue(1000, 900), "0 ms");
  });

  it("labels T4 and T5 unavailable unless a timestamp was actually recorded", () => {
    const marks = emptyVoiceLatencyMarks();
    marks.originMs = 10;
    marks.at.t2 = 10;
    marks.at.t3 = 18;
    marks.note.t4 = "not visible to this device";
    marks.note.t5 = "not visible to this device";
    const rows = formatVoiceLatencyRows(marks);
    const t2 = rows.find((r) => r.id === "T2");
    const t4 = rows.find((r) => r.id === "T4");
    const t5 = rows.find((r) => r.id === "T5");
    assert.equal(t2?.value, "0 ms");
    assert.equal(t4?.value, "unavailable — not visible to this device");
    assert.equal(t5?.value, "unavailable — not visible to this device");
  });

  it("reports transcript-to-audio gaps only when both ends were stamped", () => {
    const marks = emptyVoiceLatencyMarks();
    marks.at.t2 = 1000;
    marks.at.t3 = 1800;
    marks.at.t6 = 1900;
    marks.at.t8 = 1920;
    marks.at.t9 = 2300;
    marks.at.t10 = 2350;
    const gaps = formatVoiceGapRows(marks);
    assert.equal(gaps.find((r) => r.id === "T2→T3")?.value, "800 ms");
    assert.equal(gaps.find((r) => r.id === "T3→T6")?.value, "100 ms");
    assert.equal(gaps.find((r) => r.id === "T8→T9")?.value, "380 ms");
    assert.equal(gaps.find((r) => r.id === "T2→T10")?.value, "1350 ms");
  });
});

describe("voice diagnostics visibility", () => {
  it("stays off in Node and for normal users", () => {
    assert.equal(shouldExposeVoiceDiag(), false);
  });
});
