export const PHOTO_PROVIDER = "xai";
export const PHOTO_MODEL = "grok-imagine-image-2.0";
export const VIDEO_EDIT_MODEL = "grok-imagine-video";

export const PHOTO_ASPECTS = ["1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3"] as const;
export type PhotoAspect = (typeof PHOTO_ASPECTS)[number];

export const PHOTO_RESOLUTIONS = ["1k", "2k"] as const;
export type PhotoResolution = (typeof PHOTO_RESOLUTIONS)[number];

export const STUDIO_KINDS = ["photo", "video"] as const;
export type StudioKind = (typeof STUDIO_KINDS)[number];

export const STUDIO_ORIGINS = ["generate", "upload"] as const;
export type StudioOrigin = (typeof STUDIO_ORIGINS)[number];

export const ASSET_ROLES = ["original", "generated", "edit", "frame"] as const;
export type AssetRole = (typeof ASSET_ROLES)[number];

export const PHOTO_PROMPT_MAX = 2000;
export const PHOTO_TITLE_MAX = 120;
export const PHOTO_MAX_BYTES = 4_000_000;
export const VIDEO_EDIT_MAX_BYTES = 12_000_000;
export const VIDEO_EDIT_MAX_SEC = 8.7;

export const STUDIO_CAPABILITIES = {
  provider: PHOTO_PROVIDER,
  photoModel: PHOTO_MODEL,
  videoEditModel: VIDEO_EDIT_MODEL,
  photoGenerate: true,
  photoEdit: true,
  photoUpload: true,
  videoGenerate: true,
  videoImageToVideo: true,
  videoPromptEdit: true,
  videoUploadMp4: true,
  videoEditMaxSec: VIDEO_EDIT_MAX_SEC,
  native4k: false,
  timelineCut: false,
  slowMotion: false,
  audioRemix: false,
  burnInCaptions: false,
  autoKillDetection: false,
} as const;

export function isPhotoAspect(value: string): value is PhotoAspect {
  return (PHOTO_ASPECTS as readonly string[]).includes(value);
}

export function asPhotoAspect(value: string | null | undefined): PhotoAspect {
  return isPhotoAspect(value || "") ? value as PhotoAspect : "1:1";
}

export function titleFromPrompt(text: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return "Untitled";
  return clean.slice(0, 72);
}

export function parseDataUri(uri: string): { mime: string; b64: string; bytes: number } | null {
  const match = /^data:([^;,]+);base64,([A-Za-z0-9+/=\s]+)$/.exec(uri.trim());
  if (!match) return null;
  const mime = match[1]!.toLowerCase();
  const b64 = match[2]!.replace(/\s+/g, "");
  const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
  const bytes = Math.floor((b64.length * 3) / 4) - padding;
  return { mime, b64, bytes };
}

export function isAllowedPhotoMime(mime: string): boolean {
  return mime === "image/jpeg" || mime === "image/png" || mime === "image/webp" || mime === "image/jpg";
}

export function isAllowedVideoMime(mime: string): boolean {
  return mime === "video/mp4" || mime === "video/quicktime";
}

export function publicStudioError(message: string | null | undefined): string {
  const text = (message || "").trim();
  if (!text) return "Something went wrong. Please try again.";
  if (/sk-[a-zA-Z0-9]|api[_-]?key|bearer\s/i.test(text)) return "Something went wrong. Please try again.";
  if (/\b(403|401)\b/.test(text) || /unavailable|xai key/i.test(text)) {
    return "Studio is unavailable right now.";
  }
  if (/unauthorized/i.test(text)) return "Sign in to use Studio.";
  if (/not found/i.test(text)) return "Not found.";
  if (text.length > 220) return "Something went wrong. Please try again.";
  return text;
}

export function buildPhotoGenerationBody(input: {
  prompt: string;
  aspectRatio: PhotoAspect;
  resolution: PhotoResolution;
}): Record<string, unknown> {
  return {
    model: PHOTO_MODEL,
    prompt: input.prompt,
    n: 1,
    aspect_ratio: input.aspectRatio,
    resolution: input.resolution,
    response_format: "b64_json",
  };
}

export function buildPhotoEditBody(input: {
  prompt: string;
  imageDataUri: string;
  aspectRatio?: PhotoAspect;
}): Record<string, unknown> {
  const body: Record<string, unknown> = {
    model: PHOTO_MODEL,
    prompt: input.prompt,
    image: { url: input.imageDataUri, type: "image_url" },
  };
  if (input.aspectRatio) body.aspect_ratio = input.aspectRatio;
  return body;
}

/** Prompt-based visual edit is supported. Timeline/audio remix is not. */
export function classifyVideoEdit(instruction: string): { ok: true } | { ok: false; reason: string } {
  const text = instruction.trim();
  if (!text) return { ok: false, reason: "Describe the change." };
  if (
    /\b(cut out|trim|first \d+|last \d+|slow[- ]mo(?:tion)?|louder|volume|boring parts|timeline|splice|ffmpeg|20-second|30-second|60-second|2 minute)\b/i.test(
      text,
    )
  ) {
    return {
      ok: false,
      reason:
        "AEVORA can change how a short clip looks — mood, objects, weather, clothing. It cannot cut, slow-motion, raise volume, or make a clip longer. Uploads must be MP4 under 8.7 seconds.",
    };
  }
  return { ok: true };
}

export type StudioAssetView = {
  id: number;
  role: AssetRole;
  versionN: number;
  mime: string;
  prompt: string;
  createdAt: string;
};

export type StudioProject = {
  id: number;
  kind: StudioKind;
  origin: StudioOrigin;
  title: string;
  prompt: string;
  status: string;
  aspectRatio: string;
  currentAssetId: number | null;
  originalAssetId: number | null;
  linkedVideoId: number | null;
  assets: StudioAssetView[];
  createdAt: string;
  updatedAt: string;
};

export type StudioLibraryItem = {
  id: number;
  source: "studio" | "video";
  kind: "photo" | "video";
  title: string;
  status: string;
  updatedAt: string;
};
