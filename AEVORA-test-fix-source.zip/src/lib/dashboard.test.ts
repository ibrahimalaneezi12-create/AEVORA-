import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  calendarDateInZone,
  classifyDue,
  composeDashboard,
  firstName,
  pickActiveGoals,
  pickTodaysTasks,
  relativeLabel,
  DASHBOARD_TASKS_LIMIT,
  type DashboardPending,
} from "./dashboard-format.ts";
import type { Goal, Task } from "./goals-format.ts";
import type { Memory } from "./memory-format.ts";

function goal(partial: Partial<Goal> & Pick<Goal, "id" | "title">): Goal {
  return {
    description: "",
    status: "active",
    targetDate: null,
    createdAt: "2026-09-17T00:00:00.000Z",
    updatedAt: "2026-09-17T00:00:00.000Z",
    ...partial,
  };
}

function task(partial: Partial<Task> & Pick<Task, "id" | "title">): Task {
  return {
    goalId: null,
    notes: "",
    status: "todo",
    dueDate: null,
    sortOrder: 0,
    createdAt: "2026-09-17T00:00:00.000Z",
    updatedAt: "2026-09-17T00:00:00.000Z",
    ...partial,
  };
}

function mem(partial: Partial<Memory> & Pick<Memory, "id" | "title" | "body">): Memory {
  return {
    kind: "fact",
    tags: "",
    source: "user",
    pinned: false,
    createdAt: "2026-09-17T00:00:00.000Z",
    updatedAt: "2026-09-17T00:00:00.000Z",
    ...partial,
  };
}

describe("firstName", () => {
  it("uses the first word of a display name", () => {
    assert.equal(firstName("Ibrahim Step10"), "Ibrahim");
  });

  it("falls back when empty", () => {
    assert.equal(firstName(null), "there");
    assert.equal(firstName("   "), "there");
  });
});

describe("calendarDateInZone", () => {
  it("returns the UTC calendar date", () => {
    assert.equal(calendarDateInZone(new Date("2026-09-17T23:30:00.000Z"), "UTC"), "2026-09-17");
  });

  it("crosses the date line in a far-east zone", () => {
    assert.equal(
      calendarDateInZone(new Date("2026-09-17T23:30:00.000Z"), "Pacific/Auckland"),
      "2026-09-18",
    );
  });

  it("falls back to UTC for an invalid zone", () => {
    assert.equal(calendarDateInZone(new Date("2026-09-17T12:00:00.000Z"), "Not/AZone"), "2026-09-17");
  });
});

describe("classifyDue", () => {
  it("splits overdue, today, upcoming, and undated", () => {
    assert.equal(classifyDue("2026-09-16", "2026-09-17"), "overdue");
    assert.equal(classifyDue("2026-09-17", "2026-09-17"), "today");
    assert.equal(classifyDue("2026-09-18", "2026-09-17"), "upcoming");
    assert.equal(classifyDue(null, "2026-09-17"), "none");
  });
});

describe("pickTodaysTasks", () => {
  const today = "2026-09-17";

  it("keeps overdue and today, drops future, undated, and closed", () => {
    const picked = pickTodaysTasks(
      [
        task({ id: 1, title: "Overdue", dueDate: "2026-09-01" }),
        task({ id: 2, title: "Today", dueDate: today }),
        task({ id: 3, title: "Future", dueDate: "2026-10-01" }),
        task({ id: 4, title: "Undated", dueDate: null }),
        task({ id: 5, title: "Done today", dueDate: today, status: "done" }),
        task({ id: 6, title: "Cancelled", dueDate: today, status: "cancelled" }),
        task({ id: 7, title: "Doing today", dueDate: today, status: "doing" }),
      ],
      today,
    );
    assert.deepEqual(
      picked.map((t) => t.title),
      ["Overdue", "Today", "Doing today"],
    );
  });

  it("sorts overdue before today, then by sort_order", () => {
    const picked = pickTodaysTasks(
      [
        task({ id: 2, title: "Today late", dueDate: today, sortOrder: 2 }),
        task({ id: 1, title: "Today first", dueDate: today, sortOrder: 1 }),
        task({ id: 3, title: "Older overdue", dueDate: "2026-09-01", sortOrder: 9 }),
      ],
      today,
    );
    assert.deepEqual(
      picked.map((t) => t.title),
      ["Older overdue", "Today first", "Today late"],
    );
  });

  it("caps the list", () => {
    const many = Array.from({ length: DASHBOARD_TASKS_LIMIT + 3 }, (_, i) =>
      task({ id: i + 1, title: `T${i}`, dueDate: today }),
    );
    assert.equal(pickTodaysTasks(many, today).length, DASHBOARD_TASKS_LIMIT);
  });
});

describe("pickActiveGoals", () => {
  it("drops paused, done, and archived", () => {
    const picked = pickActiveGoals([
      goal({ id: 1, title: "Live" }),
      goal({ id: 2, title: "Paused", status: "paused" }),
      goal({ id: 3, title: "Done", status: "done" }),
      goal({ id: 4, title: "Archived", status: "archived" }),
    ]);
    assert.deepEqual(
      picked.map((g) => g.title),
      ["Live"],
    );
  });
});

describe("relativeLabel", () => {
  const now = Date.parse("2026-09-17T12:00:00.000Z");

  it("uses compact relative units", () => {
    assert.equal(relativeLabel("2026-09-17T11:59:30.000Z", now), "Just now");
    assert.equal(relativeLabel("2026-09-17T11:50:00.000Z", now), "10m");
    assert.equal(relativeLabel("2026-09-17T09:00:00.000Z", now), "3h");
    assert.equal(relativeLabel("2026-09-15T12:00:00.000Z", now), "2d");
  });
});

describe("composeDashboard", () => {
  const pending: DashboardPending = {
    id: 9,
    conversationId: 3,
    toolId: "memory.save",
    displayName: "Save a memory",
    permissionLevel: "review",
    title: "Save tea preference",
    summary: "Remember black tea.",
    createdAt: "2026-09-17T12:00:00.000Z",
  };

  it("assembles greeting, today, pending, tasks, goals, memories, chat", () => {
    const snap = composeDashboard({
      displayName: "Ibrahim Ali",
      timezone: "UTC",
      now: new Date("2026-09-17T12:00:00.000Z"),
      pendingTotal: 1,
      pending: [pending],
      goals: [goal({ id: 1, title: "Drink less sugar", targetDate: "2026-10-01" })],
      tasks: [
        task({
          id: 4,
          title: "Buy tea",
          dueDate: "2026-09-17",
          goalId: 1,
          status: "doing",
        }),
        task({ id: 5, title: "Future", dueDate: "2026-12-01", goalId: 1 }),
      ],
      memories: [
        mem({
          id: 2,
          title: "Tea preference",
          body: "I drink black tea every morning.",
          pinned: true,
          kind: "preference",
        }),
      ],
      lastConversation: {
        id: 3,
        title: "About tea",
        updatedAt: "2026-09-17T11:00:00.000Z",
      },
    });
    assert.equal(snap.greetingName, "Ibrahim");
    assert.equal(snap.today, "2026-09-17");
    assert.equal(snap.pendingTotal, 1);
    assert.equal(snap.pending[0]?.title, "Save tea preference");
    assert.equal(snap.todaysTasks.length, 1);
    assert.equal(snap.todaysTasks[0]?.goalTitle, "Drink less sugar");
    assert.equal(snap.todaysTasks[0]?.dueKind, "today");
    assert.equal(snap.activeGoals[0]?.openTaskCount, 2);
    assert.equal(snap.recentMemories[0]?.pinned, true);
    assert.match(snap.recentMemories[0]?.bodyPreview ?? "", /black tea/);
    assert.equal(snap.lastConversation?.id, 3);
    assert.equal(JSON.stringify(snap).includes("payload"), false);
  });

  it("does not treat a foreign-looking pending payload field as data", () => {
    const snap = composeDashboard({
      displayName: "A",
      timezone: "UTC",
      now: new Date("2026-09-17T12:00:00.000Z"),
      pendingTotal: 0,
      pending: [],
      goals: [],
      tasks: [],
      memories: [],
      lastConversation: null,
    });
    assert.equal(snap.pending.length, 0);
    assert.equal(snap.lastConversation, null);
    assert.equal(snap.greetingName, "A");
  });
});
