export type TurnLatency = {
  firstTokenMs: number | null;
  completeMs: number;
  search: boolean;
};

export function elapsedMs(startedAt: number, at = Date.now()): number {
  return Math.max(0, at - startedAt);
}

export function markFirstToken(startedAt: number, firstTokenMs: number | null): number {
  return firstTokenMs ?? elapsedMs(startedAt);
}

export function shouldExposeLatency(): boolean {
  return process.env.NODE_ENV !== "production";
}

/** Voice acceptance marks. Never invent a timestamp. */
export const VOICE_LATENCY_STEPS = [
  { id: "T0", key: "t0", label: "user begins speaking" },
  { id: "T1", key: "t1", label: "speech detected" },
  { id: "T2", key: "t2", label: "speech ended" },
  { id: "T3", key: "t3", label: "transcript" },
  { id: "T4", key: "t4", label: "brain received" },
  { id: "T5", key: "t5", label: "model started" },
  { id: "T6", key: "t6", label: "first model output" },
  { id: "T7", key: "t7", label: "first speakable sentence" },
  { id: "T8", key: "t8", label: "TTS request" },
  { id: "T9", key: "t9", label: "TTS audio received" },
  { id: "T10", key: "t10", label: "first audible audio" },
  { id: "T11", key: "t11", label: "response complete" },
] as const;

export type VoiceLatencyKey = (typeof VOICE_LATENCY_STEPS)[number]["key"];

export type VoiceLatencyMarks = {
  originMs: number | null;
  at: Partial<Record<VoiceLatencyKey, number | null>>;
  note: Partial<Record<VoiceLatencyKey, string>>;
};

export function emptyVoiceLatencyMarks(): VoiceLatencyMarks {
  return { originMs: null, at: {}, note: {} };
}

export function formatVoiceLatencyValue(
  originMs: number | null,
  at: number | null | undefined,
  note?: string,
): string {
  if (at == null || originMs == null) {
    return note ? `unavailable — ${note}` : "unavailable";
  }
  return `${Math.max(0, at - originMs)} ms`;
}

export function formatVoiceLatencyRows(marks: VoiceLatencyMarks): {
  id: string;
  label: string;
  value: string;
}[] {
  return VOICE_LATENCY_STEPS.map((step) => ({
    id: step.id,
    label: step.label,
    value: formatVoiceLatencyValue(marks.originMs, marks.at[step.key], marks.note[step.key]),
  }));
}

export function formatVoiceGapRows(marks: VoiceLatencyMarks): {
  id: string;
  label: string;
  value: string;
}[] {
  const at = marks.at;
  const gap = (from: number | null | undefined, to: number | null | undefined) => {
    if (from == null || to == null) return "unavailable";
    return `${Math.max(0, to - from)} ms`;
  };
  return [
    { id: "T2→T3", label: "speech end → transcript", value: gap(at.t2, at.t3) },
    { id: "T3→T6", label: "transcript → first text", value: gap(at.t3, at.t6) },
    { id: "T3→T10", label: "transcript → first audio", value: gap(at.t3, at.t10) },
    { id: "T8→T9", label: "TTS latency", value: gap(at.t8, at.t9) },
    { id: "T2→T10", label: "speech end → first audio", value: gap(at.t2, at.t10) },
  ];
}

export function shouldExposeVoiceDiag(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get("voiceDebug") === "1") return true;
    if (window.localStorage.getItem("aegis-voice-debug") === "1") return true;
  } catch {
    return false;
  }
  return false;
}
