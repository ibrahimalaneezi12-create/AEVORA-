/**
 * Server-only seal for broker secrets. Never import from a client component.
 * Refuses to seal when no server secret exists. Never logs plaintext.
 */
import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from "node:crypto";

const globalAuth = globalThis as typeof globalThis & { __grokAuthPreviewSecret__?: string };

function sealKey(): Buffer | null {
  const raw =
    process.env.BETTER_AUTH_SECRET?.trim() || globalAuth.__grokAuthPreviewSecret__?.trim() || "";
  if (raw.length < 16) return null;
  return scryptSync(raw, "aegis-broker-v1", 32);
}

export function canSealSecrets(): boolean {
  return sealKey() !== null;
}

export function sealSecret(plain: string): string | null {
  const key = sealKey();
  if (!key || !plain) return null;
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("base64url")}.${tag.toString("base64url")}.${enc.toString("base64url")}`;
}

export function openSecret(sealed: string): string | null {
  const key = sealKey();
  if (!key || !sealed) return null;
  const [ivB, tagB, encB] = sealed.split(".");
  if (!ivB || !tagB || !encB) return null;
  try {
    const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(ivB, "base64url"));
    decipher.setAuthTag(Buffer.from(tagB, "base64url"));
    const plain = Buffer.concat([decipher.update(Buffer.from(encB, "base64url")), decipher.final()]);
    return plain.toString("utf8");
  } catch {
    return null;
  }
}
