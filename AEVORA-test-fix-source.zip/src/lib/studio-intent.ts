/**
 * Conversational Studio intent. One surface; AEVORA chooses the operation.
 * Never requires the user to pick Photo / Video / Edit first.
 */

export const STUDIO_ACTIONS = [
  "photo.generate",
  "photo.edit",
  "photo.variation",
  "photo.animate",
  "video.generate",
  "video.edit",
  "video.variation",
] as const;
export type StudioAction = (typeof STUDIO_ACTIONS)[number];

export type StudioIntentInput = {
  prompt: string;
  hasPhotoAttachment: boolean;
  hasVideoAttachment: boolean;
  hasCurrentPhoto: boolean;
  hasCurrentVideo: boolean;
  currentIsUploadedVideo?: boolean;
};

export type StudioIntent = {
  action: StudioAction;
  reason: string;
};

const VIDEO_MAKE_RE =
  /\b(video|clip|scene|cinematic|tiktok|reel|shorts?|montage|animate|animation|10[- ]?second|15[- ]?second|6[- ]?second|bring (?:it|this|that)?\s*to life|turn (?:it|this|that) into a video)\b/i;
const PHOTO_MAKE_RE =
  /\b(photo|photograph|picture|image|still|portrait|snapshot|render a (?:photo|image)|make me a photo)\b/i;
const ANIMATE_RE =
  /\b(bring (?:it|this|that)?\s*to life|animate|make it move|turn (?:it|this|that) into a video|now (?:a )?video|make a video (?:of|from) (?:this|that|it))\b/i;
const VARIATION_RE =
  /\b(another version|create another|variation|regenerate|try again|one more|new version)\b/i;
const EDIT_RE =
  /\b(edit|change|remove|replace|warmer|cooler|darker|brighter|rain|dramatic|background|sky|make it)\b/i;
const VERTICAL_RE = /\b(vertical|portrait|9\s*[x:]\s*16|phone)\b/i;
const REFERS_CURRENT_RE = /\b(this|that|it|the (?:photo|image|picture|clip|video|scene))\b/i;
const NEW_PHOTO_RE =
  /\b(make (?:me )?(?:a |an )?(?:new )?(?:photo|picture|image|still)|new photo|another photo of)\b/i;
const NEW_VIDEO_RE = /\b(make (?:me )?(?:a |an )?(?:new )?(?:video|clip|scene)|new video)\b/i;

export function classifyStudioIntent(input: StudioIntentInput): StudioIntent {
  const prompt = input.prompt.trim();
  const hasPrompt = prompt.length > 0;

  if (input.hasVideoAttachment) {
    return {
      action: "video.edit",
      reason: "An uploaded clip is the source. Describe how it should look.",
    };
  }

  if (input.hasPhotoAttachment) {
    if (ANIMATE_RE.test(prompt) || (VIDEO_MAKE_RE.test(prompt) && !PHOTO_MAKE_RE.test(prompt))) {
      return { action: "photo.animate", reason: "The attached still becomes the first frame." };
    }
    return { action: "photo.edit", reason: "The attached photo is the source to change." };
  }

  if (input.hasCurrentPhoto) {
    if (ANIMATE_RE.test(prompt) || (VIDEO_MAKE_RE.test(prompt) && !PHOTO_MAKE_RE.test(prompt))) {
      return { action: "photo.animate", reason: "Use the current still as the first frame." };
    }
    if (VARIATION_RE.test(prompt) && !EDIT_RE.test(prompt) && !NEW_PHOTO_RE.test(prompt)) {
      return { action: "photo.variation", reason: "Another version of the current still." };
    }
    if (NEW_PHOTO_RE.test(prompt) && !REFERS_CURRENT_RE.test(prompt)) {
      return { action: "photo.generate", reason: "A new still, not an edit of the current one." };
    }
    if (hasPrompt) {
      return { action: "photo.edit", reason: "Refine the current still." };
    }
    return { action: "photo.variation", reason: "Create another version of the current still." };
  }

  if (input.hasCurrentVideo) {
    if (NEW_VIDEO_RE.test(prompt) && !REFERS_CURRENT_RE.test(prompt) && !ANIMATE_RE.test(prompt)) {
      return { action: "video.generate", reason: "A new scene, not a version of the current one." };
    }
    if (VARIATION_RE.test(prompt) || VERTICAL_RE.test(prompt) || !input.currentIsUploadedVideo) {
      if (
        input.currentIsUploadedVideo &&
        EDIT_RE.test(prompt) &&
        !VARIATION_RE.test(prompt) &&
        !VERTICAL_RE.test(prompt)
      ) {
        return { action: "video.edit", reason: "Prompt-edit the uploaded clip." };
      }
      return { action: "video.variation", reason: "A new version of the current scene." };
    }
    return { action: "video.edit", reason: "Prompt-edit the uploaded clip." };
  }

  if (VIDEO_MAKE_RE.test(prompt) && !PHOTO_MAKE_RE.test(prompt)) {
    return { action: "video.generate", reason: "The request is a moving scene." };
  }

  return { action: "photo.generate", reason: "Default creation is a still, then it can be animated." };
}

export function studioSpeechFor(action: StudioAction, title: string, processing = false): string {
  if (processing) {
    if (action === "video.generate" || action === "video.variation" || action === "photo.animate") {
      return "Creating your scene.";
    }
    if (action === "video.edit") return "Editing the clip.";
  }
  switch (action) {
    case "photo.generate":
      return title ? `Here is ${title}.` : "Here is your photo.";
    case "photo.edit":
      return "Updated. The original is still here.";
    case "photo.variation":
      return "Another version.";
    case "photo.animate":
      return processing ? "Bringing this to life." : "The still is now a scene.";
    case "video.generate":
      return title ? `Here is ${title}.` : "Here is your scene.";
    case "video.edit":
      return "Updated. The original clip is still here.";
    case "video.variation":
      return "Another version of the scene.";
  }
}
