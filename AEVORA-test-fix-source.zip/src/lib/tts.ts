import { getBearerToken } from "@/lib/auth/client";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { CURATED_VOICES, TTS_TEXT_MAX } from "@/lib/tts-format";

export { CURATED_VOICES, DEFAULT_TTS_VOICE, lookupCuratedVoice, resolveTtsVoiceId } from "@/lib/tts-format";
export type { CuratedVoice } from "@/lib/tts-format";

export type SpeakResult =
  | { ok: true; mime: string; audioBase64: string; voiceId: string; fallback: false }
  | { ok: false; error: string; fallback: true; unavailable?: boolean };

const speakInput = z.object({
  text: z.string().trim().min(1).max(TTS_TEXT_MAX),
  voiceId: z.string().trim().max(40).optional(),
  locale: z.string().trim().min(2).max(16).optional(),
  speed: z.number().min(0.7).max(1.5).optional(),
});

export const speakText = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => speakInput.parse(input))
  .handler(async ({ data }): Promise<SpeakResult> => {
    const { synthesizeSpeech } = await import("@/lib/tts.server");
    return synthesizeSpeech({
      text: data.text,
      voiceId: data.voiceId,
      locale: data.locale,
      speed: data.speed,
    });
  });

export const listTtsVoices = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async () => {
    return CURATED_VOICES.map((v) => ({ ...v }));
  });

export type SpeakAudioResult =
  | { ok: true; mime: string; audio: ArrayBuffer; ttsMs: number | null }
  | { ok: false; error: string; unavailable?: boolean; ttsMs?: number };

export async function speakAudio(opts: {
  text: string;
  voiceId?: string;
  locale?: string;
  speed?: number;
  signal?: AbortSignal;
}): Promise<SpeakAudioResult> {
  const token = getBearerToken();
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch("/api/tts", {
    method: "POST",
    credentials: "include",
    headers,
    signal: opts.signal,
    body: JSON.stringify({
      text: opts.text,
      voiceId: opts.voiceId,
      locale: opts.locale,
      speed: opts.speed,
    }),
  });
  const ttsHeader = res.headers.get("X-Aegis-Tts-Ms");
  const ttsMs = ttsHeader && /^\d+$/.test(ttsHeader) ? Number(ttsHeader) : null;
  if (res.status === 401) return { ok: false, error: "Sign in to hear AEVORA." };
  const mime = res.headers.get("content-type")?.split(";")[0]?.trim() || "";
  if (mime.startsWith("audio/")) {
    return { ok: true, mime, audio: await res.arrayBuffer(), ttsMs };
  }
  let body: { error?: string; unavailable?: boolean; ttsMs?: number } = {};
  try {
    body = (await res.json()) as { error?: string; unavailable?: boolean; ttsMs?: number };
  } catch {
    body = {};
  }
  return {
    ok: false,
    error: body.error || `Voice could not speak (${res.status}).`,
    unavailable: body.unavailable,
    ttsMs: body.ttsMs ?? ttsMs ?? undefined,
  };
}
