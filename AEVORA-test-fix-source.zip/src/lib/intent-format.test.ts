import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  classifyTurnIntent,
  brokerOrderAllowed,
  intentNeedsCalendar,
  intentNeedsKeep,
  intentNeedsMail,
  intentWantsResearch,
  isCasualSpeech,
  parseLanguageSwitch,
  providerContextFlags,
  shouldSuppressMutatingProposals,
} from "./intent-format.ts";

describe("casual speech is not an action", () => {
  it("treats bored/tired/vague study as conversation", () => {
    assert.equal(isCasualSpeech("I'm bored."), true);
    assert.equal(isCasualSpeech("I'm tired today."), true);
    assert.equal(isCasualSpeech("I need to study more."), true);
    assert.equal(shouldSuppressMutatingProposals("I'm bored."), true);
    assert.equal(classifyTurnIntent("I'm bored.").kind, "conversation");
  });

  it("does not suppress explicit reminder or remember commands", () => {
    assert.equal(isCasualSpeech("Remind me tomorrow at 7 to study."), false);
    assert.equal(shouldSuppressMutatingProposals("Remind me tomorrow at 7 to study."), false);
    assert.equal(classifyTurnIntent("Remind me tomorrow at 7 to study.").kind, "reminder");
    assert.equal(classifyTurnIntent("Remember that I prefer studying at night.").kind, "memory");
  });
});

describe("language switch", () => {
  it("parses switch to Arabic, Spanish, and French", () => {
    assert.equal(parseLanguageSwitch("Switch to Arabic."), "ar");
    assert.equal(parseLanguageSwitch("Switch to Spanish."), "es");
    assert.equal(parseLanguageSwitch("Talk to me in French."), "fr");
    assert.equal(classifyTurnIntent("Switch to Spanish.").kind, "language_switch");
    assert.equal(classifyTurnIntent("Switch to Spanish.").language, "es");
  });
});

describe("planning intent", () => {
  it("recognizes plan my day/week without treating it as a create", () => {
    assert.equal(classifyTurnIntent("Plan my day.").kind, "planning");
    assert.equal(classifyTurnIntent("Plan my week.").kind, "planning");
    assert.equal(shouldSuppressMutatingProposals("Plan my day."), false);
  });
});

describe("search and research", () => {
  it("classifies explicit search and research without mutating", () => {
    assert.equal(classifyTurnIntent("Search for the weather in Cairo.").kind, "search");
    assert.equal(classifyTurnIntent("What's the latest on xAI?").kind, "search");
    assert.equal(classifyTurnIntent("Research the evidence on sleep and memory.").kind, "research");
    assert.equal(shouldSuppressMutatingProposals("Search for the weather in Cairo."), true);
    assert.equal(intentNeedsKeep(classifyTurnIntent("Search for the weather in Cairo.")), false);
    assert.equal(intentNeedsKeep(classifyTurnIntent("Research the evidence on sleep and memory.")), false);
    assert.equal(intentNeedsKeep(classifyTurnIntent("I'm bored.")), false);
    assert.equal(intentNeedsKeep(classifyTurnIntent("Remember that I drink tea.")), true);
  });
});

describe("calendar and mail context gates", () => {
  it("skips calendar and mail for ordinary chat", () => {
    const bored = classifyTurnIntent("I'm bored.");
    assert.equal(intentNeedsCalendar(bored, "I'm bored."), false);
    assert.equal(intentNeedsMail(bored, "I'm bored."), false);
    const math = classifyTurnIntent("What is 17 times 24?");
    assert.equal(intentNeedsCalendar(math, "What is 17 times 24?"), false);
    assert.equal(intentNeedsMail(math, "What is 17 times 24?"), false);
  });

  it("loads calendar for planning and schedule questions", () => {
    const plan = classifyTurnIntent("Plan my day.");
    assert.equal(intentNeedsCalendar(plan, "Plan my day."), true);
    const sched = classifyTurnIntent("What's on my calendar tomorrow?");
    assert.equal(intentNeedsCalendar(sched, "What's on my calendar tomorrow?"), true);
  });

  it("loads mail only for email requests", () => {
    const mail = classifyTurnIntent("Check my unread email.");
    assert.equal(intentNeedsMail(mail, "Check my unread email."), true);
    assert.equal(intentNeedsCalendar(mail, "Check my unread email."), false);
  });
});

describe("business, invest, learning, travel, safety", () => {
  it("classifies those turns without dumping unrelated context", () => {
    assert.equal(classifyTurnIntent("Check my business health.").kind, "business");
    assert.equal(classifyTurnIntent("Research this company.").kind, "invest");
    assert.equal(classifyTurnIntent("Help me study this.").kind, "learning");
    assert.equal(classifyTurnIntent("Plan a trip to Tokyo.").kind, "travel");
    assert.equal(classifyTurnIntent("Is this a scam?").kind, "safety");
    const flags = providerContextFlags(classifyTurnIntent("I'm bored."), "I'm bored.");
    assert.equal(flags.business, false);
    assert.equal(flags.invest, false);
    assert.equal(providerContextFlags(classifyTurnIntent("Check my business health."), "Check my business health.").business, true);
    assert.equal(providerContextFlags(classifyTurnIntent("Research this company."), "Research this company.").keep, false);
    assert.equal(providerContextFlags(classifyTurnIntent("Research this company."), "Research this company.").invest, false);
    assert.equal(providerContextFlags(classifyTurnIntent("What is an ETF?"), "What is an ETF?").invest, false);
    assert.equal(providerContextFlags(classifyTurnIntent("How is my portfolio?"), "How is my portfolio?").invest, true);
    assert.equal(providerContextFlags(classifyTurnIntent("Is my broker connected?"), "Is my broker connected?").invest, true);
    assert.equal(classifyTurnIntent("Is my Alpaca paper account connected?").kind, "invest");
    const afford = providerContextFlags(
      classifyTurnIntent("How much can the business afford to invest?"),
      "How much can the business afford to invest?",
    );
    assert.equal(afford.business, true);
    assert.equal(afford.invest, true);
    assert.equal(afford.mail, false);
    assert.equal(providerContextFlags(classifyTurnIntent("Analyze my investments."), "Analyze my investments.").keep, true);
    assert.equal(classifyTurnIntent("How's the business?").kind, "business");
    assert.equal(classifyTurnIntent("Research my competitors.").kind, "business");
    assert.equal(intentWantsResearch(classifyTurnIntent("Research my competitors."), "Research my competitors."), true);
    assert.equal(classifyTurnIntent("Find opportunities.").kind, "business");
    assert.equal(classifyTurnIntent("What have you been working on?").kind, "question");
    assert.equal(classifyTurnIntent("What needs my attention?").kind, "planning");
    assert.equal(classifyTurnIntent("What should I focus on today?").kind, "planning");
    assert.equal(classifyTurnIntent("What should I focus on in the business?").kind, "business");
    assert.equal(classifyTurnIntent("Why is this happening in the business?").kind, "business");
    assert.equal(classifyTurnIntent("Check my marketing.").kind, "business");
    assert.equal(classifyTurnIntent("Create a plan to grow sales.").kind, "business");
    assert.equal(classifyTurnIntent("Let's test a new price.").kind, "business");
    assert.equal(classifyTurnIntent("Prepare my weekly business review.").kind, "business");
    assert.equal(classifyTurnIntent("Research NVIDIA.").kind, "invest");
    assert.equal(classifyTurnIntent("Compare NVIDIA and AMD.").kind, "invest");
    assert.equal(classifyTurnIntent("Compare Nvidia and AMD.").kind, "invest");
    assert.equal(classifyTurnIntent("Compare Dola and GPT.").kind, "research");
    assert.equal(classifyTurnIntent("Compare Dola and Claude.").kind, "research");
    assert.equal(classifyTurnIntent("Compare Apple and Microsoft.").kind, "research");
    assert.equal(classifyTurnIntent("How diversified am I?").kind, "invest");
    assert.equal(providerContextFlags(classifyTurnIntent("How diversified am I?"), "How diversified am I?").invest, true);
    assert.equal(providerContextFlags(classifyTurnIntent("Should I rebalance?"), "Should I rebalance?").invest, true);
    assert.equal(providerContextFlags(classifyTurnIntent("What is a bull case?"), "What is a bull case?").invest, false);
    const trade = classifyTurnIntent("Invest £500 according to my investment plan.");
    assert.equal(trade.kind, "invest");
    assert.equal(trade.suppressMutations, true);
    assert.match(trade.note, /no broker/i);
    assert.equal(classifyTurnIntent("Buy 10 shares of NVDA").suppressMutations, true);
    const plan = providerContextFlags(trade, "Invest £500 according to my investment plan.");
    assert.equal(plan.invest, true);
    assert.equal(plan.keep, true);
    assert.equal(plan.business, false);
    assert.equal(brokerOrderAllowed("Invest £500 according to my investment plan."), true);
    assert.equal(brokerOrderAllowed("What is an ETF?"), false);
  });
});
