/**
 * Providers this keep can actually talk to.
 * Connected means a provider call succeeded. Anything else stays honest.
 */
export type LinkCategory = "Sales" | "Marketing" | "Finance" | "Operations" | "Communication";

export type LinkStatus =
  | "connected"
  | "not_connected"
  | "not_configured"
  | "authorization_required"
  | "connection_error"
  | "provider_unavailable";

export type BusinessLink = {
  id: string;
  category: LinkCategory;
  name: string;
  available: boolean;
  connected: boolean;
  status: LinkStatus;
  detail: string;
  lastCheckedAt: string;
  loginUrl: string;
  connect: "none" | "token" | "oauth" | "gate" | "shopify";
};

export function linkStatusLabel(status: LinkStatus): string {
  if (status === "connected") return "Connected";
  if (status === "not_configured") return "Needs configuration";
  if (status === "authorization_required") return "Needs authorization";
  if (status === "connection_error") return "Connection error";
  if (status === "provider_unavailable") return "Needs a provider";
  return "Not connected";
}

type LiveLink = {
  connected?: boolean;
  status?: LinkStatus;
  detail: string;
  lastCheckedAt?: string;
  loginUrl?: string;
  available?: boolean;
};

function asStatus(live: LiveLink | undefined, fallback: LinkStatus): LinkStatus {
  if (live?.status) return live.status;
  if (live?.connected) return "connected";
  return fallback;
}

export function businessLinks(live: {
  gmail: boolean;
  gmailDetail: string;
  gmailStatus?: LinkStatus;
  gmailChecked?: string;
  gmailLoginUrl?: string;
  calendar: boolean;
  calendarDetail: string;
  calendarStatus?: LinkStatus;
  calendarChecked?: string;
  calendarLoginUrl?: string;
  hubspot?: LiveLink;
  shopify?: LiveLink;
  ads?: LiveLink;
  books?: LiveLink;
  inventory?: LiveLink;
}): BusinessLink[] {
  const gmailStatus = live.gmailStatus ?? (live.gmail ? "connected" : "not_connected");
  const calendarStatus = live.calendarStatus ?? (live.calendar ? "connected" : "not_connected");
  const hubspotStatus = asStatus(live.hubspot, "not_connected");
  const shopifyStatus = asStatus(live.shopify, "not_connected");
  const ads = externalLink("ads", "Marketing", "Google Ads", live.ads, "Google Ads uses OAuth. No ads app is registered here, so spend is not being read.");
  const books = externalLink(
    "books",
    "Finance",
    "QuickBooks",
    live.books,
    "QuickBooks uses OAuth. No accounting app is registered here, so revenue is not being calculated.",
  );
  const inventory = externalLink(
    "inventory",
    "Operations",
    "Inventory",
    live.inventory,
    "Inventory is read from Shopify. No other inventory provider is registered, so stock is not being read.",
    "provider_unavailable",
  );
  return [
    {
      id: "gmail",
      category: "Communication",
      name: "Gmail",
      available: true,
      connected: gmailStatus === "connected",
      status: gmailStatus,
      detail: live.gmailDetail,
      lastCheckedAt: live.gmailChecked ?? "",
      loginUrl: live.gmailLoginUrl ?? "",
      connect: gmailStatus === "connected" ? "none" : "gate",
    },
    {
      id: "calendar",
      category: "Operations",
      name: "Google Calendar",
      available: true,
      connected: calendarStatus === "connected",
      status: calendarStatus,
      detail: live.calendarDetail,
      lastCheckedAt: live.calendarChecked ?? "",
      loginUrl: live.calendarLoginUrl ?? "",
      connect: calendarStatus === "connected" ? "none" : "gate",
    },
    {
      id: "crm",
      category: "Sales",
      name: "HubSpot",
      available: true,
      connected: hubspotStatus === "connected",
      status: hubspotStatus,
      detail: live.hubspot?.detail ?? "HubSpot is not connected. Leads are not being read.",
      lastCheckedAt: live.hubspot?.lastCheckedAt ?? "",
      loginUrl: "",
      connect: "token",
    },
    {
      id: "shop",
      category: "Sales",
      name: "Shopify",
      available: true,
      connected: shopifyStatus === "connected",
      status: shopifyStatus,
      detail: live.shopify?.detail ?? "Shopify is not connected. Orders are not being read.",
      lastCheckedAt: live.shopify?.lastCheckedAt ?? "",
      loginUrl: "",
      connect: "token",
    },
    ads,
    books,
    inventory,
  ];
}

function externalLink(
  id: string,
  category: LinkCategory,
  name: string,
  live: LiveLink | undefined,
  fallback: string,
  missing: LinkStatus = "not_configured",
): BusinessLink {
  const status = live?.status ?? missing;
  const available =
    (live?.available === true || status === "connected") && status !== "not_configured" && status !== "provider_unavailable";
  return {
    id,
    category,
    name,
    available,
    connected: status === "connected",
    status,
    detail: live?.detail || fallback,
    lastCheckedAt: live?.lastCheckedAt ?? "",
    loginUrl: "",
    connect: status === "connected" ? "none" : id === "inventory" ? "shopify" : "oauth",
  };
}
