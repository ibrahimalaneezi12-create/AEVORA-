import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { appendAudit } from "@/lib/audit";
import {
  MEMORY_BODY_MAX,
  MEMORY_CANDIDATE_LIMIT,
  MEMORY_KINDS,
  MEMORY_LIST_LIMIT,
  MEMORY_RETRIEVE_LIMIT,
  MEMORY_TAGS_MAX,
  MEMORY_TITLE_MAX,
  mapMemory,
  rankMemories,
  sanitizeIlike,
  type Memory,
  type MemoryRow,
} from "./memory-format.ts";

export {
  MEMORY_BODY_MAX,
  MEMORY_CONTEXT_CHAR_BUDGET,
  MEMORY_KINDS,
  MEMORY_LIST_LIMIT,
  MEMORY_RETRIEVE_LIMIT,
  MEMORY_TAGS_MAX,
  MEMORY_TITLE_MAX,
  clipText,
  findConflictingPreference,
  formatMemoryBlock,
  mapMemory,
  rankMemories,
  sanitizeIlike,
  scoreMemory,
  tokenize,
} from "./memory-format.ts";
export type { Memory, MemoryKind } from "./memory-format.ts";

async function readOwn(userId: string, id: number): Promise<Memory | null> {
  const sql = await getSql();
  const rows = await sql<MemoryRow>`
    select id, kind, title, body, tags, source, pinned, created_at, updated_at
    from memories
    where id = ${id} and user_id = ${userId}
  `;
  return rows[0] ? mapMemory(rows[0]) : null;
}

export async function retrieveMemories(
  userId: string,
  query: string,
): Promise<Memory[]> {
  const sql = await getSql();
  const needle = sanitizeIlike(query);
  const pattern = needle ? `%${needle}%` : "";
  const rows = await sql<MemoryRow>`
    select id, kind, title, body, tags, source, pinned, created_at, updated_at
    from memories
    where user_id = ${userId}
    order by
      pinned desc,
      case
        when ${needle} <> '' and (
          title ilike ${pattern}
          or body ilike ${pattern}
          or tags ilike ${pattern}
        ) then 0
        else 1
      end,
      updated_at desc
    limit ${MEMORY_CANDIDATE_LIMIT}
  `;
  const out: Memory[] = [];
  for (const row of rows) {
    const mapped = mapMemory(row);
    if (mapped) out.push(mapped);
  }
  return rankMemories(out, query, MEMORY_RETRIEVE_LIMIT);
}

async function writeAudit(
  userId: string,
  action: string,
  entityId: string,
  detail: string,
): Promise<void> {
  await appendAudit({
    userId,
    actor: "user",
    action,
    entityType: "memory",
    entityId,
    detail,
  });
}

const idInput = z.object({
  id: z.number().int().positive(),
});

const createInput = z.object({
  kind: z.enum(MEMORY_KINDS),
  title: z.string().trim().min(1, "Add a title.").max(MEMORY_TITLE_MAX),
  body: z.string().trim().min(1, "Add the memory.").max(MEMORY_BODY_MAX),
  tags: z.string().max(MEMORY_TAGS_MAX),
  pinned: z.boolean(),
});

const updateInput = createInput.extend({
  id: z.number().int().positive(),
});

export const listMemories = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Memory[]> => {
    const sql = await getSql();
    const rows = await sql<MemoryRow>`
      select id, kind, title, body, tags, source, pinned, created_at, updated_at
      from memories
      where user_id = ${context.userId}
      order by pinned desc, updated_at desc
      limit ${MEMORY_LIST_LIMIT}
    `;
    const out: Memory[] = [];
    for (const row of rows) {
      const mapped = mapMemory(row);
      if (mapped) out.push(mapped);
    }
    return out;
  });

export const getMemory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<Memory> => {
    const row = await readOwn(context.userId, data.id);
    if (!row) throw new Error("Memory not found.");
    return row;
  });

export const createMemory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => createInput.parse(input))
  .handler(async ({ context, data }): Promise<Memory> => {
    const sql = await getSql();
    const tags = data.tags.trim();
    const rows = await sql<MemoryRow>`
      insert into memories (user_id, kind, title, body, tags, source, pinned)
      values (
        ${context.userId},
        ${data.kind},
        ${data.title},
        ${data.body},
        ${tags},
        ${"user"},
        ${data.pinned}
      )
      returning id, kind, title, body, tags, source, pinned, created_at, updated_at
    `;
    const mapped = rows[0] ? mapMemory(rows[0]) : null;
    if (!mapped) throw new Error("Memory could not be saved.");
    await writeAudit(context.userId, "memory.created", String(mapped.id), mapped.title);
    return mapped;
  });

export const updateMemory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => updateInput.parse(input))
  .handler(async ({ context, data }): Promise<Memory> => {
    const sql = await getSql();
    const tags = data.tags.trim();
    const rows = await sql<MemoryRow>`
      update memories
      set
        kind = ${data.kind},
        title = ${data.title},
        body = ${data.body},
        tags = ${tags},
        pinned = ${data.pinned},
        updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
      returning id, kind, title, body, tags, source, pinned, created_at, updated_at
    `;
    const mapped = rows[0] ? mapMemory(rows[0]) : null;
    if (!mapped) throw new Error("Memory not found.");
    await writeAudit(context.userId, "memory.updated", String(mapped.id), mapped.title);
    return mapped;
  });

export const deleteMemory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<{ ok: true }> => {
    const sql = await getSql();
    const rows = await sql<{ id: unknown }>`
      delete from memories
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `;
    if (!rows[0]) throw new Error("Memory not found.");
    await writeAudit(context.userId, "memory.deleted", String(data.id), "");
    return { ok: true };
  });

export const retrieveMemoriesForChat = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ query: z.string().max(MEMORY_BODY_MAX) }).parse(input),
  )
  .handler(async ({ context, data }): Promise<Memory[]> => {
    return retrieveMemories(context.userId, data.query);
  });
