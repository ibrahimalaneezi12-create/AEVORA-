import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { canonicalSpeechText, nextSpeakableChunks } from "./canonical-response.ts";

describe("canonical response stream", () => {
  it("uses the same visible text for speech and drops the proposal fence", () => {
    const raw =
      "I can help with that. <<<aegis-proposals\n[{\"tool_id\":\"task.create\"}]\n>>>";
    assert.equal(canonicalSpeechText(raw), "I can help with that.");
  });

  it("speaks finished clauses while the stream is still growing", () => {
    const growing =
      "Yeah, I can help with that. The weather tomorrow looks clear across the afternoon";
    const first = nextSpeakableChunks({ canonical: growing, already: 0, ended: false });
    assert.ok(first.chunks.length >= 1);
    assert.equal(first.chunks[0]?.startsWith("Yeah, I can help with that"), true);
    assert.equal(first.chunks.join(" ").includes("afternoon"), false);
  });

  it("flushes the remainder of the SAME text when the stream ends", () => {
    const full = "It's 8:15 PM (UTC).";
    const live = nextSpeakableChunks({ canonical: full, already: 0, ended: false });
    const done = nextSpeakableChunks({
      canonical: full,
      already: live.nextIndex,
      ended: true,
    });
    const spoken = [...live.chunks, ...done.chunks].join(" ").trim();
    assert.match(spoken, /8:15 PM/);
    const again = nextSpeakableChunks({
      canonical: full,
      already: done.nextIndex || live.nextIndex,
      ended: true,
    });
    assert.deepEqual(again.chunks, []);
  });

  it("does not emit a second answer after a finished stream", () => {
    const text = "First sentence. Second sentence is a bit longer than the first one.";
    const a = nextSpeakableChunks({ canonical: text, already: 0, ended: true });
    const b = nextSpeakableChunks({ canonical: text, already: a.nextIndex, ended: true });
    assert.ok(a.chunks.length >= 1);
    assert.deepEqual(b.chunks, []);
  });

  it("starts the first finished sentence without waiting to merge a second one", () => {
    const growing = "It's 8:15 PM (UTC). I can also tell you the date if you want";
    const first = nextSpeakableChunks({ canonical: growing, already: 0, ended: false });
    assert.equal(first.chunks[0], "It's 8:15 PM (UTC).");
    assert.equal(first.chunks.join(" ").includes("date"), false);
  });
});
