import { formatInZone, resolveTimeZone } from "./time-format.ts";

export type FactKind = "time" | "date" | "day" | "math" | "convert";
export type FactAnswer = { kind: FactKind; text: string };

const TIME_RE =
  /^(?:hey aegis[, ]+)?(?:what(?:'?s| is)(?: the)?(?: current)? time|what time is it|time now|كم الساعة|ما(?: هو)? الوقت)\s*[.?!؟]*$/i;
const DATE_RE =
  /^(?:hey aegis[, ]+)?(?:what(?:'?s| is)(?: the)?(?: current)? date|what date is it|what(?:'?s| is) today(?:'?s date)?|ما(?: هو)? التاريخ)\s*[.?!؟]*$/i;
const DAY_RE =
  /^(?:hey aegis[, ]+)?(?:what(?:'?s| is)(?: the)?(?: current)? day|what day is it|what day(?: of the week)? is it|ما(?: هو)? اليوم)\s*[.?!؟]*$/i;
const MATH_WRAP_RE =
  /^(?:hey aegis[, ]+)?(?:what(?:'?s| is)|calculate|compute)?\s*(.+)$/i;
const CONVERT_RE =
  /^(?:hey aegis[, ]+)?(?:convert\s+)?(-?\d+(?:\.\d+)?)\s*(miles?|mi|kilometers?|km|pounds?|lbs?|kilograms?|kgs?|celsius|centigrade|°?c|fahrenheit|°?f|feet|ft|meters?|m)\s+(?:to|in|into)\s+(miles?|mi|kilometers?|km|pounds?|lbs?|kilograms?|kgs?|celsius|centigrade|°?c|fahrenheit|°?f|feet|ft|meters?|m)\s*[.?!]*$/i;

const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export function looksLikeFact(text: string): boolean {
  return answerFact(text, { now: new Date(), timeZone: "UTC" }) != null;
}

export function answerFact(
  text: string,
  opts: { now: Date; timeZone: string; locale?: string },
): FactAnswer | null {
  const trimmed = text.trim();
  if (!trimmed || trimmed.length > 120) return null;
  const zone = resolveTimeZone(opts.timeZone);
  const local = formatInZone(opts.now, zone);
  if (TIME_RE.test(trimmed)) {
    return { kind: "time", text: formatClock(local.time, zone) };
  }
  if (DAY_RE.test(trimmed)) {
    return { kind: "day", text: `It's ${WEEKDAYS[local.weekday] ?? "today"}.` };
  }
  if (DATE_RE.test(trimmed)) {
    return { kind: "date", text: formatPrettyDate(local.date, local.weekday) };
  }
  const converted = convertUnits(trimmed);
  if (converted) return converted;
  const math = evaluateMath(trimmed);
  if (math) return math;
  return null;
}

function formatClock(hhmm: string, zone: string): string {
  const [hs, ms] = hhmm.split(":");
  const hour = Number(hs);
  const minute = Number(ms);
  const suffix = hour >= 12 ? "PM" : "AM";
  const h12 = hour % 12 || 12;
  const label = zone === "UTC" ? "UTC" : zone.replace(/_/g, " ");
  return `It's ${h12}:${String(minute).padStart(2, "0")} ${suffix} (${label}).`;
}

function formatPrettyDate(iso: string, weekday: number): string {
  const [y, m, d] = iso.split("-");
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const month = months[Number(m) - 1] ?? m;
  return `It's ${WEEKDAYS[weekday] ?? ""}, ${month} ${Number(d)}, ${y}.`.replace(/^It's ,/, "It's");
}

function evaluateMath(text: string): FactAnswer | null {
  const wrap = text.trim().match(MATH_WRAP_RE);
  let expr = (wrap?.[1] ?? text).trim();
  expr = expr.replace(/what(?:'?s| is)\s+/i, "");
  expr = expr.replace(/[?!.؟]+$/g, "");
  expr = expr.replace(/\btimes\b/gi, "*").replace(/\bx\b/gi, "*");
  expr = expr.replace(/[×]/g, "*").replace(/[÷]/g, "/");
  expr = expr.replace(/\s+/g, "");
  if (!/^[\d.+*/()-]+$/.test(expr)) return null;
  if (expr.length < 3 || expr.length > 40) return null;
  if (!/\d/.test(expr) || !/[+*/-]/.test(expr)) return null;
  if (/\*\*|\/{2}|[+]{2,}|[*]{2,}|[/]{2,}/.test(expr.replace(/^-/, ""))) return null;
  let value: number;
  try {
    value = Function(`"use strict"; return (${expr})`)() as number;
  } catch {
    return null;
  }
  if (typeof value !== "number" || !Number.isFinite(value)) return null;
  const pretty = Number.isInteger(value) ? String(value) : String(Math.round(value * 1e6) / 1e6);
  return { kind: "math", text: pretty };
}

type Unit =
  | "mi"
  | "km"
  | "lb"
  | "kg"
  | "c"
  | "f"
  | "ft"
  | "m";

function unitOf(raw: string): Unit | null {
  const t = raw.toLowerCase().replace("°", "");
  if (t.startsWith("mi") || t === "mile" || t === "miles") return "mi";
  if (t.startsWith("km") || t.startsWith("kilo")) return "km";
  if (t.startsWith("lb") || t.startsWith("pound")) return "lb";
  if (t.startsWith("kg")) return "kg";
  if (t === "c" || t.startsWith("cels") || t.startsWith("cent")) return "c";
  if (t === "f" || t.startsWith("fahr")) return "f";
  if (t === "ft" || t.startsWith("feet") || t === "foot") return "ft";
  if (t === "m" || t.startsWith("meter") || t.startsWith("metre")) return "m";
  return null;
}

function convertUnits(text: string): FactAnswer | null {
  const m = text.trim().match(CONVERT_RE);
  if (!m) return null;
  const amount = Number(m[1]);
  const from = unitOf(m[2] ?? "");
  const to = unitOf(m[3] ?? "");
  if (!Number.isFinite(amount) || !from || !to || from === to) return null;
  const table: Record<string, (n: number) => number> = {
    "mi:km": (n) => n * 1.60934,
    "km:mi": (n) => n / 1.60934,
    "lb:kg": (n) => n * 0.453592,
    "kg:lb": (n) => n / 0.453592,
    "ft:m": (n) => n * 0.3048,
    "m:ft": (n) => n / 0.3048,
    "c:f": (n) => (n * 9) / 5 + 32,
    "f:c": (n) => ((n - 32) * 5) / 9,
  };
  const fn = table[`${from}:${to}`];
  if (!fn) return null;
  const out = fn(amount);
  const pretty = Number.isInteger(out) ? String(out) : String(Math.round(out * 1000) / 1000);
  return { kind: "convert", text: `${pretty}` };
}
