import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  GOAL_STATUSES,
  TASK_STATUSES,
  asDateOnly,
  emptyToNull,
  mapGoal,
  mapTask,
  taskMayLinkToGoal,
} from "./goals-format.ts";

describe("status sets", () => {
  it("matches spec §6.4 for goals", () => {
    assert.deepEqual([...GOAL_STATUSES], ["active", "paused", "done", "archived"]);
  });

  it("matches spec §6.4 for tasks", () => {
    assert.deepEqual([...TASK_STATUSES], ["todo", "doing", "done", "cancelled"]);
  });
});

describe("asDateOnly", () => {
  it("returns YYYY-MM-DD from a Date", () => {
    assert.equal(asDateOnly(new Date("2026-09-17T12:00:00.000Z")), "2026-09-17");
  });

  it("returns null for empty values", () => {
    assert.equal(asDateOnly(null), null);
    assert.equal(asDateOnly(""), null);
  });

  it("clips a timestamp string", () => {
    assert.equal(asDateOnly("2026-01-02 00:00:00"), "2026-01-02");
  });
});

describe("emptyToNull", () => {
  it("turns blank strings into null", () => {
    assert.equal(emptyToNull("  "), null);
    assert.equal(emptyToNull("2026-09-17"), "2026-09-17");
    assert.equal(emptyToNull(null), null);
  });
});

describe("mapGoal / mapTask", () => {
  it("drops invalid ids", () => {
    assert.equal(
      mapGoal({
        id: 0,
        title: "x",
        description: "",
        status: "active",
        target_date: null,
        created_at: "2026-09-17",
        updated_at: "2026-09-17",
      }),
      null,
    );
  });

  it("falls unknown goal status back to active", () => {
    const goal = mapGoal({
      id: 1,
      title: "Aim",
      description: "",
      status: "mystery",
      target_date: null,
      created_at: "2026-09-17T00:00:00.000Z",
      updated_at: "2026-09-17T00:00:00.000Z",
    });
    assert.equal(goal?.status, "active");
  });

  it("maps a linked task", () => {
    const task = mapTask({
      id: 4,
      goal_id: 2,
      title: "Buy tea",
      notes: "",
      status: "todo",
      due_date: "2026-09-20",
      sort_order: 1,
      created_at: "2026-09-17T00:00:00.000Z",
      updated_at: "2026-09-17T00:00:00.000Z",
    });
    assert.equal(task?.goalId, 2);
    assert.equal(task?.dueDate, "2026-09-20");
    assert.equal(task?.status, "todo");
  });

  it("treats missing goal_id as unlinked", () => {
    const task = mapTask({
      id: 5,
      goal_id: null,
      title: "Inbox",
      notes: "",
      status: "mystery",
      due_date: null,
      sort_order: 0,
      created_at: "2026-09-17T00:00:00.000Z",
      updated_at: "2026-09-17T00:00:00.000Z",
    });
    assert.equal(task?.goalId, null);
    assert.equal(task?.status, "todo");
  });

  it("does not treat a zero goal_id as a link", () => {
    const task = mapTask({
      id: 6,
      goal_id: 0,
      title: "Zero",
      notes: "",
      status: "todo",
      due_date: null,
      sort_order: 0,
      created_at: "2026-09-17T00:00:00.000Z",
      updated_at: "2026-09-17T00:00:00.000Z",
    });
    assert.equal(task?.goalId, null);
  });
});

describe("taskMayLinkToGoal", () => {
  it("allows a task and goal owned by the same user", () => {
    assert.equal(taskMayLinkToGoal("user-a", "user-a"), true);
  });

  it("rejects a goal owned by someone else", () => {
    assert.equal(taskMayLinkToGoal("user-a", "user-b"), false);
  });

  it("rejects a missing goal owner even if the id existed", () => {
    assert.equal(taskMayLinkToGoal("user-a", null), false);
    assert.equal(taskMayLinkToGoal("user-a", undefined), false);
    assert.equal(taskMayLinkToGoal("user-a", ""), false);
  });

  it("rejects an empty task owner", () => {
    assert.equal(taskMayLinkToGoal("", "user-a"), false);
  });
});
