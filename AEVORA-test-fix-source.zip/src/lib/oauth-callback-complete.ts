/**
 * Safari / live-preview OAuth completion helpers.
 * Better Auth 302s to `/auth/popup?done=1` with Set-Cookie. Safari often
 * drops that cookie on the immediate next request (ITP / bounce tracking),
 * so the popup must receive the session token from this response, not from
 * a follow-up Cookie header.
 */
export function cookieValueFromSetCookie(setCookies: string[], name: string): string | null {
  const prefix = `${name}=`;
  for (const raw of setCookies) {
    const first = raw.split(";")[0]?.trim() ?? "";
    if (!first.startsWith(prefix)) continue;
    const value = first.slice(prefix.length);
    if (!value) continue;
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  }
  return null;
}

export function oauthCallbackLocation(response: Response, origin: string): URL | null {
  const location = response.headers.get("location");
  if (!location) return null;
  try {
    return new URL(location, origin);
  } catch {
    return null;
  }
}

export function isPopupDoneLocation(url: URL): boolean {
  return url.pathname === "/auth/popup" && url.searchParams.get("done") === "1";
}
