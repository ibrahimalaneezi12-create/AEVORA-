/**
 * Server-only xAI TTS. Dynamic-import from createServerFn handlers.
 */
import { clampTtsSpeed, resolveTtsVoiceId, ttsLanguageFor, TTS_TEXT_MAX } from "./tts-format.ts";
import { normalizeForSpeech } from "./speech-normalize.ts";
import { readXaiApiKey, xaiBaseUrl } from "./ai/xai-env.server.ts";

export type TtsResult =
  | { ok: true; mime: string; audio: Uint8Array; voiceId: string; fallback: false; ttsMs: number }
  | { ok: false; error: string; fallback: true; unavailable?: boolean; ttsMs?: number };

export async function synthesizeSpeechBytes(opts: {
  text: string;
  voiceId?: string;
  locale?: string;
  speed?: number;
}): Promise<TtsResult> {
  const apiKey = readXaiApiKey();
  if (!apiKey) {
    return { ok: false, fallback: true, unavailable: true, error: "Voice is not available here." };
  }
  const spoken = normalizeForSpeech(opts.text).slice(0, TTS_TEXT_MAX);
  if (!spoken) {
    return { ok: false, fallback: true, error: "Nothing to speak." };
  }
  const voiceId = resolveTtsVoiceId(opts.voiceId);
  const language = ttsLanguageFor(opts.locale);
  const speed = clampTtsSpeed(opts.speed);
  const started = Date.now();
  try {
    const res = await fetch(`${xaiBaseUrl()}/tts`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text: spoken,
        voice_id: voiceId,
        language,
        speed,
        text_normalization: true,
        output_format: {
          codec: "mp3",
          sample_rate: 44100,
          bit_rate: 192000,
        },
      }),
    });
    const ttsMs = Date.now() - started;
    if (!res.ok) {
      return { ok: false, fallback: true, error: `Voice could not speak (${res.status}).`, ttsMs };
    }
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.byteLength < 64) {
      return { ok: false, fallback: true, error: "Voice returned empty audio.", ttsMs };
    }
    const mime = res.headers.get("content-type")?.split(";")[0]?.trim() || "audio/mpeg";
    return {
      ok: true,
      fallback: false,
      mime,
      audio: new Uint8Array(buf),
      voiceId,
      ttsMs,
    };
  } catch {
    return { ok: false, fallback: true, error: "Voice could not be reached.", ttsMs: Date.now() - started };
  }
}

export async function synthesizeSpeech(opts: {
  text: string;
  voiceId?: string;
  locale?: string;
  speed?: number;
}): Promise<
  | { ok: true; mime: string; audioBase64: string; voiceId: string; fallback: false; ttsMs: number }
  | { ok: false; error: string; fallback: true; unavailable?: boolean; ttsMs?: number }
> {
  const result = await synthesizeSpeechBytes(opts);
  if (!result.ok) return result;
  return {
    ok: true,
    fallback: false,
    mime: result.mime,
    audioBase64: Buffer.from(result.audio).toString("base64"),
    voiceId: result.voiceId,
    ttsMs: result.ttsMs,
  };
}
