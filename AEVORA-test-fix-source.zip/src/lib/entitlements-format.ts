export const ENTITLEMENT_PLANS = ["founder", "free", "plus", "pro", "business"] as const;
export type EntitlementPlan = (typeof ENTITLEMENT_PLANS)[number];

export const ENTITLEMENT_FEATURES = [
  "chat",
  "memory",
  "tasks",
  "goals",
  "reminders",
  "planning",
  "voice",
  "voicePremium",
  "search",
  "research",
  "calendar",
  "email",
  "creation",
  "pulse",
  "businessBasic",
  "businessManager",
  "investBasic",
  "investCopilot",
  "investOperator",
] as const;
export type EntitlementFeature = (typeof ENTITLEMENT_FEATURES)[number];

export type Entitlement = {
  userId: string;
  plan: EntitlementPlan;
  grantedAt: string;
  grantedReason: string;
  price: string;
  fullAccess: boolean;
};

/** Billing is not connected. Full plans stay founder, legacy business, and pro. */
const FULL_PLANS = new Set<EntitlementPlan>(["founder", "pro", "business"]);

const FREE_FEATURES = new Set<EntitlementFeature>([
  "chat",
  "memory",
  "tasks",
  "goals",
  "reminders",
  "planning",
  "voice",
  "pulse",
  "businessBasic",
  "investBasic",
]);

const PLUS_FEATURES = new Set<EntitlementFeature>([
  ...FREE_FEATURES,
  "voicePremium",
  "search",
  "research",
  "calendar",
  "email",
  "creation",
  "investCopilot",
]);

export function isEntitlementPlan(value: string | null | undefined): value is EntitlementPlan {
  return (
    value === "founder" ||
    value === "free" ||
    value === "plus" ||
    value === "pro" ||
    value === "business"
  );
}

export function asEntitlementPlan(value: string | null | undefined): EntitlementPlan {
  return isEntitlementPlan(value) ? value : "free";
}

export function planHasFullAccess(plan: EntitlementPlan): boolean {
  return FULL_PLANS.has(plan);
}

export function planPriceLabel(plan: EntitlementPlan): string {
  if (plan === "founder") return "£0";
  if (plan === "free") return "Free";
  if (plan === "plus") return "Plus";
  if (plan === "pro") return "Pro";
  return "Business";
}

export function planDisplayName(plan: EntitlementPlan): string {
  if (plan === "founder") return "Founder";
  if (plan === "free") return "Free";
  if (plan === "plus") return "Plus";
  if (plan === "pro") return "Pro";
  return "Business";
}

/**
 * Entitlement is billing, not authorization. Founder does not bypass
 * confirmation, the registry, or ownership.
 */
export function planAllowsFeature(plan: EntitlementPlan, feature: EntitlementFeature): boolean {
  if (planHasFullAccess(plan)) return true;
  if (plan === "plus") return PLUS_FEATURES.has(feature);
  return FREE_FEATURES.has(feature);
}

export function featureDeniedMessage(plan: EntitlementPlan, feature: EntitlementFeature): string {
  return `${planDisplayName(plan)} does not include ${feature}. Nothing was changed.`;
}

/** No broker integration exists in this product. Do not flip this to fake execution. */
export const BROKER_CONNECTED = false;

/** No business system (sales, ads, books) is connected. Do not invent monitoring. */
export const BUSINESS_SYSTEMS_CONNECTED = false;

export type OperatorDecision = {
  featureAllowed: boolean;
  brokerConnected: boolean;
  canExecute: false;
  reason: string;
};

export function investOperatorDecision(plan: EntitlementPlan): OperatorDecision {
  const featureAllowed = planAllowsFeature(plan, "investOperator");
  if (!featureAllowed) {
    return {
      featureAllowed: false,
      brokerConnected: BROKER_CONNECTED,
      canExecute: false,
      reason: "This plan does not include investment execution. Nothing was sent to a broker.",
    };
  }
  return {
    featureAllowed: true,
    brokerConnected: BROKER_CONNECTED,
    canExecute: false,
    reason:
      "A plan is not a broker connection. Use this user's saved broker only when assembled context says it is connected, and only after they approve the order. If assembled context does not show a connection, say nothing was sent.",
  };
}

export type BusinessMonitorDecision = {
  deeper: boolean;
  systemsConnected: boolean;
  monitoring: false;
  reason: string;
};

export function businessMonitorDecision(plan: EntitlementPlan): BusinessMonitorDecision {
  const deeper = planAllowsFeature(plan, "businessManager");
  if (!deeper) {
    return {
      deeper: false,
      systemsConnected: BUSINESS_SYSTEMS_CONNECTED,
      monitoring: false,
      reason: "Connected-system monitoring is not on this plan. Nothing is being watched in the background.",
    };
  }
  return {
    deeper: true,
    systemsConnected: BUSINESS_SYSTEMS_CONNECTED,
    monitoring: false,
    reason: "Background monitoring is not connected. Summaries use only data a source actually returns.",
  };
}

/**
 * Turn note for Business or Invest. Billing only — it does not grant tools,
 * skip confirmation, or invent a broker.
 */
export function contextTierNote(
  plan: EntitlementPlan,
  kind: "business" | "invest",
): string {
  if (kind === "business") {
    const monitor = businessMonitorDecision(plan);
    const research = planAllowsFeature(plan, "research");
    const depth = monitor.deeper
      ? "Business manager is on. Answer only from saved records and sources this turn actually retrieved. Use a section only when it has lines: what's going well, what needs attention, what is on file, what AEVORA has done, what needs the owner. Omit empty sections. If a saved decision conflicts, quote it and ask before changing it."
      : "Basic business help. Use saved identity and notes only. Do not write a manager report. Do not claim work you did not do.";
    const lookup = research
      ? " Public competitor facts may be researched this turn."
      : " Live competitor lookup is not on this plan. Do not invent competitor facts.";
    return `${depth}${lookup} ${monitor.reason}`;
  }
  const operator = investOperatorDecision(plan);
  const copilot = planAllowsFeature(plan, "investCopilot");
  const research = planAllowsFeature(plan, "research");
  const lookup = research
    ? "Current public information may be looked up this turn. Cite it. If a figure is missing, say so."
    : "Live market lookup is not on this plan. Do not invent prices, filings, or news.";
  const depth = copilot
    ? " Copilot may propose an allocation or rebalance as invest.note kind scenario. That is not an order."
    : " Stay with education, the watchlist, theses, and paper notes. Do not propose a rebalance.";
  return `${lookup}${depth} ${operator.reason}`;
}

/** One honest line for the Invest page. No charts, no fake balances. */
export function investWorkspaceLine(plan: EntitlementPlan): string {
  const operator = investOperatorDecision(plan);
  if (operator.featureAllowed) return operator.reason;
  if (planAllowsFeature(plan, "investCopilot")) {
    return `Deeper analysis and rebalancing ideas stay proposals. ${operator.reason}`;
  }
  return `Education, a watchlist, notes, and paper plans. Live market lookup is not included. ${operator.reason}`;
}
