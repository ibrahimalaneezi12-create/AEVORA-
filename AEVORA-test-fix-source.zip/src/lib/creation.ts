import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { creationSavePayload } from "@/lib/confirm-format";
import {
  asCreationKind,
  CREATION_KINDS,
  mapCreation,
  type Creation,
  type CreationRow,
} from "@/lib/creation-format";
import type { ToolHandler } from "@/lib/tools/types";

export type { Creation } from "@/lib/creation-format";
export { CREATION_KINDS } from "@/lib/creation-format";

export const creationSaveHandler: ToolHandler = async ({
  userId,
  payload,
  title: proposalTitle,
  summary,
}) => {
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "creation");
  const parsed = creationSavePayload.parse(payload);
  const title = (parsed.title ?? proposalTitle).trim();
  if (!title) throw new Error("Add a title.");
  const body = (parsed.body ?? summary).trim();
  if (!body) throw new Error("Add the writing.");
  const kind = asCreationKind(parsed.kind);
  const sql = await getSql();
  if (parsed.id) {
    const rows = await sql<CreationRow>`
      update creations
      set
        kind = ${kind},
        title = ${title.slice(0, 120)},
        body = ${body.slice(0, 12000)},
        locale = ${(parsed.locale ?? "en").trim() || "en"},
        updated_at = now()
      where id = ${parsed.id} and user_id = ${userId}
      returning id, kind, title, body, locale, conversation_id, created_at, updated_at
    `;
    const mapped = rows[0] ? mapCreation(rows[0]) : null;
    if (!mapped) throw new Error("Creation not found.");
    return `Updated writing ${mapped.id}.`;
  }
  const rows = await sql<CreationRow>`
    insert into creations (user_id, kind, title, body, locale)
    values (
      ${userId},
      ${kind},
      ${title.slice(0, 120)},
      ${body.slice(0, 12000)},
      ${(parsed.locale ?? "en").trim() || "en"}
    )
    returning id, kind, title, body, locale, conversation_id, created_at, updated_at
  `;
  const mapped = rows[0] ? mapCreation(rows[0]) : null;
  if (!mapped) throw new Error("Writing could not be saved.");
  return `Saved writing ${mapped.id}.`;
};

export const listCreations = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Creation[]> => {
    const sql = await getSql();
    const rows = await sql<CreationRow>`
      select id, kind, title, body, locale, conversation_id, created_at, updated_at
      from creations
      where user_id = ${context.userId}
      order by updated_at desc
      limit 40
    `;
    const out: Creation[] = [];
    for (const row of rows) {
      const mapped = mapCreation(row);
      if (mapped) out.push(mapped);
    }
    return out;
  });

const saveInput = z.object({
  id: z.number().int().positive().optional(),
  kind: z.enum(CREATION_KINDS).optional(),
  title: z.string().trim().min(1).max(120),
  body: z.string().trim().min(1).max(12000),
  locale: z.string().trim().min(2).max(16).optional(),
});

export const saveCreation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => saveInput.parse(input))
  .handler(async ({ context, data }): Promise<Creation> => {
    const { assertFeature } = await import("@/lib/entitlements");
    await assertFeature(context.userId, "creation");
    const sql = await getSql();
    const kind = data.kind ?? "note";
    const locale = data.locale ?? "en";
    if (data.id) {
      const rows = await sql<CreationRow>`
        update creations
        set kind = ${kind}, title = ${data.title}, body = ${data.body}, locale = ${locale}, updated_at = now()
        where id = ${data.id} and user_id = ${context.userId}
        returning id, kind, title, body, locale, conversation_id, created_at, updated_at
      `;
      const mapped = rows[0] ? mapCreation(rows[0]) : null;
      if (!mapped) throw new Error("Creation not found.");
      return mapped;
    }
    const rows = await sql<CreationRow>`
      insert into creations (user_id, kind, title, body, locale)
      values (${context.userId}, ${kind}, ${data.title}, ${data.body}, ${locale})
      returning id, kind, title, body, locale, conversation_id, created_at, updated_at
    `;
    const mapped = rows[0] ? mapCreation(rows[0]) : null;
    if (!mapped) throw new Error("Writing could not be saved.");
    return mapped;
  });
