import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { appendAudit } from "@/lib/audit";
import {
  GOAL_DESC_MAX,
  GOAL_STATUSES,
  GOAL_TITLE_MAX,
  TASK_NOTES_MAX,
  TASK_STATUSES,
  TASK_TITLE_MAX,
  emptyToNull,
  mapGoal,
  mapTask,
  type Goal,
  type GoalRow,
  type Task,
  type TaskRow,
} from "./goals-format.ts";

export {
  GOAL_DESC_MAX,
  GOAL_STATUSES,
  GOAL_TITLE_MAX,
  TASK_NOTES_MAX,
  TASK_STATUSES,
  TASK_TITLE_MAX,
  asDateOnly,
  emptyToNull,
  mapGoal,
  mapTask,
  taskMayLinkToGoal,
} from "./goals-format.ts";
export type { Goal, GoalStatus, Task, TaskStatus } from "./goals-format.ts";

const dateInput = z
  .union([z.string(), z.null(), z.undefined()])
  .transform((v) => emptyToNull(v ?? ""))
  .refine((v) => v === null || /^\d{4}-\d{2}-\d{2}$/.test(v), {
    message: "Use a calendar date.",
  });

const goalCreateInput = z.object({
  title: z.string().trim().min(1, "Add a title.").max(GOAL_TITLE_MAX),
  description: z.string().max(GOAL_DESC_MAX),
  status: z.enum(GOAL_STATUSES),
  targetDate: dateInput,
});

const goalUpdateInput = goalCreateInput.extend({
  id: z.number().int().positive(),
});

const taskCreateInput = z.object({
  title: z.string().trim().min(1, "Add a title.").max(TASK_TITLE_MAX),
  notes: z.string().max(TASK_NOTES_MAX),
  status: z.enum(TASK_STATUSES),
  dueDate: dateInput,
  goalId: z
    .number()
    .int()
    .positive()
    .nullish()
    .transform((v) => v ?? null),
});

const taskUpdateInput = taskCreateInput.extend({
  id: z.number().int().positive(),
});

const idInput = z.object({
  id: z.number().int().positive(),
});

async function writeAudit(
  userId: string,
  action: string,
  entityType: string,
  entityId: string,
  detail: string,
): Promise<void> {
  await appendAudit({
    userId,
    actor: "user",
    action,
    entityType,
    entityId,
    detail,
  });
}

/**
 * A task may link only when the goal is owned by the same verified session
 * user. Foreign and missing goals look like "not found".
 */
async function assertTaskCanLinkToGoal(taskUserId: string, goalId: number | null): Promise<void> {
  if (goalId == null) return;
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    select id from goals where id = ${goalId} and user_id = ${taskUserId}
  `;
  if (!rows[0]) throw new Error("Goal not found.");
}

export const listGoalsPage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<{ goals: Goal[]; tasks: Task[] }> => {
    const sql = await getSql();
    const goalRows = await sql<GoalRow>`
      select id, title, description, status, target_date, created_at, updated_at
      from goals
      where user_id = ${context.userId}
      order by
        case status
          when 'active' then 0
          when 'paused' then 1
          when 'done' then 2
          else 3
        end,
        updated_at desc
      limit 100
    `;
    const taskRows = await sql<TaskRow>`
      select id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
      from tasks
      where user_id = ${context.userId}
      order by sort_order asc, id asc
      limit 200
    `;
    const goals: Goal[] = [];
    for (const row of goalRows) {
      const mapped = mapGoal(row);
      if (mapped) goals.push(mapped);
    }
    const tasks: Task[] = [];
    for (const row of taskRows) {
      const mapped = mapTask(row);
      if (mapped) tasks.push(mapped);
    }
    return { goals, tasks };
  });

export const getGoal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<Goal> => {
    const sql = await getSql();
    const rows = await sql<GoalRow>`
      select id, title, description, status, target_date, created_at, updated_at
      from goals
      where id = ${data.id} and user_id = ${context.userId}
    `;
    const mapped = rows[0] ? mapGoal(rows[0]) : null;
    if (!mapped) throw new Error("Goal not found.");
    return mapped;
  });

export const getTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<Task> => {
    const sql = await getSql();
    const rows = await sql<TaskRow>`
      select id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
      from tasks
      where id = ${data.id} and user_id = ${context.userId}
    `;
    const mapped = rows[0] ? mapTask(rows[0]) : null;
    if (!mapped) throw new Error("Task not found.");
    return mapped;
  });

export const createGoal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => goalCreateInput.parse(input))
  .handler(async ({ context, data }): Promise<Goal> => {
    const sql = await getSql();
    const description = data.description.trim();
    const rows = await sql<GoalRow>`
      insert into goals (user_id, title, description, status, target_date)
      values (
        ${context.userId},
        ${data.title},
        ${description},
        ${data.status},
        ${data.targetDate}
      )
      returning id, title, description, status, target_date, created_at, updated_at
    `;
    const mapped = rows[0] ? mapGoal(rows[0]) : null;
    if (!mapped) throw new Error("Goal could not be saved.");
    await writeAudit(context.userId, "goal.created", "goal", String(mapped.id), mapped.title);
    return mapped;
  });

export const updateGoal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => goalUpdateInput.parse(input))
  .handler(async ({ context, data }): Promise<Goal> => {
    const sql = await getSql();
    const description = data.description.trim();
    const rows = await sql<GoalRow>`
      update goals
      set
        title = ${data.title},
        description = ${description},
        status = ${data.status},
        target_date = ${data.targetDate},
        updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
      returning id, title, description, status, target_date, created_at, updated_at
    `;
    const mapped = rows[0] ? mapGoal(rows[0]) : null;
    if (!mapped) throw new Error("Goal not found.");
    await writeAudit(context.userId, "goal.updated", "goal", String(mapped.id), mapped.title);
    return mapped;
  });

export const deleteGoal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<{ ok: true }> => {
    const sql = await getSql();
    await sql`
      update tasks
      set goal_id = null, updated_at = now()
      where goal_id = ${data.id} and user_id = ${context.userId}
    `;
    const rows = await sql<{ id: unknown }>`
      delete from goals
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `;
    if (!rows[0]) throw new Error("Goal not found.");
    await writeAudit(context.userId, "goal.deleted", "goal", String(data.id), "");
    return { ok: true };
  });

export const createTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => taskCreateInput.parse(input))
  .handler(async ({ context, data }): Promise<Task> => {
    await assertTaskCanLinkToGoal(context.userId, data.goalId);
    const sql = await getSql();
    const notes = data.notes.trim();
    const max = await sql<{ n: number }>`
      select coalesce(max(sort_order), 0)::int as n
      from tasks
      where user_id = ${context.userId}
    `;
    const sortOrder = (max[0]?.n ?? 0) + 1;
    const rows = await sql<TaskRow>`
      insert into tasks (user_id, goal_id, title, notes, status, due_date, sort_order)
      values (
        ${context.userId},
        ${data.goalId},
        ${data.title},
        ${notes},
        ${data.status},
        ${data.dueDate},
        ${sortOrder}
      )
      returning id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
    `;
    const mapped = rows[0] ? mapTask(rows[0]) : null;
    if (!mapped) throw new Error("Task could not be saved.");
    await writeAudit(context.userId, "task.created", "task", String(mapped.id), mapped.title);
    return mapped;
  });

export const updateTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => taskUpdateInput.parse(input))
  .handler(async ({ context, data }): Promise<Task> => {
    const sql = await getSql();
    const owned = await sql<{ user_id: string }>`
      select user_id from tasks
      where id = ${data.id} and user_id = ${context.userId}
    `;
    if (!owned[0]) throw new Error("Task not found.");
    await assertTaskCanLinkToGoal(owned[0].user_id, data.goalId);
    const notes = data.notes.trim();
    const rows = await sql<TaskRow>`
      update tasks
      set
        goal_id = ${data.goalId},
        title = ${data.title},
        notes = ${notes},
        status = ${data.status},
        due_date = ${data.dueDate},
        updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
      returning id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
    `;
    const mapped = rows[0] ? mapTask(rows[0]) : null;
    if (!mapped) throw new Error("Task not found.");
    await writeAudit(context.userId, "task.updated", "task", String(mapped.id), mapped.title);
    return mapped;
  });

export const deleteTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<{ ok: true }> => {
    const sql = await getSql();
    const rows = await sql<{ id: unknown }>`
      delete from tasks
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `;
    if (!rows[0]) throw new Error("Task not found.");
    await writeAudit(context.userId, "task.deleted", "task", String(data.id), "");
    return { ok: true };
  });
