import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { appendAudit } from "@/lib/audit";
import {
  BUSINESS_CONTEXT_LIMIT,
  BUSINESS_FIELD_MAX,
  BUSINESS_NAME_MAX,
  BUSINESS_NOTE_BODY_MAX,
  BUSINESS_NOTE_CONTEXT_LIMIT,
  BUSINESS_NOTE_KINDS,
  BUSINESS_NOTE_TITLE_MAX,
  composeBusinessBriefing,
  composeBusinessManagerReport,
  decisionWarnings,
  formatBusinessBlock,
  mapBusiness,
  mapBusinessNote,
  type Business,
  type BusinessBriefing,
  type BusinessManagerReport,
  type BusinessNote,
  type BusinessNoteRow,
  type BusinessRow,
} from "./business-format.ts";
import { businessMonitorDecision, type BusinessMonitorDecision } from "./entitlements-format.ts";
import { ensureEntitlement } from "./entitlements.ts";
import { requiredBody, requiredTitle } from "./confirm-format.ts";
import type { ToolHandler } from "./tools/types.ts";

export {
  BUSINESS_NOTE_KINDS,
  composeBusinessBriefing,
  composeBusinessManagerReport,
  formatBusinessBlock,
  businessMayAccess,
} from "./business-format.ts";
export type { Business, BusinessBriefing, BusinessManagerReport, BusinessNote, BusinessNoteKind } from "./business-format.ts";

async function writeAudit(userId: string, action: string, entityId: string, detail: string): Promise<void> {
  await appendAudit({
    userId,
    actor: "user",
    action,
    entityType: "business",
    entityId,
    detail,
  });
}

export async function listOwnBusinessesForContext(userId: string): Promise<{
  businesses: Business[];
  notes: BusinessNote[];
}> {
  const sql = await getSql();
  const [businessRows, noteRows] = await Promise.all([
    sql<BusinessRow>`
      select id, name, offer, audience, notes, created_at, updated_at
      from businesses
      where user_id = ${userId}
      order by updated_at desc
      limit ${BUSINESS_CONTEXT_LIMIT}
    `,
    sql<BusinessNoteRow>`
      select id, business_id, kind, title, body, created_at, updated_at
      from business_notes
      where user_id = ${userId}
      order by updated_at desc
      limit ${BUSINESS_NOTE_CONTEXT_LIMIT}
    `,
  ]);
  const businesses: Business[] = [];
  for (const row of businessRows) {
    const mapped = mapBusiness(row);
    if (mapped) businesses.push(mapped);
  }
  const notes: BusinessNote[] = [];
  for (const row of noteRows) {
    const mapped = mapBusinessNote(row);
    if (mapped) notes.push(mapped);
  }
  return { businesses, notes };
}

async function businessActivity(userId: string): Promise<{ pendingTitles: string[]; executedTitles: string[] }> {
  const sql = await getSql();
  const [pendingRows, executedRows] = await Promise.all([
    sql<{ title: string }>`
      select title
      from proposed_actions
      where user_id = ${userId}
        and status = ${"pending"}
        and tool_id in (${"business.save"}, ${"business.note"}, ${"business.experiment"})
      order by created_at desc
      limit 4
    `,
    sql<{ title: string }>`
      select title
      from proposed_actions
      where user_id = ${userId}
        and status = ${"executed"}
        and tool_id in (${"business.save"}, ${"business.note"}, ${"business.experiment"})
      order by executed_at desc
      limit 4
    `,
  ]);
  return {
    pendingTitles: pendingRows.map((row) => row.title).filter(Boolean),
    executedTitles: executedRows.map((row) => row.title).filter(Boolean),
  };
}

export type BusinessExperiment = {
  id: number;
  hypothesis: string;
  metric: string;
  windowDays: number;
  success: string;
  result: string;
  status: "open" | "recorded";
};

export async function listOwnExperiments(userId: string): Promise<BusinessExperiment[]> {
  const sql = await getSql();
  const rows = await sql<{
    id: unknown;
    hypothesis: string;
    metric: string;
    window_days: unknown;
    success: string;
    result: string;
    status: string;
  }>`
    select id, hypothesis, metric, window_days, success, result, status
    from business_experiments
    where user_id = ${userId}
    order by updated_at desc
    limit 6
  `;
  const out: BusinessExperiment[] = [];
  for (const row of rows) {
    const id = Number(row.id);
    if (!Number.isInteger(id) || id < 1) continue;
    const days = Number(row.window_days);
    out.push({
      id,
      hypothesis: row.hypothesis,
      metric: row.metric,
      windowDays: Number.isInteger(days) && days > 0 ? days : 14,
      success: row.success ?? "",
      result: row.result ?? "",
      status: row.status === "recorded" ? "recorded" : "open",
    });
  }
  return out;
}

/** Owned business block for the model. Manager speech only when the plan includes it. */
export async function loadBusinessContextBlock(userId: string, query: string): Promise<string> {
  const { businesses, notes } = await listOwnBusinessesForContext(userId);
  const lines = [formatBusinessBlock(businesses, notes), ...decisionWarnings(notes, query)].filter(Boolean);
  const entitlement = await ensureEntitlement(userId);
  const activity = await businessActivity(userId);
  if (businessMonitorDecision(entitlement.plan).deeper) {
    const report = composeBusinessManagerReport({ businesses, notes, ...activity });
    if (!report.empty) lines.push(`Manager report (records only; omit empty sections): ${report.speech}`);
  }
  try {
    const { businessHealthSpeech, competitorSpeech, departmentFromQuery, departmentSpeech, executiveBriefSpeech, investigateBusiness } =
      await import("@/lib/business-brain");
    const { listBusinessLinkStates } = await import("@/lib/links");
    const sources = (await listBusinessLinkStates(userId)).map((link) => ({
      id: link.id,
      label: link.name,
      category: link.category,
      connected: link.connected,
      detail: link.detail,
    }));
    const executive = /\bhow(?:['’]s| is) (?:the |my )?business\b/i.test(query) || /\bbusiness health\b/i.test(query);
    if (executive) {
      lines.push(
        executiveBriefSpeech({
          businesses,
          notes,
          sources,
          pendingTitles: activity.pendingTitles,
          executedTitles: activity.executedTitles,
        }),
      );
    } else {
      lines.push(businessHealthSpeech({ businesses, notes, sources }));
    }
    const department = departmentFromQuery(query);
    if (department) lines.push(departmentSpeech(department, notes, sources));
    if (/\bwhy\b/i.test(query)) lines.push(investigateBusiness(query, notes, sources).speech);
    if (/\bcompetitor/i.test(query)) lines.push(competitorSpeech(notes));
    if (/\bopportunit/i.test(query)) {
      const { opportunitiesFromRecords } = await import("@/lib/business-brain");
      lines.push(opportunitiesFromRecords(notes, sources).speech);
    }
    if (/\b(attention|warning|risk)\b/i.test(query)) {
      const { attentionSpeech } = await import("@/lib/business-brain");
      lines.push(attentionSpeech({ notes, sources }));
    }
    if (/\b(morning|brief)\b/i.test(query)) {
      const { businessBriefSpeech } = await import("@/lib/business-brain");
      lines.push(businessBriefSpeech("morning", { businesses, notes, sources }));
    }
    if (/\b(end of (?:the )?day|tonight|wrap up)\b/i.test(query)) {
      const { businessBriefSpeech } = await import("@/lib/business-brain");
      lines.push(businessBriefSpeech("evening", { businesses, notes, sources }));
    }
    if (/\b(weekly|monthly|review)\b/i.test(query)) {
      const { weeklyReviewSpeech } = await import("@/lib/business-brain");
      lines.push(weeklyReviewSpeech({ businesses, notes, sources }));
    }
    if (/\b(email|inbox|lead|follow-?up|gmail)\b/i.test(query)) {
      const { peekGmailInbox } = await import("@/lib/mail");
      const { mailboxSpeech } = await import("@/lib/business-records");
      const mail = await peekGmailInbox();
      lines.push(mailboxSpeech(mail.status, mail.lines));
    }
    if (/\b(calendar|meeting|deadline|schedule)\b/i.test(query)) {
      const { peekGoogleCalendar } = await import("@/lib/calendar");
      const { calendarLinkSpeech } = await import("@/lib/business-records");
      const calendar = await peekGoogleCalendar();
      lines.push(calendarLinkSpeech(calendar.status, calendar.lines));
    }
    if (/\b(lead|customer|pipeline|crm|follow-?up|sales|business)\b/i.test(query)) {
      const { readHubspotForUser } = await import("@/lib/providers.server");
      const { followUpSpeech, leadSpeech } = await import("@/lib/business-records");
      const hub = await readHubspotForUser(userId);
      lines.push(leadSpeech(hub));
      if (hub.connected && hub.leads.length) lines.push(followUpSpeech(hub.leads));
    }
    if (/\b(order|revenue|sales|shop|store|business)\b/i.test(query)) {
      const { readShopifyForUser } = await import("@/lib/providers.server");
      const { orderMoneySpeech } = await import("@/lib/business-records");
      lines.push(orderMoneySpeech(await readShopifyForUser(userId)));
    }
    if (/\b(product|inventory|stock|sku)\b/i.test(query)) {
      const { readShopifyProductsForUser } = await import("@/lib/providers.server");
      const { productStockSpeech } = await import("@/lib/business-records");
      lines.push(productStockSpeech(await readShopifyProductsForUser(userId)));
    }
    if (/\b(ad spend|google ads|campaign)\b/i.test(query)) {
      const { readAdsForUser } = await import("@/lib/providers.server");
      lines.push((await readAdsForUser(userId)).speech);
    }
    if (/\b(quickbooks|accounting|profit|revenue)\b/i.test(query)) {
      const { readBooksForUser } = await import("@/lib/providers.server");
      lines.push((await readBooksForUser(userId)).speech);
    }
    const experiments = await listOwnExperiments(userId);
    const experimentAsk = /\b(experiment|hypothesis|landing page|new price|test (?:a |an )?(?:new )?)/i.test(query);
    if (experimentAsk) {
      if (experiments.length === 0) {
        lines.push("No experiment is saved. A test stores only what you state. I will not invent a result.");
      } else {
        lines.push(
          experiments
            .map((item) => {
              const result = item.result
                ? `Result you wrote: ${item.result}. It was not calculated.`
                : "No result is recorded yet.";
              return `Experiment #${item.id}: ${item.hypothesis}. Metric: ${item.metric}. Window: ${item.windowDays} days. Status: ${item.status}. ${result}`;
            })
            .join("\n"),
        );
      }
    }
  } catch {
    /* keep the saved records even if a connector probe fails */
  }
  return lines.join("\n");
}

export const listBusinessPage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<{
    businesses: Business[];
    notes: BusinessNote[];
    briefing: BusinessBriefing;
    manager: BusinessManagerReport;
    monitor: BusinessMonitorDecision;
    experiments: BusinessExperiment[];
  }> => {
    const userId = context.userId;
    const [{ businesses, notes }, activity, entitlement, experiments] = await Promise.all([
      listOwnBusinessesForContext(userId),
      businessActivity(userId),
      ensureEntitlement(userId),
      listOwnExperiments(userId),
    ]);
    return {
      businesses,
      notes,
      briefing: composeBusinessBriefing(businesses, notes),
      manager: composeBusinessManagerReport({
        businesses,
        notes,
        pendingTitles: activity.pendingTitles,
        executedTitles: activity.executedTitles,
      }),
      monitor: businessMonitorDecision(entitlement.plan),
      experiments,
    };
  });

const saveInput = z.object({
  id: z.number().int().positive().optional(),
  name: z.string().trim().min(1).max(BUSINESS_NAME_MAX),
  offer: z.string().max(BUSINESS_FIELD_MAX).optional(),
  audience: z.string().max(BUSINESS_FIELD_MAX).optional(),
  notes: z.string().max(BUSINESS_FIELD_MAX).optional(),
});

export const saveBusiness = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => saveInput.parse(input))
  .handler(async ({ context, data }): Promise<Business> => {
    const sql = await getSql();
    const offer = (data.offer ?? "").trim();
    const audience = (data.audience ?? "").trim();
    const notes = (data.notes ?? "").trim();
    if (data.id) {
      const rows = await sql<BusinessRow>`
        update businesses
        set
          name = ${data.name},
          offer = ${offer},
          audience = ${audience},
          notes = ${notes},
          updated_at = now()
        where id = ${data.id} and user_id = ${context.userId}
        returning id, name, offer, audience, notes, created_at, updated_at
      `;
      const mapped = rows[0] ? mapBusiness(rows[0]) : null;
      if (!mapped) throw new Error("Business not found.");
      await writeAudit(context.userId, "business.updated", String(mapped.id), mapped.name);
      return mapped;
    }
    const rows = await sql<BusinessRow>`
      insert into businesses (user_id, name, offer, audience, notes)
      values (${context.userId}, ${data.name}, ${offer}, ${audience}, ${notes})
      returning id, name, offer, audience, notes, created_at, updated_at
    `;
    const mapped = rows[0] ? mapBusiness(rows[0]) : null;
    if (!mapped) throw new Error("Business could not be saved.");
    await writeAudit(context.userId, "business.created", String(mapped.id), mapped.name);
    return mapped;
  });

export const businessSaveHandler: ToolHandler = async ({ userId, payload, title }) => {
  const parsed = saveInput.parse(payload);
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "businessBasic");
  const sql = await getSql();
  const name = requiredTitle(parsed.name, title);
  const offer = (parsed.offer ?? "").trim();
  const audience = (parsed.audience ?? "").trim();
  const notes = (parsed.notes ?? "").trim();
  if (parsed.id) {
    const rows = await sql<BusinessRow>`
      update businesses
      set name = ${name}, offer = ${offer}, audience = ${audience}, notes = ${notes}, updated_at = now()
      where id = ${parsed.id} and user_id = ${userId}
      returning id, name, offer, audience, notes, created_at, updated_at
    `;
    const mapped = rows[0] ? mapBusiness(rows[0]) : null;
    if (!mapped) throw new Error("Business not found.");
    return `Updated business ${mapped.id}.`;
  }
  const rows = await sql<BusinessRow>`
    insert into businesses (user_id, name, offer, audience, notes)
    values (${userId}, ${name}, ${offer}, ${audience}, ${notes})
    returning id, name, offer, audience, notes, created_at, updated_at
  `;
  const mapped = rows[0] ? mapBusiness(rows[0]) : null;
  if (!mapped) throw new Error("Business could not be saved.");
  return `Saved business ${mapped.id}.`;
};

const noteInput = z.object({
  businessId: z.number().int().positive().optional(),
  kind: z.enum(BUSINESS_NOTE_KINDS).optional(),
  title: z.string().trim().max(BUSINESS_NOTE_TITLE_MAX).optional(),
  body: z.string().trim().max(BUSINESS_NOTE_BODY_MAX).optional(),
});

export const businessNoteHandler: ToolHandler = async ({ userId, payload, title, summary }) => {
  const parsed = noteInput.parse(payload);
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "businessBasic");
  const sql = await getSql();
  let businessId = parsed.businessId ?? 0;
  if (!businessId) {
    const existing = await sql<{ id: unknown }>`
      select id from businesses where user_id = ${userId} order by updated_at desc limit 1
    `;
    const n = Number(existing[0]?.id);
    businessId = Number.isInteger(n) && n > 0 ? n : 0;
  }
  if (!businessId) throw new Error("Save a business first.");
  const owned = await sql<{ id: unknown }>`
    select id from businesses where id = ${businessId} and user_id = ${userId}
  `;
  if (!owned[0]) throw new Error("Business not found.");
  const noteTitle = requiredTitle(parsed.title, title);
  const body = requiredBody(parsed.body, summary, noteTitle);
  const kind = parsed.kind ?? "note";
  const rows = await sql<BusinessNoteRow>`
    insert into business_notes (user_id, business_id, kind, title, body)
    values (${userId}, ${businessId}, ${kind}, ${noteTitle}, ${body})
    returning id, business_id, kind, title, body, created_at, updated_at
  `;
  const mapped = rows[0] ? mapBusinessNote(rows[0]) : null;
  if (!mapped) throw new Error("Note could not be saved.");
  return `Saved business note ${mapped.id}.`;
};

const experimentInput = z.object({
  hypothesis: z.string().trim().min(1).max(500),
  metric: z.string().trim().min(1).max(200),
  windowDays: z.number().int().min(1).max(90).optional(),
  success: z.string().trim().max(500).optional(),
  result: z.string().trim().max(2000).optional(),
});

export const businessExperimentHandler: ToolHandler = async ({ userId, payload }) => {
  const parsed = experimentInput.parse(payload);
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "businessBasic");
  const sql = await getSql();
  const result = (parsed.result ?? "").trim();
  const rows = await sql<{ id: unknown }>`
    insert into business_experiments (user_id, hypothesis, metric, window_days, success, result, status)
    values (
      ${userId},
      ${parsed.hypothesis},
      ${parsed.metric},
      ${parsed.windowDays ?? 14},
      ${parsed.success ?? ""},
      ${result},
      ${result ? "recorded" : "open"}
    )
    returning id
  `;
  const id = Number(rows[0]?.id);
  if (!Number.isInteger(id) || id < 1) throw new Error("Experiment could not be saved.");
  if (!result) return `Saved experiment ${id}. No result is recorded yet.`;
  return `Saved experiment ${id} with the result you wrote. It was not calculated.`;
};
