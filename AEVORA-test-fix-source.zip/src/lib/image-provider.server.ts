import {
  classifyProviderFailure,
  logProviderFailure,
  readXaiApiKey,
  userFacingMediaError,
  xaiBaseUrl,
} from "@/lib/ai/xai-env.server";
import { PHOTO_MODEL, buildPhotoEditBody, buildPhotoGenerationBody, type PhotoAspect, type PhotoResolution } from "@/lib/studio-format";

export type ImageResult =
  | { ok: true; dataUri: string }
  | { ok: false; error: string; unavailable?: boolean };

const PHOTO_MODEL_CANDIDATES = [PHOTO_MODEL, "grok-imagine-image"] as const;

function authHeaders(key: string): HeadersInit {
  return {
    Authorization: `Bearer ${key}`,
    "Content-Type": "application/json",
    Accept: "application/json",
  };
}

export function imageProviderAvailable(): boolean {
  return Boolean(readXaiApiKey());
}

async function urlToDataUri(url: string): Promise<string | null> {
  if (!url.startsWith("https://") && !url.startsWith("data:")) return null;
  if (url.startsWith("data:")) return url;
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const mime = (res.headers.get("content-type") || "image/jpeg").split(";")[0]?.trim() || "image/jpeg";
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.byteLength < 32) return null;
    return `data:${mime};base64,${buf.toString("base64")}`;
  } catch {
    return null;
  }
}

function readImagePayload(json: unknown): string | null {
  if (!json || typeof json !== "object") return null;
  const body = json as {
    url?: string;
    data?: { url?: string; b64_json?: string; mime_type?: string }[];
  };
  const first = body.data?.[0];
  if (first?.b64_json) {
    const mime = first.mime_type || "image/jpeg";
    return `data:${mime};base64,${first.b64_json}`;
  }
  const url = first?.url || body.url;
  return url || null;
}

async function parseOkImage(res: Response): Promise<ImageResult> {
  const json = await res.json();
  const raw = readImagePayload(json);
  if (!raw) return { ok: false, error: "Photo provider did not return an image." };
  const dataUri = await urlToDataUri(raw);
  if (!dataUri) return { ok: false, error: "Photo could not be saved." };
  return { ok: true, dataUri };
}

export async function generatePhoto(input: {
  prompt: string;
  aspectRatio: PhotoAspect;
  resolution: PhotoResolution;
}): Promise<ImageResult> {
  const key = readXaiApiKey();
  if (!key) return { ok: false, unavailable: true, error: "Studio is unavailable right now." };
  try {
    const base = buildPhotoGenerationBody(input);
    let lastStatus = 503;
    for (const model of PHOTO_MODEL_CANDIDATES) {
      const attempts = [
        { ...base, model },
        { ...base, model, response_format: "url" },
      ];
      for (const body of attempts) {
        const res = await fetch(`${xaiBaseUrl()}/images/generations`, {
          method: "POST",
          headers: authHeaders(key),
          body: JSON.stringify(body),
        });
        lastStatus = res.status;
        if (res.ok) return parseOkImage(res);
        const lastBody = await res.text().catch(() => "");
        logProviderFailure("photo.generate", classifyProviderFailure(res.status, lastBody, model));
        if (res.status === 403 || res.status === 404) break;
        if (res.status !== 400 && res.status !== 422) {
          return {
            ok: false,
            error: userFacingMediaError(res.status),
            unavailable: res.status === 401 || res.status === 403,
          };
        }
      }
    }
    return {
      ok: false,
      error: userFacingMediaError(lastStatus),
      unavailable: lastStatus === 401 || lastStatus === 403,
    };
  } catch {
    return { ok: false, error: "Photo provider could not be reached." };
  }
}

export async function editPhoto(input: {
  prompt: string;
  imageDataUri: string;
  aspectRatio?: PhotoAspect;
}): Promise<ImageResult> {
  const key = readXaiApiKey();
  if (!key) return { ok: false, unavailable: true, error: "Studio is unavailable right now." };
  try {
    let lastStatus = 503;
    for (const model of PHOTO_MODEL_CANDIDATES) {
      const res = await fetch(`${xaiBaseUrl()}/images/edits`, {
        method: "POST",
        headers: authHeaders(key),
        body: JSON.stringify({ ...buildPhotoEditBody(input), model }),
      });
      lastStatus = res.status;
      if (res.ok) return parseOkImage(res);
      const text = await res.text().catch(() => "");
      logProviderFailure("photo.edit", classifyProviderFailure(res.status, text, model));
      if (res.status !== 403 && res.status !== 404) {
        return {
          ok: false,
          error: userFacingMediaError(res.status),
          unavailable: res.status === 401 || res.status === 403,
        };
      }
    }
    return {
      ok: false,
      error: userFacingMediaError(lastStatus),
      unavailable: lastStatus === 401 || lastStatus === 403,
    };
  } catch {
    return { ok: false, error: "Photo provider could not be reached." };
  }
}
