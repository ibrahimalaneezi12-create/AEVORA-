import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { resolveLocale, isLanguageCode, type AppLocale } from "@/lib/locale";
import { VOICE_NAME_MAX } from "@/lib/voice-format";
import { asQuietHour, asResponseStyle, quietHoursPair, type ResponseStyle } from "@/lib/profile-format";

export const PROFILE_THEMES = ["system", "dark", "light"] as const;
export type ProfileTheme = (typeof PROFILE_THEMES)[number];

export type Profile = {
  userId: string;
  displayName: string | null;
  bio: string;
  timezone: string;
  theme: ProfileTheme;
  locale: AppLocale;
  fallbackLanguage: AppLocale;
  voiceEnabled: boolean;
  voiceName: string;
  detectLanguage: boolean;
  voiceSpeed: number;
  pulseEnabled: boolean;
  notifyReminders: boolean;
  notifyPulse: boolean;
  responseStyle: ResponseStyle;
  quietHoursStart: number | null;
  quietHoursEnd: number | null;
  onboardingDone: boolean;
  createdAt: string;
  updatedAt: string;
};

export type ProfileUpdate = {
  displayName: string;
  bio: string;
  timezone: string;
  theme: ProfileTheme;
  locale?: AppLocale;
  fallbackLanguage?: AppLocale;
  voiceEnabled?: boolean;
  voiceName?: string;
  detectLanguage?: boolean;
  voiceSpeed?: number;
  pulseEnabled?: boolean;
  notifyReminders?: boolean;
  notifyPulse?: boolean;
  responseStyle?: ResponseStyle;
  quietHoursStart?: number | null;
  quietHoursEnd?: number | null;
};

type ProfileRow = {
  user_id: string;
  display_name: string | null;
  bio: string;
  timezone: string;
  theme: string;
  locale: string | null;
  fallback_language: string | null;
  voice_enabled: boolean | null;
  voice_name: string | null;
  detect_language: boolean | null;
  voice_speed: number | null;
  pulse_enabled: boolean | null;
  notify_reminders: boolean | null;
  notify_pulse: boolean | null;
  response_style: string | null;
  quiet_hours_start: number | null;
  quiet_hours_end: number | null;
  onboarding_done: boolean;
  created_at: unknown;
  updated_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asTheme(value: string): ProfileTheme {
  return value === "dark" || value === "light" || value === "system"
    ? value
    : "system";
}

function mapProfile(row: ProfileRow): Profile {
  return {
    userId: row.user_id,
    displayName: row.display_name,
    bio: row.bio,
    timezone: row.timezone || "UTC",
    theme: asTheme(row.theme),
    locale: resolveLocale(row.locale),
    fallbackLanguage: resolveLocale(row.fallback_language),
    voiceEnabled: row.voice_enabled !== false,
    voiceName: (row.voice_name ?? "").slice(0, VOICE_NAME_MAX),
    detectLanguage: row.detect_language !== false,
    voiceSpeed: (() => {
      const n = Number(row.voice_speed);
      return Number.isFinite(n) ? Math.min(1.5, Math.max(0.7, n)) : 1;
    })(),
    pulseEnabled: row.pulse_enabled !== false,
    notifyReminders: row.notify_reminders !== false,
    notifyPulse: row.notify_pulse !== false,
    responseStyle: asResponseStyle(row.response_style),
    quietHoursStart: asQuietHour(row.quiet_hours_start),
    quietHoursEnd: asQuietHour(row.quiet_hours_end),
    onboardingDone: Boolean(row.onboarding_done),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

async function readProfile(userId: string): Promise<Profile | null> {
  const sql = await getSql();
  const rows = await sql<ProfileRow>`
    select user_id, display_name, bio, timezone, theme, locale, fallback_language, voice_enabled, voice_name, detect_language, voice_speed, pulse_enabled, notify_reminders, notify_pulse, response_style, quiet_hours_start, quiet_hours_end, onboarding_done, created_at, updated_at
    from profiles
    where user_id = ${userId}
  `;
  return rows[0] ? mapProfile(rows[0]) : null;
}

async function insertFirstProfile(userId: string): Promise<void> {
  const sql = await getSql();
  const users = await sql<{ name: string | null }>`
    select name from "user" where id = ${userId}
  `;
  const displayName = users[0]?.name?.trim() || null;
  await sql`
    insert into profiles (user_id, display_name)
    values (${userId}, ${displayName})
    on conflict (user_id) do nothing
  `;
}

async function countOwnProfiles(userId: string): Promise<number> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`
    select count(*)::int as n from profiles where user_id = ${userId}
  `;
  return rows[0]?.n ?? 0;
}

async function ensureOwnProfile(userId: string): Promise<Profile> {
  let profile = await readProfile(userId);
  if (!profile) {
    await insertFirstProfile(userId);
    profile = await readProfile(userId);
  }
  if (!profile) {
    throw new Error("Profile could not be created.");
  }
  const n = await countOwnProfiles(userId);
  if (n !== 1) {
    throw new Error("Expected exactly one profile row.");
  }
  return profile;
}

/**
 * First authenticated session: exactly one profiles row for this user.
 * Idempotent. Scoped to the verified session id — never a client-sent id.
 */
export const getOrCreateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Profile> => {
    try {
      const { ensureEntitlement } = await import("@/lib/entitlements");
      await ensureEntitlement(context.userId);
    } catch {
      // Entitlement is display + billing. Keep still loads.
    }
    return ensureOwnProfile(context.userId);
  });

const updateInput = z.object({
  displayName: z.string().max(80),
  bio: z.string().max(500),
  timezone: z.string().trim().min(1).max(64),
  theme: z.enum(PROFILE_THEMES),
  locale: z.string().trim().min(2).max(16).refine(isLanguageCode).optional(),
  fallbackLanguage: z.string().trim().min(2).max(16).refine(isLanguageCode).optional(),
  voiceEnabled: z.boolean().optional(),
  voiceName: z.string().max(VOICE_NAME_MAX).optional(),
  detectLanguage: z.boolean().optional(),
  voiceSpeed: z.number().min(0.7).max(1.5).optional(),
  pulseEnabled: z.boolean().optional(),
  notifyReminders: z.boolean().optional(),
  notifyPulse: z.boolean().optional(),
  responseStyle: z.enum(["calm", "direct", "warm"]).optional(),
  quietHoursStart: z.number().int().min(0).max(23).nullable().optional(),
  quietHoursEnd: z.number().int().min(0).max(23).nullable().optional(),
});

/**
 * Update this session's profiles row only. Never accepts a user id from the client.
 */
export const updateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => updateInput.parse(input))
  .handler(async ({ context, data }): Promise<Profile> => {
    await ensureOwnProfile(context.userId);
    const current = await readProfile(context.userId);
    if (!current) throw new Error("Profile could not be saved.");
    const sql = await getSql();
    const displayName = data.displayName.trim() || null;
    const bio = data.bio.trim();
    const locale = data.locale ?? current.locale;
    const fallbackLanguage = data.fallbackLanguage ?? current.fallbackLanguage;
    const voiceEnabled = data.voiceEnabled ?? current.voiceEnabled;
    const voiceName = (data.voiceName ?? current.voiceName).trim().slice(0, VOICE_NAME_MAX);
    const detectLanguage = data.detectLanguage ?? current.detectLanguage;
    const voiceSpeed = data.voiceSpeed ?? current.voiceSpeed;
    const pulseEnabled = data.pulseEnabled ?? current.pulseEnabled;
    const notifyReminders = data.notifyReminders ?? current.notifyReminders;
    const notifyPulse = data.notifyPulse ?? current.notifyPulse;
    const pair = quietHoursPair(
      data.quietHoursStart === undefined ? current.quietHoursStart : data.quietHoursStart,
      data.quietHoursEnd === undefined ? current.quietHoursEnd : data.quietHoursEnd,
    );
    const responseStyle = data.responseStyle ?? current.responseStyle;
    await sql`
      update profiles
      set
        display_name = ${displayName},
        bio = ${bio},
        timezone = ${data.timezone},
        theme = ${data.theme},
        locale = ${locale},
        fallback_language = ${fallbackLanguage},
        voice_enabled = ${voiceEnabled},
        voice_name = ${voiceName},
        detect_language = ${detectLanguage},
        voice_speed = ${voiceSpeed},
        pulse_enabled = ${pulseEnabled},
        notify_reminders = ${notifyReminders},
        notify_pulse = ${notifyPulse},
        response_style = ${responseStyle},
        quiet_hours_start = ${pair.start},
        quiet_hours_end = ${pair.end},
        updated_at = now()
      where user_id = ${context.userId}
    `;
    const profile = await readProfile(context.userId);
    if (!profile) throw new Error("Profile could not be saved.");
    const n = await countOwnProfiles(context.userId);
    if (n !== 1) {
      throw new Error("Expected exactly one profile row.");
    }
    return profile;
  });
