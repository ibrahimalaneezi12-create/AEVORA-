/**
 * Google Ads and QuickBooks OAuth. A provider is ready only when its
 * official app credentials are in the server environment. Nothing is
 * marked connected until that provider accepts the login and a read.
 * Client secrets never leave this module.
 */
import { env } from "../env.server.ts";
import { canSealSecrets, openSecret, sealSecret } from "../seal.server.ts";

export const GOOGLE_ADS_AUTH = "https://accounts.google.com/o/oauth2/v2/auth";
export const GOOGLE_TOKEN = "https://oauth2.googleapis.com/token";
export const GOOGLE_ADS_API = "https://googleads.googleapis.com/v25";
export const INTUIT_AUTH = "https://appcenter.intuit.com/connect/oauth2";
export const INTUIT_TOKEN = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer";

export const ADS_UNCONFIGURED =
  "Google Ads uses OAuth. No ads app is registered here, so spend is not being read.";
export const BOOKS_UNCONFIGURED =
  "QuickBooks uses OAuth. No accounting app is registered here, so revenue is not being calculated.";

export type OAuthProvider = "google_ads" | "quickbooks";

type Ready = {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
};

export type GoogleAdsReady = Ready & { developerToken: string };
export type QuickBooksReady = Ready & { environment: "sandbox" | "production" };

export function businessOAuthRedirect(): string | null {
  const explicit = env("BUSINESS_OAUTH_REDIRECT");
  if (explicit && /^https:\/\/[^/\s]+\/api\/business\/oauth\/callback$/.test(explicit)) return explicit;
  const base = env("BETTER_AUTH_URL")?.replace(/\/$/, "");
  if (!base) return null;
  if (!/^https:\/\/[^/\s]+$/.test(base) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(base)) return null;
  return `${base}/api/business/oauth/callback`;
}

export function googleAdsSetup(): GoogleAdsReady | { detail: string } {
  const clientId = env("GOOGLE_ADS_CLIENT_ID") ?? "";
  const clientSecret = env("GOOGLE_ADS_CLIENT_SECRET") ?? "";
  const developerToken = env("GOOGLE_ADS_DEVELOPER_TOKEN") ?? "";
  const redirectUri = businessOAuthRedirect();
  if (!clientId && !clientSecret && !developerToken) return { detail: ADS_UNCONFIGURED };
  if (!clientId || !clientSecret) return { detail: "Google Ads is missing its OAuth client. Spend is not being read." };
  if (!developerToken) return { detail: "Google Ads is missing its developer token. Spend is not being read." };
  if (!redirectUri) return { detail: "Google Ads is missing an https redirect URL. Spend is not being read." };
  if (!canSealSecrets()) return { detail: "This keep cannot store a Google Ads token safely yet. Nothing was saved." };
  return { clientId, clientSecret, developerToken, redirectUri };
}

export function quickBooksSetup(): QuickBooksReady | { detail: string } {
  const clientId = env("QUICKBOOKS_CLIENT_ID") ?? "";
  const clientSecret = env("QUICKBOOKS_CLIENT_SECRET") ?? "";
  const environment = env("QUICKBOOKS_ENVIRONMENT");
  const redirectUri = businessOAuthRedirect();
  if (!clientId && !clientSecret && !environment) return { detail: BOOKS_UNCONFIGURED };
  if (!clientId || !clientSecret) return { detail: "QuickBooks is missing its OAuth client. Revenue is not being calculated." };
  if (environment !== "sandbox" && environment !== "production") {
    return { detail: "QuickBooks environment must be sandbox or production. Revenue is not being calculated." };
  }
  if (!redirectUri) return { detail: "QuickBooks is missing an https redirect URL. Revenue is not being calculated." };
  if (!canSealSecrets()) return { detail: "This keep cannot store a QuickBooks token safely yet. Nothing was saved." };
  return { clientId, clientSecret, redirectUri, environment };
}

export function isGoogleAdsReady(value: GoogleAdsReady | { detail: string }): value is GoogleAdsReady {
  return "clientId" in value;
}

export function isQuickBooksReady(value: QuickBooksReady | { detail: string }): value is QuickBooksReady {
  return "clientId" in value;
}

export function sealOAuthState(userId: string, provider: OAuthProvider): string | null {
  if (!userId || !canSealSecrets()) return null;
  return sealSecret(JSON.stringify({ userId, provider, exp: Date.now() + 10 * 60 * 1000 }));
}

export function openOAuthState(state: string): { userId: string; provider: OAuthProvider } | null {
  const plain = openSecret(state);
  if (!plain) return null;
  try {
    const parsed = JSON.parse(plain) as { userId?: unknown; provider?: unknown; exp?: unknown };
    if (typeof parsed.userId !== "string" || !parsed.userId) return null;
    if (parsed.provider !== "google_ads" && parsed.provider !== "quickbooks") return null;
    if (typeof parsed.exp !== "number" || parsed.exp < Date.now()) return null;
    return { userId: parsed.userId, provider: parsed.provider };
  } catch {
    return null;
  }
}

function assertOrigin(url: string, origin: string): void {
  if (!url.startsWith(`${origin}/`) && url !== origin) {
    throw new Error("OAuth host was refused. Nothing was sent.");
  }
}

export function googleAdsAuthorizeUrl(setup: GoogleAdsReady, state: string): string {
  const url = new URL(GOOGLE_ADS_AUTH);
  url.searchParams.set("client_id", setup.clientId);
  url.searchParams.set("redirect_uri", setup.redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "https://www.googleapis.com/auth/adwords");
  url.searchParams.set("access_type", "offline");
  url.searchParams.set("prompt", "consent");
  url.searchParams.set("state", state);
  assertOrigin(url.toString(), "https://accounts.google.com");
  if (url.search.includes(setup.clientSecret) || url.search.includes(setup.developerToken)) {
    throw new Error("OAuth URL was refused. Nothing was sent.");
  }
  return url.toString();
}

export function quickBooksAuthorizeUrl(setup: QuickBooksReady, state: string): string {
  const url = new URL(INTUIT_AUTH);
  url.searchParams.set("client_id", setup.clientId);
  url.searchParams.set("redirect_uri", setup.redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "com.intuit.quickbooks.accounting");
  url.searchParams.set("state", state);
  assertOrigin(url.toString(), "https://appcenter.intuit.com");
  if (url.search.includes(setup.clientSecret)) throw new Error("OAuth URL was refused. Nothing was sent.");
  return url.toString();
}

export type TokenBundle = {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
  realmId: string;
  environment: "" | "sandbox" | "production";
  customerIds: string[];
};

function redact(raw: string): string {
  return raw.replace(/[A-Za-z0-9_-]{12,}/g, "[redacted]").replace(/\s+/g, " ").trim().slice(0, 140);
}

function parseTokenBody(body: unknown, previous: TokenBundle | null): TokenBundle | null {
  if (!body || typeof body !== "object") return null;
  const row = body as Record<string, unknown>;
  const accessToken = typeof row.access_token === "string" ? row.access_token : "";
  if (!accessToken) return null;
  const refreshToken = typeof row.refresh_token === "string" && row.refresh_token ? row.refresh_token : previous?.refreshToken ?? "";
  const expiresIn = typeof row.expires_in === "number" ? row.expires_in : Number(row.expires_in);
  const expiresAt = Number.isFinite(expiresIn) && expiresIn > 0 ? Date.now() + expiresIn * 1000 : Date.now() + 30 * 60 * 1000;
  return {
    accessToken,
    refreshToken,
    expiresAt,
    realmId: previous?.realmId ?? "",
    environment: previous?.environment ?? "",
    customerIds: previous?.customerIds ?? [],
  };
}

async function postForm(
  url: string,
  body: URLSearchParams,
  headers: Record<string, string>,
  fetchImpl: typeof fetch,
): Promise<{ ok: true; body: unknown } | { ok: false; status: number; error: string }> {
  assertOrigin(url, new URL(url).origin);
  try {
    const res = await fetchImpl(url, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded", ...headers },
      body,
      redirect: "error",
    });
    const text = await res.text();
    let parsed: unknown = null;
    if (text) {
      try {
        parsed = JSON.parse(text) as unknown;
      } catch {
        parsed = { error: text.slice(0, 80) };
      }
    }
    if (!res.ok) return { ok: false, status: res.status, error: redact(text) || `The provider returned ${res.status}.` };
    return { ok: true, body: parsed };
  } catch {
    return { ok: false, status: 0, error: "The provider could not be reached. Nothing was saved." };
  }
}

export async function exchangeGoogleCode(
  setup: GoogleAdsReady,
  code: string,
  fetchImpl: typeof fetch = fetch,
): Promise<{ ok: true; token: TokenBundle } | { ok: false; error: string }> {
  const body = new URLSearchParams({
    code,
    client_id: setup.clientId,
    client_secret: setup.clientSecret,
    redirect_uri: setup.redirectUri,
    grant_type: "authorization_code",
  });
  const result = await postForm(GOOGLE_TOKEN, body, {}, fetchImpl);
  if (!result.ok) return { ok: false, error: result.error };
  const token = parseTokenBody(result.body, null);
  if (!token) return { ok: false, error: "Google did not return an access token. Nothing was saved." };
  return { ok: true, token };
}

export async function exchangeQuickBooksCode(
  setup: QuickBooksReady,
  code: string,
  realmId: string,
  fetchImpl: typeof fetch = fetch,
): Promise<{ ok: true; token: TokenBundle } | { ok: false; error: string }> {
  if (!/^\d{1,20}$/.test(realmId)) return { ok: false, error: "QuickBooks did not return a company id. Nothing was saved." };
  const basic = Buffer.from(`${setup.clientId}:${setup.clientSecret}`).toString("base64");
  const body = new URLSearchParams({
    code,
    redirect_uri: setup.redirectUri,
    grant_type: "authorization_code",
  });
  const result = await postForm(INTUIT_TOKEN, body, { Authorization: `Basic ${basic}` }, fetchImpl);
  if (!result.ok) return { ok: false, error: result.error };
  const token = parseTokenBody(result.body, null);
  if (!token) return { ok: false, error: "QuickBooks did not return an access token. Nothing was saved." };
  token.realmId = realmId;
  token.environment = setup.environment;
  return { ok: true, token };
}

export function customerIdFromResource(name: string): string | null {
  const match = name.match(/^customers\/(\d{1,20})$/);
  return match?.[1] ?? null;
}

export function parseAccessibleCustomers(body: unknown): string[] {
  if (!body || typeof body !== "object") return [];
  const names = (body as { resourceNames?: unknown }).resourceNames;
  if (!Array.isArray(names)) return [];
  return names.map((name) => (typeof name === "string" ? customerIdFromResource(name) : null)).filter((id): id is string => Boolean(id));
}

export type AdsCampaign = { name: string; costMicros: string | null };

export function parseAdsSpend(body: unknown): AdsCampaign[] {
  if (!body || typeof body !== "object") return [];
  const results = (body as { results?: unknown }).results;
  if (!Array.isArray(results)) return [];
  const out: AdsCampaign[] = [];
  for (const item of results) {
    if (!item || typeof item !== "object") continue;
    const row = item as { campaign?: { name?: unknown }; metrics?: { costMicros?: unknown; cost_micros?: unknown } };
    const name = typeof row.campaign?.name === "string" ? row.campaign.name : "";
    if (!name) continue;
    const raw = row.metrics?.costMicros ?? row.metrics?.cost_micros;
    const cost = typeof raw === "string" || typeof raw === "number" ? String(raw) : null;
    out.push({ name, costMicros: cost && /^\d+$/.test(cost) ? cost : null });
  }
  return out;
}

export function adsSpendSpeech(campaigns: AdsCampaign[], error: string): string {
  if (error) return `Google Ads did not return campaigns. ${error} Spend is not calculated.`;
  if (campaigns.length === 0) return "Google Ads returned no campaigns. Spend is not calculated.";
  const priced = campaigns.filter((row) => row.costMicros !== null);
  const names = campaigns.slice(0, 8).map((row) => row.name).join("; ");
  if (priced.length !== campaigns.length) {
    return `Google Ads returned ${campaigns.length} campaigns (${names}). Some costs were missing, so spend is not calculated.`;
  }
  const micros = priced.reduce((sum, row) => sum + Number(row.costMicros), 0);
  const units = (micros / 1_000_000).toFixed(2);
  return `Among the ${priced.length} campaigns returned, cost_micros adds up to ${units} account units. Currency was not in this payload. This is not full-account spend.`;
}

export function quickBooksHost(environment: "sandbox" | "production"): string {
  return environment === "production" ? "https://quickbooks.api.intuit.com" : "https://sandbox-quickbooks.api.intuit.com";
}

export function parseTotalIncome(body: unknown): { amount: string; currency: string } | null {
  if (!body || typeof body !== "object") return null;
  const header = (body as { Header?: { Currency?: unknown } }).Header;
  const currency = typeof header?.Currency === "string" ? header.Currency : "";
  let amount = "";
  const visit = (value: unknown) => {
    if (!value || amount) return;
    if (Array.isArray(value)) {
      for (const item of value) visit(item);
      return;
    }
    if (typeof value !== "object") return;
    const row = value as Record<string, unknown>;
    const cols = row.ColData;
    if (Array.isArray(cols) && cols.length >= 2) {
      const label = cols[0] && typeof cols[0] === "object" ? (cols[0] as { value?: unknown }).value : "";
      const figure = cols[1] && typeof cols[1] === "object" ? (cols[1] as { value?: unknown }).value : "";
      if (typeof label === "string" && /^total income$/i.test(label) && typeof figure === "string" && /^-?\d+(\.\d+)?$/.test(figure)) {
        amount = figure;
        return;
      }
    }
    for (const child of Object.values(row)) visit(child);
  };
  visit(body);
  if (!amount) return null;
  return { amount, currency };
}

export function booksRevenueSpeech(income: { amount: string; currency: string } | null, error: string, connected: boolean): string {
  if (!connected) return "No accounting source is connected. Revenue is not being calculated.";
  if (error) return `QuickBooks did not return a report. ${error} Revenue is not calculated.`;
  if (!income) return "QuickBooks did not return a total income figure. Revenue is not calculated.";
  const currency = income.currency ? ` ${income.currency}` : "";
  return `QuickBooks reported total income of ${income.amount}${currency} on the report it returned. This is not a calculated forecast.`;
}

export async function listGoogleAdsCustomers(
  setup: GoogleAdsReady,
  accessToken: string,
  fetchImpl: typeof fetch = fetch,
): Promise<{ ok: true; customerIds: string[] } | { ok: false; status: number; error: string }> {
  const url = `${GOOGLE_ADS_API}/customers:listAccessibleCustomers`;
  try {
    const res = await fetchImpl(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "developer-token": setup.developerToken,
        Accept: "application/json",
      },
      redirect: "error",
    });
    const text = await res.text();
    if (!res.ok) return { ok: false, status: res.status, error: redact(text) || `Google Ads returned ${res.status}.` };
    let body: unknown = null;
    if (text) body = JSON.parse(text) as unknown;
    return { ok: true, customerIds: parseAccessibleCustomers(body) };
  } catch {
    return { ok: false, status: 0, error: "Google Ads could not be reached. Nothing was saved." };
  }
}

export async function searchGoogleAdsSpend(
  setup: GoogleAdsReady,
  accessToken: string,
  customerId: string,
  fetchImpl: typeof fetch = fetch,
): Promise<{ ok: true; campaigns: AdsCampaign[] } | { ok: false; status: number; error: string }> {
  if (!/^\d{1,20}$/.test(customerId)) return { ok: false, status: 0, error: "Google Ads did not return a customer id." };
  const url = `${GOOGLE_ADS_API}/customers/${customerId}/googleAds:search`;
  try {
    const res = await fetchImpl(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "developer-token": setup.developerToken,
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: "SELECT campaign.name, metrics.cost_micros FROM campaign ORDER BY metrics.cost_micros DESC LIMIT 8",
      }),
      redirect: "error",
    });
    const text = await res.text();
    if (!res.ok) return { ok: false, status: res.status, error: redact(text) || `Google Ads returned ${res.status}.` };
    const body = text ? (JSON.parse(text) as unknown) : null;
    return { ok: true, campaigns: parseAdsSpend(body) };
  } catch {
    return { ok: false, status: 0, error: "Google Ads could not be reached." };
  }
}

export function parseCompanyName(body: unknown): string {
  if (!body || typeof body !== "object") return "";
  const info = (body as { CompanyInfo?: { CompanyName?: unknown } }).CompanyInfo;
  return typeof info?.CompanyName === "string" ? info.CompanyName : "";
}

export async function readQuickBooksCompany(
  token: TokenBundle,
  fetchImpl: typeof fetch = fetch,
): Promise<{ ok: true; name: string } | { ok: false; status: number; error: string }> {
  if (token.environment !== "sandbox" && token.environment !== "production") {
    return { ok: false, status: 0, error: "QuickBooks environment was not stored." };
  }
  if (!/^\d{1,20}$/.test(token.realmId)) return { ok: false, status: 0, error: "QuickBooks did not return a company id." };
  const url = `${quickBooksHost(token.environment)}/v3/company/${token.realmId}/companyinfo/${token.realmId}?minorversion=75`;
  try {
    const res = await fetchImpl(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${token.accessToken}`, Accept: "application/json" },
      redirect: "error",
    });
    const text = await res.text();
    if (!res.ok) return { ok: false, status: res.status, error: redact(text) || `QuickBooks returned ${res.status}.` };
    const body = text ? (JSON.parse(text) as unknown) : null;
    const name = parseCompanyName(body);
    if (!name) return { ok: false, status: res.status, error: "QuickBooks did not return a company. Nothing was saved." };
    return { ok: true, name };
  } catch {
    return { ok: false, status: 0, error: "QuickBooks could not be reached. Nothing was saved." };
  }
}

export async function readQuickBooksIncome(
  token: TokenBundle,
  fetchImpl: typeof fetch = fetch,
): Promise<{ ok: true; income: { amount: string; currency: string } | null } | { ok: false; status: number; error: string }> {
  if (token.environment !== "sandbox" && token.environment !== "production") {
    return { ok: false, status: 0, error: "QuickBooks environment was not stored. Revenue is not calculated." };
  }
  if (!/^\d{1,20}$/.test(token.realmId)) return { ok: false, status: 0, error: "QuickBooks company id was not stored." };
  const url = `${quickBooksHost(token.environment)}/v3/company/${token.realmId}/reports/ProfitAndLoss?minorversion=75`;
  try {
    const res = await fetchImpl(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${token.accessToken}`, Accept: "application/json" },
      redirect: "error",
    });
    const text = await res.text();
    if (!res.ok) return { ok: false, status: res.status, error: redact(text) || `QuickBooks returned ${res.status}.` };
    const body = text ? (JSON.parse(text) as unknown) : null;
    return { ok: true, income: parseTotalIncome(body) };
  } catch {
    return { ok: false, status: 0, error: "QuickBooks could not be reached." };
  }
}

export async function refreshOAuthToken(
  provider: OAuthProvider,
  token: TokenBundle,
  fetchImpl: typeof fetch = fetch,
): Promise<{ ok: true; token: TokenBundle } | { ok: false; status: number; error: string }> {
  if (!token.refreshToken) return { ok: false, status: 401, error: "The saved login has no refresh token. Authorize again." };
  if (provider === "google_ads") {
    const setup = googleAdsSetup();
    if (!isGoogleAdsReady(setup)) return { ok: false, status: 0, error: setup.detail };
    const body = new URLSearchParams({
      client_id: setup.clientId,
      client_secret: setup.clientSecret,
      refresh_token: token.refreshToken,
      grant_type: "refresh_token",
    });
    const result = await postForm(GOOGLE_TOKEN, body, {}, fetchImpl);
    if (!result.ok) return result;
    const next = parseTokenBody(result.body, token);
    if (!next) return { ok: false, status: 0, error: "Google did not return a new access token." };
    return { ok: true, token: next };
  }
  const setup = quickBooksSetup();
  if (!isQuickBooksReady(setup)) return { ok: false, status: 0, error: setup.detail };
  const basic = Buffer.from(`${setup.clientId}:${setup.clientSecret}`).toString("base64");
  const body = new URLSearchParams({ refresh_token: token.refreshToken, grant_type: "refresh_token" });
  const result = await postForm(INTUIT_TOKEN, body, { Authorization: `Basic ${basic}` }, fetchImpl);
  if (!result.ok) return result;
  const next = parseTokenBody(result.body, token);
  if (!next) return { ok: false, status: 0, error: "QuickBooks did not return a new access token." };
  return { ok: true, token: next };
}
