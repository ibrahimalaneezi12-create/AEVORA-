import type { LinkStatus } from "@/lib/links-format";

export type GatePeekResult = {
  ok: boolean;
  pending?: boolean;
  loginRequired?: boolean;
  loginUrl?: string;
  errorMessage?: string;
};

/** Only the existing connector gate may be opened. No second Google OAuth host. */
export function safeGateLoginUrl(url: string | undefined): string {
  if (!url) return "";
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    const allowed =
      parsed.protocol === "https:" &&
      (host === "grok.me" ||
        host.endsWith(".grok.me") ||
        host === "app-builder-testing.com" ||
        host.endsWith(".app-builder-testing.com"));
    return allowed ? parsed.toString() : "";
  } catch {
    return "";
  }
}

export function classifyGatePeek(
  name: "Gmail" | "Google Calendar",
  result: GatePeekResult,
): { connected: boolean; status: LinkStatus; detail: string; loginUrl: string } {
  const message = result.errorMessage ?? "";
  if (
    result.pending ||
    /connector_token_pending|missing_connector_token|cannot resolve gate host/i.test(message)
  ) {
    return {
      connected: false,
      status: "not_configured",
      detail: `${name} is not configured in this keep yet. Nothing was read.`,
      loginUrl: "",
    };
  }
  if (result.loginRequired) {
    const loginUrl = safeGateLoginUrl(result.loginUrl);
    return {
      connected: false,
      status: "authorization_required",
      detail: loginUrl
        ? `${name} needs authorization. Nothing was read.`
        : `${name} needs authorization through the connector gate. No sign-in link was returned. Nothing was read.`,
      loginUrl,
    };
  }
  if (!result.ok) {
    return {
      connected: false,
      status: "connection_error",
      detail: `${name} could not be checked. Nothing was read.`,
      loginUrl: "",
    };
  }
  return { connected: true, status: "connected", detail: "", loginUrl: "" };
}
