import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  adsSpendSpeech,
  booksRevenueSpeech,
  customerIdFromResource,
  exchangeGoogleCode,
  googleAdsAuthorizeUrl,
  googleAdsSetup,
  isGoogleAdsReady,
  isQuickBooksReady,
  listGoogleAdsCustomers,
  parseAccessibleCustomers,
  parseAdsSpend,
  parseCompanyName,
  parseTotalIncome,
  quickBooksAuthorizeUrl,
  quickBooksHost,
  quickBooksSetup,
  readQuickBooksIncome,
  searchGoogleAdsSpend,
  type GoogleAdsReady,
  type QuickBooksReady,
  type TokenBundle,
} from "./oauth.server.ts";
import { classifyGatePeek, safeGateLoginUrl } from "./gate-peek.ts";

const ads: GoogleAdsReady = {
  clientId: "ads-client",
  clientSecret: "ads-secret-value",
  developerToken: "dev-token-value",
  redirectUri: "https://aegis.example/api/business/oauth/callback",
};

const books: QuickBooksReady = {
  clientId: "books-client",
  clientSecret: "books-secret-value",
  redirectUri: "https://aegis.example/api/business/oauth/callback",
  environment: "sandbox",
};

describe("business oauth", () => {
  it("builds official authorize URLs and keeps secrets out of them", () => {
    const adsUrl = new URL(googleAdsAuthorizeUrl(ads, "state-1"));
    assert.equal(adsUrl.origin, "https://accounts.google.com");
    assert.equal(adsUrl.searchParams.get("client_id"), "ads-client");
    assert.equal(adsUrl.search.includes("ads-secret-value"), false);
    assert.equal(adsUrl.search.includes("dev-token-value"), false);
    const booksUrl = new URL(quickBooksAuthorizeUrl(books, "state-2"));
    assert.equal(booksUrl.origin, "https://appcenter.intuit.com");
    assert.equal(booksUrl.search.includes("books-secret-value"), false);
    assert.equal(quickBooksHost("production"), "https://quickbooks.api.intuit.com");
    assert.equal(quickBooksHost("sandbox"), "https://sandbox-quickbooks.api.intuit.com");
  });

  it("does not invent customers, spend, or income", () => {
    assert.equal(customerIdFromResource("customers/123"), "123");
    assert.equal(customerIdFromResource("customers/abc"), null);
    assert.deepEqual(parseAccessibleCustomers({}), []);
    assert.deepEqual(parseAccessibleCustomers({ resourceNames: ["customers/9", "nope"] }), ["9"]);
    assert.deepEqual(parseAdsSpend({ results: [{ campaign: { name: "Brand" } }] }), [{ name: "Brand", costMicros: null }]);
    assert.match(adsSpendSpeech([{ name: "Brand", costMicros: null }], ""), /not calculated/);
    assert.equal(parseTotalIncome({}), null);
    assert.deepEqual(
      parseTotalIncome({ Header: { Currency: "USD" }, Rows: { Row: [{ Summary: { ColData: [{ value: "Total Income" }, { value: "10.00" }] } }] } }),
      { amount: "10.00", currency: "USD" },
    );
    assert.match(booksRevenueSpeech(null, "", false), /not being calculated/);
    assert.equal(parseCompanyName({ CompanyInfo: { CompanyName: "North" } }), "North");
    assert.equal(parseCompanyName({}), "");
  });

  it("keeps the connector gate off any other host", () => {
    assert.equal(safeGateLoginUrl("https://evil.example/steal"), "");
    assert.equal(safeGateLoginUrl("https://gate.grok.me/__gate/signin"), "https://gate.grok.me/__gate/signin");
    const pending = classifyGatePeek("Gmail", { ok: false, pending: true, errorMessage: "connector_token_pending: waiting" });
    assert.equal(pending.status, "not_configured");
    assert.equal(pending.connected, false);
    const missing = classifyGatePeek("Google Calendar", { ok: false, errorMessage: "cannot resolve gate host" });
    assert.equal(missing.status, "not_configured");
    const login = classifyGatePeek("Gmail", { ok: false, loginRequired: true, loginUrl: "https://gate.grok.me/__gate/signin" });
    assert.equal(login.status, "authorization_required");
    assert.match(login.loginUrl, /^https:\/\/gate\.grok\.me\//);
  });

  it("stays unconfigured until ads and books app credentials exist", () => {
    const keys = [
      "GOOGLE_ADS_CLIENT_ID",
      "GOOGLE_ADS_CLIENT_SECRET",
      "GOOGLE_ADS_DEVELOPER_TOKEN",
      "QUICKBOOKS_CLIENT_ID",
      "QUICKBOOKS_CLIENT_SECRET",
      "QUICKBOOKS_ENVIRONMENT",
      "BUSINESS_OAUTH_REDIRECT",
      "BETTER_AUTH_URL",
    ] as const;
    const prev = new Map(keys.map((key) => [key, process.env[key]]));
    for (const key of keys) delete process.env[key];
    try {
      const adsSetup = googleAdsSetup();
      const booksSetup = quickBooksSetup();
      assert.equal(isGoogleAdsReady(adsSetup), false);
      assert.equal(isQuickBooksReady(booksSetup), false);
      if (!isGoogleAdsReady(adsSetup)) assert.match(adsSetup.detail, /not being read/);
      if (!isQuickBooksReady(booksSetup)) assert.match(booksSetup.detail, /not being calculated/);
    } finally {
      for (const [key, value] of prev) {
        if (value === undefined) delete process.env[key];
        else process.env[key] = value;
      }
    }
  });

  it("does not treat a tokenless Google response or a failed ads list as data", async () => {
    const exchanged = await exchangeGoogleCode(ads, "code", async () => Response.json({ token_type: "Bearer" }));
    assert.equal(exchanged.ok, false);
    const denied = await listGoogleAdsCustomers(ads, "access-token", async () => new Response("denied", { status: 401 }));
    assert.equal(denied.ok, false);
    if (!denied.ok) assert.equal(denied.status, 401);
    const refused = await searchGoogleAdsSpend(ads, "access-token", "not-an-id", async () => {
      throw new Error("should not fetch");
    });
    assert.equal(refused.ok, false);
  });

  it("reads only the customers and income the provider actually returned", async () => {
    let auth = "";
    let developer = "";
    const listed = await listGoogleAdsCustomers(ads, "access-token", async (_url, init) => {
      const headers = new Headers(init?.headers);
      auth = headers.get("authorization") ?? "";
      developer = headers.get("developer-token") ?? "";
      return Response.json({ resourceNames: ["customers/42", "nope"] });
    });
    assert.equal(listed.ok, true);
    if (listed.ok) assert.deepEqual(listed.customerIds, ["42"]);
    assert.equal(auth, "Bearer access-token");
    assert.equal(developer, "dev-token-value");
    assert.equal(auth.includes("ads-secret-value"), false);

    const token: TokenBundle = {
      accessToken: "books-access",
      refreshToken: "books-refresh",
      expiresAt: Date.now() + 60_000,
      realmId: "99",
      environment: "sandbox",
      customerIds: [],
    };
    let called = "";
    const report = await readQuickBooksIncome(token, async (url, init) => {
      called = String(url);
      const headers = new Headers(init?.headers);
      assert.equal(headers.get("authorization"), "Bearer books-access");
      return Response.json({ Header: { Currency: "USD" } });
    });
    assert.equal(report.ok, true);
    if (report.ok) assert.equal(report.income, null);
    assert.match(called, /^https:\/\/sandbox-quickbooks\.api\.intuit\.com\/v3\/company\/99\/reports\/ProfitAndLoss/);
    const unstored = await readQuickBooksIncome({ ...token, environment: "" }, async () => {
      throw new Error("should not fetch");
    });
    assert.equal(unstored.ok, false);
  });
});
