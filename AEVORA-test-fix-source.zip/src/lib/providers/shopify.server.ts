/**
 * Shopify Admin API. Token stays in X-Shopify-Access-Token.
 * Shop host must be *.myshopify.com. No other host is called.
 * https://shopify.dev/docs/api/admin-rest
 */
import type { BusinessOrder } from "@/lib/business-records";

export const SHOPIFY_API_VERSION = "2025-10";

export type ShopifyCall =
  | { ok: true; status: number; body: unknown }
  | { ok: false; status: number; error: string };

export function normalizeShopHost(input: string): string | null {
  let host = input.trim().toLowerCase().replace(/^https?:\/\//, "").split("/")[0]?.split("?")[0] ?? "";
  host = host.replace(/:\d+$/, "");
  if (!host || host.includes("@") || host.includes("..")) return null;
  if (host.endsWith(".myshopify.com")) {
    /* already a shop host */
  } else if (!host.includes(".")) {
    host = `${host}.myshopify.com`;
  } else {
    return null;
  }
  if (!/^[a-z0-9][a-z0-9-]{0,60}\.myshopify\.com$/.test(host)) return null;
  return host;
}

export function shopifyUrl(host: string, path: string): string {
  const safe = normalizeShopHost(host);
  if (!safe) throw new Error("Store address is not a Shopify shop. Nothing was sent.");
  const suffix = path.startsWith("/") ? path : `/${path}`;
  const url = `https://${safe}${suffix}`;
  if (!url.startsWith(`https://${safe}/`)) {
    throw new Error("Store host was refused. Nothing was sent.");
  }
  return url;
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : null;
}

function str(value: unknown): string {
  if (typeof value === "string") return value;
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return "";
}

export function parseShopifyShop(body: unknown): { name: string; currency: string } | null {
  const root = asRecord(body);
  const shop = asRecord(root?.shop);
  if (!shop) return null;
  const name = str(shop.name);
  if (!name && !str(shop.myshopify_domain) && !str(shop.domain)) return null;
  return { name, currency: str(shop.currency) };
}

export function parseShopifyOrders(body: unknown): BusinessOrder[] {
  const root = asRecord(body);
  const orders = root && Array.isArray(root.orders) ? root.orders : [];
  const out: BusinessOrder[] = [];
  for (const item of orders) {
    const row = asRecord(item);
    if (!row || !str(row.id)) continue;
    out.push({
      source: "shopify",
      id: str(row.id),
      total: str(row.total_price),
      currency: str(row.currency),
      status: str(row.financial_status),
      createdAt: str(row.created_at),
    });
  }
  return out;
}

export function shopifyCapabilities(shopOk: boolean, ordersOk: boolean, productsOk = false, inventoryOk = false): string[] {
  const caps: string[] = [];
  if (shopOk) caps.push("shop.read");
  if (ordersOk) caps.push("orders.read");
  if (productsOk) caps.push("products.read");
  if (inventoryOk) caps.push("inventory.read");
  return caps;
}

export async function shopifyRequest(opts: {
  shop: string;
  path: string;
  token: string;
  fetchImpl?: typeof fetch;
}): Promise<ShopifyCall> {
  const url = shopifyUrl(opts.shop, opts.path);
  if (url.includes(opts.token)) throw new Error("Store request was refused. Nothing was sent.");
  const fetchImpl = opts.fetchImpl ?? fetch;
  try {
    const res = await fetchImpl(url, {
      method: "GET",
      headers: {
        "X-Shopify-Access-Token": opts.token,
        Accept: "application/json",
      },
      redirect: "error",
    });
    const text = await res.text();
    let body: unknown = null;
    if (text) {
      try {
        body = JSON.parse(text) as unknown;
      } catch {
        body = { errors: text.slice(0, 120) };
      }
    }
    if (!res.ok) {
      const message = asRecord(body);
      const err = str(message?.errors) || text.slice(0, 120);
      const clipped = err.replace(/[A-Za-z0-9_-]{12,}/g, "[redacted]").slice(0, 140);
      return { ok: false, status: res.status, error: `The store returned ${res.status}. ${clipped}`.trim() };
    }
    return { ok: true, status: res.status, body };
  } catch {
    return { ok: false, status: 0, error: "Shopify could not be reached. Nothing was saved." };
  }
}

export function shopifyShopPath(): string {
  return `/admin/api/${SHOPIFY_API_VERSION}/shop.json`;
}

export function shopifyOrdersPath(): string {
  return `/admin/api/${SHOPIFY_API_VERSION}/orders.json?status=any&limit=8`;
}

export type ShopifyProduct = { id: string; title: string; inventory: string | null };

export function shopifyProductsPath(): string {
  return `/admin/api/${SHOPIFY_API_VERSION}/products.json?limit=8`;
}

export function parseShopifyProducts(body: unknown): ShopifyProduct[] {
  const root = asRecord(body);
  const products = root && Array.isArray(root.products) ? root.products : [];
  const out: ShopifyProduct[] = [];
  for (const item of products) {
    const row = asRecord(item);
    if (!row || !str(row.id)) continue;
    const variants = Array.isArray(row.variants) ? row.variants : [];
    const quantities: number[] = [];
    let sawQuantity = false;
    for (const variant of variants) {
      const record = asRecord(variant);
      if (!record || !("inventory_quantity" in record)) continue;
      const qty = record.inventory_quantity;
      if (typeof qty === "number" && Number.isFinite(qty)) {
        sawQuantity = true;
        quantities.push(qty);
      }
    }
    out.push({
      id: str(row.id),
      title: str(row.title),
      inventory: sawQuantity ? String(quantities.reduce((sum, qty) => sum + qty, 0)) : null,
    });
  }
  return out;
}
