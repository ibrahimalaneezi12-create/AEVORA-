import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  HUBSPOT_CONTACTS_PATH,
  assertHubspotUrl,
  hubspotCapabilities,
  hubspotRequest,
  parseHubspotContacts,
  safeProviderError,
} from "./hubspot.server.ts";

describe("hubspot adapter", () => {
  it("only calls the official HubSpot host and keeps the token out of the URL", async () => {
    let seen = "";
    let auth = "";
    const result = await hubspotRequest({
      path: HUBSPOT_CONTACTS_PATH,
      token: "pat-secret-token-value",
      fetchImpl: (async (url: string, init?: RequestInit) => {
        seen = String(url);
        auth = String((init?.headers as Record<string, string> | undefined)?.Authorization ?? "");
        return new Response(JSON.stringify({ results: [] }), { status: 200 });
      }) as typeof fetch,
    });
    assert.equal(result.ok, true);
    assert.equal(seen.startsWith("https://api.hubapi.com/crm/v3/objects/contacts"), true);
    assert.equal(seen.includes("pat-secret-token-value"), false);
    assert.equal(auth, "Bearer pat-secret-token-value");
    assert.throws(() => assertHubspotUrl("https://evil.example/crm"));
  });

  it("does not invent contacts", () => {
    assert.deepEqual(parseHubspotContacts({ results: [] }), []);
    assert.deepEqual(parseHubspotContacts({}), []);
    const leads = parseHubspotContacts({
      results: [
        {
          id: "1",
          properties: { firstname: "Ada", lastname: "Lovelace", email: "ada@example.com", hs_lead_status: "NEW", notes_last_contacted: "" },
        },
        { id: "" },
      ],
    });
    assert.equal(leads.length, 1);
    assert.equal(leads[0]?.name, "Ada Lovelace");
    assert.equal(leads[0]?.lastContact, "");
    assert.deepEqual(hubspotCapabilities(true, false), ["contacts.read"]);
  });

  it("does not echo a long credential in errors", () => {
    const text = safeProviderError(401, "bad pat-secret-token-value");
    assert.equal(text.includes("pat-secret-token-value"), false);
  });
});
