/**
 * HubSpot CRM. Private-app access token, Bearer header only.
 * Official: https://api.hubapi.com/crm/v3/objects/contacts
 * The token is never placed in the URL or in error text.
 */
import type { BusinessLead } from "@/lib/business-records";

const ORIGIN = "https://api.hubapi.com";

export type HubspotCall =
  | { ok: true; status: number; body: unknown }
  | { ok: false; status: number; error: string };

export function assertHubspotUrl(url: string): void {
  if (!url.startsWith(`${ORIGIN}/`)) {
    throw new Error("CRM host is not HubSpot. Nothing was sent.");
  }
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : null;
}

function str(value: unknown): string {
  return typeof value === "string" ? value : "";
}

export function safeProviderError(status: number, raw: string): string {
  const clipped = raw.replace(/[A-Za-z0-9_-]{12,}/g, "[redacted]").replace(/\s+/g, " ").trim().slice(0, 140);
  if (!clipped) return `The provider returned ${status}. Nothing was read.`;
  return `The provider returned ${status}. ${clipped}`;
}

export function parseHubspotContacts(body: unknown): BusinessLead[] {
  const root = asRecord(body);
  const results = root && Array.isArray(root.results) ? root.results : [];
  const out: BusinessLead[] = [];
  for (const item of results) {
    const row = asRecord(item);
    if (!row || !str(row.id)) continue;
    const props = asRecord(row.properties) ?? {};
    const first = str(props.firstname);
    const last = str(props.lastname);
    const name = [first, last].filter(Boolean).join(" ");
    const lastContact = "notes_last_contacted" in props ? str(props.notes_last_contacted) : null;
    out.push({
      source: "hubspot",
      id: str(row.id),
      name,
      email: str(props.email),
      stage: str(props.hs_lead_status),
      lastContact,
    });
  }
  return out;
}

export function hubspotCapabilities(contactsOk: boolean, dealsOk: boolean): string[] {
  const caps: string[] = [];
  if (contactsOk) caps.push("contacts.read");
  if (dealsOk) caps.push("deals.read");
  return caps;
}

export async function hubspotRequest(opts: {
  path: string;
  token: string;
  fetchImpl?: typeof fetch;
}): Promise<HubspotCall> {
  const path = opts.path.startsWith("/") ? opts.path : `/${opts.path}`;
  const url = `${ORIGIN}${path}`;
  assertHubspotUrl(url);
  if (url.includes(opts.token)) {
    throw new Error("CRM request was refused. Nothing was sent.");
  }
  const fetchImpl = opts.fetchImpl ?? fetch;
  try {
    const res = await fetchImpl(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${opts.token}`,
        Accept: "application/json",
      },
      redirect: "error",
    });
    const text = await res.text();
    let body: unknown = null;
    if (text) {
      try {
        body = JSON.parse(text) as unknown;
      } catch {
        body = { message: text.slice(0, 120) };
      }
    }
    if (!res.ok) {
      const message = asRecord(body);
      const err = str(message?.message) || text.slice(0, 120);
      return { ok: false, status: res.status, error: safeProviderError(res.status, err) };
    }
    return { ok: true, status: res.status, body };
  } catch {
    return { ok: false, status: 0, error: "HubSpot could not be reached. Nothing was saved." };
  }
}

export const HUBSPOT_CONTACTS_PATH =
  "/crm/v3/objects/contacts?limit=10&properties=firstname,lastname,email,hs_lead_status,notes_last_contacted";

export const HUBSPOT_DEALS_PATH = "/crm/v3/objects/deals?limit=1&properties=dealname";
