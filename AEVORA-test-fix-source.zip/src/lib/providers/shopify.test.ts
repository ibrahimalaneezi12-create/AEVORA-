import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  normalizeShopHost,
  parseShopifyOrders,
  parseShopifyProducts,
  parseShopifyShop,
  shopifyRequest,
  shopifyShopPath,
} from "./shopify.server.ts";

describe("shopify adapter", () => {
  it("refuses hosts that are not a Shopify shop", () => {
    assert.equal(normalizeShopHost("evil.example"), null);
    assert.equal(normalizeShopHost("https://api.alpaca.markets"), null);
    assert.equal(normalizeShopHost("shop.myshopify.com.evil.com"), null);
    assert.equal(normalizeShopHost("northwind"), "northwind.myshopify.com");
    assert.equal(normalizeShopHost("https://North-Wind.myshopify.com/admin"), "north-wind.myshopify.com");
  });

  it("calls only the shop host and does not put the token in the URL", async () => {
    let seen = "";
    let header = "";
    const result = await shopifyRequest({
      shop: "northwind",
      path: shopifyShopPath(),
      token: "shpat-secret-token",
      fetchImpl: (async (url: string, init?: RequestInit) => {
        seen = String(url);
        header = String((init?.headers as Record<string, string> | undefined)?.["X-Shopify-Access-Token"] ?? "");
        return new Response(JSON.stringify({ shop: { name: "Northwind", currency: "GBP" } }), { status: 200 });
      }) as typeof fetch,
    });
    assert.equal(result.ok, true);
    assert.equal(seen, `https://northwind.myshopify.com${shopifyShopPath()}`);
    assert.equal(seen.includes("shpat-secret-token"), false);
    assert.equal(header, "shpat-secret-token");
    assert.equal(parseShopifyShop({ shop: { name: "Northwind", currency: "GBP" } })?.name, "Northwind");
    assert.equal(parseShopifyShop({}), null);
  });

  it("does not invent orders", () => {
    assert.deepEqual(parseShopifyOrders({}), []);
    const orders = parseShopifyOrders({
      orders: [{ id: 9, total_price: "12.50", currency: "GBP", financial_status: "paid", created_at: "2026-09-01T00:00:00Z" }, { id: "" }],
    });
    assert.equal(orders.length, 1);
    assert.equal(orders[0]?.total, "12.50");
    assert.equal(orders[0]?.status, "paid");
  });

  it("does not invent stock when Shopify omits it", () => {
    assert.deepEqual(parseShopifyProducts({}), []);
    const products = parseShopifyProducts({
      products: [
        { id: 1, title: "Lamp", variants: [{ inventory_quantity: 2 }, { inventory_quantity: 1 }] },
        { id: 2, title: "Cord", variants: [{}] },
      ],
    });
    assert.equal(products[0]?.inventory, "3");
    assert.equal(products[1]?.inventory, null);
  });
});
