import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { appendAudit } from "@/lib/audit";
import {
  CONFIRM_FLOORS,
  mapPermissionSettings,
  type PermissionSettings,
  type PermissionSettingsRow,
} from "./permissions-format.ts";

export {
  CONFIRM_FLOORS,
  asConfirmFloor,
  effectiveLevel,
  isConfirmFloor,
  mapPermissionSettings,
} from "./permissions-format.ts";
export type { ConfirmFloor, PermissionSettings } from "./permissions-format.ts";

async function writeAudit(userId: string, detail: string): Promise<void> {
  await appendAudit({
    userId,
    actor: "user",
    action: "permission.settings.updated",
    entityType: "permission_settings",
    entityId: "settings",
    detail,
  });
}

/**
 * Load this user's policy. Missing rows get catalog defaults. Auto-run is
 * always returned false regardless of what is on disk.
 */
export async function loadPermissionPolicy(userId: string): Promise<PermissionSettings> {
  const sql = await getSql();
  await sql`
    insert into permission_settings (user_id)
    values (${userId})
    on conflict (user_id) do nothing
  `;
  const rows = await sql<PermissionSettingsRow>`
    select confirm_floor, auto_run_safe, auto_run_review, updated_at
    from permission_settings
    where user_id = ${userId}
  `;
  const row = rows[0];
  if (!row) {
    return {
      confirmFloor: "safe",
      autoRunSafe: false,
      autoRunReview: false,
      updatedAt: new Date().toISOString(),
    };
  }
  return mapPermissionSettings(row);
}

export const getPermissionSettings = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<PermissionSettings> => {
    return loadPermissionPolicy(context.userId);
  });

const updateInput = z.object({
  confirmFloor: z.enum(CONFIRM_FLOORS),
});

/**
 * User may raise the confirmation floor. Auto-run cannot be written true.
 * Never accepts a user id from the client.
 */
export const updatePermissionSettings = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => updateInput.parse(input))
  .handler(async ({ context, data }): Promise<PermissionSettings> => {
    const sql = await getSql();
    await sql`
      insert into permission_settings (user_id)
      values (${context.userId})
      on conflict (user_id) do nothing
    `;
    const rows = await sql<PermissionSettingsRow>`
      update permission_settings
      set
        confirm_floor = ${data.confirmFloor},
        auto_run_safe = ${false},
        auto_run_review = ${false},
        updated_at = now()
      where user_id = ${context.userId}
      returning confirm_floor, auto_run_safe, auto_run_review, updated_at
    `;
    const mapped = rows[0] ? mapPermissionSettings(rows[0]) : null;
    if (!mapped) throw new Error("Permission settings could not be saved.");
    await writeAudit(context.userId, `confirm_floor=${mapped.confirmFloor}`);
    return mapped;
  });
