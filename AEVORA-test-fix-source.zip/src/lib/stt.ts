import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getBearerToken } from "@/lib/auth/client";
import { STT_MAX_BYTES } from "@/lib/stt-format";

export { STT_MODEL, STT_MAX_SECONDS } from "@/lib/stt-format";

export type TranscribeClientResult =
  | { ok: true; text: string; sttMs?: number }
  | { ok: false; error: string; unavailable?: boolean; sttMs?: number };

const transcribeInput = z.object({
  audioBase64: z.string().min(8).max(Math.ceil(STT_MAX_BYTES * 1.4)),
  mime: z.string().trim().max(80).optional(),
  locale: z.string().trim().min(2).max(16).optional(),
});

export const transcribeUtterance = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => transcribeInput.parse(input))
  .handler(async ({ data }) => {
    const { transcribeSpeech } = await import("@/lib/stt.server");
    return transcribeSpeech({
      audioBase64: data.audioBase64,
      mime: data.mime,
      locale: data.locale,
    });
  });

export async function transcribeAudioBuffer(
  bytes: Uint8Array,
  mime: string,
  locale?: string,
): Promise<TranscribeClientResult> {
  const token = getBearerToken();
  const headers: Record<string, string> = {
    "Content-Type": mime || "audio/wav",
  };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (locale) headers["X-Aegis-Locale"] = locale;
  const res = await fetch("/api/stt", {
    method: "POST",
    credentials: "include",
    headers,
    body: new Blob([new Uint8Array(bytes)], { type: mime || "audio/wav" }),
  });
  if (res.status === 401) return { ok: false, error: "Sign in to talk to AEVORA." };
  if (!res.ok) {
    return { ok: false, error: `Voice could not be transcribed (${res.status}).` };
  }
  const body = (await res.json()) as TranscribeClientResult;
  if (!body || typeof body !== "object") return { ok: false, error: "I did not catch that. Try again." };
  return body;
}
