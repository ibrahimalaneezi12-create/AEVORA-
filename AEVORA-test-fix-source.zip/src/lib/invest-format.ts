import { clipText } from "./memory-format.ts";
import { sessionOwns } from "./privacy.ts";

export const INVEST_SYMBOL_MAX = 16;
export const INVEST_NAME_MAX = 80;
export const INVEST_THESIS_MAX = 2000;
export const INVEST_NOTE_TITLE_MAX = 80;
export const INVEST_NOTE_BODY_MAX = 4000;
export const INVEST_WATCH_CONTEXT_LIMIT = 12;
export const INVEST_NOTE_CONTEXT_LIMIT = 8;

export const INVEST_NOTE_KINDS = ["note", "thesis", "decision", "paper", "scenario"] as const;
export type InvestNoteKind = (typeof INVEST_NOTE_KINDS)[number];

export type WatchItem = {
  id: number;
  symbol: string;
  name: string;
  thesis: string;
  createdAt: string;
  updatedAt: string;
};

export type InvestNote = {
  id: number;
  symbol: string;
  kind: InvestNoteKind;
  title: string;
  body: string;
  createdAt: string;
  updatedAt: string;
};

export type WatchRow = {
  id: unknown;
  symbol: string;
  name: string;
  thesis: string;
  created_at: unknown;
  updated_at: unknown;
};

export type InvestNoteRow = {
  id: unknown;
  symbol: string;
  kind: string;
  title: string;
  body: string;
  created_at: unknown;
  updated_at: unknown;
};

export type InvestOverview = {
  watchlist: WatchItem[];
  notes: InvestNote[];
  empty: boolean;
  disclaimer: string;
  speech: string;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

export function asInvestNoteKind(value: string): InvestNoteKind {
  return (INVEST_NOTE_KINDS as readonly string[]).includes(value)
    ? (value as InvestNoteKind)
    : "note";
}

export function normalizeSymbol(raw: string): string {
  return raw.trim().toUpperCase().replace(/[^A-Z0-9.-]/g, "").slice(0, INVEST_SYMBOL_MAX);
}

export function mapWatchItem(row: WatchRow): WatchItem | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  const symbol = normalizeSymbol(row.symbol);
  if (!symbol) return null;
  return {
    id,
    symbol,
    name: row.name ?? "",
    thesis: row.thesis ?? "",
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function mapInvestNote(row: InvestNoteRow): InvestNote | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  return {
    id,
    symbol: normalizeSymbol(row.symbol),
    kind: asInvestNoteKind(row.kind),
    title: row.title,
    body: row.body ?? "",
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function investMayAccess(sessionUserId: string, rowUserId: string | null | undefined): boolean {
  return sessionOwns(sessionUserId, rowUserId);
}

export function formatInvestBlock(watchlist: WatchItem[], notes: InvestNote[]): string {
  if (watchlist.length === 0 && notes.length === 0) return "";
  const lines: string[] = [];
  for (const w of watchlist) {
    lines.push(
      `- watch #${w.id} ${w.symbol}${w.name ? ` (${clipText(w.name, 40)})` : ""}${w.thesis ? `: ${clipText(w.thesis, 120)}` : ""}`,
    );
  }
  for (const n of notes) {
    lines.push(`- journal #${n.id} (${n.kind}${n.symbol ? ` ${n.symbol}` : ""}) ${clipText(n.title, 80)}: ${clipText(n.body, 160)}`);
  }
  return lines.join("\n");
}

export const INVEST_DISCLAIMER =
  "Research and decision support only. No guaranteed returns. No autonomous trades. Figures that are not in the keep or current sources are not invented.";

export function composeInvestOverview(watchlist: WatchItem[], notes: InvestNote[]): InvestOverview {
  const empty = watchlist.length === 0 && notes.length === 0;
  const speech = empty
    ? "Your watchlist is empty. Name a company or ticker and I can research it, then propose adding it. I will not invent prices or place a trade."
    : [
        watchlist.length
          ? `Watching ${watchlist.map((w) => w.symbol).join(", ")}.`
          : "No symbols on the watchlist.",
        notes.length ? `${notes.length} journal item${notes.length === 1 ? "" : "s"}.` : "",
        "Live prices are not stored here. Ask me to look up current public information.",
      ]
        .filter(Boolean)
        .join(" ");
  return { watchlist, notes, empty, disclaimer: INVEST_DISCLAIMER, speech };
}

export function isTradeRequest(text: string): boolean {
  return /\b(?:buy|sell|sell short|short sell|go short|market order|limit order|place a trade|execute a trade|wire (?:the )?money|invest\s+[£$€]?\s?\d+)\b/i.test(
    text,
  );
}

/** Paper, thesis, and notes are basic. A rebalance scenario is copilot. */
export function investNoteFeature(kind: InvestNoteKind): "investBasic" | "investCopilot" {
  return kind === "scenario" ? "investCopilot" : "investBasic";
}
