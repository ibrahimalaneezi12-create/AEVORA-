import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  brokerHandoffHtml,
  handoffIsPreviewOnly,
  handoffKeepsSafariFirstPartyTap,
} from "./oauth-handoff-html.ts";

describe("oauth popup handoff html", () => {
  it("keeps a Safari first-party tap without a second Google login button", () => {
    const html = brokerHandoffHtml("https://auth.grok.me/api/auth/oauth2/authorize?state=abc");
    assert.equal(handoffKeepsSafariFirstPartyTap(html), true);
    assert.equal(handoffIsPreviewOnly(html), true);
    assert.match(html, /https:\/\/auth\.grok\.me\/api\/auth\/oauth2\/authorize\?state=abc/);
    assert.match(html, /window\.location\.replace/);
    assert.match(html, /safari/i);
  });

  it("does not use a Host-prefixed OAuth state cookie name in the handoff contract", () => {
    const html = brokerHandoffHtml("https://auth.grok.me/api/auth/oauth2/authorize?state=x");
    assert.equal(html.includes("__Host-grok-auth.state"), false);
  });
});
