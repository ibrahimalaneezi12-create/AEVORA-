import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { answerFact } from "./facts.ts";
import { decideKnowledge } from "./knowledge-format.ts";
import {
  classifyTurnIntent,
  intentWantsResearch,
  intentWantsSearch,
  providerContextFlags,
  shouldSuppressMutatingProposals,
} from "./intent-format.ts";
import { classifyIntelligenceLane } from "./ai/router.ts";
import { buildSystemPrompt, CHAT_COMPLETION_MODEL } from "./ai/complete.server.ts";
import { canRunTool, catalogLevel } from "./orchestrator/catalog.ts";
import { approvalBlockedReason, CANNOT_APPROVE } from "./confirm-format.ts";
import { sanitizeAegisText } from "./personality.ts";
import { looksLikeSafetyRequest } from "./safety-format.ts";
import { isFollowUpTurn } from "./followup-format.ts";
import { isTradeRequest } from "./invest-format.ts";
import { chatModelCandidates, PRIMARY_CHAT_MODEL, shouldTryNextModel, userFacingProviderError } from "./ai/xai-env.server.ts";

describe("intelligence regression — architecture, not memorized answers", () => {
  it("1 time of day is deterministic and fast", () => {
    const fact = answerFact("What time is it?", { now: new Date("2026-09-22T12:00:00Z"), timeZone: "UTC" });
    assert.ok(fact);
    assert.equal(fact.kind, "time");
    assert.equal(classifyIntelligenceLane("What time is it?"), "fast");
  });

  it("2 arithmetic is calculated, not searched", () => {
    assert.equal(decideKnowledge("What is 15 × 7?").action, "calculate");
    assert.equal(intentWantsSearch(classifyTurnIntent("What is 15 × 7?")), false);
  });

  it("3 normal conversation is not an action", () => {
    assert.equal(classifyTurnIntent("I'm bored.").kind, "conversation");
    assert.equal(shouldSuppressMutatingProposals("I'm bored."), true);
  });

  it("4 school questions stay on the model", () => {
    assert.equal(decideKnowledge("What is photosynthesis?").action, "answer");
    assert.equal(classifyTurnIntent("What is photosynthesis?").kind, "question");
  });

  it("5–7 unknown entities and comparisons search or research without hard-coded products", () => {
    for (const q of ["What is Dola?", "What is Perplexity?", "Tell me about Claude", "What is Gemini?", "What is Cursor?"]) {
      assert.equal(decideKnowledge(q).action, "search", q);
    }
    assert.equal(decideKnowledge("Compare Dola and GPT.").action, "research");
    assert.equal(intentWantsResearch(classifyTurnIntent("Compare Dola and GPT.")), true);
  });

  it("8 current information searches", () => {
    assert.equal(classifyTurnIntent("What's the weather?").kind, "search");
    assert.equal(intentWantsSearch(classifyTurnIntent("What's the latest on xAI?")), true);
  });

  it("9 follow-ups resolve in-conversation", () => {
    assert.equal(isFollowUpTurn("Make it 8."), true);
    assert.equal(classifyTurnIntent("Make it 8.").kind, "followup");
  });

  it("10–12 memory retrieve, remember, forget", () => {
    assert.equal(classifyTurnIntent("What did we decide?").kind, "memory");
    assert.equal(classifyTurnIntent("Remember that I prefer short answers.").kind, "memory");
    assert.equal(classifyTurnIntent("Forget that.").kind, "memory");
    assert.equal(providerContextFlags(classifyTurnIntent("Remember that I drink tea."), "Remember that I drink tea.").keep, true);
  });

  it("13–17 tasks, goals, reminders", () => {
    assert.equal(classifyTurnIntent("Create a task: study calculus.").kind, "goals");
    assert.equal(classifyTurnIntent("Create a goal: pass exams.").kind, "goals");
    assert.equal(classifyTurnIntent("Remind me tomorrow at 7.").kind, "reminder");
    assert.equal(classifyTurnIntent("Move that to Thursday.").kind, "followup");
    assert.equal(canRunTool("task.create"), true);
    assert.equal(canRunTool("reminder.create"), true);
  });

  it("18 planning uses keep and calendar, invents nothing in the prompt", () => {
    const intent = classifyTurnIntent("Plan my week.");
    assert.equal(intent.kind, "planning");
    const flags = providerContextFlags(intent, "Plan my week.");
    assert.equal(flags.keep, true);
    assert.equal(flags.calendar, true);
    assert.match(intent.note, /Do not fabricate/);
  });

  it("19–21 calendar and email stay permissioned", () => {
    assert.equal(classifyTurnIntent("What's on my calendar tomorrow?").kind, "action");
    assert.equal(classifyTurnIntent("Draft an email to Sam.").kind, "action");
    assert.equal(catalogLevel("email.send"), "approval");
    assert.equal(catalogLevel("calendar.create"), "review");
    assert.equal(approvalBlockedReason("email.send", "approval"), null);
  });

  it("22–24 business and invest never fabricate and never trade", () => {
    assert.equal(classifyTurnIntent("Check my business health.").kind, "business");
    assert.equal(classifyTurnIntent("Research this company.").kind, "invest");
    assert.equal(classifyTurnIntent("Analyze my investments.").kind, "invest");
    assert.equal(canRunTool("invest.trade"), false);
    assert.equal(isTradeRequest("Place a trade for NVDA"), true);
    assert.match(classifyTurnIntent("Check my business health.").note, /Never invent revenue/);
  });

  it("25 study planning is learning", () => {
    assert.equal(classifyTurnIntent("Help me study this. Make a study plan.").kind, "learning");
  });

  it("26–27 multilingual language switch", () => {
    assert.equal(classifyTurnIntent("Switch to Arabic.").kind, "language_switch");
    assert.equal(classifyTurnIntent("Switch to Arabic.").language, "ar");
    assert.match(buildSystemPrompt("", "ar"), /Arabic/);
  });

  it("28–29 voice is the same brain — no extra tools", () => {
    assert.equal(canRunTool("chat.reply"), false);
    assert.equal(CHAT_COMPLETION_MODEL, PRIMARY_CHAT_MODEL);
  });

  it("30–32 tools, confirmation, restricted", () => {
    assert.equal(canRunTool("memory.save"), true);
    assert.equal(approvalBlockedReason("permission.update", "restricted"), CANNOT_APPROVE);
    assert.equal(canRunTool("permission.update"), false);
    assert.equal(canRunTool("external.http"), false);
  });

  it("33 failed provider requests stay generic", () => {
    assert.match(userFacingProviderError(403), /unavailable/i);
    assert.doesNotMatch(userFacingProviderError(403), /403/);
    assert.equal(shouldTryNextModel(403), true);
    assert.equal(shouldTryNextModel(401), false);
    assert.deepEqual(chatModelCandidates("deep").slice(0, 3), ["grok-4.5", "grok-4", "grok-3"]);
  });

  it("34 privacy isolation of provider context", () => {
    const casual = providerContextFlags(classifyTurnIntent("I'm bored."), "I'm bored.");
    assert.deepEqual(casual, { keep: false, calendar: false, mail: false, business: false, invest: false });
    const search = providerContextFlags(classifyTurnIntent("What is Dola?"), "What is Dola?");
    assert.equal(search.keep, false);
    assert.equal(search.business, false);
    const biz = providerContextFlags(classifyTurnIntent("Check my business health."), "Check my business health.");
    assert.equal(biz.business, true);
    assert.equal(biz.mail, false);
    const company = providerContextFlags(classifyTurnIntent("Research this company."), "Research this company.");
    assert.equal(company.invest, false);
    assert.equal(company.keep, false);
    assert.equal(providerContextFlags(classifyTurnIntent("What is an ETF?"), "What is an ETF?").invest, false);
  });

  it("35 personality does not mirror profanity", () => {
    assert.equal(sanitizeAegisText("That is fucking slow.").includes("fuck"), false);
  });

  it("safety, travel, and missions stay on one brain", () => {
    assert.equal(looksLikeSafetyRequest("Is this email phishing?"), true);
    assert.equal(classifyTurnIntent("Is this a scam?").kind, "safety");
    assert.equal(classifyTurnIntent("Plan a trip to Tokyo.").kind, "travel");
    assert.equal(classifyTurnIntent("Help me start a YouTube channel.").kind, "planning");
    assert.equal(classifyIntelligenceLane("Help me start a YouTube channel."), "deep");
  });
});
