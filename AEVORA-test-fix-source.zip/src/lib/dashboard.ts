import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { displayNameFor } from "@/lib/orchestrator/catalog";
import type { PermissionLevel } from "@/lib/orchestrator/types";
import { mapGoal, mapTask, type GoalRow, type TaskRow } from "./goals-format.ts";
import { mapMemory, type MemoryRow } from "./memory-format.ts";
import { parseChatWorkspace } from "./chat-workspace.ts";
import {
  DASHBOARD_MEMORY_LIMIT,
  DASHBOARD_PENDING_LIMIT,
  composeDashboard,
  type DashboardConversation,
  type DashboardPending,
  type DashboardSnapshot,
} from "./dashboard-format.ts";

export {
  DASHBOARD_GOALS_LIMIT,
  DASHBOARD_MEMORY_LIMIT,
  DASHBOARD_PENDING_LIMIT,
  DASHBOARD_TASKS_LIMIT,
  calendarDateInZone,
  classifyDue,
  composeDashboard,
  firstName,
  pickActiveGoals,
  pickTodaysTasks,
  relativeLabel,
} from "./dashboard-format.ts";
export type {
  DashboardConversation,
  DashboardGoal,
  DashboardMemory,
  DashboardPending,
  DashboardSnapshot,
  DashboardTask,
  DueKind,
} from "./dashboard-format.ts";

type PendingRow = {
  id: unknown;
  conversation_id: unknown;
  tool_id: string;
  permission_level: string;
  title: string;
  summary: string;
  created_at: unknown;
};

type ConversationRow = {
  id: unknown;
  title: string;
  updated_at: unknown;
  workspace?: unknown;
};

type ProfileBits = {
  display_name: string | null;
  timezone: string;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

function asLevel(value: string): PermissionLevel {
  if (value === "safe" || value === "review" || value === "approval" || value === "restricted") {
    return value;
  }
  return "restricted";
}

function mapPending(row: PendingRow): DashboardPending | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  const conversationId = asPositiveInt(row.conversation_id);
  return {
    id,
    conversationId: conversationId || null,
    toolId: row.tool_id,
    displayName: displayNameFor(row.tool_id),
    permissionLevel: asLevel(row.permission_level),
    title: row.title,
    summary: row.summary,
    createdAt: toIso(row.created_at),
  };
}

function mapLastConversation(row: ConversationRow): DashboardConversation | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  return {
    id,
    title: row.title || "New conversation",
    updatedAt: toIso(row.updated_at),
    workspace: parseChatWorkspace(row.workspace),
  };
}

/**
 * Read-only composition of the keep. Every query is scoped to the session
 * user. Does not write. Does not return proposal payloads.
 */
export const getDashboard = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<DashboardSnapshot> => {
    const sql = await getSql();
    const userId = context.userId;

    const [
      profileRows,
      pendingCountRows,
      pendingRows,
      goalRows,
      taskRows,
      memoryRows,
      conversationRows,
    ] = await Promise.all([
      sql<ProfileBits>`
        select display_name, timezone
        from profiles
        where user_id = ${userId}
      `,
      sql<{ n: number }>`
        select count(*)::int as n
        from proposed_actions
        where user_id = ${userId} and status = ${"pending"}
      `,
      sql<PendingRow>`
        select id, conversation_id, tool_id, permission_level, title, summary, created_at
        from proposed_actions
        where user_id = ${userId} and status = ${"pending"}
        order by created_at desc
        limit ${DASHBOARD_PENDING_LIMIT}
      `,
      sql<GoalRow>`
        select id, title, description, status, target_date, created_at, updated_at
        from goals
        where user_id = ${userId}
        order by
          case status
            when 'active' then 0
            when 'paused' then 1
            when 'done' then 2
            else 3
          end,
          updated_at desc
        limit 100
      `,
      sql<TaskRow>`
        select id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
        from tasks
        where user_id = ${userId}
        order by sort_order asc, id asc
        limit 200
      `,
      sql<MemoryRow>`
        select id, kind, title, body, tags, source, pinned, created_at, updated_at
        from memories
        where user_id = ${userId}
        order by pinned desc, updated_at desc
        limit ${DASHBOARD_MEMORY_LIMIT}
      `,
      sql<ConversationRow>`
        select id, title, updated_at, workspace
        from conversations
        where user_id = ${userId} and archived = false
        order by updated_at desc
        limit 1
      `,
    ]);

    const pending: DashboardPending[] = [];
    for (const row of pendingRows) {
      const mapped = mapPending(row);
      if (mapped) pending.push(mapped);
    }
    const goals = [];
    for (const row of goalRows) {
      const mapped = mapGoal(row);
      if (mapped) goals.push(mapped);
    }
    const tasks = [];
    for (const row of taskRows) {
      const mapped = mapTask(row);
      if (mapped) tasks.push(mapped);
    }
    const memories = [];
    for (const row of memoryRows) {
      const mapped = mapMemory(row);
      if (mapped) memories.push(mapped);
    }

    return composeDashboard({
      displayName: profileRows[0]?.display_name ?? null,
      timezone: profileRows[0]?.timezone || "UTC",
      now: new Date(),
      pendingTotal: pendingCountRows[0]?.n ?? pending.length,
      pending,
      goals,
      tasks,
      memories,
      lastConversation: conversationRows[0] ? mapLastConversation(conversationRows[0]) : null,
    });
  });
