/**
 * One AEVORA brain, three conversation workspaces.
 * A thread belongs to exactly one of them. Messages are not copied across.
 */

export const CHAT_WORKSPACES = ["main", "business", "invest"] as const;
export type ChatWorkspaceId = (typeof CHAT_WORKSPACES)[number];

export function parseChatWorkspace(value: unknown): ChatWorkspaceId {
  if (value === "business" || value === "invest" || value === "main") return value;
  return "main";
}

/** Same user, wrong thread still does not open. Cross-user is a separate check. */
export function workspaceAllows(stored: unknown, requested: ChatWorkspaceId): boolean {
  return parseChatWorkspace(stored) === requested;
}

export function workspaceIntentNote(workspace: ChatWorkspaceId): string {
  if (workspace === "business") {
    return "This thread is Business chat. It is not personal chat and not Invest chat. Use only saved business records and sources that answered. If a source is not connected, say so. Do not invent leads, orders, stock, spend, or revenue.";
  }
  if (workspace === "invest") {
    return "This thread is Invest chat. It is not personal chat and not Business chat. Do not invent balances, holdings, prices, or fills. Pending is not filled. Paper is not live.";
  }
  return "";
}

export function workspaceDraftKey(workspace: ChatWorkspaceId): string {
  return `aegis-chat-draft:${workspace}`;
}

export function conversationIdFromHash(hash: string): number | null | "invalid" {
  const raw = hash.replace(/^#/, "");
  if (raw === "chat") return null;
  const match = raw.match(/^chat\/([^/]+)$/);
  if (!match) return "invalid";
  const id = match[1] ?? "";
  const n = Number.parseInt(id, 10);
  if (!Number.isInteger(n) || n < 1 || String(n) !== id) return "invalid";
  return n;
}

export function workspaceFromPathname(pathname: string): ChatWorkspaceId {
  if (pathname === "/app/business" || pathname.startsWith("/app/business/")) return "business";
  if (pathname === "/app/invest" || pathname.startsWith("/app/invest/")) return "invest";
  return "main";
}

export function workspaceChatPath(
  workspace: ChatWorkspaceId,
): "/app/chat" | "/app/business" | "/app/invest" {
  if (workspace === "business") return "/app/business";
  if (workspace === "invest") return "/app/invest";
  return "/app/chat";
}

/** Hash fragment for a workspace thread. Empty string clears a leftover hash. */
export function workspaceChatHash(workspace: ChatWorkspaceId, conversationId?: number | null): string {
  if (workspace === "main") return "";
  return conversationId && conversationId > 0 ? `chat/${conversationId}` : "chat";
}

/** Plain href for <a> tags that cannot use the router Link hash prop. */
export function workspaceChatHref(workspace: ChatWorkspaceId, conversationId?: number | null): string {
  const path = workspaceChatPath(workspace);
  if (workspace === "main") {
    return conversationId && conversationId > 0 ? `/app/chat/${conversationId}` : "/app/chat";
  }
  return `${path}#${workspaceChatHash(workspace, conversationId)}`;
}

export function workspaceThreadLink(
  workspace: ChatWorkspaceId,
  conversationId: number,
):
  | { to: "/app/chat/$id"; params: { id: string }; hash: "" }
  | { to: "/app/business"; params?: undefined; hash: string }
  | { to: "/app/invest"; params?: undefined; hash: string } {
  if (workspace === "business") {
    return { to: "/app/business", hash: `chat/${conversationId}` };
  }
  if (workspace === "invest") {
    return { to: "/app/invest", hash: `chat/${conversationId}` };
  }
  return { to: "/app/chat/$id", params: { id: String(conversationId) }, hash: "" };
}

export function isWorkspaceChatHash(hash: string): boolean {
  const raw = hash.replace(/^#/, "");
  return raw === "chat" || raw.startsWith("chat/");
}
