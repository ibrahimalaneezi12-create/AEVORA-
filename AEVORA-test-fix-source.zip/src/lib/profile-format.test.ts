import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { asQuietHour, asResponseStyle, quietHoursPair } from "./profile-format.ts";

describe("response style", () => {
  it("accepts the three styles and refuses junk", () => {
    assert.equal(asResponseStyle("direct"), "direct");
    assert.equal(asResponseStyle("warm"), "warm");
    assert.equal(asResponseStyle("calm"), "calm");
    assert.equal(asResponseStyle("sassy"), "calm");
    assert.equal(asResponseStyle(""), "calm");
  });
});

describe("quiet hours pair", () => {
  it("requires both bounds", () => {
    assert.deepEqual(quietHoursPair(22, 7), { start: 22, end: 7 });
    assert.deepEqual(quietHoursPair(22, null), { start: null, end: null });
    assert.deepEqual(quietHoursPair("nope", 7), { start: null, end: null });
    assert.equal(asQuietHour(24), null);
    assert.equal(asQuietHour(0), 0);
  });
});
