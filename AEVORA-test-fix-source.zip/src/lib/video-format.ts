export const VIDEO_MODEL = "grok-imagine-video-1.5";
export const VIDEO_EDIT_MODEL = "grok-imagine-video";
export const VIDEO_PROVIDER = "xai";

export const VIDEO_ASPECTS = ["16:9", "9:16", "1:1", "4:3", "3:4", "3:2", "2:3"] as const;
export type VideoAspect = (typeof VIDEO_ASPECTS)[number];

export const VIDEO_RESOLUTIONS = ["480p", "720p", "1080p"] as const;
export type VideoResolution = (typeof VIDEO_RESOLUTIONS)[number];

export const VIDEO_STATUSES = ["draft", "queued", "processing", "completed", "failed", "cancelled"] as const;
export type VideoStatus = (typeof VIDEO_STATUSES)[number];

export const VIDEO_JOB_KINDS = ["generate", "image_to_video", "edit"] as const;
export type VideoJobKind = (typeof VIDEO_JOB_KINDS)[number];

export const SCENE_DURATION_MIN = 1;
export const SCENE_DURATION_MAX = 15;
export const PROJECT_SCENE_MAX = 4;
export const VIDEO_TITLE_MAX = 120;
export const VIDEO_PROMPT_MAX = 2000;
export const VIDEO_CAPTION_MAX = 4000;
export const VIDEO_IMAGE_MAX_BYTES = 3_500_000;

export type VideoScenePlan = {
  title: string;
  prompt: string;
  durationSec: number;
  camera: string;
};

export type VideoPlan = {
  title: string;
  description: string;
  aspectRatio: VideoAspect;
  resolution: VideoResolution;
  generateAudio: boolean;
  captions: string;
  scenes: VideoScenePlan[];
  notes: string[];
};

export type VideoScene = {
  id: number;
  projectId: number;
  sortOrder: number;
  title: string;
  prompt: string;
  durationSec: number;
  camera: string;
  status: VideoStatus;
  error: string;
  hasMedia: boolean;
};

export type VideoProject = {
  id: number;
  title: string;
  description: string;
  status: VideoStatus;
  aspectRatio: VideoAspect;
  resolution: VideoResolution;
  generateAudio: boolean;
  captions: string;
  captionsLocale: string;
  brief: string;
  scenes: VideoScene[];
  createdAt: string;
  updatedAt: string;
};

export type VideoJob = {
  id: number;
  projectId: number;
  sceneId: number | null;
  kind: string;
  status: VideoStatus;
  model: string;
  error: string;
  durationSec: number | null;
  resolution: string;
  aspectRatio: string;
  createdAt: string;
  updatedAt: string;
};

export type VideoVersion = {
  id: number;
  label: string;
  createdAt: string;
};

export type VideoCapabilities = {
  provider: typeof VIDEO_PROVIDER;
  model: typeof VIDEO_MODEL;
  textToVideo: true;
  imageToVideo: true;
  referenceToVideo: true;
  videoToVideo: false;
  promptVideoEdit: true;
  autoKillDetection: false;
  lipSyncDedicated: false;
  burnInCaptions: false;
  ffmpegStitch: false;
  maxDurationSec: typeof SCENE_DURATION_MAX;
  maxScenes: typeof PROJECT_SCENE_MAX;
  resolutions: typeof VIDEO_RESOLUTIONS;
  aspects: typeof VIDEO_ASPECTS;
  fps: "provider-default";
  audio: "native-when-generate_audio";
  maxExport: "1080p clip per scene";
};

export const VIDEO_CAPABILITIES: VideoCapabilities = {
  provider: VIDEO_PROVIDER,
  model: VIDEO_MODEL,
  textToVideo: true,
  imageToVideo: true,
  referenceToVideo: true,
  videoToVideo: false,
  promptVideoEdit: true,
  autoKillDetection: false,
  lipSyncDedicated: false,
  burnInCaptions: false,
  ffmpegStitch: false,
  maxDurationSec: SCENE_DURATION_MAX,
  maxScenes: PROJECT_SCENE_MAX,
  resolutions: VIDEO_RESOLUTIONS,
  aspects: VIDEO_ASPECTS,
  fps: "provider-default",
  audio: "native-when-generate_audio",
  maxExport: "1080p clip per scene",
};

export function isVideoAspect(value: string | null | undefined): value is VideoAspect {
  return (VIDEO_ASPECTS as readonly string[]).includes(value ?? "");
}

export function isVideoResolution(value: string | null | undefined): value is VideoResolution {
  return (VIDEO_RESOLUTIONS as readonly string[]).includes(value ?? "");
}

export function asVideoAspect(value: string | null | undefined): VideoAspect {
  return isVideoAspect(value) ? value : "16:9";
}

export function asVideoResolution(value: string | null | undefined): VideoResolution {
  return isVideoResolution(value) ? value : "720p";
}


export function clampSceneDuration(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return 8;
  return Math.min(SCENE_DURATION_MAX, Math.max(SCENE_DURATION_MIN, Math.round(n)));
}

export function asVideoStatus(value: string | null | undefined): VideoStatus {
  if (value && (VIDEO_STATUSES as readonly string[]).includes(value)) return value as VideoStatus;
  return "draft";
}

const GAMING_RE =
  /\b(fortnite|roblox|minecraft|call of duty|cod\b|fifa|ea sports|rocket league|valorant|warzone|gameplay|montage|esports|clutch|sweaty)\b/i;
const SHORT_RE = /\b(tiktok|reel|shorts?|vertical|9\s*[x:]\s*16|phone video)\b/i;
const SQUARE_RE = /\b(1\s*[x:]\s*1|square|instagram post)\b/i;
const CINEMA_RE = /\b(cinematic|film|movie|dramatic|noir)\b/i;
const DURATION_RE = /(\d{1,2})\s*-?\s*(?:s|sec|secs|second|seconds)\b/i;
const CAMERA_HINTS: Array<[RegExp, string]> = [
  [/\b(dolly|push[- ]?in|push in)\b/i, "slow push-in"],
  [/\b(pull[- ]?out|pull out|reveal)\b/i, "pull-out"],
  [/\b(orbit|circle around)\b/i, "orbit"],
  [/\b(tracking|follow)\b/i, "tracking shot"],
  [/\b(crane|aerial|drone)\b/i, "aerial"],
  [/\b(handheld|shaky)\b/i, "handheld"],
  [/\b(close[- ]?up)\b/i, "close-up"],
  [/\b(wide shot|establishing)\b/i, "wide shot"],
  [/\b(first[- ]?person|pov)\b/i, "first-person"],
];

function titleFromBrief(brief: string): string {
  const trimmed = brief.trim().replace(/\s+/g, " ");
  if (!trimmed) return "Untitled video";
  const first = trimmed.split(/[.!?]/)[0]?.trim() || trimmed;
  return first.slice(0, VIDEO_TITLE_MAX);
}

function cameraFrom(brief: string): string {
  for (const [re, label] of CAMERA_HINTS) {
    if (re.test(brief)) return label;
  }
  if (CINEMA_RE.test(brief)) return "cinematic dolly";
  return "steady cinematic";
}

function styleSuffix(brief: string): string {
  const bits: string[] = [];
  if (GAMING_RE.test(brief)) {
    bits.push(
      "high-energy gameplay edit, punchy cuts, no invented kill detection, keep the subject framed",
    );
  }
  if (CINEMA_RE.test(brief)) bits.push("cinematic lighting, shallow depth, filmic colour");
  if (SHORT_RE.test(brief)) bits.push("hook in the first second, vertical-safe framing");
  return bits.length ? ` ${bits.join(". ")}.` : "";
}

function splitScenes(brief: string, totalSec: number): VideoScenePlan[] {
  const style = styleSuffix(brief);
  const camera = cameraFrom(brief);
  const sceneCount = Math.min(PROJECT_SCENE_MAX, Math.max(1, Math.ceil(totalSec / SCENE_DURATION_MAX)));
  const per = clampSceneDuration(totalSec / sceneCount);
  const scenes: VideoScenePlan[] = [];
  for (let i = 0; i < sceneCount; i += 1) {
    const beat =
      i === 0
        ? "Opening beat. Strong first frame. "
        : i === sceneCount - 1
          ? "Closing beat. Hold the final image. "
          : `Continuing beat ${i + 1}. Match the same subject and wardrobe. `;
    scenes.push({
      title: sceneCount === 1 ? "Scene" : `Scene ${i + 1}`,
      prompt: `${beat}${brief.trim()}${style} Camera: ${camera}.`.slice(0, VIDEO_PROMPT_MAX),
      durationSec: per,
      camera,
    });
  }
  return scenes;
}

export function planVideoRequest(brief: string): VideoPlan {
  const text = brief.trim().slice(0, VIDEO_PROMPT_MAX);
  const notes: string[] = [];
  let aspect: VideoAspect = "16:9";
  if (SHORT_RE.test(text)) aspect = "9:16";
  else if (SQUARE_RE.test(text)) aspect = "1:1";
  const durationMatch = text.match(DURATION_RE);
  const asked = durationMatch ? Number(durationMatch[1]) : 8;
  const total = Math.min(SCENE_DURATION_MAX * PROJECT_SCENE_MAX, Math.max(SCENE_DURATION_MIN, asked || 8));
  if (asked > SCENE_DURATION_MAX) {
    notes.push(
      `Each generated clip is at most ${SCENE_DURATION_MAX}s. Longer asks become consecutive scenes, previewed one clip at a time.`,
    );
  }
  let resolution: VideoResolution = CINEMA_RE.test(text) ? "1080p" : "720p";
  if (/\b4k\b/i.test(text)) {
    resolution = "1080p";
    notes.push("4K is not available. Using 1080p, the highest supported export.");
  }
  if (/\b60\s*fps\b/i.test(text)) {
    notes.push("Frame rate is the provider default. 60 FPS is not a selectable export.");
  }
  if (/\b(only keep the kills|detect kills|auto highlight)\b/i.test(text)) {
    notes.push("Automatic kill/highlight detection is not available. Describe the moments you want kept.");
  }
  const scenes = splitScenes(text || "A calm cinematic establishing shot.", total);
  return {
    title: titleFromBrief(text || "Untitled video"),
    description: text,
    aspectRatio: aspect,
    resolution,
    generateAudio: !/\b(silent|no audio|mute)\b/i.test(text),
    captions: "",
    scenes,
    notes,
  };
}

export function applyNaturalEdit(plan: VideoPlan, instruction: string): VideoPlan {
  const next: VideoPlan = {
    ...plan,
    scenes: plan.scenes.map((s) => ({ ...s })),
    notes: [...plan.notes],
  };
  const text = instruction.trim();
  if (!text) return next;
  if (SHORT_RE.test(text)) next.aspectRatio = "9:16";
  if (SQUARE_RE.test(text)) next.aspectRatio = "1:1";
  if (/\b(16\s*[x:]\s*9|landscape|widescreen)\b/i.test(text)) next.aspectRatio = "16:9";
  if (/\b1080\b/i.test(text) || /\b4k\b/i.test(text)) next.resolution = "1080p";
  if (/\b720\b/i.test(text)) next.resolution = "720p";
  if (/\b480\b/i.test(text)) next.resolution = "480p";
  if (/\b(silent|no audio|mute)\b/i.test(text)) next.generateAudio = false;
  if (/\b(with audio|sound on|voiceover)\b/i.test(text)) next.generateAudio = true;
  if (/\b(faster|shorter|cut down)\b/i.test(text)) {
    next.scenes = next.scenes.map((s) => ({ ...s, durationSec: clampSceneDuration(s.durationSec - 2) }));
  }
  if (/\b(slower|longer|more dramatic)\b/i.test(text)) {
    next.scenes = next.scenes.map((s) => ({ ...s, durationSec: clampSceneDuration(s.durationSec + 2) }));
  }
  if (/\b(use the second (clip|scene) first|swap|move this scene before)\b/i.test(text) && next.scenes.length > 1) {
    const [a, b, ...rest] = next.scenes;
    if (a && b) next.scenes = [b, a, ...rest];
  }
  if (/\b(captions|subtitles)\b/i.test(text) && !next.captions) {
    next.captions = next.description.slice(0, VIDEO_CAPTION_MAX);
    next.notes.push("Captions are shown on the player. They are not burned into the file.");
  }
  if (/\bdarker\b/i.test(text)) {
    next.scenes = next.scenes.map((s) => ({
      ...s,
      prompt: `${s.prompt} Mood: darker, low-key lighting.`.slice(0, VIDEO_PROMPT_MAX),
    }));
  }
  if (/\bending faster\b/i.test(text) && next.scenes.length) {
    const last = next.scenes[next.scenes.length - 1];
    if (last) last.durationSec = clampSceneDuration(Math.max(SCENE_DURATION_MIN, last.durationSec - 3));
  }
  if (text && !SHORT_RE.test(text) && !/\b(16\s*[x:]\s*9|silent|captions|darker|faster|slower)\b/i.test(text)) {
    next.scenes = next.scenes.map((s) => ({
      ...s,
      prompt: `${s.prompt} Revision: ${text}`.slice(0, VIDEO_PROMPT_MAX),
    }));
    next.description = `${next.description} ${text}`.trim().slice(0, VIDEO_PROMPT_MAX);
  }
  return next;
}

export function qualityGate(plan: VideoPlan): string[] {
  const issues: string[] = [];
  if (!plan.scenes.length) issues.push("Add at least one scene.");
  if (plan.scenes.some((s) => !s.prompt.trim())) issues.push("A scene is missing a description.");
  if (!isVideoAspect(plan.aspectRatio)) issues.push("That aspect ratio is not supported.");
  if (!isVideoResolution(plan.resolution)) issues.push("That resolution is not supported.");
  if (plan.scenes.length > PROJECT_SCENE_MAX) issues.push(`At most ${PROJECT_SCENE_MAX} scenes.`);
  return issues;
}

export const VIDEO_ASPECT_LABELS: Record<VideoAspect, string> = {
  "16:9": "Landscape",
  "9:16": "Portrait",
  "1:1": "Square",
  "4:3": "Classic",
  "3:4": "Tall",
  "3:2": "Photo",
  "2:3": "Poster",
};

export const VIDEO_RESOLUTION_LABELS: Record<VideoResolution, string> = {
  "480p": "Faster",
  "720p": "High",
  "1080p": "Highest",
};

export type StudioControls = {
  aspectRatio: VideoAspect;
  resolution: VideoResolution;
  durationSec: number;
  generateAudio: boolean;
};

export const DEFAULT_STUDIO_CONTROLS: StudioControls = {
  aspectRatio: "16:9",
  resolution: "720p",
  durationSec: 8,
  generateAudio: true,
};

export function applyStudioControls(plan: VideoPlan, controls: StudioControls): VideoPlan {
  const durationSec = clampSceneDuration(controls.durationSec);
  return {
    ...plan,
    aspectRatio: isVideoAspect(controls.aspectRatio) ? controls.aspectRatio : plan.aspectRatio,
    resolution: isVideoResolution(controls.resolution) ? controls.resolution : plan.resolution,
    generateAudio: Boolean(controls.generateAudio),
    scenes: plan.scenes.map((scene) => ({ ...scene, durationSec })),
  };
}

export function jobStatusCopy(status: VideoStatus): { title: string; detail: string } {
  if (status === "queued" || status === "processing") {
    return { title: "Creating your scene", detail: "Your video is being generated." };
  }
  if (status === "completed") return { title: "Ready", detail: "Your scene is ready to watch." };
  if (status === "cancelled") return { title: "Cancelled", detail: "Generation was stopped." };
  if (status === "failed") {
    return { title: "Could not create this scene", detail: "Something went wrong while creating your video. Please try again." };
  }
  return { title: "Draft", detail: "Describe a scene, then generate." };
}

export function publicVideoError(message: string | null | undefined): string {
  const text = (message || "").trim();
  if (!text) return "Something went wrong while creating your video. Please try again.";
  if (/sk-[a-zA-Z0-9]|api[_-]?key|bearer\s/i.test(text)) {
    return "Something went wrong while creating your video. Please try again.";
  }
  if (/\b(403|401)\b/.test(text) || /unavailable|xai key/i.test(text)) return "Video generation is unavailable right now.";
  if (/unauthorized/i.test(text)) return "Sign in to create video.";
  if (/not found/i.test(text)) return "Not found.";
  if (/3\.5|too large|still image/i.test(text)) return text;
  if (/could not start|could not be reached|status failed/i.test(text)) {
    return "Something went wrong while creating your video. Please try again.";
  }
  if (text.length > 180) return "Something went wrong while creating your video. Please try again.";
  return text;
}

export function aspectFrameClass(aspect: string): string {
  if (aspect === "9:16" || aspect === "3:4" || aspect === "2:3") return "aspect-[9/16] max-h-[70vh] mx-auto";
  if (aspect === "1:1") return "aspect-square max-h-[70vh] mx-auto";
  if (aspect === "4:3" || aspect === "3:2") return "aspect-[4/3]";
  return "aspect-video";
}

export function snapshotPlan(plan: Pick<VideoPlan, "title" | "description" | "aspectRatio" | "resolution" | "generateAudio" | "captions" | "scenes">): string {
  return JSON.stringify({
    title: plan.title,
    description: plan.description,
    aspectRatio: plan.aspectRatio,
    resolution: plan.resolution,
    generateAudio: plan.generateAudio,
    captions: plan.captions,
    scenes: plan.scenes,
  });
}

export function buildVideoGenerationBody(input: {
  prompt: string;
  duration: number;
  aspectRatio: VideoAspect;
  resolution: VideoResolution;
  generateAudio: boolean;
  imageDataUrl?: string | null;
}): Record<string, unknown> {
  const body: Record<string, unknown> = {
    model: VIDEO_MODEL,
    prompt: input.prompt,
    duration: input.duration,
    aspect_ratio: input.aspectRatio,
    resolution: input.resolution,
    generate_audio: input.generateAudio,
  };
  if (input.imageDataUrl) {
    body.image = { url: input.imageDataUrl, type: "image_url" };
  }
  return body;
}

export function buildVideoEditBody(input: { prompt: string; videoDataUri: string }): Record<string, unknown> {
  return {
    model: VIDEO_EDIT_MODEL,
    prompt: input.prompt,
    video: { url: input.videoDataUri, type: "video_url" },
  };
}
