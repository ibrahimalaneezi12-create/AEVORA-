import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { completeSentencesForSpeech, normalizeForSpeech, splitSpeakableSentences, stripProposalFence } from "./speech-normalize.ts";

describe("normalizeForSpeech", () => {
  it("does not speak markdown or raw URLs", () => {
    const spoken = normalizeForSpeech(
      "**Hello** visit https://example.com/path and `code`.",
    );
    assert.equal(spoken.includes("**"), false);
    assert.equal(/https?:\/\//i.test(spoken), false);
    assert.match(spoken, /Hello/);
    assert.match(spoken, /link/i);
  });

  it("splits into natural phrases", () => {
    const parts = splitSpeakableSentences(
      "First sentence. Second sentence is a bit longer than the first one.",
    );
    assert.ok(parts.length >= 1);
    assert.equal(parts.join(" ").includes("**"), false);
  });
});

describe("completeSentencesForSpeech", () => {
  it("does not speak an unfinished last sentence or a proposal fence", () => {
    const first =
      "Aegis kept the keep private and never ran a tool without asking you first.";
    const parts = completeSentencesForSpeech(`${first} And this unfinished thought`);
    assert.deepEqual(parts, [first]);
    assert.equal(stripProposalFence("Hello. <<<aegis-proposals\n[]").trim(), "Hello.");
    assert.ok(completeSentencesForSpeech("Hello. <<<aegis-proposals\n[]").join(" ").includes("Hello"));
  });

  it("can start speaking a finished clause while a long sentence is still growing", () => {
    const growing =
      "Yeah, I can help with that, the weather tomorrow looks clear across the afternoon so";
    const parts = completeSentencesForSpeech(growing);
    assert.ok(parts.length >= 1);
    assert.match(parts[0] ?? "", /Yeah, I can help with that,/);
    assert.equal(parts.join(" ").includes("afternoon so"), false);
  });
});
