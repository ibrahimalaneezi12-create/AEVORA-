import { looksLikeFact } from "./facts.ts";
import { looksLikeSafetyRequest } from "./safety-format.ts";

/**
 * When to answer from the model vs search/research vs calculate.
 * No hard-coded products or people — unknown names trigger search.
 */

const COMMON_SCHOOL_TOPICS =
  /\b(photosynthesis|gravity|atom|molecule|democracy|noun|verb|adjective|mitosis|dna|rna|algebra|geometry|fractions?|percent(?:age)?|evaporation|condensation|volcano|earthquake|solar system|planet|oxygen|carbon|hydrogen|water cycle|food chain|ecosystem|mammal|reptile|integer|prime number|pythagoras|newton|einstein)\b/i;

const FRESHNESS_RE =
  /\b(latest|current(?:ly)?|right now|as of|today'?s|this week|who won|score|headline|weather|forecast|stock price|release(?:d)?|version of|changelog|pricing|is .* still|available now|202[4-9]|flight(?:s)?|hotel(?:s)?)\b/i;

const COMPARE_RE =
  /\b(compare|vs\.?|versus|difference between|better(?: one)?)\b/i;

const INVEST_RESEARCH_RE =
  /\b(analy[sz]e this (?:investment|company|stock)|research this company|investment thesis|bull case|bear case)\b/i;

const EXPLAIN_RE =
  /^(?:hey aegis[, ]+)?(?:find out (?:what|who)\s+|what(?:'?s| is)\s+|who(?:'?s| is)\s+|tell me about\s+|explain\s+|define\s+)(.+?)(?:\s+is)?\s*[.?!؟]*$/i;

const STOP = new Set(
  "the a an of and or to for in on at it this that what who how why is are was were my your our their".split(" "),
);

export type KnowledgeAction = "answer" | "search" | "research" | "calculate";

export type KnowledgeDecision = {
  action: KnowledgeAction;
  reason: string;
};

function leftoverTopic(text: string): string {
  const match = text.trim().match(EXPLAIN_RE);
  let topic = (match?.[1] ?? "").trim();
  topic = topic.replace(/\s+is$/i, "").trim();
  return topic;
}

function looksLikeNamedEntity(topic: string): boolean {
  const words = topic.split(/\s+/).filter(Boolean);
  if (words.length === 0 || words.length > 6) return false;
  if (COMMON_SCHOOL_TOPICS.test(topic)) return false;
  if (words.some((w) => /[A-Z]/.test(w[0] ?? "") || /[0-9]/.test(w) || /[-./+]/.test(w))) return true;
  if (words.length <= 3 && words.every((w) => !STOP.has(w.toLowerCase()))) {
    const joined = words.join(" ");
    if (joined.length >= 3 && joined.length <= 40) return true;
  }
  return false;
}

export function needsFreshness(text: string): boolean {
  return FRESHNESS_RE.test(text);
}

export function isCompareQuestion(text: string): boolean {
  return COMPARE_RE.test(text) && /\b(and|vs\.?|versus|or)\b/i.test(text);
}

export function decideKnowledge(text: string): KnowledgeDecision {
  const trimmed = text.trim();
  if (!trimmed) return { action: "answer", reason: "empty" };
  if (looksLikeFact(trimmed)) return { action: "calculate", reason: "deterministic" };
  if (looksLikeSafetyRequest(trimmed)) return { action: "answer", reason: "safety-heuristic" };
  if (
    isCompareQuestion(trimmed) ||
    /\bresearch\b/i.test(trimmed) ||
    /\binvestigate\b/i.test(trimmed) ||
    INVEST_RESEARCH_RE.test(trimmed)
  ) {
    return { action: "research", reason: "compare-or-research" };
  }
  if (needsFreshness(trimmed)) {
    return { action: "search", reason: "freshness" };
  }
  if (/\bfind out (?:what|who)\b/i.test(trimmed)) {
    return { action: "search", reason: "unknown-entity" };
  }
  const topic = leftoverTopic(trimmed);
  if (topic && looksLikeNamedEntity(topic)) {
    return { action: "search", reason: "unknown-entity" };
  }
  return { action: "answer", reason: "model-knowledge" };
}