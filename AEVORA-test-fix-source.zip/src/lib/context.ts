/**
 * Server-only context assembly. Dynamic-import from createServerFn handlers.
 * Never import from client components.
 */
import { getSql } from "@/lib/db";
import { resolveLocale, resolveTurnLocale, type AppLocale } from "@/lib/locale";
import { retrieveMemories } from "@/lib/memory";
import { listOwnRemindersForContext } from "@/lib/reminders";
import { mapGoal, mapTask, type GoalRow, type TaskRow } from "@/lib/goals-format";
import {
  calendarDateInZone,
  classifyDue,
  pickActiveGoals,
  pickTodaysTasks,
} from "@/lib/dashboard-format";
import {
  CONTEXT_GOALS_LIMIT,
  CONTEXT_PENDING_LIMIT,
  CONTEXT_REMINDERS_LIMIT,
  CONTEXT_TASKS_LIMIT,
  assemblePromptBlock,
  contextTrace,
  type AssembledBits,
  type ContextPending,
  type ContextTrace,
} from "@/lib/context-format";

export type AssembledContext = {
  locale: AppLocale;
  promptBlock: string;
  trace: ContextTrace;
  responseStyle: string;
};

type ProfileBits = {
  locale: string | null;
  detect_language: boolean | null;
  timezone: string | null;
  fallback_language: string | null;
  response_style: string | null;
};

type PendingRow = {
  id: unknown;
  title: string;
  permission_level: string;
};

function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

export async function assembleContext(
  userId: string,
  opts: {
    query: string;
    now?: Date;
    includeCalendar?: boolean;
    includeMail?: boolean;
    includeKeep?: boolean;
    includeBusiness?: boolean;
    includeInvest?: boolean;
  },
): Promise<AssembledContext> {
  const sql = await getSql();
  const now = opts.now ?? new Date();
  const includeCalendar = opts.includeCalendar === true;
  const includeMail = opts.includeMail === true;
  const includeKeep = opts.includeKeep !== false;
  const includeBusiness = opts.includeBusiness === true;
  const includeInvest = opts.includeInvest === true;

  const [profileRows, goalRows, taskRows, pendingRows, memories, reminderRows, calendarBlock, mailBlock, businessBits, investBits] =
    await Promise.all([
    sql<ProfileBits>`
      select locale, detect_language, timezone, fallback_language, response_style
      from profiles
      where user_id = ${userId}
    `,
    includeKeep
      ? sql<GoalRow>`
      select id, title, description, status, target_date, created_at, updated_at
      from goals
      where user_id = ${userId}
      order by
        case status
          when 'active' then 0
          when 'paused' then 1
          when 'done' then 2
          else 3
        end,
        updated_at desc
      limit 40
    `
      : Promise.resolve([] as GoalRow[]),
    includeKeep
      ? sql<TaskRow>`
      select id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
      from tasks
      where user_id = ${userId}
      order by sort_order asc, id asc
      limit 80
    `
      : Promise.resolve([] as TaskRow[]),
    includeKeep
      ? sql<PendingRow>`
      select id, title, permission_level
      from proposed_actions
      where user_id = ${userId} and status = ${"pending"}
      order by created_at desc
      limit ${CONTEXT_PENDING_LIMIT}
    `
      : Promise.resolve([] as PendingRow[]),
    includeKeep ? retrieveMemories(userId, opts.query) : Promise.resolve([]),
    includeKeep ? listOwnRemindersForContext(userId) : Promise.resolve([]),
    includeCalendar ? loadCalendarBlock(userId, now) : Promise.resolve(""),
    includeMail ? loadMailBlock(userId) : Promise.resolve(""),
    includeBusiness ? loadBusinessBlock(userId, opts.query) : Promise.resolve(""),
    includeInvest ? loadInvestBlock(userId, opts.query) : Promise.resolve(""),
  ]);

  const preferred = resolveLocale(profileRows[0]?.locale);
  const detect = profileRows[0]?.detect_language !== false;
  const locale = resolveTurnLocale({
    preferred,
    detect,
    text: opts.query,
    fallback: resolveLocale(profileRows[0]?.fallback_language),
  });
  const timezone = profileRows[0]?.timezone?.trim() || "UTC";
  const today = calendarDateInZone(now, timezone);

  const goals = [];
  for (const row of goalRows) {
    const mapped = mapGoal(row);
    if (mapped) goals.push(mapped);
  }
  const tasks = [];
  for (const row of taskRows) {
    const mapped = mapTask(row);
    if (mapped) tasks.push(mapped);
  }

  const pending: ContextPending[] = [];
  for (const row of pendingRows) {
    const id = asPositiveInt(row.id);
    if (!id) continue;
    pending.push({
      id,
      title: row.title,
      permissionLevel: row.permission_level,
    });
  }

  const bits: AssembledBits = {
    locale,
    memories,
    goals: pickActiveGoals(goals, CONTEXT_GOALS_LIMIT).map((g) => ({
      id: g.id,
      title: g.title,
      targetDate: g.targetDate,
    })),
    tasks: pickTodaysTasks(tasks, today, CONTEXT_TASKS_LIMIT).map((t) => ({
      id: t.id,
      title: t.title,
      dueDate: t.dueDate,
      status: t.status,
      dueKind: classifyDue(t.dueDate, today) === "none" ? undefined : classifyDue(t.dueDate, today),
    })),
    pending,
    reminders: reminderRows.slice(0, CONTEXT_REMINDERS_LIMIT).map((r) => ({
      id: r.id,
      title: r.title,
      fireAt: r.fireAt,
      recurrence: r.recurrence,
      status: r.status,
    })),
    businessBlock: businessBits,
    investBlock: investBits,
  };

  return {
    locale,
    responseStyle: profileRows[0]?.response_style?.trim() || "calm",
    promptBlock: [
      assemblePromptBlock(bits),
      calendarBlock ? `<calendar>\n${calendarBlock}\n</calendar>` : "",
      mailBlock ? `<mail>\n${mailBlock}\n</mail>` : "",
    ]
      .filter(Boolean)
      .join("\n\n"),
    trace: contextTrace(bits),
  };
}

async function loadCalendarBlock(userId: string, now: Date): Promise<string> {
  try {
    const { listOwnCalendarForContext, formatCalendarBlock, peekGoogleCalendar, formatGoogleCalendarBlock } =
      await import("@/lib/calendar");
    const events = await listOwnCalendarForContext(userId, now);
    let block = formatCalendarBlock(events);
    const google = await peekGoogleCalendar();
    block = [block, formatGoogleCalendarBlock(google)].filter(Boolean).join("\n");
    return block;
  } catch {
    return "";
  }
}

async function loadMailBlock(userId: string): Promise<string> {
  try {
    const { listOwnDraftsForContext, formatDraftsBlock, peekGmailInbox, formatGmailBlock } =
      await import("@/lib/mail");
    const drafts = await listOwnDraftsForContext(userId);
    let block = formatDraftsBlock(drafts);
    block = [block, formatGmailBlock(await peekGmailInbox())].filter(Boolean).join("\n");
    return block;
  } catch {
    return "";
  }
}

async function loadBusinessBlock(userId: string, query: string): Promise<string> {
  try {
    const { loadBusinessContextBlock } = await import("@/lib/business");
    return await loadBusinessContextBlock(userId, query);
  } catch {
    return "";
  }
}

async function loadInvestBlock(userId: string, query: string): Promise<string> {
  try {
    const { listOwnInvestForContext, listOwnInvestPlans } = await import("@/lib/invest");
    const { formatInvestBlock } = await import("@/lib/invest-format");
    const { watchlist, notes } = await listOwnInvestForContext(userId);
    const plans = await listOwnInvestPlans(userId);
    const block = formatInvestBlock(watchlist, notes);
    const planLines = plans
      .map((plan) => {
        const horizon = plan.horizon ? ` Horizon you wrote: ${plan.horizon}.` : "";
        const contribution = plan.contribution ? ` Contribution you wrote: ${plan.contribution}.` : "";
        return `Investment plan #${plan.id}: ${plan.title}.${horizon}${contribution} It does not place an order and does not guarantee a result.`;
      })
      .join("\n");
    const { questionNeedsPortfolio, portfolioAnalysisSpeech, portfolioSpeech, comparisonSpeech, scenarioSpeech, rebalanceSpeech, thesisSpeech, journalSpeech, watchSpeech } = await import("@/lib/invest-brain");
    let speech = "";
    if (questionNeedsPortfolio(query)) {
      const { readBrokerSnapshot } = await import("@/lib/broker.server");
      const snapshot = await readBrokerSnapshot(userId);
      speech = /\b(diversif|concentrat|allocation|analy)/i.test(query)
        ? portfolioAnalysisSpeech(snapshot)
        : portfolioSpeech(snapshot);
      if (/\brebalanc/i.test(query)) speech = `${speech} ${rebalanceSpeech(plans.length > 0, snapshot)}`;
    } else if (/\brebalanc/i.test(query)) {
      speech = rebalanceSpeech(plans.length > 0, { connected: false, verified: false, mode: null, provider: "", capabilities: [], account: null, positions: [], orders: [], accountStatus: "", lastCheckedAt: "", error: "" });
    }
    if (/\bcompare\b/i.test(query)) speech = [speech, comparisonSpeech()].filter(Boolean).join(" ");
    if (/\b(bull|base case|bear)\b/i.test(query)) speech = [speech, scenarioSpeech()].filter(Boolean).join(" ");
    if (/\bthesis\b/i.test(query)) {
      speech = [speech, thesisSpeech(notes.filter((note) => note.kind === "thesis"))].filter(Boolean).join(" ");
    }
    if (/\bjournal\b/i.test(query)) speech = [speech, journalSpeech(notes.length)].filter(Boolean).join(" ");
    if (/\bwatch(?:list|ing)?\b/i.test(query)) speech = [speech, watchSpeech(watchlist.map((item) => item.symbol))].filter(Boolean).join(" ");
    return [block, planLines, speech].filter(Boolean).join("\n");
  } catch {
    return "";
  }
}
