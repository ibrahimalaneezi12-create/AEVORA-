import { speechTagFor } from "./languages.ts";

export type CuratedVoice = {
  id: string;
  name: string;
  style: string;
  gender: "female" | "male";
};

export const CURATED_VOICES: readonly CuratedVoice[] = [
  { id: "liora", name: "Liora", style: "Calm, warm, conversational", gender: "female" },
  { id: "lux", name: "Lux", style: "Grounded, calm, quietly wise", gender: "male" },
  { id: "rigel", name: "Rigel", style: "Precise, professional, clear", gender: "male" },
  { id: "carina", name: "Carina", style: "Soft, empathetic, soothing", gender: "female" },
  { id: "celeste", name: "Celeste", style: "Compassionate and reassuring", gender: "female" },
  { id: "ara", name: "Ara", style: "Warm and friendly", gender: "female" },
  { id: "rex", name: "Rex", style: "Confident and clear", gender: "male" },
  { id: "eve", name: "Eve", style: "Energetic and upbeat", gender: "female" },
];

export const DEFAULT_TTS_VOICE = "liora";
export const TTS_TEXT_MAX = 1800;
export const TTS_SPEED_MIN = 0.7;
export const TTS_SPEED_MAX = 1.5;

const BY_ID = new Map(CURATED_VOICES.map((v) => [v.id, v]));

export function lookupCuratedVoice(id: string | null | undefined): CuratedVoice | null {
  const key = (id ?? "").trim().toLowerCase();
  if (!key) return null;
  return BY_ID.get(key) ?? null;
}

export function resolveTtsVoiceId(preferred: string | null | undefined): string {
  return lookupCuratedVoice(preferred)?.id ?? DEFAULT_TTS_VOICE;
}

const TTS_LANGS = new Set([
  "en",
  "ar-EG",
  "ar-SA",
  "ar-AE",
  "bn",
  "zh",
  "fr",
  "de",
  "hi",
  "id",
  "it",
  "ja",
  "ko",
  "pt-BR",
  "pt-PT",
  "ru",
  "es-MX",
  "es-ES",
  "tr",
  "vi",
]);

export function ttsLanguageFor(locale: string | null | undefined): string {
  const tag = speechTagFor(locale ?? "en");
  if (TTS_LANGS.has(tag)) return tag;
  const prefix = (locale ?? "en").split(/[-_]/)[0]?.toLowerCase() || "en";
  if (prefix === "ar") return "ar-SA";
  if (prefix === "es") return "es-ES";
  if (prefix === "pt") return "pt-PT";
  if (prefix === "zh") return "zh";
  if (TTS_LANGS.has(prefix)) return prefix;
  return "auto";
}

export function clampTtsSpeed(value: number | null | undefined): number {
  if (typeof value !== "number" || !Number.isFinite(value)) return 1;
  return Math.min(TTS_SPEED_MAX, Math.max(TTS_SPEED_MIN, value));
}
