/**
 * Rebuild an auth request against the public preview origin.
 * The live preview proxy often keeps Host as loopback while sending
 * X-Forwarded-Host as *.grok-sandbox.com. Better Auth's OAuth redirect_uri
 * must be that public host or the Grok broker rejects Google/X callbacks
 * with invalid_grant / invalid code.
 *
 * Only grok-sandbox hosts are trusted from forwarded headers.
 */
export function isGrokSandboxHost(host: string): boolean {
  const name = host.split(":")[0]?.trim().toLowerCase() ?? "";
  return name === "grok-sandbox.com" || name.endsWith(".grok-sandbox.com");
}

/** First value of a possibly comma-stacked forwarded header. */
export function firstForwardedValue(value: string | null | undefined): string | undefined {
  const part = value?.split(",")[0]?.trim();
  return part ? part : undefined;
}

export function previewForwarding(request: Request): { host: string; proto: "http" | "https" } | null {
  const forwardedHost = firstForwardedValue(request.headers.get("x-forwarded-host"));
  if (!forwardedHost || !isGrokSandboxHost(forwardedHost)) return null;
  const forwardedProto = firstForwardedValue(request.headers.get("x-forwarded-proto"));
  return {
    host: forwardedHost,
    proto: forwardedProto === "http" ? "http" : "https",
  };
}

export function publicAuthUrl(request: Request): URL {
  const url = new URL(request.url);
  const forwarding = previewForwarding(request);
  if (forwarding) {
    const [hostname, port] = forwarding.host.split(":");
    url.hostname = hostname ?? forwarding.host;
    url.port = port ?? "";
    url.protocol = `${forwarding.proto}:`;
  }
  return url;
}

/** Headers Better Auth should use so authorize + token share one redirect_uri. */
export function authBrokerHeaders(request: Request): Headers {
  const headers = new Headers(request.headers);
  const forwarding = previewForwarding(request);
  if (forwarding) {
    const publicUrl = publicAuthUrl(request);
    headers.set("host", publicUrl.host);
    headers.set("x-forwarded-host", forwarding.host);
    headers.set("x-forwarded-proto", forwarding.proto);
  }
  return headers;
}

export function requestForAuthBroker(request: Request): Request {
  const publicUrl = publicAuthUrl(request);
  const original = new URL(request.url);
  const forwarding = previewForwarding(request);
  if (publicUrl.href === original.href && !forwarding) return request;
  const headers = authBrokerHeaders(request);
  const init: RequestInit & { duplex?: "half" } = {
    method: request.method,
    headers,
    redirect: "manual",
  };
  if (request.method !== "GET" && request.method !== "HEAD") {
    init.body = request.body;
    init.duplex = "half";
  }
  return new Request(publicUrl.href, init);
}
