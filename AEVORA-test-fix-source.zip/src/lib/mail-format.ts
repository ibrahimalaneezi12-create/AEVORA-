export const EMAIL_SUBJECT_MAX = 200;
export const EMAIL_BODY_MAX = 8000;
export const EMAIL_STATUSES = ["draft", "sent", "failed"] as const;
export type EmailStatus = (typeof EMAIL_STATUSES)[number];

export type EmailDraft = {
  id: number;
  toAddress: string;
  ccAddress: string;
  subject: string;
  body: string;
  status: EmailStatus;
  conversationId: number | null;
  sentAt: string | null;
  error: string;
  createdAt: string;
  updatedAt: string;
};

export type EmailDraftRow = {
  id: unknown;
  to_address: string;
  cc_address: string;
  subject: string;
  body: string;
  status: string;
  conversation_id: unknown;
  sent_at: unknown;
  error: string;
  created_at: unknown;
  updated_at: unknown;
};

function toIso(value: unknown): string | null {
  if (value == null) return null;
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

export function mapEmailDraft(row: EmailDraftRow): EmailDraft | null {
  const id = asId(row.id);
  if (!id) return null;
  const status: EmailStatus =
    row.status === "sent" || row.status === "failed" ? row.status : "draft";
  return {
    id,
    toAddress: row.to_address,
    ccAddress: row.cc_address ?? "",
    subject: row.subject,
    body: row.body,
    status,
    conversationId: asId(row.conversation_id) || null,
    sentAt: toIso(row.sent_at),
    error: row.error ?? "",
    createdAt: toIso(row.created_at) ?? "",
    updatedAt: toIso(row.updated_at) ?? "",
  };
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function looksLikeEmail(value: string): boolean {
  return EMAIL_RE.test(value.trim());
}

export function formatDraftsBlock(rows: EmailDraft[]): string {
  if (rows.length === 0) return "";
  return rows
    .slice(0, 6)
    .map((row) => `- (#${row.id} ${row.status}) To ${row.toAddress}: ${row.subject}`)
    .join("\n");
}

