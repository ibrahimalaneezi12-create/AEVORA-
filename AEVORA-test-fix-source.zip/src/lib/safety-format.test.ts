import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { assessDigitalSafety, looksLikeSafetyRequest } from "./safety-format.ts";

describe("digital safety", () => {
  it("recognizes an explicit safety question", () => {
    assert.equal(looksLikeSafetyRequest("Is this a scam?"), true);
    assert.equal(looksLikeSafetyRequest("What time is it?"), false);
  });

  it("flags typical phishing patterns without claiming certainty", () => {
    const verdict = assessDigitalSafety(
      "Your account will be closed immediately. Verify your password here http://bit.ly/unlock-now and send a gift card.",
    );
    assert.equal(verdict.stance, "suspicious");
    assert.ok(verdict.reasons.length >= 2);
    assert.match(verdict.advice, /cannot be certain/i);
  });

  it("stays uncertain on a single weak signal", () => {
    const verdict = assessDigitalSafety("This invoice is due today, please pay now.");
    assert.equal(verdict.stance, "uncertain");
    assert.match(verdict.advice, /not proof/i);
  });

  it("does not certify a clean message as safe", () => {
    const verdict = assessDigitalSafety("Lunch tomorrow at 1?");
    assert.equal(verdict.stance, "clear");
    assert.match(verdict.advice, /cannot certify/i);
  });
});
