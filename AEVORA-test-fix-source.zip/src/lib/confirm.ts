import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { appendAudit } from "@/lib/audit";
import { displayNameFor } from "@/lib/orchestrator/catalog";
import type { PermissionLevel } from "@/lib/orchestrator/types";
import { parseChatWorkspace, type ChatWorkspaceId } from "@/lib/chat-workspace";
import {
  CANNOT_APPROVE,
  NOT_FOUND,
  NOT_PENDING,
  mapConfirmView,
  type ProposalConfirmView,
  type ProposalRow,
} from "@/lib/confirm-format";

export type { ProposalConfirmView } from "@/lib/confirm-format";

type FullRow = ProposalRow;

async function writeAudit(
  userId: string,
  actor: "user" | "system",
  action: string,
  entityType: string,
  entityId: string,
  permissionLevel: PermissionLevel | null,
  detail: string,
): Promise<void> {
  await appendAudit({
    userId,
    actor,
    action,
    entityType,
    entityId,
    permissionLevel,
    detail,
  });
}

async function loadOwn(userId: string, id: number): Promise<FullRow | null> {
  const sql = await getSql();
  const rows = await sql<FullRow>`
    select
      id, conversation_id, tool_id, permission_level, title, summary,
      payload_json, status, created_at, error
    from proposed_actions
    where id = ${id} and user_id = ${userId}
  `;
  return rows[0] ?? null;
}

function toView(row: FullRow, result: string | null = null): ProposalConfirmView {
  const mapped = mapConfirmView(row, displayNameFor(row.tool_id), result);
  if (!mapped) throw new Error(NOT_FOUND);
  return mapped;
}

async function conversationWorkspace(
  userId: string,
  conversationId: number | null,
): Promise<ChatWorkspaceId> {
  if (!conversationId) return "main";
  const sql = await getSql();
  const rows = await sql<{ workspace: unknown }>`
    select workspace from conversations
    where id = ${conversationId} and user_id = ${userId}
  `;
  return parseChatWorkspace(rows[0]?.workspace);
}

async function toViewForUser(
  userId: string,
  row: FullRow,
  result: string | null = null,
): Promise<ProposalConfirmView> {
  const view = toView(row, result);
  view.workspace = await conversationWorkspace(userId, view.conversationId);
  return view;
}

async function executeTool(userId: string, row: FullRow): Promise<string> {
  const { executeRegisteredTool } = await import("@/lib/tools/registry");
  const proposalId = typeof row.id === "number" ? row.id : Number(row.id);
  return executeRegisteredTool({
    userId,
    toolId: row.tool_id,
    payloadJson: row.payload_json ?? "{}",
    title: row.title,
    summary: row.summary,
    proposalId: Number.isInteger(proposalId) && proposalId > 0 ? proposalId : undefined,
  });
}

async function markTerminal(
  userId: string,
  id: number,
  status: "executed" | "failed",
  error: string | null,
): Promise<FullRow | null> {
  const sql = await getSql();
  const rows = await sql<FullRow>`
    update proposed_actions
    set
      status = ${status},
      executed_at = now(),
      error = ${error}
    where id = ${id} and user_id = ${userId} and status = ${"approved"}
    returning
      id, conversation_id, tool_id, permission_level, title, summary,
      payload_json, status, created_at, error
  `;
  return rows[0] ?? null;
}

const idInput = z.object({
  id: z.number().int().positive(),
});

/**
 * Load one of this user's proposals, including a plain-language payload.
 * Never accepts a user id from the client. Other users' rows look not found.
 */
export const getProposal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<ProposalConfirmView> => {
    const row = await loadOwn(context.userId, data.id);
    if (!row) throw new Error(NOT_FOUND);
    return toViewForUser(context.userId, row);
  });

/**
 * Deny a pending proposal. Does not execute. Replay and non-pending rows fail.
 */
export const denyProposal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<ProposalConfirmView> => {
    const existing = await loadOwn(context.userId, data.id);
    if (!existing) throw new Error(NOT_FOUND);
    if (existing.status !== "pending") throw new Error(NOT_PENDING);

    const sql = await getSql();
    const rows = await sql<FullRow>`
      update proposed_actions
      set status = ${"denied"}, decided_at = now()
      where id = ${data.id} and user_id = ${context.userId} and status = ${"pending"}
      returning
        id, conversation_id, tool_id, permission_level, title, summary,
        payload_json, status, created_at, error
    `;
    const row = rows[0];
    if (!row) throw new Error(NOT_PENDING);
    await writeAudit(
      context.userId,
      "user",
      "proposal.denied",
      "proposed_action",
      String(data.id),
      toView(row).permissionLevel,
      `${row.tool_id}: ${row.title}`,
    );
    return toViewForUser(context.userId, row);
  });

/**
 * Approve a pending proposal and execute it once through the tool registry.
 * Restricted / unregistered / handler-less tools cannot be approved.
 * Replay does not execute again.
 */
export const approveProposal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<ProposalConfirmView> => {
    const existing = await loadOwn(context.userId, data.id);
    if (!existing) throw new Error(NOT_FOUND);

    const preview = toView(existing);
    if (existing.status !== "pending") throw new Error(NOT_PENDING);
    if (!preview.canApprove) throw new Error(preview.blockedReason ?? CANNOT_APPROVE);

    const sql = await getSql();
    const claimed = await sql<FullRow>`
      update proposed_actions
      set status = ${"approved"}, decided_at = now()
      where id = ${data.id} and user_id = ${context.userId} and status = ${"pending"}
      returning
        id, conversation_id, tool_id, permission_level, title, summary,
        payload_json, status, created_at, error
    `;
    const claimedRow = claimed[0];
    if (!claimedRow) throw new Error(NOT_PENDING);

    await writeAudit(
      context.userId,
      "user",
      "proposal.approved",
      "proposed_action",
      String(data.id),
      preview.permissionLevel,
      `${claimedRow.tool_id}: ${claimedRow.title}`,
    );

    try {
      const result = await executeTool(context.userId, claimedRow);
      const done = await markTerminal(context.userId, data.id, "executed", null);
      const finalRow = done ?? (await loadOwn(context.userId, data.id));
      if (!finalRow) throw new Error(NOT_FOUND);
      await writeAudit(
        context.userId,
        "system",
        "proposal.executed",
        "proposed_action",
        String(data.id),
        preview.permissionLevel,
        result,
      );
      return toViewForUser(context.userId, finalRow, result);
    } catch (err) {
      const message = err instanceof Error ? err.message : "This action failed.";
      const failed = await markTerminal(context.userId, data.id, "failed", message);
      const finalRow = failed ?? (await loadOwn(context.userId, data.id));
      if (!finalRow) throw new Error(NOT_FOUND);
      await writeAudit(
        context.userId,
        "system",
        "proposal.failed",
        "proposed_action",
        String(data.id),
        preview.permissionLevel,
        message,
      );
      return toViewForUser(context.userId, finalRow);
    }
  });
