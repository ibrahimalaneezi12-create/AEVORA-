import { localeLabel, type AppLocale } from "./locale.ts";
import { clipText, formatMemoryBlock, type Memory } from "./memory-format.ts";

export const CONTEXT_GOALS_LIMIT = 4;
export const CONTEXT_TASKS_LIMIT = 6;
export const CONTEXT_PENDING_LIMIT = 3;
export const CONTEXT_REMINDERS_LIMIT = 6;
export const CONTEXT_CHAR_BUDGET = 3600;

export type ContextGoal = {
  id: number;
  title: string;
  targetDate: string | null;
};

export type ContextTask = {
  id: number;
  title: string;
  dueDate: string | null;
  status: string;
  dueKind?: "overdue" | "today" | string;
};

export type ContextPending = {
  id: number;
  title: string;
  permissionLevel: string;
};

export type ContextReminder = {
  id: number;
  title: string;
  fireAt: string;
  recurrence: string;
  status: string;
};

export type AssembledBits = {
  locale: AppLocale;
  memories: Memory[];
  goals: ContextGoal[];
  tasks: ContextTask[];
  pending: ContextPending[];
  reminders?: ContextReminder[];
  businessBlock?: string;
  investBlock?: string;
};

export type ContextTrace = {
  locale: AppLocale;
  memoryIds: number[];
  goalIds: number[];
  taskIds: number[];
  pendingIds: number[];
  reminderIds: number[];
};

export function formatGoalsBlock(rows: ContextGoal[]): string {
  if (rows.length === 0) return "";
  return rows
    .map((g) => {
      const when = g.targetDate ? ` — target ${g.targetDate}` : "";
      return `- (#${g.id}) ${clipText(g.title, 80)}${when}`;
    })
    .join("\n");
}

export function formatTasksBlock(rows: ContextTask[]): string {
  if (rows.length === 0) return "";
  return rows
    .map((t) => {
      const due = t.dueDate ? ` — due ${t.dueDate}` : "";
      const kind = t.dueKind ? ` ${t.dueKind}` : "";
      return `- (#${t.id}${kind}) ${clipText(t.title, 80)}${due}`;
    })
    .join("\n");
}

export function formatPendingBlock(rows: ContextPending[]): string {
  if (rows.length === 0) return "";
  return rows
    .map(
      (p) =>
        `- (#${p.id} ${p.permissionLevel}) ${clipText(p.title, 80)} — waiting for your Approve`,
    )
    .join("\n");
}

function wrap(tag: string, inner: string): string {
  const t = inner.trim();
  if (!t) return "";
  return `<${tag}>\n${t}\n</${tag}>`;
}

export function formatRemindersBlock(rows: ContextReminder[]): string {
  if (rows.length === 0) return "";
  return rows
    .map(
      (r) =>
        `- (#${r.id} ${r.status} ${r.recurrence}) ${clipText(r.title, 80)} — ${r.fireAt}`,
    )
    .join("\n");
}

export function languageFooter(locale: AppLocale): string {
  const label = localeLabel(locale);
  const names =
    label.native && label.native !== label.english
      ? `${label.english} / ${label.native}`
      : label.english;
  return [
    `Language: ${names} (${locale}). Reply in the user's current language.`,
    "Mixed-language turns are valid. Follow-ups (that, it, tomorrow, the other one, actually make it 8) refer to this conversation.",
    "Context is not permission. Never claim you already acted. Do not silent-save a message as memory.",
    "When updating or forgetting, use the memory/task/goal/reminder id from this block.",
    "Do not invent calendar events. Reminders are reminder.create, not task.create.",
    "Do not invent business revenue or investment prices. Missing figures stay missing.",
  ].join(" ");
}

export function assemblePromptBlock(bits: AssembledBits): string {
  const parts = [
    wrap("user-memory", formatMemoryBlock(bits.memories)),
    wrap("active-goals", formatGoalsBlock(bits.goals)),
    wrap("open-tasks", formatTasksBlock(bits.tasks)),
    wrap("scheduled-reminders", formatRemindersBlock(bits.reminders ?? [])),
    wrap("pending-actions", formatPendingBlock(bits.pending)),
    wrap("business", bits.businessBlock ?? ""),
    wrap("invest", bits.investBlock ?? ""),
    languageFooter(bits.locale),
  ].filter(Boolean);
  const joined = parts.join("\n\n");
  if (joined.length <= CONTEXT_CHAR_BUDGET) return joined;
  return `${joined.slice(0, CONTEXT_CHAR_BUDGET).trimEnd()}…`;
}

export function contextTrace(bits: AssembledBits): ContextTrace {
  return {
    locale: bits.locale,
    memoryIds: bits.memories.map((m) => m.id),
    goalIds: bits.goals.map((g) => g.id),
    taskIds: bits.tasks.map((t) => t.id),
    pendingIds: bits.pending.map((p) => p.id),
    reminderIds: (bits.reminders ?? []).map((r) => r.id),
  };
}
