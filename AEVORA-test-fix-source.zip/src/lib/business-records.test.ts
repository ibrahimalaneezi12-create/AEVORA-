import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { followUpSpeech, leadSpeech, mailboxSpeech, orderMoneySpeech, productStockSpeech } from "./business-records.ts";

describe("business records", () => {
  it("does not invent leads or revenue", () => {
    assert.match(leadSpeech({ connected: false, leads: [], error: "" }), /No CRM is connected/);
    assert.match(orderMoneySpeech({ connected: false, orders: [], error: "" }), /not being calculated/);
    assert.match(mailboxSpeech("not_connected", []), /won't guess/);
    const partial = orderMoneySpeech({
      connected: true,
      error: "",
      orders: [
        { source: "shopify", id: "1", total: "10.00", currency: "GBP", status: "paid", createdAt: "" },
        { source: "shopify", id: "2", total: "", currency: "GBP", status: "paid", createdAt: "" },
      ],
    });
    assert.match(partial, /not calculated/);
    assert.equal(/£\d|\$\d/.test(partial), false);
  });

  it("sums only complete returned totals and does not call that full revenue", () => {
    const speech = orderMoneySpeech({
      connected: true,
      error: "",
      orders: [
        { source: "shopify", id: "1", total: "10.50", currency: "GBP", status: "paid", createdAt: "" },
        { source: "shopify", id: "2", total: "2.50", currency: "GBP", status: "paid", createdAt: "" },
      ],
    });
    assert.match(speech, /13\.00 GBP/);
    assert.match(speech, /not the store's full revenue/);
  });

  it("does not treat a missing last-contact field as a follow-up", () => {
    const none = followUpSpeech([
      { source: "hubspot", id: "1", name: "Ada", email: "", stage: "", lastContact: null },
    ]);
    assert.match(none, /will not say who needs a follow-up/);
    const empty = followUpSpeech([
      { source: "hubspot", id: "1", name: "Ada", email: "", stage: "", lastContact: "" },
    ]);
    assert.match(empty, /Confidence is low/);
    assert.match(empty, /not proof/);
  });

  it("does not invent stock", () => {
    assert.match(productStockSpeech({ connected: false, products: [], error: "" }), /not read/);
    const missing = productStockSpeech({
      connected: true,
      error: "",
      products: [{ title: "Lamp", inventory: null }],
    });
    assert.match(missing, /not calculated/);
    assert.equal(/\b0\b/.test(missing), false);
  });
});
