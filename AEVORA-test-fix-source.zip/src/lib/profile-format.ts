export const RESPONSE_STYLES = ["calm", "direct", "warm"] as const;
export type ResponseStyle = (typeof RESPONSE_STYLES)[number];

export const RESPONSE_STYLE_COPY: Record<ResponseStyle, { label: string; hint: string }> = {
  calm: { label: "Calm", hint: "Measured, unhurried" },
  direct: { label: "Direct", hint: "Short sentences" },
  warm: { label: "Warm", hint: "Kind, not familiar" },
};

export function isResponseStyle(value: string | null | undefined): value is ResponseStyle {
  return value === "calm" || value === "direct" || value === "warm";
}

export function asResponseStyle(value: string | null | undefined): ResponseStyle {
  return isResponseStyle(value) ? value : "calm";
}

export function asQuietHour(value: unknown): number | null {
  if (value == null || value === "") return null;
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 0 || n > 23) return null;
  return n;
}

/** Both hours or neither. A lone bound is treated as off. */
export function quietHoursPair(
  start: unknown,
  end: unknown,
): { start: number | null; end: number | null } {
  const s = asQuietHour(start);
  const e = asQuietHour(end);
  if (s == null || e == null) return { start: null, end: null };
  return { start: s, end: e };
}

export function formatHourLabel(hour: number): string {
  return `${String(hour).padStart(2, "0")}:00`;
}
