import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  advanceAfterDelivery,
  canClaimStatus,
  isDuplicateFire,
  retryOrFail,
  snoozeInstant,
} from "./reminders-format.ts";
import type { Reminder } from "./reminders-format.ts";

function rem(partial: Partial<Reminder>): Reminder {
  return {
    id: 1,
    title: "Study",
    body: "calculus",
    timezone: "UTC",
    fireAt: "2026-09-18T19:00:00.000Z",
    localDate: "2026-09-18",
    localTime: "19:00",
    recurrence: "once",
    weekday: null,
    status: "scheduled",
    snoozeUntil: null,
    lastFiredAt: null,
    locale: "en",
    retryCount: 0,
    relatedTaskId: null,
    relatedGoalId: null,
    createdAt: "2026-09-18T00:00:00.000Z",
    updatedAt: "2026-09-18T00:00:00.000Z",
    ...partial,
  };
}

describe("duplicate prevention", () => {
  it("treats fires within a minute as duplicates", () => {
    const a = rem({});
    assert.equal(isDuplicateFire(a.fireAt, new Date("2026-09-18T19:00:30.000Z")), true);
    assert.equal(isDuplicateFire(a.fireAt, new Date("2026-09-18T19:05:00.000Z")), false);
  });
});

describe("claim / advance", () => {
  it("only scheduled and snoozed can be claimed", () => {
    assert.equal(canClaimStatus("scheduled"), true);
    assert.equal(canClaimStatus("snoozed"), true);
    assert.equal(canClaimStatus("pending_delivery"), false);
    assert.equal(canClaimStatus("cancelled"), false);
  });

  it("completes a one-time reminder after delivery and reschedules daily", () => {
    const once = advanceAfterDelivery(rem({ recurrence: "once" }), new Date("2026-09-18T19:00:00Z"));
    assert.equal(once.status, "delivered");
    const daily = advanceAfterDelivery(
      rem({ recurrence: "daily", localTime: "19:00" }),
      new Date("2026-09-18T19:00:00Z"),
    );
    assert.equal(daily.status, "scheduled");
    assert.ok(daily.fireAt.getTime() > Date.parse("2026-09-18T19:00:00Z"));
  });

  it("fails after three retries", () => {
    const first = retryOrFail(rem({ retryCount: 0 }), new Date("2026-09-18T19:00:00Z"));
    assert.equal(first.status, "scheduled");
    const last = retryOrFail(rem({ retryCount: 2 }), new Date("2026-09-18T19:00:00Z"));
    assert.equal(last.status, "failed");
  });
});

describe("snooze", () => {
  it("moves fire_at forward", () => {
    const next = snoozeInstant(new Date("2026-09-18T19:00:00Z"), 30);
    assert.equal(next.toISOString(), "2026-09-18T19:30:00.000Z");
  });
});
