/** Timezone-aware helpers. Store instants in UTC; convert using IANA zones. */

export const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;
export const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function isValidTimeZone(zone: string): boolean {
  const z = zone.trim();
  if (!z) return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: z }).format(new Date());
    return true;
  } catch {
    return false;
  }
}

export function resolveTimeZone(zone: string | null | undefined): string {
  const z = (zone ?? "").trim() || "UTC";
  return isValidTimeZone(z) ? z : "UTC";
}

function partsInZone(date: Date, timeZone: string): Record<string, string> {
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    weekday: "short",
  });
  const out: Record<string, string> = {};
  for (const part of dtf.formatToParts(date)) {
    if (part.type !== "literal") out[part.type] = part.value;
  }
  return out;
}

function asUtcMs(year: number, month: number, day: number, hour: number, minute: number): number {
  return Date.UTC(year, month - 1, day, hour, minute, 0);
}

/** Offset (ms) of `timeZone` at `instant`: zoneLocal - UTC. */
export function zoneOffsetMs(instant: Date, timeZone: string): number {
  const zone = resolveTimeZone(timeZone);
  const p = partsInZone(instant, zone);
  const hour = Number(p.hour) % 24;
  const localAsUtc = asUtcMs(
    Number(p.year),
    Number(p.month),
    Number(p.day),
    hour,
    Number(p.minute),
  );
  const secondAdj = Number(p.second || "0") * 1000;
  return localAsUtc + secondAdj - instant.getTime();
}

/**
 * Interpret a wall-clock `YYYY-MM-DD` + `HH:MM` in `timeZone` as a UTC Date.
 * Recomputes once so DST transitions land on the intended local time.
 */
export function zonedDateTimeToUtc(
  date: string,
  time: string,
  timeZone: string,
): Date | null {
  if (!DATE_RE.test(date) || !TIME_RE.test(time)) return null;
  const zone = resolveTimeZone(timeZone);
  const [ys, ms, ds] = date.split("-");
  const [hs, mins] = time.split(":");
  const year = Number(ys);
  const month = Number(ms);
  const day = Number(ds);
  const hour = Number(hs);
  const minute = Number(mins);
  if (![year, month, day, hour, minute].every((n) => Number.isFinite(n))) return null;
  const guess = new Date(asUtcMs(year, month, day, hour, minute));
  const offset1 = zoneOffsetMs(guess, zone);
  const first = new Date(guess.getTime() - offset1);
  const offset2 = zoneOffsetMs(first, zone);
  if (offset2 === offset1) return first;
  return new Date(guess.getTime() - offset2);
}

export function formatInZone(
  instant: Date,
  timeZone: string,
): { date: string; time: string; weekday: number } {
  const zone = resolveTimeZone(timeZone);
  const p = partsInZone(instant, zone);
  const hour = String(Number(p.hour) % 24).padStart(2, "0");
  const date = `${p.year}-${p.month}-${p.day}`;
  const time = `${hour}:${p.minute}`;
  const map: Record<string, number> = {
    Sun: 0,
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6,
  };
  return { date, time, weekday: map[p.weekday ?? ""] ?? 0 };
}

export function addDaysUtc(instant: Date, days: number): Date {
  return new Date(instant.getTime() + days * 86400000);
}

export function addMinutesUtc(instant: Date, minutes: number): Date {
  return new Date(instant.getTime() + minutes * 60000);
}

export type Recurrence = "once" | "daily" | "weekly" | "weekdays";

export function isRecurrence(value: string | null | undefined): value is Recurrence {
  return value === "once" || value === "daily" || value === "weekly" || value === "weekdays";
}

/**
 * Next fire after `from` (exclusive) for a recurring reminder that fires at
 * `localTime` in `timeZone`. Weekly uses `weekday` (0=Sun).
 */
export function nextOccurrence(opts: {
  from: Date;
  timeZone: string;
  localTime: string;
  recurrence: Recurrence;
  weekday?: number | null;
}): Date | null {
  const { from, localTime, recurrence } = opts;
  const zone = resolveTimeZone(opts.timeZone);
  if (recurrence === "once") return null;
  const start = formatInZone(from, zone);
  for (let i = 1; i <= 14; i += 1) {
    const probe = addDaysUtc(from, i);
    const local = formatInZone(probe, zone);
    const candidate = zonedDateTimeToUtc(local.date, localTime, zone);
    if (!candidate || candidate.getTime() <= from.getTime()) continue;
    if (recurrence === "daily") return candidate;
    if (recurrence === "weekdays") {
      if (local.weekday >= 1 && local.weekday <= 5) return candidate;
      continue;
    }
    if (recurrence === "weekly") {
      const want = opts.weekday ?? start.weekday;
      if (local.weekday === want) return candidate;
    }
  }
  return null;
}

export function parseIsoInstant(value: string | null | undefined): Date | null {
  if (!value) return null;
  const t = Date.parse(value);
  if (Number.isNaN(t)) return null;
  return new Date(t);
}
