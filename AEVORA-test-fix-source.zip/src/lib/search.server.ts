/**
 * Server-only public web search via xAI. Dynamic-import from createServerFn.
 * Never fabricates citations. Fail closed with an honest error.
 */
import { englishNameFor, lookupLanguage } from "./languages.ts";
import {
  chatModelCandidates,
  classifyProviderFailure,
  logProviderFailure,
  MISSING_XAI_KEY_ERROR,
  readXaiApiKey,
  shouldTryNextModel,
  userFacingProviderError,
  xaiBaseUrl,
} from "./ai/xai-env.server.ts";

export type SearchHit = {
  url: string;
  title?: string;
};

export type SearchTurnResult =
  | { ok: true; text: string; citations: string[] }
  | { ok: false; error: string; unavailable?: boolean };

const SEARCH_MAX_TOKENS = 1400;

function extractCitations(body: unknown): string[] {
  const urls = new Set<string>();
  const visit = (value: unknown) => {
    if (!value) return;
    if (typeof value === "string") {
      if (/^https?:\/\//i.test(value)) urls.add(value);
      return;
    }
    if (Array.isArray(value)) {
      for (const item of value) visit(item);
      return;
    }
    if (typeof value === "object") {
      const rec = value as Record<string, unknown>;
      if (typeof rec.url === "string") visit(rec.url);
      if (typeof rec.uri === "string") visit(rec.uri);
      if ("citations" in rec) visit(rec.citations);
      if ("sources" in rec) visit(rec.sources);
      if ("output" in rec) visit(rec.output);
    }
  };
  visit(body);
  return [...urls].slice(0, 12);
}

function extractOutputText(body: unknown): string {
  if (!body || typeof body !== "object") return "";
  const rec = body as Record<string, unknown>;
  if (typeof rec.output_text === "string" && rec.output_text.trim()) return rec.output_text.trim();
  const choices = rec.choices;
  if (Array.isArray(choices)) {
    const msg = (choices[0] as { message?: { content?: string | null } } | undefined)?.message?.content;
    if (typeof msg === "string" && msg.trim()) return msg.trim();
  }
  const output = rec.output;
  if (Array.isArray(output)) {
    const parts: string[] = [];
    for (const item of output) {
      if (!item || typeof item !== "object") continue;
      const content = (item as { content?: unknown }).content;
      if (typeof content === "string") parts.push(content);
      if (Array.isArray(content)) {
        for (const block of content) {
          if (block && typeof block === "object") {
            const text = (block as { text?: unknown }).text;
            if (typeof text === "string") parts.push(text);
          }
        }
      }
    }
    const joined = parts.join("\n").trim();
    if (joined) return joined;
  }
  return "";
}

function withCitations(text: string, citations: string[]): string {
  if (citations.length === 0) return text;
  if (/https?:\/\//i.test(text) && /source/i.test(text)) return text;
  const lines = citations.map((url, i) => `${i + 1}. ${url}`);
  return `${text.trim()}\n\nSources:\n${lines.join("\n")}`;
}

const SEARCH_RULES =
  " Use current public sources when freshness or an unfamiliar named entity matters. " +
  "Prefer official documentation, official product pages, and primary sources over SEO blogs. " +
  "Never invent websites, quotes, prices, dates, versions, or statistics. " +
  "If you cannot verify an entity, say so. If sources disagree, say so. Cite sources. " +
  "Do not claim you searched if the search failed.";

export async function completeSearchTurn(opts: {
  history: { role: "user" | "assistant"; content: string }[];
  locale?: string;
  intentNote?: string;
  memoryContext?: string;
  research?: boolean;
}): Promise<SearchTurnResult> {
  const apiKey = readXaiApiKey();
  if (!apiKey) {
    return { ok: false, unavailable: true, error: MISSING_XAI_KEY_ERROR };
  }
  const meta = lookupLanguage(opts.locale);
  const lang = meta
    ? ` Reply in ${englishNameFor(meta.code)} unless the user wrote in another language this turn.`
    : "";
  const research =
    opts.research === true
      ? " This is research: break the question into subquestions, compare sources, and present a synthesis with citations. Do not dump raw links."
      : " Search when needed to answer. Synthesize; do not dump raw results.";
  const system =
    "You are AEVORA, a private personal steward." +
    SEARCH_RULES +
    lang +
    research +
    (opts.intentNote ? ` ${opts.intentNote}` : "") +
    (opts.memoryContext?.trim()
      ? `\n\n<assembled-context>\n${opts.memoryContext.trim().slice(0, 2400)}\n</assembled-context>`
      : "");

  const input = [
    { role: "system", content: system },
    ...opts.history.slice(-12).map((m) => ({ role: m.role, content: m.content })),
  ];

  const tryResponses = async (model: string): Promise<Response> =>
    fetch(`${xaiBaseUrl()}/responses`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        input,
        tools: [{ type: "web_search" }],
        max_output_tokens: SEARCH_MAX_TOKENS,
        temperature: 0.4,
      }),
    });

  const tryChat = async (model: string): Promise<Response> =>
    fetch(`${xaiBaseUrl()}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        max_tokens: SEARCH_MAX_TOKENS,
        temperature: 0.4,
        search_parameters: {
          mode: "on",
          return_citations: true,
          max_search_results: opts.research === true ? 12 : 8,
          sources: [{ type: "web" }],
        },
        messages: input,
      }),
    });

  let res: Response | null = null;
  let lastModel = "";
  for (const model of chatModelCandidates("deep")) {
    lastModel = model;
    try {
      res = await tryResponses(model);
      if (res.status === 404 || res.status === 400 || res.status === 422) {
        const failed = await res.text().catch(() => "");
        logProviderFailure("search.responses", classifyProviderFailure(res.status, failed, model));
        res = await tryChat(model);
      }
    } catch {
      try {
        res = await tryChat(model);
      } catch {
        continue;
      }
    }
    if (!res) continue;
    if (res.ok) break;
    const bodyText = await res.text().catch(() => "");
    logProviderFailure("search", classifyProviderFailure(res.status, bodyText, model));
    if (!shouldTryNextModel(res.status) && res.status !== 400 && res.status !== 422) break;
    res = new Response(null, { status: res.status });
  }

  if (!res) {
    return { ok: false, error: "I could not search right now. Nothing else changed." };
  }

  if (!res.ok) {
    if (lastModel) {
      logProviderFailure("search", classifyProviderFailure(res.status, "", lastModel));
    }
    return {
      ok: false,
      error: `${userFacingProviderError(res.status)} Nothing else changed.`,
      unavailable: res.status === 401 || res.status === 403,
    };
  }

  const body: unknown = await res.json();
  const text = extractOutputText(body);
  if (!text) return { ok: false, error: "Search returned nothing I could use. Nothing else changed." };
  const citations = extractCitations(body);
  return { ok: true, text: withCitations(text, citations), citations };
}
