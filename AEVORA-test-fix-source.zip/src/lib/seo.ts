/**
 * Public pages may be indexed. Private keeps never are.
 * Canonical and sitemap URLs exist only for a configured https origin
 * that is not localhost or a known preview host.
 */

const PREVIEW_HOST =
  /(^|\.)localhost$|\.local$|(^|\.)app-builder-testing\.com$|\.vercel\.app$|^127\.|^0\.0\.0\.0$|^\[?::1\]?$/;

export function isIndexablePath(pathname: string): boolean {
  const path = (pathname.split("?")[0] ?? "/").split("#")[0] || "/";
  return path === "/";
}

export function robotsDirective(pathname: string): "index, follow" | "noindex, nofollow" {
  return isIndexablePath(pathname) ? "index, follow" : "noindex, nofollow";
}

export function publicSiteOrigin(configured: string | null | undefined): string | null {
  const raw = (configured ?? "").trim();
  if (!raw) return null;
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  if (url.protocol !== "https:") return null;
  const host = url.hostname.toLowerCase();
  if (!host || PREVIEW_HOST.test(host)) return null;
  return url.origin;
}

export function robotsTxt(origin: string | null): string {
  const lines = [
    "User-agent: *",
    "Allow: /",
    "Disallow: /app",
    "Disallow: /login",
    "Disallow: /api",
    "Disallow: /auth",
  ];
  if (origin) lines.push(`Sitemap: ${origin}/sitemap.xml`);
  return `${lines.join("\n")}\n`;
}

export function sitemapXml(origin: string | null): string {
  const urls = origin ? [`  <url><loc>${origin}/</loc></url>`] : [];
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="https://www.sitemaps.org/schemas/sitemap/0.9">
${urls.join("\n")}
</urlset>
`;
}
