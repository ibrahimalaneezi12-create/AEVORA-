import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import type { ProposedActionView, RejectedProposalView } from "@/lib/orchestrator/types";
import { parseChatWorkspace, type ChatWorkspaceId } from "@/lib/chat-workspace";

export const CHAT_MESSAGE_MAX = 4000;
export const DEFAULT_CONVERSATION_TITLE = "New conversation";

export type Conversation = {
  id: number;
  title: string;
  workspace: ChatWorkspaceId;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
};

export type ChatMessage = {
  id: number;
  conversationId: number;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
};

export type ConversationDetail = {
  conversation: Conversation;
  messages: ChatMessage[];
  proposals: ProposedActionView[];
};

export type SendChatResult =
  | {
      ok: true;
      conversation: Conversation;
      userMessage: ChatMessage;
      assistantMessage: ChatMessage;
      proposals: ProposedActionView[];
      rejected: RejectedProposalView[];
      citations: string[];
    }
  | {
      ok: false;
      error: string;
      unavailable?: boolean;
      conversation: Conversation | null;
      userMessage: ChatMessage | null;
      assistantMessage: null;
      proposals: ProposedActionView[];
      rejected: RejectedProposalView[];
      citations: string[];
    };

type ConversationRow = {
  id: unknown;
  title: string;
  workspace?: unknown;
  archived: boolean;
  created_at: unknown;
  updated_at: unknown;
};

type MessageRow = {
  id: unknown;
  conversation_id: unknown;
  role: string;
  content: string;
  created_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

function mapConversation(row: ConversationRow): Conversation {
  return {
    id: asPositiveInt(row.id),
    title: row.title || DEFAULT_CONVERSATION_TITLE,
    workspace: parseChatWorkspace(row.workspace),
    archived: Boolean(row.archived),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function mapMessage(row: MessageRow): ChatMessage | null {
  if (row.role !== "user" && row.role !== "assistant") return null;
  const id = asPositiveInt(row.id);
  const conversationId = asPositiveInt(row.conversation_id);
  if (!id || !conversationId) return null;
  return {
    id,
    conversationId,
    role: row.role,
    content: row.content,
    createdAt: toIso(row.created_at),
  };
}

async function readConversation(userId: string, id: number): Promise<Conversation | null> {
  const sql = await getSql();
  const rows = await sql<ConversationRow>`
    select id, title, workspace, archived, created_at, updated_at
    from conversations
    where id = ${id} and user_id = ${userId}
  `;
  return rows[0] ? mapConversation(rows[0]) : null;
}

async function insertConversation(userId: string, workspace: ChatWorkspaceId): Promise<Conversation> {
  const sql = await getSql();
  const rows = await sql<ConversationRow>`
    insert into conversations (user_id, workspace)
    values (${userId}, ${workspace})
    returning id, title, workspace, archived, created_at, updated_at
  `;
  const row = rows[0];
  if (!row) throw new Error("Conversation could not be created.");
  return mapConversation(row);
}

async function readMessages(userId: string, conversationId: number): Promise<ChatMessage[]> {
  const sql = await getSql();
  const rows = await sql<MessageRow>`
    select id, conversation_id, role, content, created_at
    from messages
    where user_id = ${userId} and conversation_id = ${conversationId}
    order by id asc
  `;
  const out: ChatMessage[] = [];
  for (const row of rows) {
    const mapped = mapMessage(row);
    if (mapped) out.push(mapped);
  }
  return out;
}

const conversationIdInput = z.object({
  conversationId: z.number().int().positive(),
  workspace: z.enum(["main", "business", "invest"]).optional(),
});

const sendInput = z.object({
  conversationId: z.number().int().positive().optional(),
  content: z.string().trim().min(1, "Say something first.").max(CHAT_MESSAGE_MAX),
  workspace: z.enum(["main", "business", "invest"]).optional(),
});

function workspaceFrom(input: unknown): ChatWorkspaceId {
  if (!input || typeof input !== "object") return "main";
  return parseChatWorkspace((input as { workspace?: unknown }).workspace);
}

export const listConversations = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => ({ workspace: workspaceFrom(input) }))
  .handler(async ({ context, data }): Promise<Conversation[]> => {
    const sql = await getSql();
    const rows = await sql<ConversationRow>`
      select id, title, workspace, archived, created_at, updated_at
      from conversations
      where user_id = ${context.userId} and archived = false and workspace = ${data.workspace}
      order by updated_at desc
      limit 50
    `;
    return rows.map(mapConversation).filter((c) => c.id > 0);
  });

export const getConversation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => conversationIdInput.parse(input))
  .handler(async ({ context, data }): Promise<ConversationDetail> => {
    const conversation = await readConversation(context.userId, data.conversationId);
    if (!conversation) throw new Error("Conversation not found.");
    const requested = parseChatWorkspace(data.workspace ?? "main");
    if (conversation.workspace !== requested) throw new Error("Conversation not found.");
    const messages = await readMessages(context.userId, conversation.id);
    let proposals: ProposedActionView[] = [];
    try {
      const { listOwnProposals } = await import("@/lib/orchestrator/turn.server");
      proposals = await listOwnProposals(context.userId, conversation.id);
    } catch {
      proposals = [];
    }
    return { conversation, messages, proposals };
  });

export const createConversation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => ({ workspace: workspaceFrom(input) }))
  .handler(async ({ context, data }): Promise<Conversation> => {
    return insertConversation(context.userId, data.workspace);
  });

export const sendChatMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => sendInput.parse(input))
  .handler(async ({ context, data }): Promise<SendChatResult> => {
    const { executeOwnedTurn } = await import("@/lib/chat-turn.server");
    const result = await executeOwnedTurn({
      userId: context.userId,
      content: data.content,
      conversationId: data.conversationId,
      workspace: parseChatWorkspace(data.workspace ?? "main"),
    });
    if (!result.ok) {
      return {
        ok: false,
        error: result.error,
        unavailable: result.unavailable,
        conversation: result.conversation,
        userMessage: result.userMessage,
        assistantMessage: null,
        proposals: [],
        rejected: [],
        citations: [],
      };
    }
    return {
      ok: true,
      conversation: result.conversation,
      userMessage: result.userMessage,
      assistantMessage: result.assistantMessage,
      proposals: result.proposals,
      rejected: result.rejected,
      citations: result.citations,
    };
  });

export const retryChat = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => conversationIdInput.parse(input))
  .handler(async ({ context, data }): Promise<SendChatResult> => {
    const { retryOwnedTurn } = await import("@/lib/chat-turn.server");
    const result = await retryOwnedTurn(
      context.userId,
      data.conversationId,
      parseChatWorkspace(data.workspace ?? "main"),
    );
    if (!result.ok) {
      return {
        ok: false,
        error: result.error,
        unavailable: result.unavailable,
        conversation: result.conversation,
        userMessage: result.userMessage,
        assistantMessage: null,
        proposals: [],
        rejected: [],
        citations: [],
      };
    }
    return {
      ok: true,
      conversation: result.conversation,
      userMessage: result.userMessage,
      assistantMessage: result.assistantMessage,
      proposals: result.proposals,
      rejected: result.rejected,
      citations: result.citations,
    };
  });
