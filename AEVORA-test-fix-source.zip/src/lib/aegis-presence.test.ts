import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { VOICE_STATES } from "./voice-format.ts";

describe("voice mode states", () => {
  it("covers the immersive voice phases", () => {
    for (const phase of [
      "idle",
      "listening",
      "user_speaking",
      "thinking",
      "speaking",
      "interrupted",
      "error",
    ] as const) {
      assert.ok(VOICE_STATES.includes(phase));
    }
  });
});
