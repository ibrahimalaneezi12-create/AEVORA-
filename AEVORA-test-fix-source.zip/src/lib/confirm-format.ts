import { z } from "zod";
import { catalogLevel, isChatReply, lookupTool, canRunTool } from "./orchestrator/catalog.ts";
import type { PermissionLevel, ProposalStatus, ProposedActionView } from "./orchestrator/types.ts";
import { MEMORY_BODY_MAX, MEMORY_KINDS, MEMORY_TAGS_MAX, MEMORY_TITLE_MAX } from "./memory-format.ts";
import { GOAL_DESC_MAX, GOAL_STATUSES, GOAL_TITLE_MAX, TASK_NOTES_MAX, TASK_STATUSES, TASK_TITLE_MAX } from "./goals-format.ts";
import { parseChatWorkspace, type ChatWorkspaceId } from "./chat-workspace.ts";

const PROFILE_THEMES = ["system", "dark", "light"] as const;

export const NOT_PENDING = "This action is no longer pending.";
export const NOT_FOUND = "Proposal not found.";
export const CANNOT_APPROVE = "This action cannot be approved.";

export type ProposalRow = {
  id: unknown;
  conversation_id: unknown;
  tool_id: string;
  permission_level: string;
  title: string;
  summary: string;
  payload_json: string;
  status: string;
  created_at: unknown;
  error: string | null;
};

export type PayloadLine = {
  label: string;
  value: string;
};

export type ProposalConfirmView = ProposedActionView & {
  payloadPreview: PayloadLine[];
  canApprove: boolean;
  canDeny: boolean;
  blockedReason: string | null;
  error: string | null;
  result: string | null;
  workspace: ChatWorkspaceId;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

function asLevel(value: string): PermissionLevel {
  if (value === "safe" || value === "review" || value === "approval" || value === "restricted") {
    return value;
  }
  return "restricted";
}

function asStatus(value: string): ProposalStatus {
  if (
    value === "pending" ||
    value === "approved" ||
    value === "denied" ||
    value === "executed" ||
    value === "failed" ||
    value === "cancelled"
  ) {
    return value;
  }
  return "pending";
}

export function mapProposalView(
  row: Omit<ProposalRow, "payload_json"> & { payload_json?: string },
  displayName: string,
): ProposedActionView | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  const conversationId = asPositiveInt(row.conversation_id);
  return {
    id,
    conversationId: conversationId || null,
    toolId: row.tool_id,
    displayName,
    permissionLevel: asLevel(row.permission_level),
    title: row.title,
    summary: row.summary,
    status: asStatus(row.status),
    createdAt: toIso(row.created_at),
  };
}

export function parsePayloadJson(raw: string): Record<string, unknown> {
  try {
    const value = JSON.parse(raw) as unknown;
    if (value && typeof value === "object" && !Array.isArray(value)) {
      return value as Record<string, unknown>;
    }
  } catch {
    // Invalid JSON is an empty payload; execute will fail closed if a field is required.
  }
  return {};
}

/**
 * Approve is allowed only for an allowlisted, non-Restricted tool.
 * Catalog Restricted and stored Restricted both block. The model cannot override.
 */
export function approvalBlockedReason(
  toolId: string,
  storedLevel: PermissionLevel,
): string | null {
  if (storedLevel === "restricted") return CANNOT_APPROVE;
  if (isChatReply(toolId)) return CANNOT_APPROVE;
  if (catalogLevel(toolId) === "restricted") return CANNOT_APPROVE;
  if (!lookupTool(toolId)) return CANNOT_APPROVE;
  if (!canRunTool(toolId)) return CANNOT_APPROVE;
  return null;
}

/** Deny is allowed only while the row is still pending. */
export function canDenyStatus(status: ProposalStatus): boolean {
  return status === "pending";
}

/**
 * Approve requires pending + allowlisted + not Restricted.
 * Stored level and catalog are both checked so a quieter stored value cannot bypass.
 */
export function cannotApproveMessage(
  toolId: string,
  storedLevel: PermissionLevel,
  status: ProposalStatus,
): string | null {
  if (status !== "pending") return NOT_PENDING;
  return approvalBlockedReason(toolId, storedLevel);
}

export function canApproveStatus(
  toolId: string,
  storedLevel: PermissionLevel,
  status: ProposalStatus,
): boolean {
  return cannotApproveMessage(toolId, storedLevel, status) === null;
}

const PAYLOAD_LABELS: Record<string, string> = {
  kind: "Kind",
  title: "Title",
  body: "Memory",
  tags: "Tags",
  pinned: "Pinned",
  notes: "Notes",
  status: "Status",
  dueDate: "Due",
  goalId: "Goal",
  id: "Item",
  query: "Search",
  displayName: "Name",
  bio: "Bio",
  timezone: "Timezone",
  theme: "Theme",
  targetDate: "Target date",
  description: "Description",
  fireAt: "When",
  localDate: "Date",
  localTime: "Time",
  recurrence: "Repeat",
  minutes: "Snooze (min)",
  locale: "Language",
  weekday: "Weekday",
  startAt: "Starts",
  endAt: "Ends",
  location: "Location",
  to: "To",
  cc: "Cc",
  subject: "Subject",
  offer: "Offer",
  audience: "Audience",
  symbol: "Symbol",
  thesis: "Thesis",
  businessId: "Business",
};

function previewValue(value: unknown): string | null {
  if (value == null) return null;
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  if (typeof value === "string") {
    const t = value.trim();
    return t ? t.slice(0, 280) : null;
  }
  return null;
}

/** Plain-language payload lines for the confirmation page. Drops nested junk. */
export function payloadPreview(payload: Record<string, unknown>): PayloadLine[] {
  const out: PayloadLine[] = [];
  for (const [key, value] of Object.entries(payload)) {
    const text = previewValue(value);
    if (!text) continue;
    out.push({
      label: PAYLOAD_LABELS[key] ?? key,
      value: text,
    });
  }
  return out;
}

export function mapConfirmView(
  row: ProposalRow,
  displayName: string,
  result: string | null = null,
): ProposalConfirmView | null {
  const view = mapProposalView(row, displayName);
  if (!view) return null;
  const payload = parsePayloadJson(row.payload_json ?? "{}");
  const pending = view.status === "pending";
  const blocked = approvalBlockedReason(view.toolId, view.permissionLevel);
  return {
    ...view,
    payloadPreview: payloadPreview(payload),
    canApprove: pending && blocked === null,
    canDeny: pending,
    blockedReason: pending ? blocked : null,
    error: row.error ?? null,
    result,
    workspace: parseChatWorkspace((row as ProposalRow & { workspace?: unknown }).workspace),
  };
}

const optionalDate = z
  .union([z.string(), z.null(), z.undefined()])
  .optional()
  .transform((v) => {
    if (v == null) return null;
    const t = String(v).trim();
    if (t === "") return null;
    return t;
  })
  .refine((v) => v === null || /^\d{4}-\d{2}-\d{2}$/.test(v), {
    message: "Use a calendar date.",
  });

export const memorySavePayload = z.object({
  id: z.number().int().positive().optional(),
  kind: z.enum(MEMORY_KINDS).optional(),
  title: z.string().trim().max(MEMORY_TITLE_MAX).optional(),
  body: z.string().trim().max(MEMORY_BODY_MAX).optional(),
  tags: z.string().max(MEMORY_TAGS_MAX).optional(),
  pinned: z.boolean().optional(),
});

export const memorySearchPayload = z.object({
  query: z.string().trim().max(MEMORY_BODY_MAX).optional(),
});

export const taskCreatePayload = z.object({
  title: z.string().trim().max(TASK_TITLE_MAX).optional(),
  notes: z.string().max(TASK_NOTES_MAX).optional(),
  status: z.enum(TASK_STATUSES).optional(),
  dueDate: optionalDate,
  goalId: z.number().int().positive().nullish().optional(),
});

export const taskUpdatePayload = z.object({
  id: z.number().int().positive(),
  title: z.string().trim().min(1).max(TASK_TITLE_MAX).optional(),
  notes: z.string().max(TASK_NOTES_MAX).optional(),
  status: z.enum(TASK_STATUSES).optional(),
  dueDate: optionalDate,
  goalId: z.number().int().positive().nullish().optional(),
});

export const goalCreatePayload = z.object({
  title: z.string().trim().max(GOAL_TITLE_MAX).optional(),
  description: z.string().max(GOAL_DESC_MAX).optional(),
  status: z.enum(GOAL_STATUSES).optional(),
  targetDate: optionalDate,
});

export const idPayload = z.object({
  id: z.number().int().positive(),
});

export const profileUpdatePayload = z.object({
  displayName: z.string().max(80).optional(),
  bio: z.string().max(500).optional(),
  timezone: z.string().trim().min(1).max(64).optional(),
  theme: z.enum(PROFILE_THEMES).optional(),
  locale: z.string().trim().min(2).max(16).optional(),
});

export const goalUpdatePayload = z.object({
  id: z.number().int().positive(),
  title: z.string().trim().min(1).max(GOAL_TITLE_MAX).optional(),
  description: z.string().max(GOAL_DESC_MAX).optional(),
  status: z.enum(GOAL_STATUSES).optional(),
  targetDate: optionalDate,
});

export const businessSavePayload = z.object({
  id: z.number().int().positive().optional(),
  name: z.string().trim().max(80).optional(),
  offer: z.string().max(500).optional(),
  audience: z.string().max(500).optional(),
  notes: z.string().max(500).optional(),
});

export const businessNotePayload = z.object({
  businessId: z.number().int().positive().optional(),
  kind: z.string().trim().max(32).optional(),
  title: z.string().trim().max(80).optional(),
  body: z.string().trim().max(4000).optional(),
});

export const investWatchPayload = z.object({
  symbol: z.string().trim().max(16).optional(),
  name: z.string().max(80).optional(),
  thesis: z.string().max(2000).optional(),
});

export const investNotePayload = z.object({
  symbol: z.string().trim().max(16).optional(),
  kind: z.string().trim().max(32).optional(),
  title: z.string().trim().max(80).optional(),
  body: z.string().trim().max(4000).optional(),
});

const optionalTime = z
  .union([z.string(), z.null(), z.undefined()])
  .optional()
  .transform((v) => {
    if (v == null) return null;
    const t = String(v).trim();
    return t || null;
  });

export const reminderCreatePayload = z.object({
  title: z.string().trim().max(80).optional(),
  body: z.string().max(500).optional(),
  timezone: z.string().trim().min(1).max(64).optional(),
  fireAt: optionalTime,
  localDate: optionalDate,
  localTime: optionalTime,
  recurrence: z.enum(["once", "daily", "weekly", "weekdays"]).optional(),
  weekday: z.number().int().min(0).max(6).nullish(),
  locale: z.string().trim().min(2).max(16).optional(),
  relatedTaskId: z.number().int().positive().nullish(),
  relatedGoalId: z.number().int().positive().nullish(),
});

export const reminderUpdatePayload = reminderCreatePayload.extend({
  id: z.number().int().positive(),
});

export const reminderSnoozePayload = z.object({
  id: z.number().int().positive(),
  minutes: z.number().int().min(1).max(24 * 60).optional(),
  fireAt: optionalTime,
});

export const reminderCancelPayload = idPayload;
export const reminderCompletePayload = idPayload;

export const calendarCreatePayload = z.object({
  title: z.string().trim().max(120).optional(),
  notes: z.string().max(2000).optional(),
  location: z.string().max(200).optional(),
  startAt: optionalTime,
  endAt: optionalTime,
  timezone: z.string().trim().min(1).max(64).optional(),
  recurrence: z.enum(["once", "daily", "weekly", "weekdays"]).optional(),
});

export const calendarUpdatePayload = calendarCreatePayload.extend({
  id: z.number().int().positive(),
});

export const emailDraftPayload = z.object({
  to: z.string().trim().max(200).optional(),
  cc: z.string().trim().max(400).optional(),
  subject: z.string().trim().max(200).optional(),
  body: z.string().max(8000).optional(),
});

export const emailSendPayload = idPayload;

export const creationSavePayload = z.object({
  id: z.number().int().positive().optional(),
  kind: z.string().trim().max(32).optional(),
  title: z.string().trim().max(120).optional(),
  body: z.string().max(12000).optional(),
  locale: z.string().trim().min(2).max(16).optional(),
});

export const searchWebPayload = z.object({
  query: z.string().trim().max(500).optional(),
});

export function requiredTitle(payloadTitle: string | undefined, fallback: string): string {
  const t = (payloadTitle ?? "").trim() || fallback.trim();
  if (!t) throw new Error("Add a title.");
  return t.slice(0, 80);
}

export function requiredBody(
  payloadBody: string | undefined,
  summary: string,
  title: string,
): string {
  const t = (payloadBody ?? "").trim() || summary.trim() || title.trim();
  if (!t) throw new Error("Add the memory.");
  return t.slice(0, MEMORY_BODY_MAX);
}
