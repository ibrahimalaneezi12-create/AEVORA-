export const STT_MODEL = "grok-voice-transcribe-2.0";
export const STT_MAX_BYTES = 1_500_000;
export const STT_MAX_SECONDS = 20;

export const RECORDER_MIME_CANDIDATES = [
  "audio/webm;codecs=opus",
  "audio/webm",
  "audio/mp4;codecs=mp4a.40.2",
  "audio/mp4",
  "audio/ogg;codecs=opus",
] as const;

export function pickRecorderMime(isTypeSupported: (type: string) => boolean): string {
  for (const type of RECORDER_MIME_CANDIDATES) {
    if (isTypeSupported(type)) return type;
  }
  return "";
}

export function filenameForMime(mime: string): string {
  if (mime.includes("wav")) return "speech.wav";
  if (mime.includes("mp4") || mime.includes("aac") || mime.includes("m4a")) return "speech.m4a";
  if (mime.includes("ogg")) return "speech.ogg";
  return "speech.webm";
}

export function parseTranscriptBody(body: unknown): string {
  if (!body || typeof body !== "object") return "";
  const rec = body as Record<string, unknown>;
  if (typeof rec.text === "string" && rec.text.trim()) return rec.text.trim();
  if (typeof rec.transcript === "string" && rec.transcript.trim()) return rec.transcript.trim();
  if (typeof rec.transcription === "string" && rec.transcription.trim()) return rec.transcription.trim();
  const alt = rec.result;
  if (alt && typeof alt === "object") {
    const text = (alt as { text?: unknown }).text;
    if (typeof text === "string" && text.trim()) return text.trim();
  }
  return "";
}

export function rmsFromTimeDomain(bytes: Uint8Array): number {
  if (bytes.length === 0) return 0;
  let sum = 0;
  for (const sample of bytes) {
    const v = (sample - 128) / 128;
    sum += v * v;
  }
  return Math.sqrt(sum / bytes.length);
}

export function isSpeechLevel(rms: number): boolean {
  return rms >= 0.045;
}

export function isBargeLevel(rms: number): boolean {
  return rms >= 0.12;
}
