import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  clipText,
  findConflictingPreference,
  formatMemoryBlock,
  mapMemory,
  rankMemories,
  sanitizeIlike,
  scoreMemory,
  tokenize,
  MEMORY_CONTEXT_CHAR_BUDGET,
  type Memory,
} from "./memory-format.ts";

function mem(partial: Partial<Memory> & Pick<Memory, "id" | "title" | "body">): Memory {
  return {
    kind: "fact",
    tags: "",
    source: "user",
    pinned: false,
    createdAt: "2026-09-17T00:00:00.000Z",
    updatedAt: "2026-09-17T00:00:00.000Z",
    ...partial,
  };
}

describe("sanitizeIlike", () => {
  it("strips wildcard characters so callers cannot broaden a search", () => {
    assert.equal(sanitizeIlike("tea%preference_"), "tea preference");
    assert.equal(sanitizeIlike("  black\\tea  "), "black tea");
  });

  it("trims and caps length", () => {
    assert.equal(sanitizeIlike("  tea  "), "tea");
    assert.equal(sanitizeIlike("x".repeat(100)).length, 80);
  });
});

describe("clipText", () => {
  it("leaves short text alone", () => {
    assert.equal(clipText("Prefers tea", 80), "Prefers tea");
  });

  it("collapses whitespace and ellipsizes", () => {
    assert.equal(clipText("alpha   beta   gamma", 10), "alpha bet…");
  });
});

describe("formatMemoryBlock", () => {
  it("returns empty string for no rows", () => {
    assert.equal(formatMemoryBlock([]), "");
  });

  it("includes id, kind, title, body, and pinned marker", () => {
    const block = formatMemoryBlock([
      mem({
        id: 1,
        kind: "preference",
        title: "Tea preference",
        body: "I drink black tea every morning.",
        pinned: true,
        tags: "drinks",
      }),
    ]);
    assert.match(block, /#1/);
    assert.match(block, /pinned preference/);
    assert.match(block, /Tea preference/);
    assert.match(block, /black tea/);
    assert.match(block, /\[drinks\]/);
  });

  it("stays under the character budget", () => {
    const many = Array.from({ length: 8 }, (_, i) =>
      mem({
        id: i + 1,
        title: `Title ${i}`,
        body: "x".repeat(400),
        pinned: i === 0,
      }),
    );
    const block = formatMemoryBlock(many);
    assert.ok(block.length <= MEMORY_CONTEXT_CHAR_BUDGET);
  });
});

describe("tokenize / rankMemories", () => {
  it("keeps Arabic tokens", () => {
    assert.ok(tokenize("أفضل الدراسة في الليل").includes("الدراسة"));
  });

  it("ranks a study preference above an unrelated sport fact", () => {
    const soccer = mem({
      id: 2,
      kind: "fact",
      title: "Favorite sport",
      body: "Soccer is my favorite sport.",
    });
    const study = mem({
      id: 3,
      kind: "preference",
      title: "Study time",
      body: "I prefer studying after dinner.",
    });
    const ranked = rankMemories([soccer, study], "What should I study tonight?");
    assert.equal(ranked[0]?.id, 3);
    assert.equal(
      ranked.some((r) => r.id === 2),
      false,
    );
    assert.ok(scoreMemory(study, "What should I study tonight?") > scoreMemory(soccer, "What should I study tonight?"));
  });

  it("still keeps a pinned unrelated memory", () => {
    const soccer = mem({
      id: 2,
      kind: "fact",
      title: "Favorite sport",
      body: "Soccer is my favorite sport.",
      pinned: true,
    });
    const study = mem({
      id: 3,
      kind: "preference",
      title: "Study time",
      body: "I prefer studying after dinner.",
    });
    const ranked = rankMemories([soccer, study], "What should I study tonight?");
    assert.equal(ranked.some((r) => r.id === 2), true);
    assert.equal(ranked.some((r) => r.id === 3), true);
  });

  it("retrieves Arabic-origin memory from an English query", () => {
    const night = mem({
      id: 9,
      kind: "preference",
      title: "Study",
      body: "أفضل الدراسة في الليل studying at night",
    });
    const ranked = rankMemories([night], "When do I study at night?");
    assert.equal(ranked[0]?.id, 9);
  });
});

describe("findConflictingPreference", () => {
  it("updates the study-time preference instead of duplicating", () => {
    const old = mem({
      id: 4,
      kind: "preference",
      title: "Study time",
      body: "I study at 7 PM.",
    });
    const found = findConflictingPreference([old], {
      title: "Study time",
      body: "I prefer studying at 8 PM now.",
    });
    assert.equal(found?.id, 4);
  });

  it("does not treat a sport fact as a study preference", () => {
    const sport = mem({
      id: 5,
      kind: "fact",
      title: "Favorite sport",
      body: "Soccer.",
    });
    const found = findConflictingPreference([sport], {
      title: "Study time",
      body: "I prefer studying at 8 PM now.",
    });
    assert.equal(found, null);
  });
});

describe("mapMemory", () => {
  it("drops invalid ids", () => {
    assert.equal(
      mapMemory({
        id: 0,
        kind: "fact",
        title: "x",
        body: "y",
        tags: "",
        source: "user",
        pinned: false,
        created_at: "2026-09-17",
        updated_at: "2026-09-17",
      }),
      null,
    );
  });

  it("falls back unknown kinds to fact", () => {
    const row = mapMemory({
      id: 2,
      kind: "mystery",
      title: "x",
      body: "y",
      tags: "",
      source: "user",
      pinned: true,
      created_at: "2026-09-17T00:00:00.000Z",
      updated_at: "2026-09-17T00:00:00.000Z",
    });
    assert.equal(row?.kind, "fact");
    assert.equal(row?.pinned, true);
  });
});
