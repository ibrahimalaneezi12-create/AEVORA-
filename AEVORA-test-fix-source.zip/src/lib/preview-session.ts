/**
 * Live-preview session hand-off. The auth client stores the bearer under this
 * key after OAuth popup sign-in; email/password must do the same so a
 * partitioned iframe can stay signed in. Client-safe — no Node imports.
 */
export const PREVIEW_SESSION_STORAGE_KEY = "grok-auth.bearer-token";

export function capturePreviewSessionToken(token: string | null | undefined): void {
  if (typeof window === "undefined") return;
  try {
    if (!token) window.sessionStorage.removeItem(PREVIEW_SESSION_STORAGE_KEY);
    else window.sessionStorage.setItem(PREVIEW_SESSION_STORAGE_KEY, token);
  } catch {
    // Storage blocked — cookie path still attempted.
  }
}

export function clearPreviewSessionToken(): void {
  capturePreviewSessionToken(null);
}
