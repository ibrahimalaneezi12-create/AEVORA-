import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { isIndexablePath, publicSiteOrigin, robotsDirective, robotsTxt, sitemapXml } from "./seo.ts";

describe("public vs private indexing", () => {
  it("indexes only the public landing", () => {
    assert.equal(isIndexablePath("/"), true);
    assert.equal(robotsDirective("/"), "index, follow");
    for (const path of ["/app", "/app/chat", "/app/business", "/app/invest", "/login", "/api/chat/stream", "/auth/popup"]) {
      assert.equal(isIndexablePath(path), false, path);
      assert.equal(robotsDirective(path), "noindex, nofollow");
    }
  });

  it("refuses localhost, preview, and http origins", () => {
    assert.equal(publicSiteOrigin("http://aegis.example"), null);
    assert.equal(publicSiteOrigin("https://localhost:8080"), null);
    assert.equal(publicSiteOrigin("https://127.0.0.1"), null);
    assert.equal(publicSiteOrigin("https://my-app.vercel.app"), null);
    assert.equal(publicSiteOrigin("https://preview.app-builder-testing.com"), null);
    assert.equal(publicSiteOrigin(""), null);
    assert.equal(publicSiteOrigin("https://aegis.example"), "https://aegis.example");
  });

  it("allows the public root and blocks private routes without blocking the site", () => {
    const body = robotsTxt("https://aegis.example");
    assert.match(body, /^User-agent: \*/m);
    assert.match(body, /^Allow: \/$/m);
    assert.match(body, /^Disallow: \/app$/m);
    assert.match(body, /^Disallow: \/login$/m);
    assert.match(body, /^Disallow: \/api$/m);
    assert.match(body, /^Sitemap: https:\/\/aegis\.example\/sitemap\.xml$/m);
    assert.doesNotMatch(body, /^Disallow: \/$/m);
    const unsited = robotsTxt(null);
    assert.doesNotMatch(unsited, /Sitemap:/);
    assert.doesNotMatch(unsited, /localhost/);
  });

  it("lists only the public landing and never a private url", () => {
    const xml = sitemapXml("https://aegis.example");
    assert.match(xml, /<loc>https:\/\/aegis\.example\/<\/loc>/);
    assert.doesNotMatch(xml, /\/app|\/login|\/api|user|conversation/i);
    const empty = sitemapXml(null);
    assert.doesNotMatch(empty, /<loc>/);
    assert.doesNotMatch(empty, /localhost|vercel\.app/);
  });
});
