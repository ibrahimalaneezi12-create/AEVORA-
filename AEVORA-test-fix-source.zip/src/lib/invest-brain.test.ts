import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { brokerClientOrderId, brokerStatusNote, comparisonSpeech, emptySnapshot, journalSpeech, mayUseBroker, orderSpeech, parseOrderIntent, portfolioAnalysisSpeech, portfolioSpeech, rebalanceSpeech, scenarioSpeech, thesisSpeech, watchSpeech } from "./invest-brain.ts";

describe("invest brain", () => {
  it("refuses a portfolio when no broker is connected", () => {
    const speech = portfolioSpeech(emptySnapshot());
    assert.match(speech, /No broker is connected/);
    assert.equal(/\b(AAPL|£|\$)\d/.test(speech), false);
  });

  it("quotes only fields the broker returned", () => {
    const speech = portfolioSpeech({
      ...emptySnapshot(),
      connected: true,
      mode: "paper",
      provider: "alpaca",
      capabilities: ["account.read"],
      account: {
        id: "a",
        accountNumber: "1",
        status: "ACTIVE",
        equity: "100.00",
        cash: "",
        tradingBlocked: false,
      },
      positions: [],
    });
    assert.match(speech, /100\.00/);
    assert.match(speech, /no open positions/i);
    assert.match(speech, /cannot place orders/i);
  });

  it("does not call a pending order filled", () => {
    assert.match(orderSpeech("pending", "AAPL", "paper"), /pending/i);
    assert.match(orderSpeech("pending", "AAPL", "paper"), /not filled/i);
    assert.equal(/\bis filled\b/i.test(orderSpeech("pending", "AAPL", "paper")), false);
    assert.match(orderSpeech("filled", "AAPL", "live"), /filled/);
    assert.match(orderSpeech("failed", "AAPL", "live"), /Nothing was filled/);
    assert.match(orderSpeech("accepted", "AAPL", "paper"), /not filled/i);
    assert.equal(/\bpending\b/i.test(orderSpeech("done_for_day", "AAPL", "paper")), false);
    assert.equal(/\bis filled\b/i.test(orderSpeech("done_for_day", "AAPL", "paper")), false);
  });

  it("isolates broker ownership", () => {
    assert.equal(mayUseBroker("user-a", "user-b"), false);
    assert.equal(mayUseBroker("user-a", "user-a"), true);
    assert.equal(mayUseBroker("", "user-a"), false);
  });

  it("does not invent concentration or accept a client account id", () => {
    const speech = portfolioAnalysisSpeech({
      ...emptySnapshot(),
      connected: true,
      mode: "paper",
      provider: "alpaca",
      capabilities: ["positions.read"],
      account: {
        id: "secret-account",
        accountNumber: "999",
        status: "ACTIVE",
        equity: "10",
        cash: "1",
        tradingBlocked: false,
      },
      positions: [{ symbol: "AAPL", qty: "1", side: "long", marketValue: "", unrealizedPl: "", currentPrice: "" }],
    });
    assert.match(speech, /did not return market values/i);
    assert.match(speech, /will not estimate them/i);
    assert.equal(speech.includes("secret-account"), false);
    const partial = portfolioSpeech({
      ...emptySnapshot(),
      connected: true,
      verified: true,
      mode: "paper",
      provider: "alpaca",
      capabilities: ["account.read", "balance.read"],
      account: {
        id: "a",
        accountNumber: "1",
        status: "ACTIVE",
        equity: "50.00",
        cash: "10.00",
        tradingBlocked: false,
      },
      error: "Orders could not be read.",
    });
    assert.match(partial, /50\.00/);
    assert.match(partial, /Recent orders were not read/);
    assert.equal(/no recent orders/i.test(partial), false);
    assert.equal(parseOrderIntent({ symbol: "AAPL", side: "buy", qty: "1", userId: "user-b", accountId: "999" }), null);
    assert.equal(parseOrderIntent({ symbol: "AAPL", side: "buy", qty: "1" })?.symbol, "AAPL");
  });

  it("reports a saved broker without inventing a balance", () => {
    const saved = brokerStatusNote({
      connected: true,
      mode: "paper",
      accountStatus: "ACTIVE",
      capabilities: ["account.read"],
    });
    assert.match(saved, /saved Alpaca paper/);
    assert.match(saved, /do not say no broker is connected/i);
    assert.doesNotMatch(saved, /^no broker is connected/i);
    assert.doesNotMatch(saved, /\$|equity reported/i);
    const none = brokerStatusNote({ connected: false, mode: null, accountStatus: "", capabilities: [] });
    assert.match(none, /no saved broker link/i);
    assert.equal(brokerClientOrderId(12), "aegis-12");
    assert.equal(brokerClientOrderId(undefined), "");
    assert.equal(brokerClientOrderId(0), "");
  });

  it("keeps scenarios and comparisons from inventing prices", () => {
    assert.match(scenarioSpeech(), /not forecasts/i);
    assert.match(scenarioSpeech(), /No return is guaranteed/i);
    assert.equal(/\$\d|£\d/.test(scenarioSpeech()), false);
    assert.match(comparisonSpeech(), /do not declare a winner/i);
    assert.match(rebalanceSpeech(false, emptySnapshot()), /will not invent/i);
    assert.match(thesisSpeech([]), /will not invent a thesis/i);
    assert.match(journalSpeech(0), /journal is empty/i);
    assert.match(journalSpeech(2), /not a performance record/i);
    assert.equal(/\$\d|£\d/.test(journalSpeech(2)), false);
    assert.match(watchSpeech([]), /no stored price/i);
    assert.match(watchSpeech(["AAPL"]), /not holdings/i);
    assert.doesNotMatch(watchSpeech(["AAPL"]), /\$|price is \d/i);
  });
});
