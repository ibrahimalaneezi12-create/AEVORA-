/**
 * Digital-safety heuristics. Never claim certainty. Never execute anything.
 */

export type SafetyStance = "clear" | "suspicious" | "uncertain";

export type SafetyVerdict = {
  stance: SafetyStance;
  reasons: string[];
  advice: string;
};

const URGENCY = /\b(immediately|urgent|act now|within \d+ hours|account will be (?:closed|suspended)|final notice)\b/i;
const MONEY = /\b(gift cards?|wire transfer|bitcoin|crypto|usdt|western union|send (?:me )?(?:money|payment)|pay (?:now|today)|invoice attached)\b/i;
const CREDENTIALS = /\b(confirm (?:your )?password|verify (?:your )?account|login here|unlock (?:your )?account|one[- ]time (?:code|pin)|ssn|social security)\b/i;
const SECRECY = /\b(do not tell|don'?t tell anyone|keep this secret|between us)\b/i;
const PRIZE = /\b(you(?:'ve| have) won|claim your prize|selected (?:as )?a winner|free iphone)\b/i;
const LINK = /\bhttps?:\/\/\S+/i;
const SHORT_LINK = /\b(?:bit\.ly|tinyurl|t\.co|rb\.gy)\/\S+/i;

export function looksLikeSafetyRequest(text: string): boolean {
  return /\b(phish(?:ing)?|scam|suspicious (?:link|message|email|text)|is this (?:safe|a scam|legit|real)|looks like a scam|spam (?:text|email)|risky link)\b/i.test(
    text,
  );
}

export function assessDigitalSafety(text: string): SafetyVerdict {
  const reasons: string[] = [];
  if (URGENCY.test(text)) reasons.push("It presses for immediate action.");
  if (MONEY.test(text)) reasons.push("It asks for money, gift cards, or crypto.");
  if (CREDENTIALS.test(text)) reasons.push("It asks for a password, code, or account verification.");
  if (SECRECY.test(text)) reasons.push("It asks you to keep the request secret.");
  if (PRIZE.test(text)) reasons.push("It promises a prize or winnings.");
  if (SHORT_LINK.test(text)) reasons.push("It uses a shortened link that hides the real destination.");
  else if (LINK.test(text) && (URGENCY.test(text) || CREDENTIALS.test(text))) {
    reasons.push("It pairs a link with urgency or a login request.");
  }

  if (reasons.length >= 2) {
    return {
      stance: "suspicious",
      reasons,
      advice:
        "Treat this as suspicious. Do not send money, codes, or passwords. Open the official site yourself instead of tapping a link. I cannot be certain from text alone.",
    };
  }
  if (reasons.length === 1) {
    return {
      stance: "uncertain",
      reasons,
      advice:
        "One warning sign is present, but that is not proof. Check the sender through a channel you already trust. I will not claim this is definitely a scam.",
    };
  }
  return {
    stance: "clear",
    reasons: [],
    advice:
      "I do not see the usual scam patterns, but I cannot certify a message from text alone. If something still feels off, verify through an official channel.",
  };
}

export function safetyPromptNote(verdict: SafetyVerdict): string {
  if (verdict.stance === "suspicious") {
    return `Digital safety: heuristic flags this as suspicious (${verdict.reasons.join(" ")}). Do not claim certainty. Advise not to send money or credentials. Do not visit or click the link. Do not create tasks.`;
  }
  if (verdict.stance === "uncertain") {
    return `Digital safety: one heuristic matched. Stay uncertain. Do not claim it is safe or a scam. Do not create tasks.`;
  }
  return "Digital safety question. Do not claim certainty. Do not visit links. Do not create tasks.";
}
