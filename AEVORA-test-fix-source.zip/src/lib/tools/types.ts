export type ToolContext = {
  userId: string;
  toolId: string;
  payload: Record<string, unknown>;
  title: string;
  summary: string;
  /** Set only by the approval path. Never taken from the model payload. */
  proposalId?: number;
};

export type ToolHandler = (ctx: ToolContext) => Promise<string>;

export type StoredTool = {
  id: string;
  displayName: string;
  description: string;
  permissionLevel: "safe" | "review" | "approval" | "restricted";
  enabled: boolean;
};
