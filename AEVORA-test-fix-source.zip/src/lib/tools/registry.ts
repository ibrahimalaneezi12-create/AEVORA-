import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { CANNOT_APPROVE, parsePayloadJson } from "@/lib/confirm-format";
import {
  catalogLevel,
  isExecutable,
  listedTools,
  lookupTool,
} from "./definitions.ts";
import { builtinHandlers } from "./handlers.ts";
import type { StoredTool, ToolHandler } from "./types.ts";

export type { ToolContext, ToolHandler, StoredTool } from "./types.ts";

function isSchemaError(err: unknown): boolean {
  if (!err || typeof err !== "object") return false;
  const name = (err as { name?: string }).name;
  return name === "ZodError" || "issues" in err;
}

const CANNOT_RUN = "This action could not run.";

const handlers = new Map<string, ToolHandler>();

for (const [id, handler] of Object.entries(builtinHandlers)) {
  handlers.set(id, handler);
}

/**
 * Plug-in point for a later capability's side effect. Classification still
 * uses `registerTool`. Approve still uses the same POST. Activity still
 * appends. No HTTP / email / pay handlers are registered here.
 */
export function registerHandler(toolId: string, handler: ToolHandler): void {
  if (toolId.startsWith("external.")) {
    throw new Error("External tools cannot be registered.");
  }
  if (handlers.has(toolId)) throw new Error("Handler already registered.");
  handlers.set(toolId, handler);
}

export function getHandler(toolId: string): ToolHandler | null {
  return handlers.get(toolId) ?? null;
}

export function hasRuntimeHandler(toolId: string): boolean {
  return handlers.has(toolId);
}

type CatalogRow = {
  id: string;
  display_name: string;
  description: string;
  permission_level: string;
  enabled: boolean;
};

function asStored(row: CatalogRow): StoredTool | null {
  const level = row.permission_level;
  if (level !== "safe" && level !== "review" && level !== "approval" && level !== "restricted") {
    return null;
  }
  return {
    id: row.id,
    displayName: row.display_name,
    description: row.description,
    permissionLevel: level,
    enabled: Boolean(row.enabled),
  };
}

/**
 * Upsert in-code tools into `tool_catalog`. Code is the source of truth for
 * metadata; the table is the durable allowlist. Fail-open: execute still
 * fail-closes if the row is missing.
 */
export async function syncToolCatalog(): Promise<void> {
  try {
    const sql = await getSql();
    for (const tool of listedTools()) {
      await sql`
        insert into tool_catalog (id, display_name, description, permission_level, enabled)
        values (
          ${tool.id},
          ${tool.displayName},
          ${tool.description},
          ${tool.permissionLevel},
          ${tool.enabled}
        )
        on conflict (id) do update set
          display_name = excluded.display_name,
          description = excluded.description,
          permission_level = excluded.permission_level,
          enabled = excluded.enabled
      `;
    }
  } catch {
    // Seed is best-effort. Execute still requires a matching enabled row.
  }
}

async function loadStored(toolId: string): Promise<StoredTool | null> {
  const sql = await getSql();
  const rows = await sql<CatalogRow>`
    select id, display_name, description, permission_level, enabled
    from tool_catalog
    where id = ${toolId}
  `;
  const row = rows[0];
  return row ? asStored(row) : null;
}

/**
 * Fail closed: in-code catalog, durable row, handler, and Restricted checks
 * must all agree the tool may run.
 */
export async function assertRunnable(toolId: string): Promise<void> {
  await syncToolCatalog();
  if (!isExecutable(toolId) || catalogLevel(toolId) === "restricted") {
    throw new Error(CANNOT_APPROVE);
  }
  const tool = lookupTool(toolId);
  if (!tool || !tool.enabled) throw new Error(CANNOT_APPROVE);
  if (!getHandler(toolId)) throw new Error(CANNOT_APPROVE);
  const stored = await loadStored(toolId);
  if (!stored || !stored.enabled) throw new Error(CANNOT_APPROVE);
  if (stored.permissionLevel === "restricted") throw new Error(CANNOT_APPROVE);
}

export async function executeRegisteredTool(input: {
  userId: string;
  toolId: string;
  payloadJson: string;
  title: string;
  summary: string;
  proposalId?: number;
}): Promise<string> {
  if (!input.userId) throw new Error(CANNOT_APPROVE);
  await assertRunnable(input.toolId);
  const handler = getHandler(input.toolId);
  if (!handler) throw new Error(CANNOT_APPROVE);
  const payload = parsePayloadJson(input.payloadJson);
  try {
    return await handler({
      userId: input.userId,
      toolId: input.toolId,
      payload,
      title: input.title,
      summary: input.summary,
      proposalId: input.proposalId,
    });
  } catch (err) {
    if (isSchemaError(err)) throw new Error(CANNOT_RUN);
    throw err;
  }
}

const listInput = z.object({}).optional();

/**
 * Signed-in discovery of the durable catalog. Not user-owned. No handlers,
 * no payloads. Client never sends a user id.
 */
export const listToolCatalog = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => listInput.parse(input ?? {}))
  .handler(async (): Promise<StoredTool[]> => {
    await syncToolCatalog();
    const sql = await getSql();
    const rows = await sql<CatalogRow>`
      select id, display_name, description, permission_level, enabled
      from tool_catalog
      order by id asc
    `;
    const out: StoredTool[] = [];
    for (const row of rows) {
      const mapped = asStored(row);
      if (mapped) out.push(mapped);
    }
    return out;
  });
