import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  canRunTool,
  catalogLevel,
  isChatReply,
  isExecutable,
  isValidToolId,
  listedTools,
  lookupTool,
  registerTool,
} from "./definitions.ts";

describe("tool registry definitions", () => {
  it("lists every spec §7.2 in-product id and no HTTP/email/pay tools", () => {
    const ids = listedTools()
      .map((t) => t.id)
      .filter((id) => !id.startsWith("test."))
      .sort();
    assert.deepEqual(
      ids.sort(),
      [
        "broker.order",
        "business.experiment",
        "business.note",
        "business.save",
        "calendar.create",
        "calendar.delete",
        "calendar.list",
        "calendar.update",
        "conversation.delete",
        "creation.save",
        "email.draft",
        "email.list",
        "email.send",
        "goal.create",
        "goal.update",
        "invest.note",
        "invest.plan",
        "invest.unwatch",
        "invest.watch",
        "memory.delete",
        "memory.save",
        "memory.search",
        "permission.update",
        "photo.edit",
        "photo.generate",
        "profile.update",
        "reminder.cancel",
        "reminder.complete",
        "reminder.create",
        "reminder.list",
        "reminder.snooze",
        "reminder.update",
        "research.query",
        "search.web",
        "task.create",
        "task.delete",
        "task.list",
        "task.update",
        "video.create",
        "video.edit",
        "video.generate",
      ].sort(),
    );
    assert.equal(ids.some((id) => id.startsWith("external.")), false);
    assert.equal(ids.includes("chat.reply"), false);
  });

  it("marks in-product Safe/Review/Approval tools executable and Restricted not", () => {
    assert.equal(isExecutable("memory.search"), true);
    assert.equal(isExecutable("memory.save"), true);
    assert.equal(isExecutable("memory.delete"), true);
    assert.equal(canRunTool("memory.save"), true);
    assert.equal(canRunTool("calendar.create"), true);
    assert.equal(canRunTool("email.send"), true);
    assert.equal(isExecutable("permission.update"), false);
    assert.equal(isExecutable("search.web"), false);
    assert.equal(isExecutable("research.query"), false);
    assert.equal(canRunTool("permission.update"), false);
    assert.equal(canRunTool("chat.reply"), false);
    assert.equal(canRunTool("shell.exec"), false);
    assert.equal(canRunTool("external.email"), false);
  });

  it("accepts dotted tool ids and rejects junk", () => {
    assert.equal(isValidToolId("memory.save"), true);
    assert.equal(isValidToolId("goal.create"), true);
    assert.equal(isValidToolId("chat.reply"), true);
    assert.equal(isValidToolId("not-a-tool"), false);
    assert.equal(isValidToolId("SaveMemory"), false);
    assert.equal(isValidToolId(""), false);
  });

  it("refuses to register chat.reply, external.*, duplicates, and junk ids", () => {
    assert.throws(() =>
      registerTool({
        id: "chat.reply",
        displayName: "Reply",
        description: "no",
        permissionLevel: "safe",
        enabled: true,
      }),
    );
    assert.throws(() =>
      registerTool({
        id: "external.email",
        displayName: "Email",
        description: "no",
        permissionLevel: "safe",
        enabled: true,
      }),
    );
    assert.throws(() =>
      registerTool({
        id: "memory.save",
        displayName: "Dup",
        description: "no",
        permissionLevel: "review",
        enabled: true,
      }),
    );
    assert.throws(() =>
      registerTool({
        id: "Nope",
        displayName: "Nope",
        description: "no",
        permissionLevel: "safe",
        enabled: true,
      }),
    );
  });

  it("lets a future in-product tool plug in without replacing the catalog", () => {
    registerTool(
      {
        id: "test.step14.probe",
        displayName: "Probe",
        description: "Registry plug-in probe",
        permissionLevel: "review",
        enabled: true,
      },
      { executable: true },
    );
    assert.equal(lookupTool("test.step14.probe")?.displayName, "Probe");
    assert.equal(catalogLevel("test.step14.probe"), "review");
    assert.equal(isExecutable("test.step14.probe"), true);
    assert.equal(canRunTool("test.step14.probe"), true);
    assert.equal(isChatReply("test.step14.probe"), false);
  });

  it("does not treat a registered tool as runnable without the executable flag", () => {
    registerTool({
      id: "test.step14.nohandler",
      displayName: "No handler",
      description: "Registered without a handler",
      permissionLevel: "review",
      enabled: true,
    });
    assert.equal(lookupTool("test.step14.nohandler")?.permissionLevel, "review");
    assert.equal(isExecutable("test.step14.nohandler"), false);
    assert.equal(canRunTool("test.step14.nohandler"), false);
    assert.equal(catalogLevel("test.step14.nohandler"), "review");
  });
});
