import type { PermissionLevel, ToolDefinition } from "@/lib/orchestrator/types";

/**
 * In-code tool catalog. Classification reads this map, never the model.
 * Handlers live in `registry.ts` (server). A future capability plugs in by
 * calling `registerTool` here and `registerHandler` on the server — same
 * proposal → approval → execute → activity path. No second gate.
 *
 * `chat.reply` is not a tool. `external.*` cannot be registered.
 */
const TOOLS: ToolDefinition[] = [
  {
    id: "memory.search",
    displayName: "Search memory",
    description: "Read own memories",
    permissionLevel: "safe",
    enabled: true,
  },
  {
    id: "task.list",
    displayName: "List tasks",
    description: "Read own tasks and goals",
    permissionLevel: "safe",
    enabled: true,
  },
  {
    id: "reminder.list",
    displayName: "List reminders",
    description: "Read own reminders",
    permissionLevel: "safe",
    enabled: true,
  },
  {
    id: "memory.save",
    displayName: "Save a memory",
    description: "Insert or update own memory",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "task.create",
    displayName: "Create a task",
    description: "Insert own task",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "task.update",
    displayName: "Update a task",
    description: "Update own task",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "goal.create",
    displayName: "Create a goal",
    description: "Insert own goal",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "goal.update",
    displayName: "Update a goal",
    description: "Update own goal",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "reminder.create",
    displayName: "Create a reminder",
    description: "Schedule a reminder",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "reminder.update",
    displayName: "Update a reminder",
    description: "Edit own reminder",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "reminder.snooze",
    displayName: "Snooze a reminder",
    description: "Postpone own reminder",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "reminder.complete",
    displayName: "Complete a reminder",
    description: "Mark own reminder done",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "memory.delete",
    displayName: "Delete a memory",
    description: "Destructive memory delete",
    permissionLevel: "approval",
    enabled: true,
  },
  {
    id: "task.delete",
    displayName: "Delete a task",
    description: "Destructive task delete",
    permissionLevel: "approval",
    enabled: true,
  },
  {
    id: "reminder.cancel",
    displayName: "Cancel a reminder",
    description: "Cancel own reminder",
    permissionLevel: "approval",
    enabled: true,
  },
  {
    id: "conversation.delete",
    displayName: "Delete a conversation",
    description: "Destructive conversation delete",
    permissionLevel: "approval",
    enabled: true,
  },
  {
    id: "profile.update",
    displayName: "Update profile",
    description: "Identity change",
    permissionLevel: "approval",
    enabled: true,
  },
  {
    id: "permission.update",
    displayName: "Change permissions",
    description: "Frozen off; no self-loosening",
    permissionLevel: "restricted",
    enabled: true,
  },
  {
    id: "calendar.list",
    displayName: "List calendar",
    description: "Read own calendar",
    permissionLevel: "safe",
    enabled: true,
  },
  {
    id: "calendar.create",
    displayName: "Create calendar event",
    description: "Insert own event",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "calendar.update",
    displayName: "Update calendar event",
    description: "Edit own event",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "calendar.delete",
    displayName: "Delete calendar event",
    description: "Remove own event",
    permissionLevel: "approval",
    enabled: true,
  },
  {
    id: "email.list",
    displayName: "List email drafts",
    description: "Read own drafts",
    permissionLevel: "safe",
    enabled: true,
  },
  {
    id: "email.draft",
    displayName: "Draft an email",
    description: "Create an email draft",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "email.send",
    displayName: "Send an email",
    description: "Send a prepared email",
    permissionLevel: "approval",
    enabled: true,
  },
  {
    id: "creation.save",
    displayName: "Save a creation",
    description: "Store generated writing",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "video.create",
    displayName: "Create a video project",
    description: "Plan a private video from a description",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "video.generate",
    displayName: "Generate a video",
    description: "Render a scene with Imagine Video",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "photo.generate",
    displayName: "Generate a photo",
    description: "Create a private still with Imagine Image",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "photo.edit",
    displayName: "Edit a photo",
    description: "Natural-language edit of an owned photo",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "video.edit",
    displayName: "Edit a video",
    description: "Natural-language look edit of a short owned clip",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "search.web",
    displayName: "Search the web",
    description: "Look up current public information",
    permissionLevel: "safe",
    enabled: true,
  },
  {
    id: "research.query",
    displayName: "Research a question",
    description: "Multi-source investigation",
    permissionLevel: "safe",
    enabled: true,
  },
  {
    id: "business.save",
    displayName: "Save business",
    description: "Insert or update own business identity",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "business.note",
    displayName: "Save a business note",
    description: "Store an owned business note",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "invest.watch",
    displayName: "Watch an investment",
    description: "Add a symbol to the owned watchlist",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "invest.unwatch",
    displayName: "Remove from watchlist",
    description: "Remove an owned watchlist row",
    permissionLevel: "approval",
    enabled: true,
  },
  {
    id: "invest.note",
    displayName: "Save an investment note",
    description: "Thesis, decision, or paper trade",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "invest.plan",
    displayName: "Save an investment plan",
    description: "Store an owned plan. Does not place an order",
    permissionLevel: "review",
    enabled: true,
  },
  {
    id: "broker.order",
    displayName: "Place a broker order",
    description: "Send an order only to a connected Alpaca account after approval",
    permissionLevel: "approval",
    enabled: true,
  },
  {
    id: "business.experiment",
    displayName: "Save a business experiment",
    description: "Store a hypothesis. Does not invent a result",
    permissionLevel: "review",
    enabled: true,
  },
];

const BY_ID = new Map(TOOLS.map((t) => [t.id, t]));

/** Tools that have an in-process handler. Restricted / future stubs stay out. */
const EXECUTABLE = new Set<string>([
  "memory.search",
  "task.list",
  "reminder.list",
  "memory.save",
  "task.create",
  "task.update",
  "goal.create",
  "goal.update",
  "reminder.create",
  "reminder.update",
  "reminder.snooze",
  "reminder.complete",
  "memory.delete",
  "task.delete",
  "reminder.cancel",
  "conversation.delete",
  "profile.update",
  "calendar.list",
  "calendar.create",
  "calendar.update",
  "calendar.delete",
  "email.list",
  "email.draft",
  "email.send",
  "creation.save",
  "video.create",
  "video.generate",
  "photo.generate",
  "photo.edit",
  "video.edit",
  "business.save",
  "business.note",
  "invest.watch",
  "invest.unwatch",
  "invest.note",
  "invest.plan",
  "broker.order",
  "business.experiment",
]);

export const TOOL_ID_RE = /^[a-z][a-z0-9]*(?:\.[a-z][a-z0-9_]*)+$/;

export function isValidToolId(toolId: string): boolean {
  return TOOL_ID_RE.test(toolId);
}

export function isChatReply(toolId: string): boolean {
  return toolId === "chat.reply";
}

export function lookupTool(toolId: string): ToolDefinition | null {
  return BY_ID.get(toolId) ?? null;
}

export function displayNameFor(toolId: string): string {
  return lookupTool(toolId)?.displayName ?? toolId;
}

export function catalogLevel(toolId: string): PermissionLevel {
  if (toolId.startsWith("external.")) return "restricted";
  const tool = lookupTool(toolId);
  if (!tool || !tool.enabled) return "restricted";
  return tool.permissionLevel;
}

export function isExecutable(toolId: string): boolean {
  const tool = lookupTool(toolId);
  if (!tool || !tool.enabled) return false;
  if (tool.permissionLevel === "restricted") return false;
  return EXECUTABLE.has(tool.id);
}

/** True when Approve may run this id: registered, enabled, not Restricted, has a handler. */
export function canRunTool(toolId: string): boolean {
  if (isChatReply(toolId)) return false;
  return isExecutable(toolId) && catalogLevel(toolId) !== "restricted";
}

/** Read-only catalog for settings. The model never supplies this list. */
export function listedTools(): readonly ToolDefinition[] {
  return TOOLS;
}

/**
 * Plug-in point for a later capability. Does not execute. Does not loosen
 * Restricted. `external.*` and `chat.reply` are refused.
 */
export function registerTool(
  def: ToolDefinition,
  options?: { executable?: boolean },
): void {
  if (!isValidToolId(def.id) || isChatReply(def.id) || def.id.startsWith("external.")) {
    throw new Error("Invalid tool id.");
  }
  if (BY_ID.has(def.id)) throw new Error("Tool already registered.");
  const row: ToolDefinition = {
    id: def.id,
    displayName: def.displayName,
    description: def.description,
    permissionLevel: def.permissionLevel,
    enabled: def.enabled,
  };
  TOOLS.push(row);
  BY_ID.set(row.id, row);
  if (options?.executable && row.enabled && row.permissionLevel !== "restricted") {
    EXECUTABLE.add(row.id);
  }
}

export function markExecutable(toolId: string): void {
  const tool = lookupTool(toolId);
  if (!tool || !tool.enabled || tool.permissionLevel === "restricted") return;
  EXECUTABLE.add(toolId);
}
