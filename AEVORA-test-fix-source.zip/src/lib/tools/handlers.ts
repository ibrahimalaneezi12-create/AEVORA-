import { getSql } from "@/lib/db";
import {
  emptyToNull,
  mapGoal,
  mapTask,
  type GoalRow,
  type TaskRow,
} from "@/lib/goals-format";
import { findConflictingPreference, mapMemory, type MemoryRow } from "@/lib/memory-format";
import {
  goalCreatePayload,
  goalUpdatePayload,
  idPayload,
  memorySavePayload,
  memorySearchPayload,
  profileUpdatePayload,
  requiredBody,
  requiredTitle,
  taskCreatePayload,
  taskUpdatePayload,
} from "@/lib/confirm-format";
import {
  reminderCancelHandler,
  reminderCompleteHandler,
  reminderCreateHandler,
  reminderListHandler,
  reminderSnoozeHandler,
  reminderUpdateHandler,
} from "@/lib/reminders";
import {
  calendarCreateHandler,
  calendarDeleteHandler,
  calendarListHandler,
  calendarUpdateHandler,
} from "@/lib/calendar";
import { creationSaveHandler } from "@/lib/creation";
import { videoCreateHandler, videoGenerateHandler } from "@/lib/video";
import { photoEditHandler, photoGenerateHandler, videoEditHandler } from "@/lib/studio";
import { emailDraftHandler, emailListHandler, emailSendHandler } from "@/lib/mail";
import { businessExperimentHandler, businessNoteHandler, businessSaveHandler } from "@/lib/business";
import { brokerOrderHandler } from "@/lib/broker.server";
import { investNoteHandler, investPlanHandler, investUnwatchHandler, investWatchHandler } from "@/lib/invest";
import type { ToolHandler } from "./types.ts";

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

async function assertGoalOwned(userId: string, goalId: number | null | undefined): Promise<void> {
  if (goalId == null) return;
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    select id from goals where id = ${goalId} and user_id = ${userId}
  `;
  if (!rows[0]) throw new Error("Goal not found.");
}

const memorySearch: ToolHandler = async ({ userId, payload, summary }) => {
  const query = (memorySearchPayload.parse(payload).query ?? "").trim() || summary;
  const { retrieveMemories } = await import("@/lib/memory");
  const rows = await retrieveMemories(userId, query);
  if (rows.length === 0) return "No matching memories.";
  return rows.length === 1 ? "Found 1 memory." : `Found ${rows.length} memories.`;
};

const taskList: ToolHandler = async ({ userId }) => {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`
    select count(*)::int as n from tasks where user_id = ${userId}
  `;
  const n = rows[0]?.n ?? 0;
  return n === 1 ? "1 task." : `${n} tasks.`;
};

const memorySave: ToolHandler = async ({ userId, payload, title: proposalTitle, summary }) => {
  const parsed = memorySavePayload.parse(payload);
  const sql = await getSql();
  if (parsed.id) {
    const existing = await sql<MemoryRow>`
      select id, kind, title, body, tags, source, pinned, created_at, updated_at
      from memories
      where id = ${parsed.id} and user_id = ${userId}
    `;
    const current = existing[0] ? mapMemory(existing[0]) : null;
    if (!current) throw new Error("Memory not found.");
    const title = (parsed.title ?? current.title).trim() || current.title;
    const body = (parsed.body ?? current.body).trim() || current.body;
    const rows = await sql<MemoryRow>`
      update memories
      set
        kind = ${parsed.kind ?? current.kind},
        title = ${title},
        body = ${body},
        tags = ${parsed.tags ?? current.tags},
        pinned = ${parsed.pinned ?? current.pinned},
        updated_at = now()
      where id = ${current.id} and user_id = ${userId}
      returning id, kind, title, body, tags, source, pinned, created_at, updated_at
    `;
    const mapped = rows[0] ? mapMemory(rows[0]) : null;
    if (!mapped) throw new Error("Memory not found.");
    return `Updated memory ${mapped.id}.`;
  }
  const title = requiredTitle(parsed.title, proposalTitle);
  const body = requiredBody(parsed.body, summary, title);
  const kind = parsed.kind ?? "fact";
  const tags = (parsed.tags ?? "").trim();
  const pinned = parsed.pinned ?? false;
  if (kind === "preference") {
    const existing = await sql<MemoryRow>`
      select id, kind, title, body, tags, source, pinned, created_at, updated_at
      from memories
      where user_id = ${userId} and kind = ${"preference"}
      order by updated_at desc
      limit 40
    `;
    const mappedExisting = [];
    for (const row of existing) {
      const m = mapMemory(row);
      if (m) mappedExisting.push(m);
    }
    const conflict = findConflictingPreference(mappedExisting, { title, body });
    if (conflict) {
      const rows = await sql<MemoryRow>`
        update memories
        set
          title = ${title},
          body = ${body},
          tags = ${tags || conflict.tags},
          pinned = ${parsed.pinned ?? conflict.pinned},
          updated_at = now()
        where id = ${conflict.id} and user_id = ${userId}
        returning id, kind, title, body, tags, source, pinned, created_at, updated_at
      `;
      const mapped = rows[0] ? mapMemory(rows[0]) : null;
      if (!mapped) throw new Error("Memory not found.");
      return `Updated memory ${mapped.id}.`;
    }
  }
  const rows = await sql<MemoryRow>`
    insert into memories (user_id, kind, title, body, tags, source, pinned)
    values (
      ${userId},
      ${kind},
      ${title},
      ${body},
      ${tags},
      ${"assistant"},
      ${pinned}
    )
    returning id, kind, title, body, tags, source, pinned, created_at, updated_at
  `;
  const mapped = rows[0] ? mapMemory(rows[0]) : null;
  if (!mapped) throw new Error("Memory could not be saved.");
  return `Saved memory ${mapped.id}.`;
};

const taskCreate: ToolHandler = async ({ userId, payload, title: proposalTitle }) => {
  const parsed = taskCreatePayload.parse(payload);
  const title = requiredTitle(parsed.title, proposalTitle);
  const notes = (parsed.notes ?? "").trim();
  const status = parsed.status ?? "todo";
  const dueDate = parsed.dueDate ?? null;
  const goalId = parsed.goalId ?? null;
  await assertGoalOwned(userId, goalId);
  const sql = await getSql();
  const max = await sql<{ n: number }>`
    select coalesce(max(sort_order), 0)::int as n
    from tasks
    where user_id = ${userId}
  `;
  const sortOrder = (max[0]?.n ?? 0) + 1;
  const rows = await sql<TaskRow>`
    insert into tasks (user_id, goal_id, title, notes, status, due_date, sort_order)
    values (
      ${userId},
      ${goalId},
      ${title},
      ${notes},
      ${status},
      ${dueDate},
      ${sortOrder}
    )
    returning id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
  `;
  const mapped = rows[0] ? mapTask(rows[0]) : null;
  if (!mapped) throw new Error("Task could not be saved.");
  return `Created task ${mapped.id}.`;
};

const taskUpdate: ToolHandler = async ({ userId, payload }) => {
  const parsed = taskUpdatePayload.parse(payload);
  const sql = await getSql();
  const existing = await sql<TaskRow>`
    select id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
    from tasks
    where id = ${parsed.id} and user_id = ${userId}
  `;
  const current = existing[0] ? mapTask(existing[0]) : null;
  if (!current) throw new Error("Task not found.");
  const title = parsed.title ?? current.title;
  const notes = parsed.notes ?? current.notes;
  const status = parsed.status ?? current.status;
  const dueDate = "dueDate" in payload ? parsed.dueDate : current.dueDate;
  const goalId = "goalId" in payload ? (parsed.goalId ?? null) : current.goalId;
  await assertGoalOwned(userId, goalId);
  const rows = await sql<TaskRow>`
    update tasks
    set
      goal_id = ${goalId},
      title = ${title},
      notes = ${notes.trim()},
      status = ${status},
      due_date = ${dueDate},
      updated_at = now()
    where id = ${current.id} and user_id = ${userId}
    returning id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
  `;
  const mapped = rows[0] ? mapTask(rows[0]) : null;
  if (!mapped) throw new Error("Task not found.");
  return `Updated task ${mapped.id}.`;
};

const goalCreate: ToolHandler = async ({ userId, payload, title: proposalTitle }) => {
  const parsed = goalCreatePayload.parse(payload);
  const title = requiredTitle(parsed.title, proposalTitle);
  const description = (parsed.description ?? "").trim();
  const status = parsed.status ?? "active";
  const targetDate = parsed.targetDate ?? null;
  const sql = await getSql();
  const rows = await sql<GoalRow>`
    insert into goals (user_id, title, description, status, target_date)
    values (
      ${userId},
      ${title},
      ${description},
      ${status},
      ${targetDate}
    )
    returning id, title, description, status, target_date, created_at, updated_at
  `;
  if (!rows[0]) throw new Error("Goal could not be saved.");
  return `Created goal ${asId(rows[0].id)}.`;
};

const goalUpdate: ToolHandler = async ({ userId, payload }) => {
  const parsed = goalUpdatePayload.parse(payload);
  const sql = await getSql();
  const existing = await sql<GoalRow>`
    select id, title, description, status, target_date, created_at, updated_at
    from goals
    where id = ${parsed.id} and user_id = ${userId}
  `;
  const current = existing[0] ? mapGoal(existing[0]) : null;
  if (!current) throw new Error("Goal not found.");
  const title = parsed.title ?? current.title;
  const description = parsed.description ?? current.description;
  const status = parsed.status ?? current.status;
  const targetDate = "targetDate" in payload ? parsed.targetDate : current.targetDate;
  const rows = await sql<GoalRow>`
    update goals
    set
      title = ${title},
      description = ${description.trim()},
      status = ${status},
      target_date = ${targetDate},
      updated_at = now()
    where id = ${current.id} and user_id = ${userId}
    returning id, title, description, status, target_date, created_at, updated_at
  `;
  if (!rows[0]) throw new Error("Goal not found.");
  return `Updated goal ${current.id}.`;
};

const memoryDelete: ToolHandler = async ({ userId, payload }) => {
  const parsed = idPayload.parse(payload);
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    delete from memories
    where id = ${parsed.id} and user_id = ${userId}
    returning id
  `;
  if (!rows[0]) throw new Error("Memory not found.");
  return `Deleted memory ${parsed.id}.`;
};

const taskDelete: ToolHandler = async ({ userId, payload }) => {
  const parsed = idPayload.parse(payload);
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    delete from tasks
    where id = ${parsed.id} and user_id = ${userId}
    returning id
  `;
  if (!rows[0]) throw new Error("Task not found.");
  return `Deleted task ${parsed.id}.`;
};

const conversationDelete: ToolHandler = async ({ userId, payload }) => {
  const parsed = idPayload.parse(payload);
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    delete from conversations
    where id = ${parsed.id} and user_id = ${userId}
    returning id
  `;
  if (!rows[0]) throw new Error("Conversation not found.");
  return `Deleted conversation ${parsed.id}.`;
};

const profileUpdate: ToolHandler = async ({ userId, payload }) => {
  const parsed = profileUpdatePayload.parse(payload);
  const sql = await getSql();
  const current = await sql<{
    display_name: string | null;
    bio: string;
    timezone: string;
    theme: string;
  }>`
    select display_name, bio, timezone, theme
    from profiles
    where user_id = ${userId}
  `;
  const row = current[0];
  if (!row) throw new Error("Profile not found.");
  const displayName =
    parsed.displayName !== undefined ? emptyToNull(parsed.displayName) : row.display_name;
  const bio = parsed.bio !== undefined ? parsed.bio.trim() : row.bio;
  const timezone = parsed.timezone !== undefined ? parsed.timezone.trim() : row.timezone;
  const theme = parsed.theme ?? row.theme;
  await sql`
    update profiles
    set
      display_name = ${displayName},
      bio = ${bio},
      timezone = ${timezone || "UTC"},
      theme = ${theme},
      updated_at = now()
    where user_id = ${userId}
  `;
  return "Updated profile.";
};

/**
 * In-product handlers. Future capabilities add an entry here (or call
 * `registerHandler`) without changing Approve / Deny / Activity.
 */
export const builtinHandlers: Record<string, ToolHandler> = {
  "memory.search": memorySearch,
  "task.list": taskList,
  "reminder.list": reminderListHandler,
  "memory.save": memorySave,
  "task.create": taskCreate,
  "task.update": taskUpdate,
  "goal.create": goalCreate,
  "goal.update": goalUpdate,
  "reminder.create": reminderCreateHandler,
  "reminder.update": reminderUpdateHandler,
  "reminder.snooze": reminderSnoozeHandler,
  "reminder.complete": reminderCompleteHandler,
  "memory.delete": memoryDelete,
  "task.delete": taskDelete,
  "reminder.cancel": reminderCancelHandler,
  "conversation.delete": conversationDelete,
  "profile.update": profileUpdate,
  "calendar.list": calendarListHandler,
  "calendar.create": calendarCreateHandler,
  "calendar.update": calendarUpdateHandler,
  "calendar.delete": calendarDeleteHandler,
  "email.list": emailListHandler,
  "email.draft": emailDraftHandler,
  "email.send": emailSendHandler,
  "creation.save": creationSaveHandler,
  "video.create": videoCreateHandler,
  "video.generate": videoGenerateHandler,
  "photo.generate": photoGenerateHandler,
  "photo.edit": photoEditHandler,
  "video.edit": videoEditHandler,
  "business.save": businessSaveHandler,
  "business.note": businessNoteHandler,
  "invest.watch": investWatchHandler,
  "invest.unwatch": investUnwatchHandler,
  "invest.note": investNoteHandler,
  "invest.plan": investPlanHandler,
  "broker.order": brokerOrderHandler,
  "business.experiment": businessExperimentHandler,
};
