import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  STUDIO_CAPABILITIES,
  buildPhotoEditBody,
  buildPhotoGenerationBody,
  classifyVideoEdit,
  parseDataUri,
  publicStudioError,
  titleFromPrompt,
} from "./studio-format.ts";
import { canRunTool, catalogLevel, isExecutable, listedTools } from "./tools/definitions.ts";

describe("studio format", () => {
  it("does not claim unsupported video edits", () => {
    assert.equal(STUDIO_CAPABILITIES.timelineCut, false);
    assert.equal(STUDIO_CAPABILITIES.slowMotion, false);
    assert.equal(STUDIO_CAPABILITIES.native4k, false);
    assert.equal(STUDIO_CAPABILITIES.photoEdit, true);
    assert.equal(STUDIO_CAPABILITIES.videoPromptEdit, true);
    assert.equal(classifyVideoEdit("Add rain").ok, true);
    assert.equal(classifyVideoEdit("Cut out the boring parts").ok, false);
    assert.equal(classifyVideoEdit("Make the audio louder").ok, false);
    assert.equal(classifyVideoEdit("slow motion on the goal").ok, false);
  });

  it("parses data uris without treating client ids as owners", () => {
    const uri = "data:image/png;base64,AAAA";
    const parsed = parseDataUri(uri);
    assert.ok(parsed);
    assert.equal(parsed?.mime, "image/png");
    assert.equal(titleFromPrompt("  A cinematic football photo  ").startsWith("A cinematic"), true);
    assert.equal(publicStudioError("Bearer sk-secret"), "Something went wrong. Please try again.");
    assert.equal(publicStudioError("Photo could not start (403)."), "Studio is unavailable right now.");
  });

  it("builds documented image request bodies", () => {
    const gen = buildPhotoGenerationBody({ prompt: "A still", aspectRatio: "16:9", resolution: "1k" });
    assert.equal(gen.model, "grok-imagine-image-2.0");
    assert.equal(gen.response_format, "b64_json");
    const edit = buildPhotoEditBody({ prompt: "Warmer", imageDataUri: "data:image/png;base64,AAAA" });
    assert.deepEqual(edit.image, { url: "data:image/png;base64,AAAA", type: "image_url" });
  });
});

describe("studio tools", () => {
  it("registers photo and video edit as review", () => {
    const ids = listedTools().map((t) => t.id);
    assert.equal(ids.includes("photo.generate"), true);
    assert.equal(ids.includes("photo.edit"), true);
    assert.equal(ids.includes("video.edit"), true);
    assert.equal(catalogLevel("photo.edit"), "review");
    assert.equal(catalogLevel("video.edit"), "review");
    assert.equal(isExecutable("photo.generate"), true);
    assert.equal(canRunTool("video.edit"), true);
  });
});
