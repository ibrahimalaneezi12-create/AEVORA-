import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { isFounderEmail, normalizeAccountEmail } from "@/lib/founder-email";
import {
  asEntitlementPlan,
  featureDeniedMessage,
  planAllowsFeature,
  planHasFullAccess,
  planPriceLabel,
  type Entitlement,
  type EntitlementFeature,
} from "@/lib/entitlements-format";

export type {
  Entitlement,
  EntitlementFeature,
  EntitlementPlan,
} from "@/lib/entitlements-format";
export {
  planAllowsFeature,
  planDisplayName,
  planHasFullAccess,
  planPriceLabel,
  featureDeniedMessage,
  contextTierNote,
} from "@/lib/entitlements-format";

type EntitlementRow = {
  user_id: string;
  plan: string;
  granted_at: unknown;
  granted_reason: string;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function mapEntitlement(row: EntitlementRow): Entitlement {
  const plan = asEntitlementPlan(row.plan);
  return {
    userId: row.user_id,
    plan,
    grantedAt: toIso(row.granted_at),
    grantedReason: row.granted_reason,
    price: planPriceLabel(plan),
    fullAccess: planHasFullAccess(plan),
  };
}

async function readEntitlement(userId: string): Promise<Entitlement | null> {
  const sql = await getSql();
  const rows = await sql<EntitlementRow>`
    select user_id, plan, granted_at, granted_reason
    from entitlements
    where user_id = ${userId}
  `;
  return rows[0] ? mapEntitlement(rows[0]) : null;
}

async function accountEmail(userId: string): Promise<string | null> {
  const sql = await getSql();
  const rows = await sql<{ email: string | null }>`
    select email from "user" where id = ${userId}
  `;
  const email = normalizeAccountEmail(rows[0]?.email);
  return email || null;
}

/**
 * Founder is Ibrahim's authenticated email only. Never first-user. Never a
 * client-supplied flag. Other accounts stay Free.
 */
export async function ensureEntitlement(userId: string): Promise<Entitlement> {
  const existing = await readEntitlement(userId);
  const email = await accountEmail(userId);
  const sql = await getSql();

  if (isFounderEmail(email)) {
    if (existing?.plan === "founder") {
      if (existing.grantedReason === "founder-email") return existing;
      await sql`
        update entitlements
        set granted_reason = ${"founder-email"}
        where user_id = ${userId}
      `;
      return (await readEntitlement(userId)) ?? existing;
    }
    await sql`
      insert into entitlements (user_id, plan, granted_reason)
      values (${userId}, ${"founder"}, ${"founder-email"})
      on conflict (user_id) do update
        set plan = excluded.plan, granted_reason = excluded.granted_reason
    `;
    const created = await readEntitlement(userId);
    if (!created) throw new Error("Entitlement could not be created.");
    return created;
  }

  if (existing?.plan === "founder") {
    await sql`
      update entitlements
      set plan = ${"free"}, granted_reason = ${"signup"}
      where user_id = ${userId} and plan = ${"founder"}
    `;
  } else if (existing) {
    return existing;
  } else {
    await sql`
      insert into entitlements (user_id, plan, granted_reason)
      values (${userId}, ${"free"}, ${"signup"})
      on conflict (user_id) do nothing
    `;
  }

  const created = await readEntitlement(userId);
  if (!created) throw new Error("Entitlement could not be created.");
  return created;
}

export async function entitlementFor(userId: string): Promise<Entitlement> {
  return ensureEntitlement(userId);
}

export async function assertFeature(
  userId: string,
  feature: EntitlementFeature,
): Promise<Entitlement> {
  const row = await ensureEntitlement(userId);
  if (!planAllowsFeature(row.plan, feature)) {
    throw new Error(featureDeniedMessage(row.plan, feature));
  }
  return row;
}

export const getEntitlement = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Entitlement> => {
    return ensureEntitlement(context.userId);
  });
