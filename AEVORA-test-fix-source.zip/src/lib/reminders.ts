import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { appendAudit } from "@/lib/audit";
import { resolveLocale } from "@/lib/locale";
import { resolveTimeZone, formatInZone, nextOccurrence } from "@/lib/time-format";
import type { Recurrence } from "@/lib/time-format";
import type { ToolHandler } from "@/lib/tools/types";
import {
  reminderCancelPayload,
  reminderCompletePayload,
  reminderCreatePayload,
  reminderSnoozePayload,
  reminderUpdatePayload,
  requiredTitle,
} from "@/lib/confirm-format";
import {
  ATTEMPT_STATUSES,
  DEVICE_PERMISSIONS,
  REMINDER_BODY_MAX,
  advanceAfterDelivery,
  canClaimStatus,
  isDuplicateFire,
  mapReminder,
  resolveFireAt,
  retryOrFail,
  snoozeInstant,
  type AttemptStatus,
  type DevicePermission,
  type NotificationDevice,
  type Reminder,
  type ReminderRow,
} from "./reminders-format.ts";

export { mapReminder } from "./reminders-format.ts";
export type { Reminder, NotificationAttempt, NotificationDevice } from "./reminders-format.ts";

const MAX_LIST = 80;

export type ClaimedReminder = {
  reminder: Reminder;
  attemptId: number;
};

const idInput = z.object({
  id: z.number().int().positive(),
});

const snoozeInput = reminderSnoozePayload;

const deviceInput = z.object({
  deviceKey: z.string().trim().min(8).max(80),
  label: z.string().trim().max(80).optional(),
  permission: z.enum(DEVICE_PERMISSIONS).optional(),
});

const claimInput = z.object({
  deviceKey: z.string().trim().min(8).max(80),
});

const ackInput = z.object({
  reminderId: z.number().int().positive(),
  attemptId: z.number().int().positive(),
  status: z.enum(ATTEMPT_STATUSES),
  error: z.string().max(240).optional(),
});

async function writeAudit(
  userId: string,
  actor: "user" | "system" | "assistant",
  action: string,
  entityType: string,
  entityId: string,
  detail: string,
): Promise<void> {
  await appendAudit({
    userId,
    actor,
    action,
    entityType,
    entityId,
    detail,
  });
}

async function loadOwn(userId: string, id: number): Promise<Reminder | null> {
  const sql = await getSql();
  const rows = await sql<ReminderRow>`
    select id, title, body, timezone, fire_at, local_date, local_time, recurrence, weekday,
           status, snooze_until, last_fired_at, locale, retry_count, related_task_id, related_goal_id,
           created_at, updated_at
    from reminders
    where id = ${id} and user_id = ${userId}
  `;
  return rows[0] ? mapReminder(rows[0]) : null;
}

async function loadProfileBits(userId: string): Promise<{ timezone: string; locale: string }> {
  const sql = await getSql();
  const rows = await sql<{ timezone: string | null; locale: string | null }>`
    select timezone, locale from profiles where user_id = ${userId}
  `;
  return {
    timezone: resolveTimeZone(rows[0]?.timezone),
    locale: resolveLocale(rows[0]?.locale),
  };
}

async function assertOwnedLink(
  userId: string,
  relatedTaskId: number | null | undefined,
  relatedGoalId: number | null | undefined,
): Promise<void> {
  const sql = await getSql();
  if (relatedTaskId) {
    const rows = await sql<{ id: unknown }>`
      select id from tasks where id = ${relatedTaskId} and user_id = ${userId}
    `;
    if (!rows[0]) throw new Error("Task not found.");
  }
  if (relatedGoalId) {
    const rows = await sql<{ id: unknown }>`
      select id from goals where id = ${relatedGoalId} and user_id = ${userId}
    `;
    if (!rows[0]) throw new Error("Goal not found.");
  }
}

function clipBody(value: string | null | undefined): string {
  return (value ?? "").trim().slice(0, REMINDER_BODY_MAX);
}

function asRecurrence(value: string | null | undefined): Recurrence {
  if (value === "daily" || value === "weekly" || value === "weekdays" || value === "once") {
    return value;
  }
  return "once";
}

function fireForCreate(input: {
  fireAt?: string | null;
  localDate?: string | null;
  localTime?: string | null;
  timezone: string;
  recurrence: Recurrence;
  weekday?: number | null;
  now?: Date;
}): { fire: Date; localDate: string; localTime: string; weekday: number | null } {
  const now = input.now ?? new Date();
  const zone = resolveTimeZone(input.timezone);
  let fire = resolveFireAt({
    fireAt: input.fireAt,
    localDate: input.localDate,
    localTime: input.localTime,
    timezone: zone,
    now,
  });
  if (!fire && input.localTime && !input.localDate) {
    const today = formatInZone(now, zone);
    fire = resolveFireAt({
      localDate: today.date,
      localTime: input.localTime,
      timezone: zone,
      now,
    });
    if (fire && fire.getTime() <= now.getTime() && input.recurrence !== "once") {
      fire = nextOccurrence({
        from: now,
        timeZone: zone,
        localTime: input.localTime,
        recurrence: input.recurrence,
        weekday: input.weekday,
      });
    } else if (fire && fire.getTime() <= now.getTime()) {
      const tomorrow = formatInZone(new Date(now.getTime() + 86400000), zone);
      fire = resolveFireAt({
        localDate: tomorrow.date,
        localTime: input.localTime,
        timezone: zone,
        now,
      });
    }
  }
  if (!fire) throw new Error("Pick a time for the reminder.");
  if (input.recurrence !== "once" && fire.getTime() <= now.getTime()) {
    const bumped = nextOccurrence({
      from: now,
      timeZone: zone,
      localTime: input.localTime ?? formatInZone(fire, zone).time,
      recurrence: input.recurrence,
      weekday: input.weekday,
    });
    if (bumped) fire = bumped;
  }
  const wall = formatInZone(fire, zone);
  return {
    fire,
    localDate: input.localDate || wall.date,
    localTime: input.localTime || wall.time,
    weekday: input.weekday ?? (input.recurrence === "weekly" ? wall.weekday : null),
  };
}

async function insertReminder(
  userId: string,
  input: {
    title: string;
    body: string;
    timezone: string;
    fire: Date;
    localDate: string | null;
    localTime: string | null;
    recurrence: Recurrence;
    weekday: number | null;
    locale: string;
    relatedTaskId: number | null;
    relatedGoalId: number | null;
  },
): Promise<Reminder> {
  const sql = await getSql();
  const rows = await sql<ReminderRow>`
    insert into reminders (
      user_id, title, body, timezone, fire_at, local_date, local_time,
      recurrence, weekday, status, locale, related_task_id, related_goal_id
    )
    values (
      ${userId},
      ${input.title},
      ${input.body},
      ${input.timezone},
      ${input.fire.toISOString()},
      ${input.localDate},
      ${input.localTime},
      ${input.recurrence},
      ${input.weekday},
      ${"scheduled"},
      ${input.locale},
      ${input.relatedTaskId},
      ${input.relatedGoalId}
    )
    returning id, title, body, timezone, fire_at, local_date, local_time, recurrence, weekday,
              status, snooze_until, last_fired_at, locale, retry_count, related_task_id, related_goal_id,
              created_at, updated_at
  `;
  const mapped = rows[0] ? mapReminder(rows[0]) : null;
  if (!mapped) throw new Error("Reminder could not be saved.");
  return mapped;
}

export async function listOwnRemindersForContext(userId: string): Promise<Reminder[]> {
  const sql = await getSql();
  const rows = await sql<ReminderRow>`
    select id, title, body, timezone, fire_at, local_date, local_time, recurrence, weekday,
           status, snooze_until, last_fired_at, locale, retry_count, related_task_id, related_goal_id,
           created_at, updated_at
    from reminders
    where user_id = ${userId}
      and status in (${"scheduled"}, ${"snoozed"}, ${"pending_delivery"})
    order by fire_at asc
    limit ${MAX_LIST}
  `;
  const out: Reminder[] = [];
  for (const row of rows) {
    const mapped = mapReminder(row);
    if (mapped) out.push(mapped);
  }
  return out;
}

export const reminderListHandler: ToolHandler = async ({ userId }) => {
  const rows = await listOwnRemindersForContext(userId);
  const n = rows.length;
  return n === 1 ? "1 reminder." : `${n} reminders.`;
};

export const reminderCreateHandler: ToolHandler = async ({ userId, payload, title: proposalTitle }) => {
  const parsed = reminderCreatePayload.parse(payload);
  const title = requiredTitle(parsed.title, proposalTitle);
  const body = clipBody(parsed.body);
  const profile = await loadProfileBits(userId);
  const timezone = resolveTimeZone(parsed.timezone || profile.timezone);
  const locale = resolveLocale(parsed.locale || profile.locale);
  const recurrence = asRecurrence(parsed.recurrence);
  const relatedTaskId = parsed.relatedTaskId ?? null;
  const relatedGoalId = parsed.relatedGoalId ?? null;
  await assertOwnedLink(userId, relatedTaskId, relatedGoalId);
  const scheduled = fireForCreate({
    fireAt: parsed.fireAt,
    localDate: parsed.localDate,
    localTime: parsed.localTime,
    timezone,
    recurrence,
    weekday: parsed.weekday ?? null,
  });
  const mapped = await insertReminder(userId, {
    title,
    body,
    timezone,
    fire: scheduled.fire,
    localDate: scheduled.localDate,
    localTime: scheduled.localTime,
    recurrence,
    weekday: scheduled.weekday,
    locale,
    relatedTaskId,
    relatedGoalId,
  });
  await writeAudit(userId, "assistant", "reminder.created", "reminder", String(mapped.id), mapped.title);
  return `Created reminder ${mapped.id}.`;
};

export const reminderUpdateHandler: ToolHandler = async ({ userId, payload }) => {
  const parsed = reminderUpdatePayload.parse(payload);
  const current = await loadOwn(userId, parsed.id);
  if (!current) throw new Error("Reminder not found.");
  const title = parsed.title?.trim() ? parsed.title.trim().slice(0, 80) : current.title;
  const body = parsed.body !== undefined ? clipBody(parsed.body) : current.body;
  const timezone = resolveTimeZone(parsed.timezone || current.timezone);
  const locale = resolveLocale(parsed.locale || current.locale);
  const recurrence = asRecurrence(parsed.recurrence ?? current.recurrence);
  const relatedTaskId =
    "relatedTaskId" in payload ? (parsed.relatedTaskId ?? null) : current.relatedTaskId;
  const relatedGoalId =
    "relatedGoalId" in payload ? (parsed.relatedGoalId ?? null) : current.relatedGoalId;
  await assertOwnedLink(userId, relatedTaskId, relatedGoalId);
  const hasTime =
    Boolean(parsed.fireAt) || Boolean(parsed.localDate) || Boolean(parsed.localTime);
  const scheduled = hasTime
    ? fireForCreate({
        fireAt: parsed.fireAt ?? current.fireAt,
        localDate: parsed.localDate ?? current.localDate,
        localTime: parsed.localTime ?? current.localTime,
        timezone,
        recurrence,
        weekday: parsed.weekday ?? current.weekday,
      })
    : {
        fire: new Date(current.fireAt),
        localDate: current.localDate ?? "",
        localTime: current.localTime ?? "",
        weekday: parsed.weekday ?? current.weekday,
      };
  const sql = await getSql();
  const rows = await sql<ReminderRow>`
    update reminders
    set
      title = ${title},
      body = ${body},
      timezone = ${timezone},
      fire_at = ${scheduled.fire.toISOString()},
      local_date = ${scheduled.localDate || current.localDate},
      local_time = ${scheduled.localTime || current.localTime},
      recurrence = ${recurrence},
      weekday = ${scheduled.weekday},
      locale = ${locale},
      related_task_id = ${relatedTaskId},
      related_goal_id = ${relatedGoalId},
      status = ${current.status === "cancelled" || current.status === "completed" ? current.status : "scheduled"},
      snooze_until = null,
      updated_at = now()
    where id = ${current.id} and user_id = ${userId}
    returning id, title, body, timezone, fire_at, local_date, local_time, recurrence, weekday,
              status, snooze_until, last_fired_at, locale, retry_count, related_task_id, related_goal_id,
              created_at, updated_at
  `;
  const mapped = rows[0] ? mapReminder(rows[0]) : null;
  if (!mapped) throw new Error("Reminder not found.");
  await writeAudit(userId, "assistant", "reminder.scheduled", "reminder", String(mapped.id), mapped.title);
  return `Updated reminder ${mapped.id}.`;
};

export const reminderSnoozeHandler: ToolHandler = async ({ userId, payload }) => {
  const parsed = reminderSnoozePayload.parse(payload);
  const mapped = await applySnooze(userId, parsed.id, parsed.minutes ?? 10, parsed.fireAt, "assistant");
  return `Snoozed reminder ${mapped.id}.`;
};

export const reminderCompleteHandler: ToolHandler = async ({ userId, payload }) => {
  const parsed = reminderCompletePayload.parse(payload);
  await applyComplete(userId, parsed.id, "assistant");
  return `Completed reminder ${parsed.id}.`;
};

export const reminderCancelHandler: ToolHandler = async ({ userId, payload }) => {
  const parsed = reminderCancelPayload.parse(payload);
  await applyCancel(userId, parsed.id, "assistant");
  return `Cancelled reminder ${parsed.id}.`;
};

async function applySnooze(
  userId: string,
  id: number,
  minutes: number,
  fireAt: string | null | undefined,
  actor: "user" | "system" | "assistant",
): Promise<Reminder> {
  const current = await loadOwn(userId, id);
  if (!current) throw new Error("Reminder not found.");
  const now = new Date();
  const next = fireAt
    ? resolveFireAt({ fireAt, timezone: current.timezone, now })
    : snoozeInstant(now, minutes);
  if (!next) throw new Error("Pick a time for the reminder.");
  const wall = formatInZone(next, current.timezone);
  const sql = await getSql();
  const rows = await sql<ReminderRow>`
    update reminders
    set
      fire_at = ${next.toISOString()},
      local_date = ${wall.date},
      local_time = ${wall.time},
      status = ${"snoozed"},
      snooze_until = ${next.toISOString()},
      updated_at = now()
    where id = ${id} and user_id = ${userId}
      and status in (${"scheduled"}, ${"snoozed"}, ${"pending_delivery"})
    returning id, title, body, timezone, fire_at, local_date, local_time, recurrence, weekday,
              status, snooze_until, last_fired_at, locale, retry_count, related_task_id, related_goal_id,
              created_at, updated_at
  `;
  const mapped = rows[0] ? mapReminder(rows[0]) : null;
  if (!mapped) throw new Error("Reminder not found.");
  await writeAudit(userId, actor === "assistant" ? "assistant" : actor, "reminder.scheduled", "reminder", String(mapped.id), mapped.title);
  return mapped;
}

async function applyComplete(userId: string, id: number, actor: "user" | "assistant"): Promise<void> {
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    update reminders
    set status = ${"completed"}, completed_at = now(), updated_at = now()
    where id = ${id} and user_id = ${userId}
      and status not in (${"cancelled"}, ${"completed"})
    returning id
  `;
  if (!rows[0]) throw new Error("Reminder not found.");
  await writeAudit(userId, actor, "reminder.scheduled", "reminder", String(id), "completed");
}

async function applyCancel(userId: string, id: number, actor: "user" | "assistant"): Promise<void> {
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    update reminders
    set status = ${"cancelled"}, cancelled_at = now(), updated_at = now()
    where id = ${id} and user_id = ${userId}
      and status not in (${"cancelled"}, ${"completed"})
    returning id
  `;
  if (!rows[0]) throw new Error("Reminder not found.");
  await writeAudit(userId, actor, "reminder.cancelled", "reminder", String(id), "");
}

async function loadDevice(
  userId: string,
  deviceKey: string,
): Promise<{ id: number } | null> {
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    select id from notification_devices
    where user_id = ${userId} and device_key = ${deviceKey}
  `;
  const n = typeof rows[0]?.id === "number" ? rows[0].id : Number(rows[0]?.id);
  if (!Number.isInteger(n) || n < 1) return null;
  return { id: n };
}

export const listReminders = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Reminder[]> => {
    const sql = await getSql();
    const rows = await sql<ReminderRow>`
      select id, title, body, timezone, fire_at, local_date, local_time, recurrence, weekday,
             status, snooze_until, last_fired_at, locale, retry_count, related_task_id, related_goal_id,
             created_at, updated_at
      from reminders
      where user_id = ${context.userId}
      order by fire_at asc
      limit ${MAX_LIST}
    `;
    const out: Reminder[] = [];
    for (const row of rows) {
      const mapped = mapReminder(row);
      if (mapped) out.push(mapped);
    }
    return out;
  });

const userCreateInput = z.object({
  title: z.string().trim().min(1, "Add a title.").max(80),
  body: z.string().max(REMINDER_BODY_MAX).optional(),
  localDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use a calendar date."),
  localTime: z.string().regex(/^\d{2}:\d{2}$/, "Use a time."),
  recurrence: z.enum(["once", "daily", "weekly", "weekdays"]).optional(),
});

export const createReminder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => userCreateInput.parse(input))
  .handler(async ({ context, data }): Promise<Reminder> => {
    const profile = await loadProfileBits(context.userId);
    const recurrence = asRecurrence(data.recurrence);
    const scheduled = fireForCreate({
      localDate: data.localDate,
      localTime: data.localTime,
      timezone: profile.timezone,
      recurrence,
    });
    const mapped = await insertReminder(context.userId, {
      title: data.title,
      body: clipBody(data.body),
      timezone: profile.timezone,
      fire: scheduled.fire,
      localDate: scheduled.localDate,
      localTime: scheduled.localTime,
      recurrence,
      weekday: scheduled.weekday,
      locale: profile.locale,
      relatedTaskId: null,
      relatedGoalId: null,
    });
    await writeAudit(context.userId, "user", "reminder.created", "reminder", String(mapped.id), mapped.title);
    return mapped;
  });

export const snoozeReminder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => snoozeInput.parse(input))
  .handler(async ({ context, data }): Promise<Reminder> => {
    return applySnooze(context.userId, data.id, data.minutes ?? 10, data.fireAt, "user");
  });

export const completeReminder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<{ ok: true }> => {
    await applyComplete(context.userId, data.id, "user");
    return { ok: true };
  });

export const cancelReminder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<{ ok: true }> => {
    await applyCancel(context.userId, data.id, "user");
    return { ok: true };
  });

export const registerNotificationDevice = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => deviceInput.parse(input))
  .handler(async ({ context, data }): Promise<NotificationDevice> => {
    const sql = await getSql();
    const permission: DevicePermission = data.permission ?? "default";
    const label = (data.label ?? "").slice(0, 80);
    const revoked = permission === "revoked";
    const rows = await sql<{
      id: unknown;
      device_key: string;
      label: string;
      permission: string;
      last_seen_at: unknown;
      revoked_at: unknown;
    }>`
      insert into notification_devices (user_id, device_key, label, permission, last_seen_at, revoked_at)
      values (
        ${context.userId},
        ${data.deviceKey},
        ${label},
        ${permission},
        now(),
        ${revoked ? new Date().toISOString() : null}
      )
      on conflict (user_id, device_key) do update set
        label = excluded.label,
        permission = excluded.permission,
        last_seen_at = now(),
        revoked_at = case
          when excluded.permission = ${"revoked"} then now()
          else null
        end
      returning id, device_key, label, permission, last_seen_at, revoked_at
    `;
    const row = rows[0];
    if (!row) throw new Error("Device could not be saved.");
    const id = typeof row.id === "number" ? row.id : Number(row.id);
    return {
      id,
      deviceKey: row.device_key,
      label: row.label,
      permission: (DEVICE_PERMISSIONS as readonly string[]).includes(row.permission)
        ? (row.permission as DevicePermission)
        : "default",
      lastSeenAt: row.last_seen_at instanceof Date ? row.last_seen_at.toISOString() : String(row.last_seen_at),
      revokedAt: row.revoked_at
        ? row.revoked_at instanceof Date
          ? row.revoked_at.toISOString()
          : String(row.revoked_at)
        : null,
    };
  });

export const claimDueReminders = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => claimInput.parse(input))
  .handler(async ({ context, data }): Promise<ClaimedReminder[]> => {
    const sql = await getSql();
    const now = new Date();
    const device = await loadDevice(context.userId, data.deviceKey);
    const candidates = await sql<ReminderRow>`
      select id, title, body, timezone, fire_at, local_date, local_time, recurrence, weekday,
             status, snooze_until, last_fired_at, locale, retry_count, related_task_id, related_goal_id,
             created_at, updated_at
      from reminders
      where user_id = ${context.userId}
        and status in (${"scheduled"}, ${"snoozed"})
        and fire_at <= ${now.toISOString()}
      order by fire_at asc
      limit 20
    `;
    const claimed: ClaimedReminder[] = [];
    for (const row of candidates) {
      const current = mapReminder(row);
      if (!current || !canClaimStatus(current.status)) continue;
      if (current.lastFiredAt && isDuplicateFire(current.lastFiredAt, now)) continue;
      const locked = await sql<ReminderRow>`
        update reminders
        set status = ${"pending_delivery"}, last_fired_at = ${now.toISOString()}, updated_at = now()
        where id = ${current.id}
          and user_id = ${context.userId}
          and status in (${"scheduled"}, ${"snoozed"})
        returning id, title, body, timezone, fire_at, local_date, local_time, recurrence, weekday,
                  status, snooze_until, last_fired_at, locale, retry_count, related_task_id, related_goal_id,
                  created_at, updated_at
      `;
      const reminder = locked[0] ? mapReminder(locked[0]) : null;
      if (!reminder) continue;
      const attempts = await sql<{ id: unknown }>`
        insert into notification_attempts (user_id, reminder_id, device_id, status, error)
        values (
          ${context.userId},
          ${reminder.id},
          ${device?.id ?? null},
          ${"pending"},
          ${""}
        )
        returning id
      `;
      const attemptId = typeof attempts[0]?.id === "number" ? attempts[0].id : Number(attempts[0]?.id);
      if (!Number.isInteger(attemptId) || attemptId < 1) continue;
      await writeAudit(
        context.userId,
        "system",
        "notification.scheduled",
        "reminder",
        String(reminder.id),
        reminder.title,
      );
      claimed.push({ reminder, attemptId });
    }
    return claimed;
  });

export const ackNotificationAttempt = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => ackInput.parse(input))
  .handler(async ({ context, data }): Promise<{ ok: true }> => {
    const sql = await getSql();
    const status: AttemptStatus = data.status;
    const error = (data.error ?? "").slice(0, 240);
    const attemptRows = await sql<{ id: unknown; reminder_id: unknown }>`
      update notification_attempts
      set status = ${status}, error = ${error}
      where id = ${data.attemptId}
        and user_id = ${context.userId}
        and reminder_id = ${data.reminderId}
      returning id, reminder_id
    `;
    if (!attemptRows[0]) throw new Error("Attempt not found.");
    const reminder = await loadOwn(context.userId, data.reminderId);
    if (!reminder) throw new Error("Reminder not found.");
    const now = new Date();
    if (status === "failed") {
      const next = retryOrFail(reminder, now);
      await sql`
        update reminders
        set
          status = ${next.status},
          fire_at = ${next.fireAt.toISOString()},
          retry_count = ${next.retryCount},
          updated_at = now()
        where id = ${reminder.id} and user_id = ${context.userId}
      `;
      await writeAudit(
        context.userId,
        "system",
        next.status === "failed" ? "notification.failed" : "notification.scheduled",
        "reminder",
        String(reminder.id),
        reminder.title,
      );
      return { ok: true };
    }
    if (status === "expired") {
      await sql`
        update reminders
        set status = ${"expired"}, updated_at = now()
        where id = ${reminder.id} and user_id = ${context.userId}
      `;
      await writeAudit(context.userId, "system", "notification.failed", "reminder", String(reminder.id), "expired");
      return { ok: true };
    }
    const next = advanceAfterDelivery(reminder, now);
    await sql`
      update reminders
      set
        status = ${next.status},
        fire_at = ${next.fireAt.toISOString()},
        retry_count = 0,
        updated_at = now()
      where id = ${reminder.id} and user_id = ${context.userId}
        and status = ${"pending_delivery"}
    `;
    await writeAudit(
      context.userId,
      "system",
      status === "delivered" ? "notification.sent" : "notification.scheduled",
      "reminder",
      String(reminder.id),
      reminder.title,
    );
    return { ok: true };
  });
