import {
  addMinutesUtc,
  isRecurrence,
  isValidTimeZone,
  nextOccurrence,
  parseIsoInstant,
  resolveTimeZone,
  zonedDateTimeToUtc,
  type Recurrence,
} from "./time-format.ts";
import { resolveLocale } from "./locale.ts";

export const REMINDER_TITLE_MAX = 80;
export const REMINDER_BODY_MAX = 500;
export const REMINDER_STATUSES = [
  "scheduled",
  "snoozed",
  "pending_delivery",
  "delivered",
  "failed",
  "cancelled",
  "completed",
  "expired",
] as const;
export type ReminderStatus = (typeof REMINDER_STATUSES)[number];

export const ATTEMPT_STATUSES = ["pending", "delivered", "failed", "skipped", "expired"] as const;
export type AttemptStatus = (typeof ATTEMPT_STATUSES)[number];

export const DEVICE_PERMISSIONS = ["default", "granted", "denied", "revoked"] as const;
export type DevicePermission = (typeof DEVICE_PERMISSIONS)[number];

export type Reminder = {
  id: number;
  title: string;
  body: string;
  timezone: string;
  fireAt: string;
  localDate: string | null;
  localTime: string | null;
  recurrence: Recurrence;
  weekday: number | null;
  status: ReminderStatus;
  snoozeUntil: string | null;
  lastFiredAt: string | null;
  locale: string;
  retryCount: number;
  relatedTaskId: number | null;
  relatedGoalId: number | null;
  createdAt: string;
  updatedAt: string;
};

export type ReminderRow = {
  id: unknown;
  title: string;
  body: string;
  timezone: string;
  fire_at: unknown;
  local_date: string | null;
  local_time: string | null;
  recurrence: string;
  weekday: number | null;
  status: string;
  snooze_until: unknown;
  last_fired_at: unknown;
  locale: string | null;
  retry_count: number | null;
  related_task_id: unknown;
  related_goal_id: unknown;
  created_at: unknown;
  updated_at: unknown;
};

export type NotificationDevice = {
  id: number;
  deviceKey: string;
  label: string;
  permission: DevicePermission;
  lastSeenAt: string;
  revokedAt: string | null;
};

export type NotificationAttempt = {
  id: number;
  reminderId: number;
  deviceId: number | null;
  status: AttemptStatus;
  error: string;
  attemptedAt: string;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

function asStatus(value: string): ReminderStatus {
  return (REMINDER_STATUSES as readonly string[]).includes(value)
    ? (value as ReminderStatus)
    : "scheduled";
}

function asRecurrence(value: string): Recurrence {
  return isRecurrence(value) ? value : "once";
}

export function mapReminder(row: ReminderRow): Reminder | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  const fireAt = toIso(row.fire_at);
  if (!fireAt) return null;
  return {
    id,
    title: row.title,
    body: row.body ?? "",
    timezone: resolveTimeZone(row.timezone),
    fireAt,
    localDate: row.local_date,
    localTime: row.local_time,
    recurrence: asRecurrence(row.recurrence),
    weekday: row.weekday ?? null,
    status: asStatus(row.status),
    snoozeUntil: row.snooze_until ? toIso(row.snooze_until) : null,
    lastFiredAt: row.last_fired_at ? toIso(row.last_fired_at) : null,
    locale: resolveLocale(row.locale),
    retryCount: row.retry_count ?? 0,
    relatedTaskId: asPositiveInt(row.related_task_id) || null,
    relatedGoalId: asPositiveInt(row.related_goal_id) || null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export type ReminderCreateInput = {
  title: string;
  body: string;
  timezone: string;
  fireAt?: string | null;
  localDate?: string | null;
  localTime?: string | null;
  recurrence: Recurrence;
  weekday?: number | null;
  locale: string;
  relatedTaskId?: number | null;
  relatedGoalId?: number | null;
};

export function resolveFireAt(input: {
  fireAt?: string | null;
  localDate?: string | null;
  localTime?: string | null;
  timezone: string;
  now?: Date;
}): Date | null {
  const zone = resolveTimeZone(input.timezone);
  if (input.fireAt) {
    const instant = parseIsoInstant(input.fireAt);
    if (instant) return instant;
  }
  if (input.localDate && input.localTime) {
    return zonedDateTimeToUtc(input.localDate, input.localTime, zone);
  }
  return null;
}

export function computeNextFire(reminder: Pick<Reminder, "recurrence" | "localTime" | "timezone" | "weekday" | "fireAt">, from: Date): Date | null {
  if (reminder.recurrence === "once") return null;
  const localTime = reminder.localTime ?? "09:00";
  return nextOccurrence({
    from,
    timeZone: reminder.timezone,
    localTime,
    recurrence: reminder.recurrence,
    weekday: reminder.weekday,
  });
}

export function snoozeInstant(from: Date, minutes: number): Date {
  const n = Math.min(24 * 60, Math.max(1, Math.round(minutes)));
  return addMinutesUtc(from, n);
}

export function isDuplicateFire(existingFireAt: string, nextFireAt: Date, windowMs = 60_000): boolean {
  const a = Date.parse(existingFireAt);
  if (Number.isNaN(a)) return false;
  return Math.abs(a - nextFireAt.getTime()) < windowMs;
}

export function canClaimStatus(status: ReminderStatus): boolean {
  return status === "scheduled" || status === "snoozed";
}

export function advanceAfterDelivery(reminder: Reminder, deliveredAt: Date): {
  status: ReminderStatus;
  fireAt: Date;
} {
  if (reminder.recurrence === "once") {
    return { status: "delivered", fireAt: deliveredAt };
  }
  const next = computeNextFire(reminder, deliveredAt);
  if (!next) return { status: "expired", fireAt: deliveredAt };
  return { status: "scheduled", fireAt: next };
}

export function retryOrFail(reminder: Reminder, now: Date): {
  status: ReminderStatus;
  fireAt: Date;
  retryCount: number;
} {
  const retryCount = reminder.retryCount + 1;
  if (retryCount >= 3) {
    return { status: "failed", fireAt: now, retryCount };
  }
  return { status: "scheduled", fireAt: addMinutesUtc(now, 1), retryCount };
}

export { isValidTimeZone, resolveTimeZone };
