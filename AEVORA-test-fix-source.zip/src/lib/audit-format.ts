import type { PermissionLevel } from "./orchestrator/types.ts";

export const AUDIT_ACTORS = ["user", "assistant", "system"] as const;
export type AuditActor = (typeof AUDIT_ACTORS)[number];

export const ACTIVITY_LEVEL_FILTERS = [
  "all",
  "safe",
  "review",
  "approval",
  "restricted",
] as const;
export type ActivityLevelFilter = (typeof ACTIVITY_LEVEL_FILTERS)[number];

export const ACTIVITY_PAGE_SIZE = 50;
export const ACTIVITY_PENDING_LIMIT = 8;
export const AUDIT_DETAIL_MAX = 240;
export const AUDIT_ACTION_MAX = 80;

/**
 * Locked event names for the activity stream. Writers use these strings.
 * Unknown future names still render — the viewer does not fail closed on a
 * new tool. Reserved names are listed so reminders, notifications, and later
 * integrations can plug in without a schema change.
 *
 * `proposal.execution_started` is reserved. Step 12 writes approved, then
 * executed or failed; that pair is the execution record.
 */
export const AUDIT_ACTIONS = [
  "proposal.created",
  "proposal.rejected",
  "proposal.approved",
  "proposal.denied",
  "proposal.execution_started",
  "proposal.executed",
  "proposal.failed",
  "memory.created",
  "memory.updated",
  "memory.deleted",
  "goal.created",
  "goal.updated",
  "goal.deleted",
  "task.created",
  "task.updated",
  "task.deleted",
  "permission.settings.updated",
  "reminder.created",
  "reminder.scheduled",
  "reminder.cancelled",
  "notification.scheduled",
  "notification.sent",
  "notification.failed",
] as const;

export type AuditAction = (typeof AUDIT_ACTIONS)[number];

const ACTION_TITLE: Record<string, string> = {
  "proposal.created": "Proposed an action",
  "proposal.rejected": "Rejected a restricted action",
  "proposal.approved": "Approved an action",
  "proposal.denied": "Denied an action",
  "proposal.execution_started": "Started executing an action",
  "proposal.executed": "Executed an action",
  "proposal.failed": "Action failed",
  "memory.created": "Added a memory",
  "memory.updated": "Updated a memory",
  "memory.deleted": "Deleted a memory",
  "goal.created": "Added a goal",
  "goal.updated": "Updated a goal",
  "goal.deleted": "Deleted a goal",
  "task.created": "Added a task",
  "task.updated": "Updated a task",
  "task.deleted": "Deleted a task",
  "permission.settings.updated": "Updated confirmation settings",
  "reminder.created": "Added a reminder",
  "reminder.scheduled": "Scheduled a reminder",
  "reminder.cancelled": "Cancelled a reminder",
  "notification.scheduled": "Scheduled a notification",
  "notification.sent": "Sent a notification",
  "notification.failed": "Notification failed",
};

const ACTOR_COPY: Record<AuditActor, string> = {
  user: "You",
  assistant: "AEVORA",
  system: "System",
};

const SENSITIVE_DETAIL =
  /payload_json|payload-secret|"payload"|password|bearer |api[_-]?key/i;
const JSONISH = /^\s*[{[]/;

export type AuditRow = {
  id: unknown;
  actor: string;
  action: string;
  entity_type: string;
  entity_id: string;
  permission_level: string | null;
  detail: string;
  created_at: unknown;
};

export type ActivityEvent = {
  id: number;
  actor: AuditActor;
  actorLabel: string;
  action: string;
  title: string;
  detail: string;
  entityType: string;
  entityId: string;
  permissionLevel: PermissionLevel | null;
  toolId: string | null;
  createdAt: string;
};

export type ActivityPending = {
  id: number;
  conversationId: number | null;
  toolId: string;
  displayName: string;
  permissionLevel: PermissionLevel;
  title: string;
  summary: string;
  createdAt: string;
};

export type ActivityCursor = {
  createdAt: string;
  id: number;
};

export type ActivityPage = {
  items: ActivityEvent[];
  nextCursor: ActivityCursor | null;
  pending: ActivityPending[];
  pendingTotal: number;
};

export function isActivityLevelFilter(value: string): value is ActivityLevelFilter {
  return (ACTIVITY_LEVEL_FILTERS as readonly string[]).includes(value);
}

export function asActivityLevelFilter(value: string | null | undefined): ActivityLevelFilter {
  if (value && isActivityLevelFilter(value)) return value;
  return "all";
}

export function asActor(value: string | null | undefined): AuditActor {
  if (value === "assistant" || value === "system" || value === "user") return value;
  return "system";
}

export function asPermissionLevel(value: string | null | undefined): PermissionLevel | null {
  if (value === "safe" || value === "review" || value === "approval" || value === "restricted") {
    return value;
  }
  return null;
}

export function clipAuditText(value: string, max: number): string {
  const t = value.replace(/\s+/g, " ").trim();
  if (t.length <= max) return t;
  return `${t.slice(0, Math.max(0, max - 1)).trimEnd()}…`;
}

export function sanitizeDetail(raw: string | null | undefined): string {
  const t = (raw ?? "").trim();
  if (!t) return "";
  if (SENSITIVE_DETAIL.test(t) || JSONISH.test(t)) return "";
  return clipAuditText(t, AUDIT_DETAIL_MAX);
}

export function eventTitle(action: string): string {
  const known = ACTION_TITLE[action];
  if (known) return known;
  const cleaned = action.replace(/[._]+/g, " ").trim();
  if (!cleaned) return "Activity";
  return cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
}

export function actorLabel(actor: AuditActor): string {
  return ACTOR_COPY[actor];
}

const TOOL_ID_RE = /^([a-z][a-z0-9]*(?:\.[a-z][a-z0-9_]*)+):\s+/i;

export function toolIdFromRow(entityType: string, entityId: string, detail: string): string | null {
  if (entityType === "tool" && entityId.includes(".")) return entityId;
  const match = TOOL_ID_RE.exec(detail);
  if (!match) return null;
  return match[1]?.toLowerCase() ?? null;
}

export function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

/**
 * Map a stored row to a client view. Drops user_id. Never includes a payload.
 */
export function mapActivityEvent(row: AuditRow): ActivityEvent | null {
  const id = asId(row.id);
  if (!id) return null;
  const actor = asActor(row.actor);
  const action = clipAuditText(row.action || "", AUDIT_ACTION_MAX);
  if (!action) return null;
  const detail = sanitizeDetail(row.detail);
  const entityType = clipAuditText(row.entity_type || "", AUDIT_ACTION_MAX);
  const entityIdRaw = clipAuditText(row.entity_id || "", AUDIT_ACTION_MAX);
  const entityId = entityType === "permission_settings" ? "" : entityIdRaw;
  return {
    id,
    actor,
    actorLabel: actorLabel(actor),
    action,
    title: eventTitle(action),
    detail,
    entityType,
    entityId,
    permissionLevel: asPermissionLevel(row.permission_level),
    toolId: toolIdFromRow(entityType, entityId, row.detail ?? ""),
    createdAt: toIso(row.created_at),
  };
}

export function encodeCursor(cursor: ActivityCursor): string {
  return `${cursor.createdAt}|${cursor.id}`;
}

export function decodeCursor(raw: string | null | undefined): ActivityCursor | null {
  if (!raw) return null;
  const sep = raw.lastIndexOf("|");
  if (sep <= 0) return null;
  const createdAt = raw.slice(0, sep).trim();
  const id = asId(raw.slice(sep + 1));
  if (!createdAt || !id || Number.isNaN(Date.parse(createdAt))) return null;
  return { createdAt, id };
}

export function pageFromRows(
  rows: ActivityEvent[],
  limit: number,
): { items: ActivityEvent[]; nextCursor: ActivityCursor | null } {
  const hasMore = rows.length > limit;
  const items = hasMore ? rows.slice(0, limit) : rows;
  const last = items[items.length - 1];
  return {
    items,
    nextCursor: hasMore && last ? { createdAt: last.createdAt, id: last.id } : null,
  };
}

export function matchesLevelFilter(
  permissionLevel: PermissionLevel | null,
  filter: ActivityLevelFilter,
): boolean {
  if (filter === "all") return true;
  return permissionLevel === filter;
}
