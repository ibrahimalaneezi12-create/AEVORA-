import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  CURATED_VOICES,
  DEFAULT_TTS_VOICE,
  resolveTtsVoiceId,
  ttsLanguageFor,
} from "./tts-format.ts";

describe("curated voices", () => {
  it("defaults to a calm voice and ignores unknown ids", () => {
    assert.equal(DEFAULT_TTS_VOICE, "liora");
    assert.equal(resolveTtsVoiceId(""), "liora");
    assert.equal(resolveTtsVoiceId("not-a-voice"), "liora");
    assert.equal(resolveTtsVoiceId("Ara"), "ara");
    assert.ok(CURATED_VOICES.length <= 8);
    assert.ok(CURATED_VOICES.some((v) => v.id === "lux"));
  });

  it("maps Arabic and English onto TTS language tags", () => {
    assert.equal(ttsLanguageFor("en"), "en");
    assert.equal(ttsLanguageFor("ar"), "ar-SA");
    assert.equal(ttsLanguageFor("es"), "es-ES");
  });
});
