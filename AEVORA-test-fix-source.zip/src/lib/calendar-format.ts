export const CALENDAR_TITLE_MAX = 120;
export const CALENDAR_NOTES_MAX = 2000;
export const CALENDAR_STATUSES = ["confirmed", "cancelled"] as const;
export type CalendarStatus = (typeof CALENDAR_STATUSES)[number];
export const CALENDAR_RECURRENCES = ["once", "daily", "weekly", "weekdays"] as const;
export type CalendarRecurrence = (typeof CALENDAR_RECURRENCES)[number];

export type CalendarEvent = {
  id: number;
  title: string;
  notes: string;
  location: string;
  startAt: string;
  endAt: string | null;
  timezone: string;
  status: CalendarStatus;
  source: string;
  recurrence: CalendarRecurrence;
  createdAt: string;
  updatedAt: string;
};

export type CalendarEventRow = {
  id: unknown;
  title: string;
  notes: string;
  location: string;
  start_at: unknown;
  end_at: unknown;
  timezone: string;
  status: string;
  source: string;
  recurrence?: string | null;
  created_at: unknown;
  updated_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

export function asCalendarRecurrence(value: string | null | undefined): CalendarRecurrence {
  if (value === "daily" || value === "weekly" || value === "weekdays") return value;
  return "once";
}

export function mapCalendarEvent(row: CalendarEventRow): CalendarEvent | null {
  const id = asId(row.id);
  if (!id) return null;
  const status: CalendarStatus = row.status === "cancelled" ? "cancelled" : "confirmed";
  return {
    id,
    title: row.title,
    notes: row.notes ?? "",
    location: row.location ?? "",
    startAt: toIso(row.start_at),
    endAt: row.end_at == null ? null : toIso(row.end_at),
    timezone: row.timezone || "UTC",
    status,
    source: row.source || "aegis",
    recurrence: asCalendarRecurrence(row.recurrence),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function formatCalendarContextLine(row: CalendarEvent): string {
  const when = row.startAt;
  const where = row.location ? ` @ ${row.location}` : "";
  const again = row.recurrence !== "once" ? ` (${row.recurrence})` : "";
  return `- (#${row.id}) ${row.title} — ${when}${where}${again}`;
}

export function eventOverlapsWindow(
  event: { startAt: string; endAt: string | null },
  fromIso: string,
  toIso: string,
): boolean {
  const start = Date.parse(event.startAt);
  const end = event.endAt ? Date.parse(event.endAt) : start + 60 * 60 * 1000;
  const from = Date.parse(fromIso);
  const to = Date.parse(toIso);
  if (![start, end, from, to].every(Number.isFinite)) return false;
  return start < to && end > from;
}

export function isSlotFree(
  events: Array<{ startAt: string; endAt: string | null; status?: string }>,
  fromIso: string,
  toIso: string,
): boolean {
  return !events.some((event) => {
    if (event.status === "cancelled") return false;
    return eventOverlapsWindow(event, fromIso, toIso);
  });
}
