import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { calendarDateInZone, classifyDue } from "@/lib/dashboard-format";
import { emptyPulse, inQuietHours, type PulseSnapshot, type PulseSuggestion } from "@/lib/pulse-format";

export type { PulseSnapshot, PulseSuggestion } from "@/lib/pulse-format";

type TaskRow = {
  id: unknown;
  title: string;
  due_date: string | null;
  status: string;
};

type GoalRow = {
  id: unknown;
  title: string;
  status: string;
  updated_at: unknown;
};

type ReminderRow = {
  id: unknown;
  title: string;
  fire_at: unknown;
  status: string;
};

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

export async function buildPulse(userId: string, now = new Date()): Promise<PulseSnapshot> {
  const sql = await getSql();
  const profile = await sql<{
    pulse_enabled: boolean | null;
    timezone: string | null;
    quiet_hours_start: number | null;
    quiet_hours_end: number | null;
    notify_pulse: boolean | null;
  }>`
    select pulse_enabled, timezone, quiet_hours_start, quiet_hours_end, notify_pulse from profiles where user_id = ${userId}
  `;
  const enabled = profile[0]?.pulse_enabled !== false;
  const timezone = profile[0]?.timezone?.trim() || "UTC";
  const hour = Number(
    new Intl.DateTimeFormat("en-GB", { hour: "numeric", hour12: false, timeZone: timezone }).format(now),
  );
  const quiet = inQuietHours(hour, profile[0]?.quiet_hours_start, profile[0]?.quiet_hours_end);
  if (!enabled) return emptyPulse(false, now, quiet);
  const today = calendarDateInZone(now, timezone);

  const [tasks, goals, reminders, events] = await Promise.all([
    sql<TaskRow>`
      select id, title, due_date, status from tasks
      where user_id = ${userId} and status <> ${"done"}
      order by id asc
      limit 40
    `,
    sql<GoalRow>`
      select id, title, status, updated_at from goals
      where user_id = ${userId} and status = ${"active"}
      order by updated_at asc
      limit 20
    `,
    sql<ReminderRow>`
      select id, title, fire_at, status from reminders
      where user_id = ${userId} and status in (${"scheduled"}, ${"snoozed"}, ${"pending_delivery"})
      order by fire_at asc
      limit 20
    `,
    sql<{ n: number; first_start: unknown; second_start: unknown }>`
      select count(*)::int as n,
        min(start_at) as first_start,
        (array_agg(start_at order by start_at))[2] as second_start
      from calendar_events
      where user_id = ${userId}
        and status = ${"confirmed"}
        and start_at >= ${now.toISOString()}::timestamptz
        and start_at < (${now.toISOString()}::timestamptz + interval '1 day')
    `,
  ]);

  const suggestions: PulseSuggestion[] = [];
  const dueSoon = tasks.filter((t) => {
    const kind = classifyDue(t.due_date, today);
    return kind === "today" || kind === "overdue";
  });
  if (dueSoon.length > 0) {
    suggestions.push({
      id: "tasks-due",
      kind: "tasks",
      title: dueSoon.length === 1 ? "One unfinished item is due" : `${dueSoon.length} unfinished items are due`,
      body: "Want me to help plan them? I will not move anything unless you confirm.",
      severity: "attention",
      stance: "suggestion",
      relatedType: "task",
      relatedId: String(asId(dueSoon[0]?.id) || ""),
    });
  }

  const stale = goals.filter((g) => {
    const updated = Date.parse(toIso(g.updated_at));
    return Number.isFinite(updated) && now.getTime() - updated > 7 * 24 * 3600 * 1000;
  });
  if (stale.length > 0) {
    suggestions.push({
      id: "goal-quiet",
      kind: "goals",
      title: "A goal has been quiet this week",
      body: `"${stale[0]!.title}" has not been updated recently. I can break it into smaller steps if you want.`,
      severity: "info",
      stance: "information",
      relatedType: "goal",
      relatedId: String(asId(stale[0]?.id) || ""),
    });
  }

  const soon = reminders.filter((r) => {
    const fire = Date.parse(toIso(r.fire_at));
    return Number.isFinite(fire) && fire - now.getTime() < 12 * 3600 * 1000 && fire >= now.getTime();
  });
  if (soon.length > 0) {
    suggestions.push({
      id: "reminder-soon",
      kind: "reminders",
      title: soon.length === 1 ? "A reminder is due in the next 12 hours" : `${soon.length} reminders are due soon`,
      body: soon[0]!.title,
      severity: "info",
      stance: "information",
      relatedType: "reminder",
      relatedId: String(asId(soon[0]?.id) || ""),
    });
  }

  const nEvents = events[0]?.n ?? 0;
  const first = events[0]?.first_start;
  const second = events[0]?.second_start;
  if (nEvents >= 2 && first && second) {
    const a = Date.parse(toIso(first));
    const b = Date.parse(toIso(second));
    if (Number.isFinite(a) && Number.isFinite(b) && Math.abs(b - a) < 45 * 60 * 1000) {
      suggestions.push({
        id: "calendar-close",
        kind: "calendar",
        title: "Two events sit close together today",
        body: "I can help you review them. I will not move either unless you confirm.",
        severity: "attention",
        stance: "suggestion",
        relatedType: "calendar",
        relatedId: "",
      });
    }
  }

  return {
    generatedAt: now.toISOString(),
    enabled: true,
    quiet,
    suggestions: suggestions.slice(0, 4),
  };
}

export const getPulse = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<PulseSnapshot> => {
    return buildPulse(context.userId);
  });
