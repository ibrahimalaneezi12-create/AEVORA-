import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { formatCalendarContextLine, mapCalendarEvent } from "./calendar-format.ts";

describe("calendar mapping", () => {
  it("maps a row and refuses a missing id", () => {
    const mapped = mapCalendarEvent({
      id: 3,
      title: "Study",
      notes: "",
      location: "Library",
      start_at: "2026-09-19T18:00:00.000Z",
      end_at: null,
      timezone: "UTC",
      status: "confirmed",
      source: "aegis",
      created_at: "2026-09-18T00:00:00.000Z",
      updated_at: "2026-09-18T00:00:00.000Z",
    });
    assert.equal(mapped?.id, 3);
    assert.equal(mapped?.recurrence, "once");
    assert.match(formatCalendarContextLine(mapped!), /Study/);
    assert.equal(
      mapCalendarEvent({
        id: 0,
        title: "Study",
        notes: "",
        location: "",
        start_at: "2026-09-19T18:00:00.000Z",
        end_at: null,
        timezone: "UTC",
        status: "confirmed",
        source: "aegis",
        created_at: "2026-09-18T00:00:00.000Z",
        updated_at: "2026-09-18T00:00:00.000Z",
      }),
      null,
    );
  });
});
