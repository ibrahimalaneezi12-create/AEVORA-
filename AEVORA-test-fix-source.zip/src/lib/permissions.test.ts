import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  asConfirmFloor,
  effectiveLevel,
  isConfirmFloor,
  mapPermissionSettings,
} from "./permissions-format.ts";

describe("asConfirmFloor", () => {
  it("accepts the three floors", () => {
    assert.equal(asConfirmFloor("safe"), "safe");
    assert.equal(asConfirmFloor("review"), "review");
    assert.equal(asConfirmFloor("approval"), "approval");
  });

  it("does not accept Restricted as a floor", () => {
    assert.equal(asConfirmFloor("restricted"), "safe");
    assert.equal(asConfirmFloor("loud"), "safe");
    assert.equal(asConfirmFloor(null), "safe");
  });
});

describe("isConfirmFloor", () => {
  it("rejects restricted and junk", () => {
    assert.equal(isConfirmFloor("approval"), true);
    assert.equal(isConfirmFloor("restricted"), false);
    assert.equal(isConfirmFloor(""), false);
  });
});

describe("effectiveLevel", () => {
  it("leaves catalog levels alone when the floor is safe", () => {
    assert.equal(effectiveLevel("safe", "safe"), "safe");
    assert.equal(effectiveLevel("review", "safe"), "review");
    assert.equal(effectiveLevel("approval", "safe"), "approval");
  });

  it("raises Safe to Review when the floor is review", () => {
    assert.equal(effectiveLevel("safe", "review"), "review");
    assert.equal(effectiveLevel("review", "review"), "review");
    assert.equal(effectiveLevel("approval", "review"), "approval");
  });

  it("raises Safe and Review to Approval when the floor is approval", () => {
    assert.equal(effectiveLevel("safe", "approval"), "approval");
    assert.equal(effectiveLevel("review", "approval"), "approval");
    assert.equal(effectiveLevel("approval", "approval"), "approval");
  });

  it("never loosens Approval or Review below the catalog", () => {
    assert.equal(effectiveLevel("approval", "safe"), "approval");
    assert.equal(effectiveLevel("approval", "review"), "approval");
    assert.equal(effectiveLevel("review", "safe"), "review");
  });

  it("never moves Restricted", () => {
    assert.equal(effectiveLevel("restricted", "safe"), "restricted");
    assert.equal(effectiveLevel("restricted", "review"), "restricted");
    assert.equal(effectiveLevel("restricted", "approval"), "restricted");
  });
});

describe("mapPermissionSettings", () => {
  it("forces auto-run off even if the row is dirty", () => {
    const mapped = mapPermissionSettings({
      confirm_floor: "approval",
      auto_run_safe: true,
      auto_run_review: true,
      updated_at: "2026-09-17T00:00:00.000Z",
    });
    assert.equal(mapped.confirmFloor, "approval");
    assert.equal(mapped.autoRunSafe, false);
    assert.equal(mapped.autoRunReview, false);
  });
});
