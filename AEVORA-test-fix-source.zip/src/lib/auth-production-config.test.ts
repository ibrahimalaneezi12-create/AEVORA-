import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  grokGoogleCallbackUrl,
  isDeployedAuthEnvironment,
  missingProductionAuthEnv,
  resolveBrokerCredentials,
} from "./auth-production-config.ts";

const preview = {
  issuer: "https://auth.grok.me",
  clientId: "grok_preview",
  clientSecret: "preview-secret",
};

describe("production auth credentials", () => {
  it("treats DATABASE_URL as deployed and does not fall back to preview secrets", () => {
    assert.equal(isDeployedAuthEnvironment({ DATABASE_URL: "postgres://db" }), true);
    const resolved = resolveBrokerCredentials({ DATABASE_URL: "postgres://db" }, preview);
    assert.equal(resolved.mode, "production-invalid");
    assert.equal(resolved.clientId, undefined);
    assert.equal(resolved.clientSecret, undefined);
    assert.ok(resolved.missing.includes("GROK_AUTH_CLIENT_SECRET"));
    assert.ok(resolved.missing.includes("BETTER_AUTH_SECRET"));
  });

  it("uses injected production credentials when every required var is present", () => {
    const env = {
      DATABASE_URL: "postgres://db",
      GROK_AUTH_ISSUER: "https://auth.grok.me",
      GROK_AUTH_CLIENT_ID: "prod-client",
      GROK_AUTH_CLIENT_SECRET: "prod-secret",
      BETTER_AUTH_URL: "https://aegis.example",
      BETTER_AUTH_SECRET: "prod-better-secret",
    };
    assert.deepEqual(missingProductionAuthEnv(env), []);
    const resolved = resolveBrokerCredentials(env, preview);
    assert.equal(resolved.mode, "production");
    assert.equal(resolved.clientId, "prod-client");
    assert.equal(resolved.clientSecret, "prod-secret");
    assert.equal(resolved.baseURL, "https://aegis.example");
  });

  it("allows preview fallback only when not deployed", () => {
    const resolved = resolveBrokerCredentials({}, preview);
    assert.equal(resolved.mode, "preview");
    assert.equal(resolved.clientId, "grok_preview");
    assert.equal(isDeployedAuthEnvironment({}), false);
  });

  it("uses a managed preview secret and leaves preview auth unconfigured when it is absent", () => {
    const previewWithoutBakedSecret = {
      issuer: "https://auth.grok.me",
      clientId: "grok_preview",
      clientSecret: "",
    };
    const configured = resolveBrokerCredentials(
      { GROK_AUTH_CLIENT_SECRET: "managed-preview-secret" },
      previewWithoutBakedSecret,
    );
    assert.equal(configured.clientSecret, "managed-preview-secret");

    const unconfigured = resolveBrokerCredentials({}, previewWithoutBakedSecret);
    assert.equal(unconfigured.clientSecret, "");
    assert.equal(unconfigured.mode, "preview");
  });
});

describe("canonical Google callback URL", () => {
  it("is the same path for authorize and token exchange", () => {
    const previewUrl = grokGoogleCallbackUrl("https://keep.grok-sandbox.com");
    const productionUrl = grokGoogleCallbackUrl("https://aegis.example");
    assert.equal(previewUrl, "https://keep.grok-sandbox.com/api/auth/oauth2/callback/grok-google");
    assert.equal(productionUrl, "https://aegis.example/api/auth/oauth2/callback/grok-google");
    assert.equal(previewUrl, grokGoogleCallbackUrl("https://keep.grok-sandbox.com/"));
  });
});
