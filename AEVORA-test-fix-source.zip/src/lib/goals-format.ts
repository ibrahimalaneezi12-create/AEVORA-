export const GOAL_STATUSES = ["active", "paused", "done", "archived"] as const;
export type GoalStatus = (typeof GOAL_STATUSES)[number];

export const TASK_STATUSES = ["todo", "doing", "done", "cancelled"] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

export const GOAL_TITLE_MAX = 80;
export const GOAL_DESC_MAX = 500;
export const TASK_TITLE_MAX = 80;
export const TASK_NOTES_MAX = 500;

export type Goal = {
  id: number;
  title: string;
  description: string;
  status: GoalStatus;
  targetDate: string | null;
  createdAt: string;
  updatedAt: string;
};

export type Task = {
  id: number;
  goalId: number | null;
  title: string;
  notes: string;
  status: TaskStatus;
  dueDate: string | null;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export type GoalRow = {
  id: unknown;
  title: string;
  description: string;
  status: string;
  target_date: unknown;
  created_at: unknown;
  updated_at: unknown;
};

export type TaskRow = {
  id: unknown;
  goal_id: unknown;
  title: string;
  notes: string;
  status: string;
  due_date: unknown;
  sort_order: unknown;
  created_at: unknown;
  updated_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

export function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

export function asDateOnly(value: unknown): string | null {
  if (value == null || value === "") return null;
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value.toISOString().slice(0, 10);
  }
  const s = String(value);
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  return null;
}

export function asGoalStatus(value: string): GoalStatus {
  return (GOAL_STATUSES as readonly string[]).includes(value)
    ? (value as GoalStatus)
    : "active";
}

export function asTaskStatus(value: string): TaskStatus {
  return (TASK_STATUSES as readonly string[]).includes(value)
    ? (value as TaskStatus)
    : "todo";
}

export function mapGoal(row: GoalRow): Goal | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  return {
    id,
    title: row.title,
    description: row.description ?? "",
    status: asGoalStatus(row.status),
    targetDate: asDateOnly(row.target_date),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function mapTask(row: TaskRow): Task | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  const goalId = asPositiveInt(row.goal_id);
  const sort = typeof row.sort_order === "number" ? row.sort_order : Number(row.sort_order) || 0;
  return {
    id,
    goalId: goalId || null,
    title: row.title,
    notes: row.notes ?? "",
    status: asTaskStatus(row.status),
    dueDate: asDateOnly(row.due_date),
    sortOrder: sort,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function emptyToNull(value: string | null | undefined): string | null {
  if (value == null) return null;
  const t = value.trim();
  return t === "" ? null : t;
}

/**
 * Link rule: a task may attach to a goal only when both rows have the same
 * owner. Existence of the goal is not enough. Callers skip this when the
 * task is unlinked (`goalId` is null).
 */
export function taskMayLinkToGoal(
  taskUserId: string,
  goalUserId: string | null | undefined,
): boolean {
  if (!taskUserId || !goalUserId) return false;
  return taskUserId === goalUserId;
}
