import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  ACTIVITY_PAGE_SIZE,
  AUDIT_ACTIONS,
  asActivityLevelFilter,
  asActor,
  decodeCursor,
  encodeCursor,
  eventTitle,
  mapActivityEvent,
  matchesLevelFilter,
  pageFromRows,
  sanitizeDetail,
  toolIdFromRow,
  type ActivityEvent,
  type AuditRow,
} from "./audit-format.ts";

function row(partial: Partial<AuditRow> & Pick<AuditRow, "id" | "action">): AuditRow {
  return {
    actor: "user",
    entity_type: "memory",
    entity_id: "1",
    permission_level: null,
    detail: "Kettle note",
    created_at: "2026-09-17T12:00:00.000Z",
    ...partial,
  };
}

function event(partial: Partial<ActivityEvent> & Pick<ActivityEvent, "id">): ActivityEvent {
  return {
    actor: "user",
    actorLabel: "You",
    action: "memory.created",
    title: "Added a memory",
    detail: "Kettle note",
    entityType: "memory",
    entityId: String(partial.id),
    permissionLevel: null,
    toolId: null,
    createdAt: `2026-09-17T12:00:00.${String(partial.id).padStart(3, "0")}Z`,
    ...partial,
  };
}

describe("eventTitle", () => {
  it("uses locked copy for known proposal and domain events", () => {
    assert.equal(eventTitle("proposal.created"), "Proposed an action");
    assert.equal(eventTitle("proposal.approved"), "Approved an action");
    assert.equal(eventTitle("proposal.denied"), "Denied an action");
    assert.equal(eventTitle("proposal.executed"), "Executed an action");
    assert.equal(eventTitle("proposal.failed"), "Action failed");
    assert.equal(eventTitle("proposal.rejected"), "Rejected a restricted action");
    assert.equal(eventTitle("memory.created"), "Added a memory");
    assert.equal(eventTitle("goal.deleted"), "Deleted a goal");
    assert.equal(eventTitle("permission.settings.updated"), "Updated confirmation settings");
  });

  it("keeps reserved future names ready without a schema change", () => {
    assert.ok(AUDIT_ACTIONS.includes("reminder.created"));
    assert.ok(AUDIT_ACTIONS.includes("notification.sent"));
    assert.ok(AUDIT_ACTIONS.includes("proposal.execution_started"));
    assert.equal(eventTitle("reminder.scheduled"), "Scheduled a reminder");
    assert.equal(eventTitle("notification.failed"), "Notification failed");
  });

  it("renders an unknown future action instead of dropping it", () => {
    assert.equal(eventTitle("calendar.event.created"), "Calendar event created");
  });
});

describe("sanitizeDetail", () => {
  it("keeps a short human title", () => {
    assert.equal(sanitizeDetail("Save tea preference"), "Save tea preference");
  });

  it("strips payload JSON and secret-looking detail", () => {
    assert.equal(sanitizeDetail('{"title":"x","payload_json":"nope"}'), "");
    assert.equal(sanitizeDetail("payload-secret-orchid-77"), "");
    assert.equal(sanitizeDetail("bearer abc"), "");
    assert.equal(sanitizeDetail('{"payload":{"body":"secret"}}'), "");
  });

  it("clips long detail", () => {
    const out = sanitizeDetail("word ".repeat(80));
    assert.ok(out.length <= 240);
    assert.ok(out.endsWith("…"));
  });
});

describe("mapActivityEvent", () => {
  it("maps a user memory write without a user id or payload field", () => {
    const view = mapActivityEvent(row({ id: 4, action: "memory.created" }));
    assert.ok(view);
    assert.equal(view.title, "Added a memory");
    assert.equal(view.actorLabel, "You");
    assert.equal(view.detail, "Kettle note");
    assert.equal(view.permissionLevel, null);
    assert.equal("user_id" in view, false);
    assert.equal("payload" in view, false);
    assert.equal("payload_json" in view, false);
  });

  it("maps a proposal row and pulls the tool id from the detail prefix", () => {
    const view = mapActivityEvent(
      row({
        id: 9,
        actor: "assistant",
        action: "proposal.created",
        entity_type: "proposed_action",
        entity_id: "12",
        permission_level: "review",
        detail: "memory.save: Save tea preference",
      }),
    );
    assert.ok(view);
    assert.equal(view.actorLabel, "AEVORA");
    assert.equal(view.permissionLevel, "review");
    assert.equal(view.toolId, "memory.save");
    assert.equal(view.entityId, "12");
  });

  it("does not leak a raw payload body that slipped into detail", () => {
    const view = mapActivityEvent(
      row({
        id: 2,
        action: "proposal.executed",
        detail: "payload-secret-orchid-77",
      }),
    );
    assert.ok(view);
    assert.equal(view.detail, "");
  });

  it("does not leak a user id stored on permission settings rows", () => {
    const view = mapActivityEvent(
      row({
        id: 8,
        action: "permission.settings.updated",
        entity_type: "permission_settings",
        entity_id: "user_abc_should_not_leak",
        detail: "confirm_floor=review",
      }),
    );
    assert.ok(view);
    assert.equal(view.entityId, "");
    assert.equal(view.detail, "confirm_floor=review");
  });

  it("drops invalid ids", () => {
    assert.equal(mapActivityEvent(row({ id: 0, action: "memory.created" })), null);
  });

  it("treats junk actors as system", () => {
    const view = mapActivityEvent(row({ id: 1, action: "memory.created", actor: "root" }));
    assert.ok(view);
    assert.equal(view.actor, "system");
  });
});

describe("toolIdFromRow", () => {
  it("uses entity_id when the entity is a tool", () => {
    assert.equal(toolIdFromRow("tool", "permission.update", "restricted"), "permission.update");
  });

  it("ignores a title that is not a tool id", () => {
    assert.equal(toolIdFromRow("memory", "3", "Kettle note"), null);
  });
});

describe("filters and cursor", () => {
  it("defaults unknown filters to all", () => {
    assert.equal(asActivityLevelFilter("restricted"), "restricted");
    assert.equal(asActivityLevelFilter("nope"), "all");
    assert.equal(asActivityLevelFilter(undefined), "all");
  });

  it("matches permission level, and All includes unlevelled account events", () => {
    assert.equal(matchesLevelFilter("review", "review"), true);
    assert.equal(matchesLevelFilter("review", "safe"), false);
    assert.equal(matchesLevelFilter(null, "all"), true);
    assert.equal(matchesLevelFilter(null, "review"), false);
  });

  it("round-trips a cursor", () => {
    const cursor = { createdAt: "2026-09-17T12:00:00.000Z", id: 44 };
    assert.deepEqual(decodeCursor(encodeCursor(cursor)), cursor);
    assert.equal(decodeCursor("bad"), null);
    assert.equal(decodeCursor(""), null);
  });

  it("pages with a next cursor only when the limit is exceeded", () => {
    const rows = [event({ id: 3 }), event({ id: 2 }), event({ id: 1 })];
    const full = pageFromRows(rows, 3);
    assert.equal(full.nextCursor, null);
    assert.equal(full.items.length, 3);
    const sliced = pageFromRows(rows, 2);
    assert.equal(sliced.items.length, 2);
    assert.deepEqual(sliced.nextCursor, { createdAt: rows[1].createdAt, id: 2 });
  });

  it("keeps the default page size large enough for a real keep", () => {
    assert.equal(ACTIVITY_PAGE_SIZE, 50);
  });
});

describe("asActor", () => {
  it("accepts the three locked actors", () => {
    assert.equal(asActor("user"), "user");
    assert.equal(asActor("assistant"), "assistant");
    assert.equal(asActor("system"), "system");
  });
});
