import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  VIDEO_CAPABILITIES,
  VIDEO_MODEL,
  applyNaturalEdit,
  applyStudioControls,
  asVideoAspect,
  asVideoResolution,
  buildVideoGenerationBody,
  clampSceneDuration,
  jobStatusCopy,
  planVideoRequest,
  publicVideoError,
  qualityGate,
  snapshotPlan,
} from "./video-format.ts";
import { sessionOwns, clientUserIdMustBeIgnored, GENERIC_NOT_FOUND } from "./privacy.ts";
import { canRunTool, catalogLevel, lookupTool } from "./orchestrator/catalog.ts";

describe("video planner", () => {
  it("plans a vertical short from a TikTok ask", () => {
    const plan = planVideoRequest("Make a 20-second TikTok of a rainy neon city.");
    assert.equal(plan.aspectRatio, "9:16");
    assert.ok(plan.scenes.length >= 1);
    assert.ok(plan.scenes.every((s) => s.durationSec <= 15));
    assert.ok(plan.notes.some((n) => /15s/i.test(n)));
  });

  it("does not claim 4K or 60fps", () => {
    const plan = planVideoRequest("Make a 4K 60fps cinematic football edit.");
    assert.equal(plan.resolution, "1080p");
    assert.ok(plan.notes.some((n) => /4K/i.test(n)));
    assert.ok(plan.notes.some((n) => /60 FPS/i.test(n)));
  });

  it("does not claim kill detection", () => {
    const plan = planVideoRequest("Fortnite montage. Only keep the kills.");
    assert.ok(plan.notes.some((n) => /kill/i.test(n)));
    assert.equal(VIDEO_CAPABILITIES.autoKillDetection, false);
  });

  it("gaming briefs stay one brain plan with a style suffix", () => {
    const plan = planVideoRequest("Make this a sweaty Fortnite montage.");
    assert.match(plan.scenes[0]?.prompt ?? "", /gameplay/i);
  });

  it("applies natural language edits without a second planner", () => {
    const base = planVideoRequest("Cinematic lake at dawn, 8 seconds.");
    const next = applyNaturalEdit(base, "Make it 9:16 and add captions. Faster.");
    assert.equal(next.aspectRatio, "9:16");
    assert.ok(next.captions.length > 0);
    assert.ok(next.scenes[0] && next.scenes[0].durationSec <= base.scenes[0]!.durationSec);
  });

  it("quality gate rejects empty scenes", () => {
    const plan = planVideoRequest("A quiet forest.");
    plan.scenes = [];
    assert.ok(qualityGate(plan).length > 0);
  });

  it("clamps duration and snapshots without user ids", () => {
    assert.equal(clampSceneDuration(99), 15);
    assert.equal(clampSceneDuration(0), 1);
    const snap = snapshotPlan(planVideoRequest("Hello"));
    assert.equal(snap.includes("userId"), false);
    assert.equal(asVideoAspect("9:16"), "9:16");
    assert.equal(asVideoResolution("nope"), "720p");
  });

  it("applies studio controls without inventing 4K or long clips", () => {
    const base = planVideoRequest("A quiet forest.");
    const next = applyStudioControls(base, {
      aspectRatio: "9:16",
      resolution: "1080p",
      durationSec: 40,
      generateAudio: false,
    });
    assert.equal(next.aspectRatio, "9:16");
    assert.equal(next.resolution, "1080p");
    assert.equal(next.generateAudio, false);
    assert.ok(next.scenes.every((s) => s.durationSec === 15));
  });

  it("keeps generation copy honest", () => {
    assert.equal(jobStatusCopy("processing").title, "Creating your scene");
    assert.equal(
      publicVideoError("xAI API key leaked sk-abc"),
      "Something went wrong while creating your video. Please try again.",
    );
    assert.equal(publicVideoError("Not found."), "Not found.");
    assert.match(publicVideoError("Video could not start (403)."), /unavailable|try again/i);
  });
});

describe("video tools and isolation", () => {
  it("registers video.create and video.generate as review, not restricted", () => {
    assert.equal(catalogLevel("video.create"), "review");
    assert.equal(catalogLevel("video.generate"), "review");
    assert.equal(canRunTool("video.create"), true);
    assert.equal(canRunTool("video.generate"), true);
    assert.equal(lookupTool("video.create")?.enabled, true);
  });

  it("never trusts a client user id for media", () => {
    assert.equal(clientUserIdMustBeIgnored("session-a", "attacker"), "session-a");
    assert.equal(sessionOwns("a", "b"), false);
    assert.equal(GENERIC_NOT_FOUND, "Not found.");
  });

  it("documents real provider limits", () => {
    assert.equal(VIDEO_CAPABILITIES.model, VIDEO_MODEL);
    assert.equal(VIDEO_CAPABILITIES.textToVideo, true);
    assert.equal(VIDEO_CAPABILITIES.imageToVideo, true);
    assert.equal(VIDEO_CAPABILITIES.videoToVideo, false);
    assert.equal(VIDEO_CAPABILITIES.ffmpegStitch, false);
    assert.equal(VIDEO_CAPABILITIES.burnInCaptions, false);
    assert.equal(VIDEO_CAPABILITIES.maxDurationSec, 15);
  });

  it("sends image-to-video as an object url, never a bare string", () => {
    const body = buildVideoGenerationBody({
      prompt: "A car in rain",
      duration: 10,
      aspectRatio: "16:9",
      resolution: "720p",
      generateAudio: true,
      imageDataUrl: "data:image/png;base64,AAAA",
    });
    assert.equal(typeof body.image, "object");
    assert.notEqual(typeof body.image, "string");
    assert.deepEqual(body.image, { url: "data:image/png;base64,AAAA", type: "image_url" });
    const plain = buildVideoGenerationBody({
      prompt: "A car in rain",
      duration: 10,
      aspectRatio: "16:9",
      resolution: "720p",
      generateAudio: true,
    });
    assert.equal("image" in plain, false);
  });
});
