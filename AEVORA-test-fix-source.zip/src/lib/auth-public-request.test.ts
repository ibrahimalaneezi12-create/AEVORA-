import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  authBrokerHeaders,
  isGrokSandboxHost,
  publicAuthUrl,
  requestForAuthBroker,
} from "./auth-public-request.ts";

describe("public auth origin", () => {
  it("accepts grok-sandbox hosts and rejects others", () => {
    assert.equal(isGrokSandboxHost("abc.grok-sandbox.com"), true);
    assert.equal(isGrokSandboxHost("grok-sandbox.com"), true);
    assert.equal(isGrokSandboxHost("evil.com"), false);
    assert.equal(isGrokSandboxHost("grok-sandbox.com.evil"), false);
    assert.equal(isGrokSandboxHost("127.0.0.1:8080"), false);
  });

  it("rewrites loopback to the forwarded preview host", () => {
    const request = new Request("http://127.0.0.1:8080/api/auth/sign-in/oauth2", {
      method: "POST",
      headers: {
        "x-forwarded-host": "keep.grok-sandbox.com",
        "x-forwarded-proto": "https",
      },
    });
    const url = publicAuthUrl(request);
    assert.equal(url.origin, "https://keep.grok-sandbox.com");
    const rebuilt = requestForAuthBroker(request);
    assert.equal(rebuilt.headers.get("host"), "keep.grok-sandbox.com");
    assert.equal(rebuilt.headers.get("x-forwarded-host"), "keep.grok-sandbox.com");
    assert.equal(rebuilt.headers.get("x-forwarded-proto"), "https");
  });

  it("normalizes stacked forwarded headers so redirect_uri stays public", () => {
    const request = new Request("http://127.0.0.1:8080/api/auth/oauth2/callback/grok-google?code=x&state=y", {
      headers: {
        host: "127.0.0.1:8080",
        "x-forwarded-host": "hds-abc.grok-code-wild.hades-www.grok-sandbox.com, 127.0.0.1:8080",
        "x-forwarded-proto": "https, http",
      },
    });
    const rebuilt = requestForAuthBroker(request);
    assert.equal(
      rebuilt.url,
      "https://hds-abc.grok-code-wild.hades-www.grok-sandbox.com/api/auth/oauth2/callback/grok-google?code=x&state=y",
    );
    const headers = authBrokerHeaders(request);
    assert.equal(headers.get("host"), "hds-abc.grok-code-wild.hades-www.grok-sandbox.com");
    assert.equal(headers.get("x-forwarded-host"), "hds-abc.grok-code-wild.hades-www.grok-sandbox.com");
    assert.equal(headers.get("x-forwarded-proto"), "https");
  });

  it("does not trust a forged forwarded host", () => {
    const request = new Request("http://127.0.0.1:8080/api/auth/ok", {
      headers: {
        "x-forwarded-host": "attacker.example",
        "x-forwarded-proto": "https",
      },
    });
    assert.equal(publicAuthUrl(request).host, "127.0.0.1:8080");
  });
});
