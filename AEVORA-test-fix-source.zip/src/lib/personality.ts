/** AEVORA may never emit these, even if the user did. Word-boundary only. */
const PROFANITY_RE =
  /\b(?:fuck(?:ing|ed|er)?|shit(?:ty)?|asshole|bitch|cunt|dickhead|motherfucker|slut|whore|bastard)\b/gi;

export function sanitizeAegisText(text: string): string {
  if (!text) return text;
  return text
    .replace(PROFANITY_RE, "")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/ \./g, ".")
    .replace(/\s+\n/g, "\n")
    .trim();
}

export function aegisContainsProfanity(text: string): boolean {
  PROFANITY_RE.lastIndex = 0;
  return PROFANITY_RE.test(text);
}
