import { getBearerToken } from "@/lib/auth/client";
import type { ChatMessage, Conversation, SendChatResult } from "@/lib/chat";
import type { ChatWorkspaceId } from "@/lib/chat-workspace";
import type { ProposedActionView, RejectedProposalView } from "@/lib/orchestrator/types";

export type StreamCallbacks = {
  onDelta?: (text: string) => void;
  onStatus?: (text: string) => void;
  onMeta?: (meta: { conversationId: number; userMessage: ChatMessage; title: string }) => void;
};

function parseSseBlock(block: string): { event: string; data: string } | null {
  let event = "message";
  const dataLines: string[] = [];
  for (const line of block.split("\n")) {
    if (line.startsWith("event:")) event = line.slice(6).trim();
    else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
  }
  if (dataLines.length === 0) return null;
  return { event, data: dataLines.join("\n") };
}

export async function sendChatStream(
  content: string,
  conversationId: number | undefined,
  callbacks: StreamCallbacks = {},
  signal?: AbortSignal,
  workspace: ChatWorkspaceId = "main",
): Promise<SendChatResult> {
  const token = getBearerToken();
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch("/api/chat/stream", {
    method: "POST",
    headers,
    credentials: "include",
    signal,
    body: JSON.stringify({ content, conversationId, workspace }),
  });
  if (!res.ok || !res.body) {
    throw new Error(res.status === 401 ? "Unauthorized" : "The request did not complete. Try once more.");
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  let doneResult: SendChatResult | null = null;
  let error: string | null = null;
  let unavailable = false;
  let errorConversation: Conversation | null = null;
  let errorUserMessage: ChatMessage | null = null;

  const handle = (block: string) => {
    const parsed = parseSseBlock(block);
    if (!parsed) return;
    let payload: unknown = null;
    try {
      payload = JSON.parse(parsed.data);
    } catch {
      return;
    }
    const rec = payload && typeof payload === "object" ? (payload as Record<string, unknown>) : {};
    if (parsed.event === "delta" && typeof rec.text === "string") callbacks.onDelta?.(rec.text);
    if (parsed.event === "status" && typeof rec.text === "string") callbacks.onStatus?.(rec.text);
    if (parsed.event === "meta") {
      callbacks.onMeta?.(rec as { conversationId: number; userMessage: ChatMessage; title: string });
    }
    if (parsed.event === "error") {
      error = typeof rec.error === "string" ? rec.error : "The request did not complete.";
      unavailable = rec.unavailable === true;
      if (rec.conversation && typeof rec.conversation === "object") {
        errorConversation = rec.conversation as Conversation;
      }
      if (rec.userMessage && typeof rec.userMessage === "object") {
        errorUserMessage = rec.userMessage as ChatMessage;
      }
    }
    if (parsed.event === "done") {
      doneResult = {
        ok: true,
        conversation: rec.conversation as Conversation,
        userMessage: rec.userMessage as ChatMessage,
        assistantMessage: rec.assistantMessage as ChatMessage,
        proposals: (rec.proposals as ProposedActionView[]) ?? [],
        rejected: (rec.rejected as RejectedProposalView[]) ?? [],
        citations: (rec.citations as string[]) ?? [],
      };
    }
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const parts = buf.split("\n\n");
    buf = parts.pop() ?? "";
    for (const part of parts) handle(part);
  }
  if (buf.trim()) handle(buf);

  if (doneResult) return doneResult;
  return {
    ok: false,
    error: error || "The request did not complete. Try once more.",
    unavailable,
    conversation: errorConversation,
    userMessage: errorUserMessage,
    assistantMessage: null,
    proposals: [],
    rejected: [],
    citations: [],
  };
}

export { parseSseBlock };
