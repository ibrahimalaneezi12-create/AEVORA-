import { stripProposalFence } from "./speech-normalize.ts";

/** Visible assistant speech: same string the UI shows, minus proposal JSON. */
export function canonicalSpeechText(raw: string): string {
  const cut = stripProposalFence(raw);
  const match = cut.match(/\n\nSources:\n([\s\S]+)$/i);
  if (!match || match.index == null) return cut.trim();
  return cut.slice(0, match.index).trimEnd();
}

function splitVisible(text: string): string[] {
  const trimmed = text.trim();
  if (!trimmed) return [];
  const parts = trimmed.match(/[^.!?؟]+[.!?؟]+(?:\s|$)|[^.!?؟]+$/g) ?? [trimmed];
  const sentences: string[] = [];
  let buf = "";
  for (const raw of parts) {
    const piece = raw.trim();
    if (!piece) continue;
    if (sentences.length === 0 && !buf) {
      sentences.push(piece);
      continue;
    }
    if ((buf + " " + piece).trim().length < 42) {
      buf = `${buf} ${piece}`.trim();
      continue;
    }
    if (buf) sentences.push(buf);
    buf = piece;
  }
  if (buf) sentences.push(buf);
  return expandVisibleClauses(sentences);
}

function expandVisibleClauses(sentences: string[]): string[] {
  const out: string[] = [];
  for (const sentence of sentences) {
    if (sentence.length < 70 || !/[,;:]/.test(sentence)) {
      out.push(sentence);
      continue;
    }
    const bits = sentence.split(/(?<=[,;:])\s+/);
    let buf = "";
    for (const bit of bits) {
      const next = `${buf} ${bit}`.trim();
      if (buf && next.length >= 40) {
        out.push(buf);
        buf = bit;
      } else {
        buf = next;
      }
    }
    if (buf) out.push(buf);
  }
  return out;
}

function completeVisible(text: string): string[] {
  const parts = splitVisible(text);
  if (parts.length === 0) return [];
  if (/[.!?؟…]["')\]]*\s*$/.test(text.trim())) return parts;
  return parts.slice(0, -1);
}

/**
 * One stream → text is already on screen; these are the not-yet-spoken
 * clauses of that SAME string. When `ended`, the leftover fragment is flushed
 * so voice never waits for another token that will not arrive.
 */
export function nextSpeakableChunks(opts: {
  canonical: string;
  already: number;
  ended: boolean;
}): { chunks: string[]; nextIndex: number } {
  const text = canonicalSpeechText(opts.canonical);
  if (!text) return { chunks: [], nextIndex: opts.already };
  const parts = opts.ended ? splitVisible(text) : completeVisible(text);
  if (opts.already >= parts.length) {
    return { chunks: [], nextIndex: Math.max(opts.already, parts.length) };
  }
  return { chunks: parts.slice(opts.already), nextIndex: parts.length };
}
