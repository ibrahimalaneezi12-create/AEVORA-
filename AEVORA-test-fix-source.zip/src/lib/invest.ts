import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { appendAudit } from "@/lib/audit";
import { ensureEntitlement } from "@/lib/entitlements";
import {
  investOperatorDecision,
  investWorkspaceLine,
  planAllowsFeature,
  planDisplayName,
  type OperatorDecision,
} from "@/lib/entitlements-format";
import {
  INVEST_NAME_MAX,
  INVEST_NOTE_BODY_MAX,
  INVEST_NOTE_CONTEXT_LIMIT,
  INVEST_NOTE_KINDS,
  INVEST_NOTE_TITLE_MAX,
  INVEST_SYMBOL_MAX,
  INVEST_THESIS_MAX,
  INVEST_WATCH_CONTEXT_LIMIT,
  composeInvestOverview,
  investNoteFeature,
  mapInvestNote,
  mapWatchItem,
  normalizeSymbol,
  type InvestNote,
  type InvestNoteRow,
  type InvestOverview,
  type WatchItem,
  type WatchRow,
} from "./invest-format.ts";
import { requiredBody, requiredTitle } from "./confirm-format.ts";
import type { ToolHandler } from "./tools/types.ts";

export {
  INVEST_DISCLAIMER,
  INVEST_NOTE_KINDS,
  composeInvestOverview,
  formatInvestBlock,
  investMayAccess,
  isTradeRequest,
  normalizeSymbol,
} from "./invest-format.ts";
export type { InvestNote, InvestNoteKind, InvestOverview, WatchItem } from "./invest-format.ts";

async function writeAudit(userId: string, action: string, entityId: string, detail: string): Promise<void> {
  await appendAudit({
    userId,
    actor: "user",
    action,
    entityType: "invest",
    entityId,
    detail,
  });
}

export async function listOwnInvestForContext(userId: string): Promise<{
  watchlist: WatchItem[];
  notes: InvestNote[];
}> {
  const sql = await getSql();
  const [watchRows, noteRows] = await Promise.all([
    sql<WatchRow>`
      select id, symbol, name, thesis, created_at, updated_at
      from invest_watchlist
      where user_id = ${userId}
      order by updated_at desc
      limit ${INVEST_WATCH_CONTEXT_LIMIT}
    `,
    sql<InvestNoteRow>`
      select id, symbol, kind, title, body, created_at, updated_at
      from invest_journal
      where user_id = ${userId}
      order by updated_at desc
      limit ${INVEST_NOTE_CONTEXT_LIMIT}
    `,
  ]);
  const watchlist: WatchItem[] = [];
  for (const row of watchRows) {
    const mapped = mapWatchItem(row);
    if (mapped) watchlist.push(mapped);
  }
  const notes: InvestNote[] = [];
  for (const row of noteRows) {
    const mapped = mapInvestNote(row);
    if (mapped) notes.push(mapped);
  }
  return { watchlist, notes };
}

export type InvestPlan = {
  id: number;
  title: string;
  body: string;
  horizon: string;
  contribution: string;
};

export async function listOwnInvestPlans(userId: string): Promise<InvestPlan[]> {
  const sql = await getSql();
  const rows = await sql<{
    id: unknown;
    title: string;
    body: string;
    horizon: string;
    contribution: string;
  }>`
    select id, title, body, horizon, contribution
    from invest_plans
    where user_id = ${userId}
    order by updated_at desc
    limit 4
  `;
  const out: InvestPlan[] = [];
  for (const row of rows) {
    const id = Number(row.id);
    if (!Number.isInteger(id) || id < 1 || !row.title) continue;
    out.push({
      id,
      title: row.title,
      body: row.body ?? "",
      horizon: row.horizon ?? "",
      contribution: row.contribution ?? "",
    });
  }
  return out;
}

export type InvestPage = {
  watchlist: WatchItem[];
  notes: InvestNote[];
  overview: InvestOverview;
  planName: string;
  copilot: boolean;
  operator: OperatorDecision;
  accessLine: string;
  plans: InvestPlan[];
};

export const listInvestPage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<InvestPage> => {
    const [{ watchlist, notes }, entitlement, plans] = await Promise.all([
      listOwnInvestForContext(context.userId),
      ensureEntitlement(context.userId),
      listOwnInvestPlans(context.userId),
    ]);
    return {
      watchlist,
      notes,
      overview: composeInvestOverview(watchlist, notes),
      planName: planDisplayName(entitlement.plan),
      copilot: planAllowsFeature(entitlement.plan, "investCopilot"),
      operator: investOperatorDecision(entitlement.plan),
      accessLine: investWorkspaceLine(entitlement.plan),
      plans,
    };
  });

const watchInput = z.object({
  symbol: z.string().trim().min(1).max(INVEST_SYMBOL_MAX),
  name: z.string().max(INVEST_NAME_MAX).optional(),
  thesis: z.string().max(INVEST_THESIS_MAX).optional(),
});

export const addWatchItem = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => watchInput.parse(input))
  .handler(async ({ context, data }): Promise<WatchItem> => {
    const sql = await getSql();
    const symbol = normalizeSymbol(data.symbol);
    if (!symbol) throw new Error("Add a ticker symbol.");
    const name = (data.name ?? "").trim();
    const thesis = (data.thesis ?? "").trim();
    const rows = await sql<WatchRow>`
      insert into invest_watchlist (user_id, symbol, name, thesis)
      values (${context.userId}, ${symbol}, ${name}, ${thesis})
      on conflict (user_id, symbol) do update set
        name = excluded.name,
        thesis = excluded.thesis,
        updated_at = now()
      returning id, symbol, name, thesis, created_at, updated_at
    `;
    const mapped = rows[0] ? mapWatchItem(rows[0]) : null;
    if (!mapped) throw new Error("Watchlist item could not be saved.");
    await writeAudit(context.userId, "invest.watched", String(mapped.id), mapped.symbol);
    return mapped;
  });

export const investWatchHandler: ToolHandler = async ({ userId, payload, title }) => {
  const parsed = watchInput.parse(payload);
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "investBasic");
  const sql = await getSql();
  const symbol = normalizeSymbol(parsed.symbol || title);
  if (!symbol) throw new Error("Add a ticker symbol.");
  const name = (parsed.name ?? "").trim();
  const thesis = (parsed.thesis ?? "").trim();
  const rows = await sql<WatchRow>`
    insert into invest_watchlist (user_id, symbol, name, thesis)
    values (${userId}, ${symbol}, ${name}, ${thesis})
    on conflict (user_id, symbol) do update set
      name = excluded.name,
      thesis = excluded.thesis,
      updated_at = now()
    returning id, symbol, name, thesis, created_at, updated_at
  `;
  const mapped = rows[0] ? mapWatchItem(rows[0]) : null;
  if (!mapped) throw new Error("Watchlist item could not be saved.");
  return `Watching ${mapped.symbol}.`;
};

const unwatchInput = z.object({
  id: z.number().int().positive().optional(),
  symbol: z.string().trim().max(INVEST_SYMBOL_MAX).optional(),
});

export const investUnwatchHandler: ToolHandler = async ({ userId, payload }) => {
  const parsed = unwatchInput.parse(payload);
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "investBasic");
  const sql = await getSql();
  if (parsed.id) {
    const rows = await sql<{ id: unknown; symbol: string }>`
      delete from invest_watchlist
      where id = ${parsed.id} and user_id = ${userId}
      returning id, symbol
    `;
    if (!rows[0]) throw new Error("Watchlist item not found.");
    return `Removed ${rows[0].symbol} from the watchlist.`;
  }
  const symbol = normalizeSymbol(parsed.symbol ?? "");
  if (!symbol) throw new Error("Watchlist item not found.");
  const rows = await sql<{ id: unknown; symbol: string }>`
    delete from invest_watchlist
    where user_id = ${userId} and symbol = ${symbol}
    returning id, symbol
  `;
  if (!rows[0]) throw new Error("Watchlist item not found.");
  return `Removed ${rows[0].symbol} from the watchlist.`;
};

const noteInput = z.object({
  symbol: z.string().trim().max(INVEST_SYMBOL_MAX).optional(),
  kind: z.enum(INVEST_NOTE_KINDS).optional(),
  title: z.string().trim().max(INVEST_NOTE_TITLE_MAX).optional(),
  body: z.string().trim().max(INVEST_NOTE_BODY_MAX).optional(),
});

export const investNoteHandler: ToolHandler = async ({ userId, payload, title, summary }) => {
  const parsed = noteInput.parse(payload);
  const kind = parsed.kind ?? "note";
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, investNoteFeature(kind));
  const sql = await getSql();
  const symbol = normalizeSymbol(parsed.symbol ?? "");
  const noteTitle = requiredTitle(parsed.title, title);
  const body = requiredBody(parsed.body, summary, noteTitle);
  const rows = await sql<InvestNoteRow>`
    insert into invest_journal (user_id, symbol, kind, title, body)
    values (${userId}, ${symbol}, ${kind}, ${noteTitle}, ${body})
    returning id, symbol, kind, title, body, created_at, updated_at
  `;
  const mapped = rows[0] ? mapInvestNote(rows[0]) : null;
  if (!mapped) throw new Error("Note could not be saved.");
  return `Saved investment note ${mapped.id}.`;
};

const planInput = z.object({
  title: z.string().trim().max(INVEST_NOTE_TITLE_MAX).optional(),
  body: z.string().trim().max(INVEST_NOTE_BODY_MAX).optional(),
  horizon: z.string().trim().max(80).optional(),
  contribution: z.string().trim().max(80).optional(),
});

export const investPlanHandler: ToolHandler = async ({ userId, payload, title, summary }) => {
  const parsed = planInput.parse(payload);
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "investBasic");
  const planTitle = requiredTitle(parsed.title, title);
  const body = requiredBody(parsed.body, summary, planTitle);
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    insert into invest_plans (user_id, title, body, horizon, contribution)
    values (${userId}, ${planTitle}, ${body}, ${parsed.horizon ?? ""}, ${parsed.contribution ?? ""})
    returning id
  `;
  const id = Number(rows[0]?.id);
  if (!Number.isInteger(id) || id < 1) throw new Error("Plan could not be saved.");
  return `Saved investment plan ${id}. It does not guarantee a result, and it does not place an order.`;
};
