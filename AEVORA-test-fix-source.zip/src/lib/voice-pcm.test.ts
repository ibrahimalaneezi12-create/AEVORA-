import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  bargeThreshold,
  concatFloat32,
  createVadState,
  downsampleTo16k,
  encodeWavPcm16,
  hangoverMs,
  PcmRing,
  prerollSampleCount,
  rmsFloat,
  speechStartThreshold,
  stepVad,
  TARGET_SAMPLE_RATE,
  trimSilence,
} from "./voice-pcm.ts";

function tone(n: number, amp: number): Float32Array {
  const out = new Float32Array(n);
  for (let i = 0; i < n; i += 1) out[i] = amp * Math.sin((i / n) * Math.PI * 8);
  return out;
}

describe("pcm encode", () => {
  it("writes a valid wav header and keeps 16 kHz mono", () => {
    const wav = encodeWavPcm16(tone(160, 0.4));
    assert.equal(String.fromCharCode(wav[0]!, wav[1]!, wav[2]!, wav[3]!), "RIFF");
    assert.equal(wav.byteLength, 44 + 160 * 2);
    const rate = new DataView(wav.buffer).getUint32(24, true);
    assert.equal(rate, TARGET_SAMPLE_RATE);
  });

  it("downsamples 48 kHz without inventing extra energy", () => {
    const src = tone(480, 0.2);
    const down = downsampleTo16k(src, 48000);
    assert.equal(down.length, 160);
    assert.ok(rmsFloat(down) > 0.05);
    assert.ok(rmsFloat(down) < 0.3);
  });
});

describe("adaptive vad", () => {
  it("ignores quiet noise and catches normal and loud speech", () => {
    const state = createVadState();
    let started = false;
    for (let i = 0; i < 12; i += 1) {
      const r = stepVad(state, 0.006, 20);
      started = started || r.started;
    }
    assert.equal(started, false);
    const quietStart = speechStartThreshold(state.noiseFloor);
    assert.ok(0.006 < quietStart);

    let sawStart = false;
    for (let i = 0; i < 4; i += 1) {
      const r = stepVad(state, 0.04, 20);
      sawStart = sawStart || r.started;
    }
    assert.equal(sawStart, true);

    const loud = createVadState();
    stepVad(loud, 0.2, 20);
    const loudStart = stepVad(loud, 0.2, 20);
    assert.equal(loudStart.started, true);
  });

  it("ends shortly after a short sentence and holds a natural pause", () => {
    assert.equal(hangoverMs(200), 120);
    assert.equal(hangoverMs(1200), 240);
    const state = createVadState();
    stepVad(state, 0.08, 20);
    stepVad(state, 0.08, 20);
    let ended = false;
    for (let i = 0; i < 20; i += 1) {
      const r = stepVad(state, 0.001, 20);
      if (r.ended) ended = true;
    }
    assert.equal(ended, true);
  });

  it("needs a higher level to barge than to start speech", () => {
    const floor = 0.01;
    assert.ok(bargeThreshold(floor) > speechStartThreshold(floor));
  });
});

describe("preroll ring", () => {
  it("keeps the latest samples for onset", () => {
    const ring = new PcmRing(4);
    ring.write(Float32Array.from([1, 2, 3]));
    ring.write(Float32Array.from([4, 5]));
    assert.deepEqual(Array.from(ring.snapshot()), [2, 3, 4, 5]);
    const joined = concatFloat32([Float32Array.from([1]), Float32Array.from([2, 3])]);
    assert.deepEqual(Array.from(joined), [1, 2, 3]);
    assert.equal(prerollSampleCount(320), 5120);
  });

  it("trims leading and trailing silence but keeps a short pad", () => {
    const samples = new Float32Array(8000);
    for (let i = 3000; i < 5000; i += 1) samples[i] = 0.2;
    const trimmed = trimSilence(samples, 0.008, 80);
    assert.ok(trimmed.length < samples.length);
    assert.ok(trimmed.length > 2000);
    assert.ok(rmsFloat(trimmed) > 0.05);
  });
});
