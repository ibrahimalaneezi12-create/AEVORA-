import {
  classifyProviderFailure,
  logProviderFailure,
  readXaiApiKey,
  userFacingMediaError,
  xaiBaseUrl,
} from "@/lib/ai/xai-env.server";
import {
  VIDEO_EDIT_MODEL,
  VIDEO_MODEL,
  buildVideoEditBody,
  buildVideoGenerationBody,
  type VideoAspect,
  type VideoResolution,
} from "@/lib/video-format";

export type VideoStartInput = {
  prompt: string;
  duration: number;
  aspectRatio: VideoAspect;
  resolution: VideoResolution;
  generateAudio: boolean;
  imageDataUrl?: string | null;
};

export type VideoStartResult =
  | { ok: true; requestId: string }
  | { ok: false; error: string; unavailable?: boolean };

export type VideoPollResult =
  | { ok: true; status: "pending" | "processing" }
  | { ok: true; status: "done"; url: string; duration: number | null }
  | { ok: true; status: "failed" | "expired"; error: string }
  | { ok: false; error: string; unavailable?: boolean };

function authHeaders(key: string): HeadersInit {
  return {
    Authorization: `Bearer ${key}`,
    "Content-Type": "application/json",
    Accept: "application/json",
  };
}

export function videoProviderAvailable(): boolean {
  return Boolean(readXaiApiKey());
}

function readJobId(json: unknown): string {
  if (!json || typeof json !== "object") return "";
  const body = json as { request_id?: unknown; id?: unknown; video?: { url?: unknown }; url?: unknown };
  const requestId = String(body.request_id || body.id || "").trim();
  if (requestId) return requestId;
  const url = String(body.video?.url || body.url || "").trim();
  if (url.startsWith("https://")) return `done:${url}`;
  return "";
}

function failFrom(status: number, bodyText: string, model: string, kind: string): VideoStartResult {
  logProviderFailure(kind, classifyProviderFailure(status, bodyText, model));
  return {
    ok: false,
    error: userFacingMediaError(status),
    unavailable: status === 401 || status === 403,
  };
}

export async function startVideoGeneration(input: VideoStartInput): Promise<VideoStartResult> {
  const key = readXaiApiKey();
  if (!key) return { ok: false, unavailable: true, error: "Video generation is unavailable right now." };
  const models = [VIDEO_MODEL, VIDEO_EDIT_MODEL].filter((name, i, all) => all.indexOf(name) === i);
  try {
    let lastStatus = 503;
    let lastModel = VIDEO_MODEL;
    let lastBody = "";
    for (const model of models) {
      lastModel = model;
      const body = { ...buildVideoGenerationBody(input), model };
      const res = await fetch(`${xaiBaseUrl()}/videos/generations`, {
        method: "POST",
        headers: authHeaders(key),
        body: JSON.stringify(body),
      });
      lastStatus = res.status;
      if (res.ok) {
        const json = await res.json();
        const requestId = readJobId(json);
        if (!requestId) return { ok: false, error: "Video provider did not return a job." };
        return { ok: true, requestId };
      }
      lastBody = await res.text().catch(() => "");
      logProviderFailure("video.generate", classifyProviderFailure(res.status, lastBody, model));
      if (res.status !== 403 && res.status !== 404) {
        return failFrom(res.status, lastBody, model, "video.generate");
      }
    }
    return failFrom(lastStatus, lastBody, lastModel, "video.generate");
  } catch {
    return { ok: false, error: "Video provider could not be reached." };
  }
}

export async function pollVideoGeneration(requestId: string): Promise<VideoPollResult> {
  const key = readXaiApiKey();
  if (!key) return { ok: false, unavailable: true, error: "Video generation is unavailable right now." };
  const id = requestId.trim();
  if (!id) return { ok: false, error: "Missing job." };
  if (id.startsWith("done:https://")) {
    return { ok: true, status: "done", url: id.slice(5), duration: null };
  }
  try {
    const res = await fetch(`${xaiBaseUrl()}/videos/${encodeURIComponent(id)}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${key}`, Accept: "application/json" },
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      logProviderFailure("video.poll", classifyProviderFailure(res.status, text, VIDEO_MODEL));
      if (res.status === 404) return { ok: true, status: "failed", error: "That render expired or was not found." };
      return { ok: false, error: userFacingMediaError(res.status) };
    }
    const json = (await res.json()) as {
      status?: string;
      video?: { url?: string; duration?: number };
      error?: string;
    };
    const status = String(json.status || "pending").toLowerCase();
    if (status === "done" || status === "completed") {
      const url = String(json.video?.url || "").trim();
      if (!url) return { ok: true, status: "failed", error: "Render finished without a file." };
      const duration = typeof json.video?.duration === "number" ? json.video.duration : null;
      return { ok: true, status: "done", url, duration };
    }
    if (status === "failed" || status === "expired") {
      return { ok: true, status: status === "expired" ? "expired" : "failed", error: "Render failed." };
    }
    return { ok: true, status: "pending" };
  } catch {
    return { ok: false, error: "Video provider could not be reached." };
  }
}

export async function startVideoEdit(input: {
  prompt: string;
  videoDataUri: string;
}): Promise<VideoStartResult> {
  const key = readXaiApiKey();
  if (!key) return { ok: false, unavailable: true, error: "Video editing is unavailable right now." };
  const body = buildVideoEditBody(input);
  try {
    let res = await fetch(`${xaiBaseUrl()}/videos/edits`, {
      method: "POST",
      headers: authHeaders(key),
      body: JSON.stringify(body),
    });
    if (res.status === 404) {
      await res.text().catch(() => "");
      res = await fetch(`${xaiBaseUrl()}/videos/generations`, {
        method: "POST",
        headers: authHeaders(key),
        body: JSON.stringify(body),
      });
    }
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return failFrom(res.status, text, VIDEO_EDIT_MODEL, "video.edit");
    }
    const json = await res.json();
    const requestId = readJobId(json);
    if (!requestId) return { ok: false, error: "Video edit did not return a job." };
    return { ok: true, requestId };
  } catch {
    return { ok: false, error: "Video provider could not be reached." };
  }
}

export async function fetchOwnedMediaBytes(url: string): Promise<{ mime: string; bytes: Uint8Array } | null> {
  const href = url.trim();
  if (!href.startsWith("https://")) return null;
  try {
    const res = await fetch(href);
    if (!res.ok) return null;
    const mime = (res.headers.get("content-type") || "video/mp4").split(";")[0]?.trim() || "video/mp4";
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes.byteLength < 32) return null;
    return { mime, bytes };
  } catch {
    return null;
  }
}
