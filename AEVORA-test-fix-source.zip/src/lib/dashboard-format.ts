import type { Goal, Task, TaskStatus } from "./goals-format.ts";
import { clipText, type Memory } from "./memory-format.ts";
import type { PermissionLevel } from "./orchestrator/types.ts";
import type { ChatWorkspaceId } from "./chat-workspace.ts";

export const DASHBOARD_PENDING_LIMIT = 8;
export const DASHBOARD_TASKS_LIMIT = 8;
export const DASHBOARD_GOALS_LIMIT = 6;
export const DASHBOARD_MEMORY_LIMIT = 4;
export const DASHBOARD_MEMORY_PREVIEW = 140;

const OPEN_TASK: ReadonlySet<TaskStatus> = new Set(["todo", "doing"]);

export type DueKind = "overdue" | "today";

export type DashboardPending = {
  id: number;
  conversationId: number | null;
  toolId: string;
  displayName: string;
  permissionLevel: PermissionLevel;
  title: string;
  summary: string;
  createdAt: string;
};

export type DashboardTask = {
  id: number;
  title: string;
  notes: string;
  status: TaskStatus;
  dueDate: string;
  dueKind: DueKind;
  goalId: number | null;
  goalTitle: string | null;
};

export type DashboardGoal = {
  id: number;
  title: string;
  targetDate: string | null;
  openTaskCount: number;
};

export type DashboardMemory = {
  id: number;
  kind: Memory["kind"];
  title: string;
  bodyPreview: string;
  pinned: boolean;
};

export type DashboardConversation = {
  id: number;
  title: string;
  updatedAt: string;
  workspace?: ChatWorkspaceId;
};

export type DashboardSnapshot = {
  greetingName: string;
  timezone: string;
  today: string;
  pendingTotal: number;
  pending: DashboardPending[];
  todaysTasks: DashboardTask[];
  activeGoals: DashboardGoal[];
  recentMemories: DashboardMemory[];
  lastConversation: DashboardConversation | null;
};

export function firstName(displayName: string | null | undefined): string {
  const t = displayName?.trim() ?? "";
  if (!t) return "there";
  return t.split(/\s+/)[0] ?? "there";
}

/** Calendar date `YYYY-MM-DD` in `timeZone`. Invalid zones fall back to UTC. */
export function calendarDateInZone(now: Date, timeZone: string): string {
  const zone = timeZone.trim() || "UTC";
  try {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: zone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).formatToParts(now);
    const year = parts.find((p) => p.type === "year")?.value;
    const month = parts.find((p) => p.type === "month")?.value;
    const day = parts.find((p) => p.type === "day")?.value;
    if (year && month && day) return `${year}-${month}-${day}`;
  } catch {
    // Invalid IANA zone.
  }
  return now.toISOString().slice(0, 10);
}

export function classifyDue(dueDate: string | null, today: string): DueKind | "upcoming" | "none" {
  if (!dueDate) return "none";
  if (dueDate < today) return "overdue";
  if (dueDate === today) return "today";
  return "upcoming";
}

export function pickTodaysTasks(tasks: Task[], today: string, limit = DASHBOARD_TASKS_LIMIT): Task[] {
  const due: Task[] = [];
  for (const task of tasks) {
    if (!OPEN_TASK.has(task.status)) continue;
    const kind = classifyDue(task.dueDate, today);
    if (kind === "overdue" || kind === "today") due.push(task);
  }
  due.sort((a, b) => {
    const ka = classifyDue(a.dueDate, today);
    const kb = classifyDue(b.dueDate, today);
    if (ka !== kb) return ka === "overdue" ? -1 : 1;
    if (a.dueDate !== b.dueDate) return (a.dueDate ?? "").localeCompare(b.dueDate ?? "");
    if (a.sortOrder !== b.sortOrder) return a.sortOrder - b.sortOrder;
    return a.id - b.id;
  });
  return due.slice(0, limit);
}

export function pickActiveGoals(goals: Goal[], limit = DASHBOARD_GOALS_LIMIT): Goal[] {
  return goals.filter((g) => g.status === "active").slice(0, limit);
}

export function pickRecentMemories(
  memories: Memory[],
  limit = DASHBOARD_MEMORY_LIMIT,
): Memory[] {
  return memories.slice(0, limit);
}

export function relativeLabel(iso: string, nowMs: number): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return "";
  const s = Math.round((nowMs - t) / 1000);
  if (s < 45) return "Just now";
  if (s < 3600) return `${Math.max(1, Math.round(s / 60))}m`;
  if (s < 86400) return `${Math.max(1, Math.round(s / 3600))}h`;
  const d = Math.round(s / 86400);
  if (d < 7) return `${d}d`;
  return iso.slice(0, 10);
}

export function composeDashboard(input: {
  displayName: string | null;
  timezone: string;
  now: Date;
  pendingTotal: number;
  pending: DashboardPending[];
  goals: Goal[];
  tasks: Task[];
  memories: Memory[];
  lastConversation: DashboardConversation | null;
}): DashboardSnapshot {
  const timezone = input.timezone.trim() || "UTC";
  const today = calendarDateInZone(input.now, timezone);
  const goalsById = new Map(input.goals.map((g) => [g.id, g]));
  const pickedTasks = pickTodaysTasks(input.tasks, today);
  const todaysTasks: DashboardTask[] = [];
  for (const task of pickedTasks) {
    const kind = classifyDue(task.dueDate, today);
    if (kind !== "overdue" && kind !== "today") continue;
    todaysTasks.push({
      id: task.id,
      title: task.title,
      notes: task.notes,
      status: task.status,
      dueDate: task.dueDate as string,
      dueKind: kind,
      goalId: task.goalId,
      goalTitle: task.goalId ? (goalsById.get(task.goalId)?.title ?? null) : null,
    });
  }
  const activeGoals = pickActiveGoals(input.goals).map((goal) => ({
    id: goal.id,
    title: goal.title,
    targetDate: goal.targetDate,
    openTaskCount: input.tasks.filter(
      (t) => t.goalId === goal.id && OPEN_TASK.has(t.status),
    ).length,
  }));
  const recentMemories = pickRecentMemories(input.memories).map((row) => ({
    id: row.id,
    kind: row.kind,
    title: row.title,
    bodyPreview: clipText(row.body, DASHBOARD_MEMORY_PREVIEW),
    pinned: row.pinned,
  }));
  return {
    greetingName: firstName(input.displayName),
    timezone,
    today,
    pendingTotal: Math.max(0, input.pendingTotal),
    pending: input.pending.slice(0, DASHBOARD_PENDING_LIMIT),
    todaysTasks,
    activeGoals,
    recentMemories,
    lastConversation: input.lastConversation,
  };
}
