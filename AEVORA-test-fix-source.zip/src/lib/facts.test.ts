import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { answerFact } from "./facts.ts";

describe("deterministic facts", () => {
  it("answers time and date from the given instant, not a guess", () => {
    const now = new Date("2026-09-19T20:15:00.000Z");
    const time = answerFact("What time is it?", { now, timeZone: "UTC" });
    assert.equal(time?.kind, "time");
    assert.match(time?.text ?? "", /8:15 PM \(UTC\)/);
    const date = answerFact("What date is it?", { now, timeZone: "UTC" });
    assert.equal(date?.kind, "date");
    assert.match(date?.text ?? "", /September 19, 2026/);
    const day = answerFact("What day is it?", { now, timeZone: "UTC" });
    assert.equal(day?.kind, "day");
    assert.match(day?.text ?? "", /Saturday/);
  });

  it("evaluates arithmetic without a model", () => {
    assert.equal(answerFact("What is 284 × 17?", { now: new Date(), timeZone: "UTC" })?.text, "4828");
    assert.equal(answerFact("17 times 24", { now: new Date(), timeZone: "UTC" })?.text, "408");
  });

  it("converts units", () => {
    assert.equal(answerFact("Convert 5 miles to kilometers", { now: new Date(), timeZone: "UTC" })?.text, "8.047");
  });

  it("does not steal reminder or chat turns", () => {
    assert.equal(answerFact("Remind me at 8.", { now: new Date(), timeZone: "UTC" }), null);
    assert.equal(answerFact("I'm bored.", { now: new Date(), timeZone: "UTC" }), null);
  });
});
