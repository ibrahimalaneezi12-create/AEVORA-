import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { isFollowUpTurn } from "./followup-format.ts";
import { classifyTurnIntent } from "./intent-format.ts";

describe("follow-up turns", () => {
  it("treats make-it / move-that as follow-ups", () => {
    assert.equal(isFollowUpTurn("Make it 8."), true);
    assert.equal(isFollowUpTurn("Move that to Thursday."), true);
    assert.equal(isFollowUpTurn("Actually make it 8."), true);
    assert.equal(classifyTurnIntent("Make it 8.").kind, "followup");
    assert.equal(classifyTurnIntent("Make it 8.").suppressMutations, false);
  });

  it("does not steal real new requests", () => {
    assert.equal(isFollowUpTurn("Remind me Friday."), false);
    assert.equal(isFollowUpTurn("Plan my week."), false);
    assert.equal(classifyTurnIntent("Remind me Friday.").kind, "reminder");
  });
});
