/**
 * Preview-only PGLite durability. Deployed AEVORA uses Neon (`DATABASE_URL`)
 * and never hits this path. The live keep used to live in process memory, so a
 * restart made a real email/password look like "invalid credentials."
 *
 * Disk under `.data/` survives hibernate/revive. Never stores secrets in the
 * diagnostic file — counts only.
 */
import { existsSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { PREVIEW_SESSION_STORAGE_KEY } from "./preview-session.ts";

export { PREVIEW_SESSION_STORAGE_KEY };

export const PREVIEW_DATA_ROOT = path.join(process.cwd(), ".data");
export const PGLITE_DATA_DIR = path.join(PREVIEW_DATA_ROOT, "pglite");
export const PGLITE_DUMP_PATH = path.join(PREVIEW_DATA_ROOT, "pglite-dump.tgz");
export const AUTH_DIAG_PATH = path.join(PREVIEW_DATA_ROOT, "auth-diag.json");

export function previewDbHasFiles(dir = PGLITE_DATA_DIR): boolean {
  return existsSync(path.join(dir, "PG_VERSION"));
}

export function previewDumpExists(file = PGLITE_DUMP_PATH): boolean {
  return existsSync(file);
}

export async function ensurePreviewDataRoot(): Promise<void> {
  await mkdir(PREVIEW_DATA_ROOT, { recursive: true });
}

export async function readDumpBlob(): Promise<Blob | null> {
  if (!previewDumpExists()) return null;
  const buf = await readFile(PGLITE_DUMP_PATH);
  return new Blob([buf]);
}

type Dumpable = {
  dumpDataDir: (compression?: "gzip" | "none") => Promise<File | Blob>;
  query: <T>(text: string, params?: unknown[]) => Promise<{ rows: T[] }>;
};

export async function snapshotPreviewDb(pg: Dumpable): Promise<void> {
  await ensurePreviewDataRoot();
  const dump = await pg.dumpDataDir("gzip");
  const buf = Buffer.from(await dump.arrayBuffer());
  const staged = `${PGLITE_DUMP_PATH}.tmp`;
  await writeFile(staged, buf);
  await writeFile(PGLITE_DUMP_PATH, buf);
  try {
    const { unlink } = await import("node:fs/promises");
    await unlink(staged);
  } catch {
    // Staged file is best-effort.
  }
  await writeAuthDiag(pg);
}

type Diag = {
  userCount: number;
  credentialAccounts: number;
  dumpedAt: string;
};

async function writeAuthDiag(pg: Dumpable): Promise<void> {
  try {
    const users = await pg.query<{ n: number }>(`select count(*)::int as n from "user"`);
    const creds = await pg.query<{ n: number }>(
      `select count(*)::int as n from "account" where "providerId" = $1`,
      ["credential"],
    );
    const diag: Diag = {
      userCount: users.rows[0]?.n ?? 0,
      credentialAccounts: creds.rows[0]?.n ?? 0,
      dumpedAt: new Date().toISOString(),
    };
    await writeFile(AUTH_DIAG_PATH, `${JSON.stringify(diag)}\n`);
  } catch {
    // Auth tables may not exist yet on a brand-new keep.
  }
}
