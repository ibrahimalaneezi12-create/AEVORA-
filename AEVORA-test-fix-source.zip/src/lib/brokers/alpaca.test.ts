import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  alpacaOrigin,
  alpacaRequest,
  assertModeOrigin,
  capabilitiesFromAccount,
  mapAlpacaOrderStatus,
  parseAccount,
  parseOrderList,
  parsePositions,
} from "./alpaca.server.ts";

describe("alpaca adapter", () => {
  it("keeps paper and live on different hosts", () => {
    assert.equal(alpacaOrigin("paper"), "https://paper-api.alpaca.markets");
    assert.equal(alpacaOrigin("live"), "https://api.alpaca.markets");
    assert.throws(() => assertModeOrigin("paper", "https://api.alpaca.markets/v2/orders"));
    assert.throws(() => assertModeOrigin("live", "https://paper-api.alpaca.markets/v2/orders"));
  });

  it("does not invent an account or a position", () => {
    assert.equal(parseAccount({}), null);
    assert.deepEqual(parsePositions({}), []);
    assert.deepEqual(parsePositions([{ symbol: "AAPL", qty: "2", market_value: "10" }]), [
      { symbol: "AAPL", qty: "2", side: "", marketValue: "10", unrealizedPl: "", currentPrice: "" },
    ]);
  });

  it("maps broker statuses without upgrading them", () => {
    assert.equal(mapAlpacaOrderStatus("pending_new"), "pending");
    assert.equal(mapAlpacaOrderStatus("partially_filled"), "partially_filled");
    assert.equal(mapAlpacaOrderStatus("rejected"), "rejected");
    assert.equal(mapAlpacaOrderStatus("accepted"), "accepted");
    assert.equal(mapAlpacaOrderStatus("filled"), "filled");
    assert.equal(mapAlpacaOrderStatus("done_for_day"), "done_for_day");
    assert.notEqual(mapAlpacaOrderStatus("accepted"), "filled");
    assert.notEqual(mapAlpacaOrderStatus("done_for_day"), "pending");
    assert.notEqual(mapAlpacaOrderStatus("done_for_day"), "filled");
    assert.deepEqual(parseOrderList([{ id: "1", status: "accepted", symbol: "AAPL", side: "buy" }, {}]), [
      { id: "1", status: "accepted", symbol: "AAPL", side: "buy", qty: "", notional: "", filledQty: "" },
    ]);
  });

  it("enables orders only when the account is allowed to trade", () => {
    const blocked = capabilitiesFromAccount(
      { id: "1", accountNumber: "1", status: "ACTIVE", equity: "1", cash: "1", tradingBlocked: true },
      true,
      true,
    );
    assert.equal(blocked.includes("order.create"), false);
    const open = capabilitiesFromAccount(
      { id: "1", accountNumber: "1", status: "ACTIVE", equity: "1", cash: "1", tradingBlocked: false },
      true,
      true,
    );
    assert.equal(open.includes("order.create"), true);
    assert.equal(open.includes("positions.read"), true);
  });

  it("sends paper orders only to the paper host", async () => {
    let seen = "";
    const result = await alpacaRequest({
      mode: "paper",
      path: "/v2/orders",
      method: "POST",
      keyId: "key-id-example",
      secret: "secret-example",
      body: { symbol: "AAPL", side: "buy", type: "market", time_in_force: "day", notional: "10" },
      fetchImpl: (async (url: string) => {
        seen = String(url);
        return new Response(JSON.stringify({ id: "ord-1", status: "accepted", symbol: "AAPL", side: "buy" }), {
          status: 200,
          headers: { "content-type": "application/json" },
        });
      }) as typeof fetch,
    });
    assert.equal(seen, "https://paper-api.alpaca.markets/v2/orders");
    assert.equal(result.ok, true);
  });
});
