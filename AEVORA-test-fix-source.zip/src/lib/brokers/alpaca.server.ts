/**
 * Alpaca Trading API. Paper and live are different hosts and different keys.
 * https://docs.alpaca.markets — paper: paper-api.alpaca.markets, live: api.alpaca.markets
 * This module never invents balances, positions, or fills.
 */

export type BrokerMode = "paper" | "live";

export type AlpacaAccount = {
  id: string;
  accountNumber: string;
  status: string;
  equity: string;
  cash: string;
  tradingBlocked: boolean;
};

export type AlpacaPosition = {
  symbol: string;
  qty: string;
  side: string;
  marketValue: string;
  unrealizedPl: string;
  currentPrice: string;
};

export type AlpacaOrderResult = {
  id: string;
  status: string;
  symbol: string;
  side: string;
  qty: string;
  notional: string;
  filledQty: string;
};

export type AlpacaCall =
  | { ok: true; status: number; body: unknown }
  | { ok: false; status: number; error: string };

const PAPER_ORIGIN = "https://paper-api.alpaca.markets";
const LIVE_ORIGIN = "https://api.alpaca.markets";

export function alpacaOrigin(mode: BrokerMode): string {
  return mode === "live" ? LIVE_ORIGIN : PAPER_ORIGIN;
}

export function assertModeOrigin(mode: BrokerMode, url: string): void {
  const origin = alpacaOrigin(mode);
  if (!url.startsWith(`${origin}/`)) {
    throw new Error("Broker host does not match the saved mode. Nothing was sent.");
  }
  if (mode === "paper" && url.startsWith(`${LIVE_ORIGIN}/`)) {
    throw new Error("Paper mode cannot call the live broker. Nothing was sent.");
  }
  if (mode === "live" && url.startsWith(`${PAPER_ORIGIN}/`)) {
    throw new Error("Live mode cannot call the paper broker. Nothing was sent.");
  }
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : null;
}

function str(value: unknown): string {
  if (typeof value === "string") return value;
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return "";
}

export function mapAlpacaOrderStatus(status: string): string {
  const s = status.trim().toLowerCase();
  if (s === "filled") return "filled";
  if (s === "partially_filled") return "partially_filled";
  if (s === "canceled" || s === "cancelled" || s === "expired") return "cancelled";
  if (s === "rejected") return "rejected";
  if (s === "accepted" || s === "accepted_for_bidding") return "accepted";
  if (s === "suspended") return "failed";
  if (
    s === "new" ||
    s === "pending_new" ||
    s === "pending_replace" ||
    s === "pending_cancel"
  ) {
    return "pending";
  }
  if (/^[a-z][a-z0-9_]{0,39}$/.test(s)) return s;
  return "unknown";
}

export function capabilitiesFromAccount(account: AlpacaAccount, positionsOk: boolean, ordersOk: boolean): string[] {
  const caps = ["account.read", "balance.read"];
  if (positionsOk) caps.push("positions.read");
  if (ordersOk) caps.push("orders.read");
  const active = account.status.toUpperCase() === "ACTIVE";
  if (active && !account.tradingBlocked) caps.push("order.create");
  return caps;
}

export function parseAccount(body: unknown): AlpacaAccount | null {
  const row = asRecord(body);
  if (!row || !str(row.id)) return null;
  return {
    id: str(row.id),
    accountNumber: str(row.account_number),
    status: str(row.status) || "unknown",
    equity: str(row.equity),
    cash: str(row.cash),
    tradingBlocked: row.trading_blocked === true || row.account_blocked === true,
  };
}

export function parsePositions(body: unknown): AlpacaPosition[] {
  if (!Array.isArray(body)) return [];
  const out: AlpacaPosition[] = [];
  for (const item of body) {
    const row = asRecord(item);
    if (!row || !str(row.symbol)) continue;
    out.push({
      symbol: str(row.symbol),
      qty: str(row.qty),
      side: str(row.side),
      marketValue: str(row.market_value),
      unrealizedPl: str(row.unrealized_pl),
      currentPrice: str(row.current_price),
    });
  }
  return out;
}

export function parseOrderList(body: unknown): AlpacaOrderResult[] {
  if (!Array.isArray(body)) return [];
  const out: AlpacaOrderResult[] = [];
  for (const item of body) {
    const order = parseOrder(item);
    if (order) out.push(order);
  }
  return out;
}

export function parseOrder(body: unknown): AlpacaOrderResult | null {
  const row = asRecord(body);
  if (!row || !str(row.id)) return null;
  return {
    id: str(row.id),
    status: mapAlpacaOrderStatus(str(row.status)),
    symbol: str(row.symbol),
    side: str(row.side),
    qty: str(row.qty),
    notional: str(row.notional),
    filledQty: str(row.filled_qty),
  };
}

export async function alpacaRequest(opts: {
  mode: BrokerMode;
  path: string;
  method?: "GET" | "POST";
  keyId: string;
  secret: string;
  body?: unknown;
  fetchImpl?: typeof fetch;
}): Promise<AlpacaCall> {
  const path = opts.path.startsWith("/") ? opts.path : `/${opts.path}`;
  const url = `${alpacaOrigin(opts.mode)}${path}`;
  assertModeOrigin(opts.mode, url);
  const fetchImpl = opts.fetchImpl ?? fetch;
  try {
    const res = await fetchImpl(url, {
      method: opts.method ?? "GET",
      headers: {
        "APCA-API-KEY-ID": opts.keyId,
        "APCA-API-SECRET-KEY": opts.secret,
        Accept: "application/json",
        ...(opts.body ? { "Content-Type": "application/json" } : {}),
      },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const text = await res.text();
    let body: unknown = null;
    if (text) {
      try {
        body = JSON.parse(text) as unknown;
      } catch {
        body = { message: text.slice(0, 180) };
      }
    }
    if (!res.ok) {
      const message = asRecord(body);
      const err = str(message?.message) || `Alpaca returned ${res.status}.`;
      const safe = err.replace(/[A-Za-z0-9_-]{12,}/g, "[redacted]").slice(0, 180);
      return { ok: false, status: res.status, error: safe || `Alpaca returned ${res.status}.` };
    }
    return { ok: true, status: res.status, body };
  } catch {
    return { ok: false, status: 0, error: "Alpaca could not be reached." };
  }
}
