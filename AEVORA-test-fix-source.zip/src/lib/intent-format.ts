import { languageFromAlias, lookupLanguage } from "./languages.ts";
import { decideKnowledge } from "./knowledge-format.ts";
import { isFollowUpTurn, followUpNote } from "./followup-format.ts";
import { looksLikeSafetyRequest, assessDigitalSafety, safetyPromptNote } from "./safety-format.ts";
import { isTradeRequest } from "./invest-format.ts";

export const INTENT_KINDS = [
  "conversation",
  "question",
  "search",
  "research",
  "reasoning",
  "planning",
  "edit",
  "create",
  "action",
  "reminder",
  "goals",
  "followup",
  "confirm",
  "language_switch",
  "memory",
  "business",
  "invest",
  "learning",
  "travel",
  "safety",
] as const;
export type IntentKind = (typeof INTENT_KINDS)[number];

export type TurnIntent = {
  kind: IntentKind;
  language: string | null;
  suppressMutations: boolean;
  note: string;
};

export type ProviderContextFlags = {
  keep: boolean;
  calendar: boolean;
  mail: boolean;
  business: boolean;
  invest: boolean;
};

const SWITCH_RE =
  /\b(?:switch(?:\s+the\s+language)?\s+to|talk(?:\s+to me)?\s+in|speak(?:\s+to me)?\s+in|responde?\s+en|antworte\s+auf|تحدث|تكلم)\s+([A-Za-zÀ-ÖØ-öø-ÿ\u0600-\u06FF\u0400-\u04FF\u0590-\u05FF]{2,32})\b/i;

const EXPLICIT_ACTION_RE =
  /\b(remind me|reminder|remember that|forget|delete|create a (?:task|goal)|add a (?:task|goal)|mark (?:that |it )?as done|move (?:that |it |the )|change (?:the |that |it )|break .{0,40} into|plan my (?:day|week)|daily briefing|save (?:this|that)|update (?:the |that )|cancel (?:that |the )?reminder|snooze|postpone)\b/i;

const CASUAL_RE =
  /^(?:i(?:['’]?m| am) (?:bored|tired|exhausted|sleepy)|i feel (?:bored|tired)|just chatting|hello|hi there|hey aegis|how are you|what'?s up|whats up|sup)\b/i;

const VAGUE_NEED_RE =
  /^(?:i (?:need to|should|ought to|wanna|want to) (?:study|work|focus|exercise) more[.!?]?)$/i;

const REMIND_RE = /\bremind me\b|\bذك[ّر]ني\b|\brecuérdame\b|\brappelez[- ]moi\b/i;
const PLAN_RE = /\bplan my (?:day|week|month)\b|\bdaily briefing\b|\bweekly review\b|\bhow did i do\b|\bwhat should i (?:work on|focus on|do(?: now)?|do first)\b|\bbiggest priority\b|\bwhat am i forgetting\b|\bwhat needs my (?:attention|decision)\b|\bwhat should i know\b|\bwhat changed\b|\bwhat is going wrong\b|\bhelp me (?:get )?ready for (?:school|work|the day|tomorrow)\b|\borganize my (?:day|week)\b/i;
const MEMORY_RE = /\bremember (?:that|this)\b|\bforget (?:that|this)\b|\bwhat did we decide\b/i;
const EDIT_RE = /\b(move|change|delete|mark|snooze|postpone|cancel|rename) (that|this|it|the)\b/i;
const GOAL_RE = /\b(goal|milestone|behind on|break .{0,40} into|create a task|add a task|new task)\b/i;
const SEARCH_RE =
  /\b(search for|look up|look it up|find me|google|search the web|what'?s the latest|is this true|browse for|find out (?:what|who))\b/i;
const RESEARCH_RE =
  /\b(research|compare (?:these|the|those)|investigate|dig into|sources on|what does the evidence)\b/i;
const FRESHNESS_RE =
  /\b(weather|forecast|news|headline|stock|score|who won|current price|latest)\b/i;
export const CALENDAR_RE =
  /\b(what do i have|what'?s my (?:day|week)|schedule|on my calendar|appointment|do i have anything)\b/i;
export const EMAIL_RE = /\b(email|inbox|unread|draft a (?:reply|response)|send (?:it|that|the email)|draft a message|rewrite this|change the tone)\b/i;
const CREATE_RE =
  /\b(write|draft|summarize|outline|create (?:a |an )?(?:message|script|study|plan|summary|video|photo|image)|make (?:me )?(?:a |an )?(?:video|tiktok|reel|short|montage|photo|image)|bring (?:it|this|that) to life|animate (?:this|that|it)|edit (?:this |the )?(?:photo|image|video|clip))\b/i;
const MISSION_RE =
  /\bhelp me (?:start|launch|build) (?:a |an |my |the )?(?:business|company|app|youtube|channel|store|website)\b|\bget my business ready\b|\blaunch my (?:business|app|channel)\b|\bi want to start (?:a |an |my )?(?:youtube|channel|business|company)\b/i;
const BUSINESS_RE =
  /\b(check my business|business briefing|business health|business morning|morning brief|end of day|why did (?:my |the )?(?:sales|revenue|costs?|conversion|customers|campaign)|why is .{0,80}?\bbusiness\b|find opportunities in (?:the |my )?business|find problems in (?:the |my )?business|my customers|my revenue|my pipeline|manage my business|help me (?:with|run) my business|my business|how(?:['’]s| is) (?:the |my )?business|weekly business (?:report|review)|business report|prepare my weekly business report|research my competitors|what have you been working on (?:for|in) (?:the |my )?business|what needs my attention in (?:the |my )?business|what should i focus on in (?:the |my )?business|what changed in (?:the |my )?business|check my (?:marketing|sales|customers|operations|finance)|business strategy|(?:let'?s |let us )?(?:test|try) (?:a |an )?(?:new )?(?:price|ad|landing page)|find ways to reduce costs|grow (?:my |the )?sales|plan to (?:grow|increase) (?:sales|revenue)|we decided\b.{0,80}\b(?:price|prices|discount|customer|product|competitor|margin))\b/i;
const INVEST_RE =
  /\b(analy[sz]e this investment|analy[sz]e my (?:investments|portfolio)|research this company|investment thesis|stock(?: price)?|shares of|etf|portfolio|watchlist|earnings|dividend|valuation|paper trade|investment plan|what changed in the market|watch these investments|how is my portfolio|how diversified|overexposed|rebalanc(?:e|ing|ed)?|bull case|bear case|base case|investment journal)\b/i;
const LEARNING_RE =
  /\b(quiz me|flashcards?|study plan|help me study|exam prep|teach me|explain this (?:to me )?like|practice questions?|revise (?:this|for))\b/i;
const TRAVEL_RE =
  /\b(trip to|itinerary|pack(?:ing)? list|flight(?:s)? to|hotel(?:s)? in|plan (?:a |my )?trip|travel to)\b/i;
const PERSONAL_INVEST_RE = /\bmy (?:investments?|portfolio|watchlist|holdings?|investment plan)\b/i;
const OWN_BROKER_RE =
  /\b(my broker|alpaca|broker connected|connected broker|paper account|live account)\b/i;

const TICKER_STOP = new Set(["AI", "API", "CEO", "CSS", "EU", "GPT", "HTML", "IT", "OK", "PDF", "SQL", "TV", "UK", "URL", "US", "USA"]);

/** Short all-caps ticker asks. "Compare Dola and GPT" stays general research. */
export function looksLikeTickerAsk(text: string): boolean {
  const t = text.trim();
  const one = t.match(/^research\s+([A-Za-z]{2,6})[.!?]?$/i);
  if (one?.[1] && one[1] === one[1].toUpperCase() && !TICKER_STOP.has(one[1])) return true;
  const pair = t.match(/^compare\s+([A-Za-z]{2,6})\s+and\s+([A-Za-z]{2,6})[.!?]?$/i);
  if (
    pair?.[1] &&
    pair[2] &&
    pair[1] === pair[1].toUpperCase() &&
    pair[2] === pair[2].toUpperCase() &&
    !TICKER_STOP.has(pair[1]) &&
    !TICKER_STOP.has(pair[2])
  ) {
    return true;
  }
  return false;
}

/** Equity compare needs a ticker. Product names stay general research. */
export function looksLikeCompanyCompare(text: string): boolean {
  const pair = text.trim().match(/^compare\s+(\S+)\s+and\s+(\S+?)[.!?]?$/i);
  if (!pair?.[1] || !pair[2]) return false;
  const raw = [pair[1], pair[2]];
  const filler = new Set(["THESE", "THOSE", "THEM", "THIS", "THAT"]);
  if (raw.some((token) => filler.has(token.toUpperCase()) || TICKER_STOP.has(token.toUpperCase()))) return false;
  const ticker = (token: string) => /^[A-Z]{2,6}$/.test(token);
  const title = (token: string) => /^[A-Z][a-z]{1,11}$/.test(token);
  if (!raw.every((token) => ticker(token) || title(token))) return false;
  return raw.some(ticker);
}

function looksLikeBusinessAsk(text: string): boolean {
  if (BUSINESS_RE.test(text)) return true;
  const t = text.trim().replace(/[.!?]+$/, "");
  return /^(?:find problems|find opportunities|how(?:['’]s| is) (?:the |my )?business|research my competitors|prepare my weekly business report)$/i.test(
    t,
  );
}

const BUSINESS_NOTE =
  "You are the same AEVORA, speaking as this user's business manager. Plain speech, not a dashboard. Use only assembled records and sources this turn retrieved. Separate fact, assumption, and uncertainty. If a figure is missing, say that source is not connected and do not estimate it. For how's the business, cover only sections that have evidence: health, what is going well, what needs attention, problems, why, opportunities, risks, work that actually happened, decisions needed, and one next step. A why-question is a detective pass: do not name a cause without evidence, and do not treat correlation as causation. An opportunity needs what, why, evidence, impact or 'not estimated', effort, risk, and next step. Experiments store only what the user states. Never invent revenue, customers, leads, or ad spend. Do not claim background monitoring. Saving identity is business.save. Notes and decisions are business.note. Experiments are business.experiment. If a saved decision conflicts, quote it and ask before changing it.";

const INVEST_NOTE =
  "You are the same AEVORA, speaking as this user's investment manager. Plain speech, not a trading terminal. No guaranteed returns. Do not predict the future as fact. Use current public sources only when this turn looked them up, and cite them. Do not describe holdings, balances, orders, or P/L unless they are in assembled context. A comparison does not declare a winner; missing metrics stay missing. Bull, base, and bear are scenarios, not forecasts, and they get no prices unless those prices are already in context. A thesis uses thesis, evidence, catalysts, risks, what would invalidate it, horizon, and review — only from what the user saved or this turn retrieved. A rebalance is a proposal, not an order, and only against a saved plan and returned holdings. A broker order is broker.order only when assembled context says this user is connected and they asked to invest or trade. Otherwise say nothing was sent. Never propose invest.trade. Watchlist is invest.watch. A plan is invest.plan. Journal is invest.note. Pending is not filled. Paper is not a live investment.";

const TRADE_NOTE =
  "The user asked to invest or place an order. If assembled context says a broker is connected and can create orders, propose broker.order with the exact symbol, side, and amount, and wait for approval. Otherwise say no broker is connected and that nothing was sent. Never say an order filled unless a broker response is already in context. Do not propose invest.trade.";

export function parseLanguageSwitch(text: string): string | null {
  const trimmed = text.trim();
  const match = trimmed.match(SWITCH_RE);
  if (match?.[1]) {
    const code = languageFromAlias(match[1]);
    if (code) return code;
  }
  const lower = trimmed.toLowerCase();
  if (/^(?:arabic|عربي|العربية)(?:\s+please)?[.!?]?$/.test(lower)) return "ar";
  if (/^(?:english)(?:\s+please)?[.!?]?$/.test(lower)) return "en";
  return null;
}

export function isExplicitAction(text: string): boolean {
  return EXPLICIT_ACTION_RE.test(text.trim());
}

export function isCasualSpeech(text: string): boolean {
  const t = text.trim();
  if (!t) return false;
  if (isExplicitAction(t)) return false;
  return CASUAL_RE.test(t) || VAGUE_NEED_RE.test(t);
}

const MUTATING_TOOLS = new Set([
  "memory.save",
  "memory.delete",
  "task.create",
  "task.update",
  "task.delete",
  "goal.create",
  "goal.update",
  "reminder.create",
  "reminder.update",
  "reminder.snooze",
  "reminder.complete",
  "reminder.cancel",
  "conversation.delete",
  "profile.update",
  "calendar.create",
  "calendar.update",
  "calendar.delete",
  "email.draft",
  "email.send",
  "creation.save",
  "video.create",
  "video.generate",
  "video.edit",
  "photo.generate",
  "photo.edit",
  "business.save",
  "business.note",
  "invest.watch",
  "invest.unwatch",
  "invest.note",
]);

export function isMutatingToolId(toolId: string): boolean {
  return MUTATING_TOOLS.has(toolId);
}

export function shouldSuppressMutatingProposals(userText: string): boolean {
  return classifyTurnIntent(userText).suppressMutations;
}

export function classifyTurnIntent(text: string): TurnIntent {
  const trimmed = text.trim();
  const language = parseLanguageSwitch(trimmed);
  if (language && lookupLanguage(language)) {
    return {
      kind: "language_switch",
      language,
      suppressMutations: false,
      note: `User asked to switch the reply language to ${language}. Reply in that language. Do not create tasks or reminders.`,
    };
  }
  if (isCasualSpeech(trimmed)) {
    return {
      kind: "conversation",
      language: null,
      suppressMutations: true,
      note: "This turn is conversation. Do not propose tools, tasks, goals, or reminders.",
    };
  }
  if (REMIND_RE.test(trimmed)) {
    return {
      kind: "reminder",
      language: null,
      suppressMutations: false,
      note: "User asked to be reminded. Propose reminder.create with a real fire time. Do not invent a second reminder.",
    };
  }
  if (looksLikeSafetyRequest(trimmed)) {
    const verdict = assessDigitalSafety(trimmed);
    return {
      kind: "safety",
      language: null,
      suppressMutations: true,
      note: safetyPromptNote(verdict),
    };
  }
  if (isTradeRequest(trimmed)) {
    return {
      kind: "invest",
      language: null,
      suppressMutations: true,
      note: TRADE_NOTE,
    };
  }
  if (OWN_BROKER_RE.test(trimmed)) {
    return {
      kind: "invest",
      language: null,
      suppressMutations: false,
      note: INVEST_NOTE,
    };
  }
  if (INVEST_RE.test(trimmed) || looksLikeTickerAsk(trimmed) || looksLikeCompanyCompare(trimmed)) {
    return {
      kind: "invest",
      language: null,
      suppressMutations: false,
      note: INVEST_NOTE,
    };
  }
  if (looksLikeBusinessAsk(trimmed)) {
    return {
      kind: "business",
      language: null,
      suppressMutations: false,
      note: BUSINESS_NOTE,
    };
  }
  if (MISSION_RE.test(trimmed)) {
    return {
      kind: "planning",
      language: null,
      suppressMutations: false,
      note: "This is a mission. Structure as goal → research → plan → tasks → calendar/reminders. Propose at most one goal.create and up to three task.create items. Wait for approval. Do not invent a dashboard or claim work is done.",
    };
  }
  if (RESEARCH_RE.test(trimmed) || decideKnowledge(trimmed).action === "research") {
    return {
      kind: "research",
      language: null,
      suppressMutations: true,
      note: "Research this with current sources. Prefer official/primary sources. Synthesize, compare, cite. Do not fabricate. If sources disagree, say so. Do not propose search.web. Do not create tasks.",
    };
  }
  if (SEARCH_RE.test(trimmed) || FRESHNESS_RE.test(trimmed) || decideKnowledge(trimmed).action === "search") {
    return {
      kind: "search",
      language: null,
      suppressMutations: true,
      note: "Look up current public information. Prefer official documentation and primary sources. Cite. Do not invent entities, versions, or prices. Do not propose search.web. Do not create tasks.",
    };
  }
  if (LEARNING_RE.test(trimmed)) {
    return {
      kind: "learning",
      language: null,
      suppressMutations: false,
      note: "Learning request. Explain at the level they asked for. Do not invent their skill level. A study plan may propose at most three task.create items after they ask to save it. Quizzes stay in chat unless they ask to remember something.",
    };
  }
  if (TRAVEL_RE.test(trimmed)) {
    return {
      kind: "travel",
      language: null,
      suppressMutations: false,
      note: "Travel planning. Use current public sources for places, visas, and typical costs. Never invent flight or hotel availability. Packing lists and itineraries are suggestions. Reminders and calendar writes need approval.",
    };
  }
  if (EMAIL_RE.test(trimmed)) {
    return {
      kind: "action",
      language: null,
      suppressMutations: false,
      note: "Email or message request. Drafts are email.draft. Sending is email.send and needs explicit approval. Never claim sent unless approved. If Gmail is not connected, say so and keep a draft. Tone changes stay in chat unless they ask to send.",
    };
  }
  if (CALENDAR_RE.test(trimmed)) {
    return {
      kind: "action",
      language: null,
      suppressMutations: false,
      note: "Calendar request. Use assembled calendar context. Do not invent events. Writes are calendar.create / calendar.update / calendar.delete.",
    };
  }
  if (CREATE_RE.test(trimmed) && !isExplicitAction(trimmed)) {
    return {
      kind: "create",
      language: null,
      suppressMutations: false,
      note: "Creation or Studio request. Use assembled Studio context if present. Propose photo.generate, photo.edit, video.create, video.generate, or video.edit only when they asked. Originals stay. Do not claim a render finished unless a job completed.",
    };
  }
  if (PLAN_RE.test(trimmed)) {
    return {
      kind: "planning",
      language: null,
      suppressMutations: false,
      note: "User asked for a plan or briefing. Use assembled context only. Do not fabricate tasks, deadlines, or calendar events. Do not create items unless they asked to save the plan.",
    };
  }
  if (MEMORY_RE.test(trimmed)) {
    return {
      kind: "memory",
      language: null,
      suppressMutations: false,
      note: "Memory request. Propose memory.save / memory.delete / memory.search using ids from context. Do not silent-save.",
    };
  }
  if (isFollowUpTurn(trimmed)) {
    return {
      kind: "followup",
      language: null,
      suppressMutations: false,
      note: followUpNote(),
    };
  }
  if (EDIT_RE.test(trimmed)) {
    return {
      kind: "edit",
      language: null,
      suppressMutations: false,
      note: "User wants to change existing keep data. Resolve the referenced id from context. If two objects could match, ask — do not guess.",
    };
  }
  if (GOAL_RE.test(trimmed)) {
    return {
      kind: "goals",
      language: null,
      suppressMutations: false,
      note: "Goal/task request. Use real ids. Breaking a goal into steps may propose up to three task.create items.",
    };
  }
  return {
    kind: "question",
    language: null,
    suppressMutations: false,
    note: "Answer from conversation and assembled context. Only propose a tool when the user asked to change the keep.",
  };
}

export function intentPromptLine(intent: TurnIntent): string {
  return `Turn intent: ${intent.kind}. ${intent.note}`;
}

export function intentWantsSearch(intent: TurnIntent, text = ""): boolean {
  if (
    intent.kind === "search" ||
    intent.kind === "research" ||
    intent.kind === "invest" ||
    intent.kind === "travel"
  ) {
    return true;
  }
  return intent.kind === "business" && /\b(competitors?|research)\b/i.test(text);
}

export function intentWantsResearch(intent: TurnIntent, text = ""): boolean {
  if (intent.kind === "research" || intent.kind === "invest") return true;
  return intent.kind === "business" && /\b(competitors?|research)\b/i.test(text);
}

export function intentNeedsKeep(intent: TurnIntent, text = ""): boolean {
  if (intent.kind === "invest") return PERSONAL_INVEST_RE.test(text);
  return (
    intent.kind !== "conversation" &&
    intent.kind !== "language_switch" &&
    intent.kind !== "search" &&
    intent.kind !== "research" &&
    intent.kind !== "safety"
  );
}

export function intentNeedsCalendar(intent: TurnIntent, text: string): boolean {
  return intent.kind === "planning" || intent.kind === "travel" || CALENDAR_RE.test(text);
}

export function intentNeedsMail(intent: TurnIntent, text: string): boolean {
  return EMAIL_RE.test(text);
}

export function intentNeedsBusiness(intent: TurnIntent): boolean {
  return intent.kind === "business";
}

export function intentNeedsInvest(intent: TurnIntent, text: string): boolean {
  if (PERSONAL_INVEST_RE.test(text) || OWN_BROKER_RE.test(text) || isTradeRequest(text)) return true;
  if (intent.kind !== "invest") return false;
  if (/^(?:what (?:is|are)|explain|define)\b/i.test(text) && !PERSONAL_INVEST_RE.test(text)) return false;
  return /\b(portfolio|holdings|positions|diversif|concentrat|allocation|watchlist|watch\b|investment plan|journal|thesis|paper trade|broker|rebalanc(?:e|ing|ed)?|bull case|bear case|base case|overexposed|how diversified)\b/i.test(
    text,
  );
}

export function needsBusinessAndInvest(text: string): boolean {
  return /\b(?:afford to invest|business (?:can |could )?afford|invest (?:from|using) (?:the )?business)\b/i.test(text);
}

export function brokerOrderAllowed(text: string): boolean {
  return isTradeRequest(text);
}

export function providerContextFlags(intent: TurnIntent, text: string): ProviderContextFlags {
  const both = needsBusinessAndInvest(text);
  return {
    keep: intentNeedsKeep(intent, text),
    calendar: intentNeedsCalendar(intent, text),
    mail: intentNeedsMail(intent, text),
    business: intentNeedsBusiness(intent) || both,
    invest: intentNeedsInvest(intent, text) || both,
  };
}
