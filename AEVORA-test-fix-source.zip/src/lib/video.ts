import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { GENERIC_NOT_FOUND } from "@/lib/privacy";
import type { ToolHandler } from "@/lib/tools/types";
import {
  VIDEO_CAPTION_MAX,
  VIDEO_IMAGE_MAX_BYTES,
  VIDEO_MODEL,
  VIDEO_PROMPT_MAX,
  VIDEO_PROVIDER,
  VIDEO_TITLE_MAX,
  applyNaturalEdit,
  applyStudioControls,
  asVideoAspect,
  asVideoResolution,
  asVideoStatus,
  clampSceneDuration,
  planVideoRequest,
  qualityGate,
  snapshotPlan,
  VIDEO_CAPABILITIES,
  type VideoJob,
  type VideoPlan,
  type VideoProject,
  type VideoScene,
  type VideoVersion,
} from "@/lib/video-format";

export type { VideoJob, VideoProject, VideoScene, VideoVersion };
export { VIDEO_CAPABILITIES, planVideoRequest, applyNaturalEdit, applyStudioControls };

type ProjectRow = {
  id: unknown;
  user_id: string;
  title: string;
  description: string;
  status: string;
  aspect_ratio: string;
  resolution: string;
  generate_audio: boolean;
  captions: string;
  captions_locale: string;
  brief: string;
  created_at: unknown;
  updated_at: unknown;
};

type SceneRow = {
  id: unknown;
  project_id: unknown;
  sort_order: unknown;
  title: string;
  prompt: string;
  duration_sec: unknown;
  camera: string;
  status: string;
  error: string;
  media_url: string;
};

type JobRow = {
  id: unknown;
  project_id: unknown;
  scene_id: unknown;
  kind: string;
  status: string;
  model: string;
  error: string;
  duration_sec: unknown;
  resolution: string;
  aspect_ratio: string;
  created_at: unknown;
  updated_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

function mapScene(row: SceneRow): VideoScene | null {
  const id = asId(row.id);
  const projectId = asId(row.project_id);
  if (!id || !projectId) return null;
  return {
    id,
    projectId,
    sortOrder: Number(row.sort_order) || 0,
    title: row.title,
    prompt: row.prompt,
    durationSec: clampSceneDuration(row.duration_sec),
    camera: row.camera,
    status: asVideoStatus(row.status),
    error: row.error || "",
    hasMedia: Boolean(row.media_url),
  };
}

function mapProject(row: ProjectRow, scenes: VideoScene[]): VideoProject | null {
  const id = asId(row.id);
  if (!id) return null;
  return {
    id,
    title: row.title,
    description: row.description,
    status: asVideoStatus(row.status),
    aspectRatio: asVideoAspect(row.aspect_ratio),
    resolution: asVideoResolution(row.resolution),
    generateAudio: Boolean(row.generate_audio),
    captions: row.captions || "",
    captionsLocale: row.captions_locale || "en",
    brief: row.brief || "",
    scenes,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function mapJob(row: JobRow): VideoJob | null {
  const id = asId(row.id);
  const projectId = asId(row.project_id);
  if (!id || !projectId) return null;
  return {
    id,
    projectId,
    sceneId: asId(row.scene_id) || null,
    kind: row.kind,
    status: asVideoStatus(row.status),
    model: row.model,
    error: row.error || "",
    durationSec: row.duration_sec == null ? null : clampSceneDuration(row.duration_sec),
    resolution: row.resolution,
    aspectRatio: row.aspect_ratio,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

async function loadScenes(userId: string, projectId: number): Promise<VideoScene[]> {
  const sql = await getSql();
  const rows = await sql<SceneRow>`
    select id, project_id, sort_order, title, prompt, duration_sec, camera, status, error, media_url
    from video_scenes
    where user_id = ${userId} and project_id = ${projectId}
    order by sort_order asc, id asc
  `;
  const out: VideoScene[] = [];
  for (const row of rows) {
    const mapped = mapScene(row);
    if (mapped) out.push(mapped);
  }
  return out;
}

async function loadProject(userId: string, projectId: number): Promise<VideoProject | null> {
  const sql = await getSql();
  const rows = await sql<ProjectRow>`
    select id, user_id, title, description, status, aspect_ratio, resolution, generate_audio,
           captions, captions_locale, brief, created_at, updated_at
    from video_projects
    where id = ${projectId} and user_id = ${userId}
  `;
  const row = rows[0];
  if (!row) return null;
  return mapProject(row, await loadScenes(userId, projectId));
}

async function insertScenes(userId: string, projectId: number, plan: VideoPlan): Promise<void> {
  const sql = await getSql();
  await sql`delete from video_scenes where project_id = ${projectId} and user_id = ${userId}`;
  let order = 0;
  for (const scene of plan.scenes) {
    await sql`
      insert into video_scenes (project_id, user_id, sort_order, title, prompt, duration_sec, camera, status)
      values (
        ${projectId},
        ${userId},
        ${order},
        ${scene.title.slice(0, 80)},
        ${scene.prompt.slice(0, VIDEO_PROMPT_MAX)},
        ${scene.durationSec},
        ${scene.camera.slice(0, 80)},
        ${"draft"}
      )
    `;
    order += 1;
  }
}

async function snapshot(userId: string, project: VideoProject, label: string): Promise<void> {
  const sql = await getSql();
  const json = snapshotPlan({
    title: project.title,
    description: project.description,
    aspectRatio: project.aspectRatio,
    resolution: project.resolution,
    generateAudio: project.generateAudio,
    captions: project.captions,
    scenes: project.scenes.map((s) => ({
      title: s.title,
      prompt: s.prompt,
      durationSec: s.durationSec,
      camera: s.camera,
    })),
  });
  await sql`
    insert into video_versions (project_id, user_id, label, snapshot_json)
    values (${project.id}, ${userId}, ${label.slice(0, 80)}, ${json})
  `;
}

async function recordUsage(
  userId: string,
  jobId: number | null,
  operation: string,
  status: string,
  durationSec: number,
  resolution: string,
): Promise<void> {
  const sql = await getSql();
  await sql`
    insert into video_usage (user_id, job_id, model, operation, duration_sec, resolution, status)
    values (${userId}, ${jobId}, ${VIDEO_MODEL}, ${operation}, ${durationSec}, ${resolution}, ${status})
  `;
}

const briefPayload = z.object({
  brief: z.string().min(1).max(VIDEO_PROMPT_MAX),
  imageDataUrl: z.string().max(VIDEO_IMAGE_MAX_BYTES * 2).optional(),
  aspectRatio: z.enum(["16:9", "9:16", "1:1", "4:3", "3:4", "3:2", "2:3"]).optional(),
  resolution: z.enum(["480p", "720p", "1080p"]).optional(),
  durationSec: z.number().int().min(1).max(15).optional(),
  generateAudio: z.boolean().optional(),
});

const idPayload = z.object({ id: z.number().int().positive() });
const editPayload = z.object({
  id: z.number().int().positive(),
  instruction: z.string().min(1).max(VIDEO_PROMPT_MAX),
});
const captionPayload = z.object({
  id: z.number().int().positive(),
  captions: z.string().max(VIDEO_CAPTION_MAX),
  locale: z.string().max(12).optional(),
});
const generatePayload = z.object({
  id: z.number().int().positive(),
  sceneId: z.number().int().positive().optional(),
  imageDataUrl: z.string().max(VIDEO_IMAGE_MAX_BYTES * 2).optional(),
});

function sanitizeImage(dataUrl: string | undefined): string | null {
  if (!dataUrl) return null;
  if (!dataUrl.startsWith("data:image/")) return null;
  if (dataUrl.length > VIDEO_IMAGE_MAX_BYTES * 1.4) return null;
  return dataUrl;
}

export const listVideoProjects = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<VideoProject[]> => {
    const sql = await getSql();
    const rows = await sql<ProjectRow>`
      select id, user_id, title, description, status, aspect_ratio, resolution, generate_audio,
             captions, captions_locale, brief, created_at, updated_at
      from video_projects
      where user_id = ${context.userId}
      order by updated_at desc
      limit 40
    `;
    const out: VideoProject[] = [];
    for (const row of rows) {
      const mapped = mapProject(row, []);
      if (mapped) out.push(mapped);
    }
    return out;
  });

export const getVideoProject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idPayload.parse(input))
  .handler(async ({ context, data }): Promise<VideoProject> => {
    const project = await loadProject(context.userId, data.id);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
  });

export const getVideoCapabilities = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async () => {
    const { videoProviderAvailable } = await import("@/lib/video-provider.server");
    return { ...VIDEO_CAPABILITIES, available: videoProviderAvailable() };
  });

export async function createVideoProjectForUser(
  userId: string,
  data: {
    brief: string;
    imageDataUrl?: string;
    aspectRatio?: "16:9" | "9:16" | "1:1" | "4:3" | "3:4" | "3:2" | "2:3";
    resolution?: "480p" | "720p" | "1080p";
    durationSec?: number;
    generateAudio?: boolean;
  },
): Promise<VideoProject> {
  const planned = planVideoRequest(data.brief);
  const plan = applyStudioControls(planned, {
    aspectRatio: data.aspectRatio ?? planned.aspectRatio,
    resolution: data.resolution ?? planned.resolution,
    durationSec: data.durationSec ?? planned.scenes[0]?.durationSec ?? 8,
    generateAudio: data.generateAudio ?? planned.generateAudio,
  });
  const issues = qualityGate(plan);
  if (issues.length) throw new Error(issues[0]);
  const sql = await getSql();
  const rows = await sql<ProjectRow>`
    insert into video_projects (
      user_id, title, description, status, aspect_ratio, resolution, generate_audio, brief
    )
    values (
      ${userId},
      ${plan.title.slice(0, VIDEO_TITLE_MAX)},
      ${plan.description.slice(0, VIDEO_PROMPT_MAX)},
      ${"draft"},
      ${plan.aspectRatio},
      ${plan.resolution},
      ${plan.generateAudio},
      ${data.brief.slice(0, VIDEO_PROMPT_MAX)}
    )
    returning id, user_id, title, description, status, aspect_ratio, resolution, generate_audio,
              captions, captions_locale, brief, created_at, updated_at
  `;
  const created = rows[0];
  if (!created) throw new Error("Project could not be saved.");
  const projectId = asId(created.id);
  await insertScenes(userId, projectId, plan);
  const project = await loadProject(userId, projectId);
  if (!project) throw new Error(GENERIC_NOT_FOUND);
  await snapshot(userId, project, "Version 1");
  void data.imageDataUrl;
  return project;
}

export const createVideoProject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => briefPayload.parse(input))
  .handler(async ({ context, data }): Promise<VideoProject> => {
    return createVideoProjectForUser(context.userId, data);
  });

export async function editVideoProjectForUser(
  userId: string,
  data: { id: number; instruction: string },
): Promise<VideoProject> {
  const current = await loadProject(userId, data.id);
  if (!current) throw new Error(GENERIC_NOT_FOUND);
  const plan = applyNaturalEdit(
    {
      title: current.title,
      description: current.description,
      aspectRatio: current.aspectRatio,
      resolution: current.resolution,
      generateAudio: current.generateAudio,
      captions: current.captions,
      scenes: current.scenes.map((s) => ({
        title: s.title,
        prompt: s.prompt,
        durationSec: s.durationSec,
        camera: s.camera,
      })),
      notes: [],
    },
    data.instruction,
  );
  const sql = await getSql();
  await sql`
    update video_projects
    set
      title = ${plan.title.slice(0, VIDEO_TITLE_MAX)},
      description = ${plan.description.slice(0, VIDEO_PROMPT_MAX)},
      aspect_ratio = ${plan.aspectRatio},
      resolution = ${plan.resolution},
      generate_audio = ${plan.generateAudio},
      captions = ${plan.captions.slice(0, VIDEO_CAPTION_MAX)},
      updated_at = now()
    where id = ${current.id} and user_id = ${userId}
  `;
  await insertScenes(userId, current.id, plan);
  const next = await loadProject(userId, current.id);
  if (!next) throw new Error(GENERIC_NOT_FOUND);
  await snapshot(userId, next, `Edit: ${data.instruction.slice(0, 40)}`);
  return next;
}

export const editVideoProject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => editPayload.parse(input))
  .handler(async ({ context, data }): Promise<VideoProject> => {
    return editVideoProjectForUser(context.userId, data);
  });

export const saveVideoCaptions = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => captionPayload.parse(input))
  .handler(async ({ context, data }): Promise<VideoProject> => {
    const sql = await getSql();
    const rows = await sql<{ id: unknown }>`
      update video_projects
      set captions = ${data.captions.slice(0, VIDEO_CAPTION_MAX)},
          captions_locale = ${(data.locale || "en").slice(0, 12)},
          updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `;
    if (!rows[0]) throw new Error(GENERIC_NOT_FOUND);
    const project = await loadProject(context.userId, data.id);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    return project;
  });

export async function startRenderForUser(
  userId: string,
  data: { id: number; sceneId?: number; imageDataUrl?: string },
): Promise<{ project: VideoProject; job: VideoJob }> {
  const project = await loadProject(userId, data.id);
  if (!project) throw new Error(GENERIC_NOT_FOUND);
  const scene = data.sceneId
    ? project.scenes.find((s) => s.id === data.sceneId)
    : project.scenes[0];
  if (!scene) throw new Error("Add a scene first.");
  const { startVideoGeneration, videoProviderAvailable } = await import("@/lib/video-provider.server");
  if (!videoProviderAvailable()) {
    throw new Error("Video generation is unavailable right now.");
  }
  const image = sanitizeImage(data.imageDataUrl);
  const started = await startVideoGeneration({
    prompt: scene.prompt,
    duration: scene.durationSec,
    aspectRatio: project.aspectRatio,
    resolution: project.resolution,
    generateAudio: project.generateAudio,
    imageDataUrl: image,
  });
  const sql = await getSql();
  if (!started.ok) {
    const failed = await sql<JobRow>`
      insert into video_jobs (
        project_id, scene_id, user_id, kind, status, provider, model, error, duration_sec, resolution, aspect_ratio
      )
      values (
        ${project.id}, ${scene.id}, ${userId},
        ${image ? "image_to_video" : "generate"},
        ${"failed"}, ${VIDEO_PROVIDER}, ${VIDEO_MODEL}, ${started.error},
        ${scene.durationSec}, ${project.resolution}, ${project.aspectRatio}
      )
      returning id, project_id, scene_id, kind, status, model, error, duration_sec, resolution, aspect_ratio, created_at, updated_at
    `;
    await recordUsage(userId, asId(failed[0]?.id), image ? "image_to_video" : "generate", "failed", scene.durationSec, project.resolution);
    throw new Error(started.error);
  }
  const rows = await sql<JobRow>`
    insert into video_jobs (
      project_id, scene_id, user_id, kind, status, provider, model, provider_job_id, duration_sec, resolution, aspect_ratio
    )
    values (
      ${project.id}, ${scene.id}, ${userId},
      ${image ? "image_to_video" : "generate"},
      ${"processing"}, ${VIDEO_PROVIDER}, ${VIDEO_MODEL}, ${started.requestId},
      ${scene.durationSec}, ${project.resolution}, ${project.aspectRatio}
    )
    returning id, project_id, scene_id, kind, status, model, error, duration_sec, resolution, aspect_ratio, created_at, updated_at
  `;
  await sql`
    update video_scenes
    set status = ${"processing"}, provider_job_id = ${started.requestId}, error = ${""}, updated_at = now()
    where id = ${scene.id} and user_id = ${userId}
  `;
  await sql`
    update video_projects set status = ${"processing"}, updated_at = now()
    where id = ${project.id} and user_id = ${userId}
  `;
  const job = rows[0] ? mapJob(rows[0]) : null;
  if (!job) throw new Error("Render could not be queued.");
  await snapshot(userId, project, "Before render");
  await recordUsage(userId, job.id, job.kind, "processing", scene.durationSec, project.resolution);
  const next = await loadProject(userId, project.id);
  if (!next) throw new Error(GENERIC_NOT_FOUND);
  return { project: next, job };
}

export const startVideoRender = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => generatePayload.parse(input))
  .handler(async ({ context, data }) => startRenderForUser(context.userId, data));

export const pollVideoRender = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idPayload.parse(input))
  .handler(async ({ context, data }): Promise<{ project: VideoProject; job: VideoJob }> => {
    const sql = await getSql();
    const rows = await sql<JobRow & { provider_job_id: string; user_id: string }>`
      select id, project_id, scene_id, kind, status, model, error, duration_sec, resolution, aspect_ratio,
             created_at, updated_at, provider_job_id, user_id
      from video_jobs
      where id = ${data.id} and user_id = ${context.userId}
    `;
    const row = rows[0];
    if (!row) throw new Error(GENERIC_NOT_FOUND);
    let status = asVideoStatus(row.status);
    if (status === "processing" || status === "queued") {
      const { pollVideoGeneration } = await import("@/lib/video-provider.server");
      const poll = await pollVideoGeneration(row.provider_job_id);
      if (!poll.ok) {
        await sql`
          update video_jobs set error = ${poll.error}, updated_at = now()
          where id = ${data.id} and user_id = ${context.userId}
        `;
      } else if (poll.status === "done") {
        status = "completed";
        await sql`
          update video_jobs
          set status = ${"completed"}, media_url = ${poll.url}, error = ${""}, updated_at = now()
          where id = ${data.id} and user_id = ${context.userId}
        `;
        if (asId(row.scene_id)) {
          await sql`
            update video_scenes
            set status = ${"completed"}, media_url = ${poll.url}, error = ${""}, updated_at = now()
            where id = ${asId(row.scene_id)} and user_id = ${context.userId}
          `;
        }
        await sql`
          update video_projects set status = ${"completed"}, updated_at = now()
          where id = ${asId(row.project_id)} and user_id = ${context.userId}
        `;
        await recordUsage(context.userId, data.id, row.kind, "completed", clampSceneDuration(row.duration_sec), row.resolution);
      } else if (poll.status === "failed" || poll.status === "expired") {
        status = "failed";
        await sql`
          update video_jobs set status = ${"failed"}, error = ${poll.error}, updated_at = now()
          where id = ${data.id} and user_id = ${context.userId}
        `;
        if (asId(row.scene_id)) {
          await sql`
            update video_scenes
            set status = ${"failed"}, error = ${poll.error}, updated_at = now()
            where id = ${asId(row.scene_id)} and user_id = ${context.userId}
          `;
        }
        await recordUsage(context.userId, data.id, row.kind, "failed", clampSceneDuration(row.duration_sec), row.resolution);
      }
    }
    const jobRows = await sql<JobRow>`
      select id, project_id, scene_id, kind, status, model, error, duration_sec, resolution, aspect_ratio, created_at, updated_at
      from video_jobs where id = ${data.id} and user_id = ${context.userId}
    `;
    const job = jobRows[0] ? mapJob(jobRows[0]) : null;
    if (!job) throw new Error(GENERIC_NOT_FOUND);
    const project = await loadProject(context.userId, job.projectId);
    if (!project) throw new Error(GENERIC_NOT_FOUND);
    void status;
    return { project, job };
  });

export const cancelVideoRender = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idPayload.parse(input))
  .handler(async ({ context, data }): Promise<VideoJob> => {
    const sql = await getSql();
    const rows = await sql<JobRow>`
      update video_jobs
      set status = ${"cancelled"}, error = ${"Cancelled."}, updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
        and status in ('queued', 'processing')
      returning id, project_id, scene_id, kind, status, model, error, duration_sec, resolution, aspect_ratio, created_at, updated_at
    `;
    const job = rows[0] ? mapJob(rows[0]) : null;
    if (!job) throw new Error(GENERIC_NOT_FOUND);
    await recordUsage(context.userId, job.id, job.kind, "cancelled", job.durationSec ?? 0, job.resolution);
    return job;
  });

export const listVideoVersions = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idPayload.parse(input))
  .handler(async ({ context, data }): Promise<VideoVersion[]> => {
    const sql = await getSql();
    const rows = await sql<{ id: unknown; label: string; created_at: unknown }>`
      select id, label, created_at from video_versions
      where project_id = ${data.id} and user_id = ${context.userId}
      order by created_at desc
      limit 20
    `;
    return rows
      .map((row) => ({ id: asId(row.id), label: row.label, createdAt: toIso(row.created_at) }))
      .filter((row) => row.id > 0);
  });

export const listVideoJobs = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idPayload.parse(input))
  .handler(async ({ context, data }): Promise<VideoJob[]> => {
    const sql = await getSql();
    const rows = await sql<JobRow>`
      select id, project_id, scene_id, kind, status, model, error, duration_sec, resolution, aspect_ratio, created_at, updated_at
      from video_jobs
      where project_id = ${data.id} and user_id = ${context.userId}
      order by created_at desc
      limit 20
    `;
    const out: VideoJob[] = [];
    for (const row of rows) {
      const mapped = mapJob(row);
      if (mapped) out.push(mapped);
    }
    return out;
  });

export async function ownedVideoMedia(
  userId: string,
  sceneId: number,
): Promise<{ url: string } | null> {
  const sql = await getSql();
  const rows = await sql<{ media_url: string }>`
    select media_url from video_scenes
    where id = ${sceneId} and user_id = ${userId} and media_url <> ''
  `;
  const url = rows[0]?.media_url?.trim() ?? "";
  if (!url.startsWith("https://")) return null;
  return { url };
}

export const videoCreateHandler: ToolHandler = async ({ userId, summary, payload }) => {
  const brief =
    typeof payload === "object" && payload && "brief" in payload
      ? String((payload as { brief?: string }).brief || "")
      : summary;
  const plan = planVideoRequest(brief || summary);
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    insert into video_projects (user_id, title, description, status, aspect_ratio, resolution, generate_audio, brief)
    values (
      ${userId},
      ${plan.title.slice(0, VIDEO_TITLE_MAX)},
      ${plan.description.slice(0, VIDEO_PROMPT_MAX)},
      ${"draft"},
      ${plan.aspectRatio},
      ${plan.resolution},
      ${plan.generateAudio},
      ${(brief || summary).slice(0, VIDEO_PROMPT_MAX)}
    )
    returning id
  `;
  const id = asId(rows[0]?.id);
  if (!id) throw new Error("Project could not be saved.");
  await insertScenes(userId, id, plan);
  return `Created video project ${id}. Open Studio → Video to generate. Nothing rendered yet.`;
};

export const videoGenerateHandler: ToolHandler = async ({ userId, payload }) => {
  const parsed = generatePayload.parse(payload);
  await startRenderForUser(userId, parsed);
  return "Render started. Open Studio → Video to watch it finish. Nothing exports until the job completes.";
};
