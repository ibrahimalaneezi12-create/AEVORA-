/**
 * Preview vs production Grok/Better Auth credentials.
 * Production must never silently use the baked preview client or an ephemeral secret.
 */
export const PRODUCTION_AUTH_ENV_KEYS = [
  "GROK_AUTH_ISSUER",
  "GROK_AUTH_CLIENT_ID",
  "GROK_AUTH_CLIENT_SECRET",
  "BETTER_AUTH_URL",
  "BETTER_AUTH_SECRET",
  "DATABASE_URL",
] as const;

export type AuthEnv = Record<string, string | undefined>;

export function isDeployedAuthEnvironment(env: AuthEnv): boolean {
  const databaseUrl = env.DATABASE_URL?.trim();
  const vercel = env.VERCEL?.trim();
  return Boolean(databaseUrl) || vercel === "1" || vercel === "true";
}

export function missingProductionAuthEnv(env: AuthEnv): string[] {
  return PRODUCTION_AUTH_ENV_KEYS.filter((key) => !env[key]?.trim());
}

export function resolveBrokerCredentials(
  env: AuthEnv,
  preview: { issuer: string; clientId: string; clientSecret: string },
): {
  mode: "preview" | "production" | "production-invalid";
  missing: string[];
  issuer: string | undefined;
  clientId: string | undefined;
  clientSecret: string | undefined;
  secret: string | undefined;
  baseURL: string | undefined;
} {
  if (isDeployedAuthEnvironment(env)) {
    const missing = missingProductionAuthEnv(env);
    if (missing.length > 0) {
      return {
        mode: "production-invalid",
        missing,
        issuer: undefined,
        clientId: undefined,
        clientSecret: undefined,
        secret: undefined,
        baseURL: undefined,
      };
    }
    return {
      mode: "production",
      missing: [],
      issuer: env.GROK_AUTH_ISSUER!.trim(),
      clientId: env.GROK_AUTH_CLIENT_ID!.trim(),
      clientSecret: env.GROK_AUTH_CLIENT_SECRET!.trim(),
      secret: env.BETTER_AUTH_SECRET!.trim(),
      baseURL: env.BETTER_AUTH_URL!.trim(),
    };
  }
  return {
    mode: "preview",
    missing: [],
    issuer: env.GROK_AUTH_ISSUER?.trim() || preview.issuer,
    clientId: env.GROK_AUTH_CLIENT_ID?.trim() || preview.clientId,
    clientSecret: env.GROK_AUTH_CLIENT_SECRET?.trim() || preview.clientSecret,
    secret: env.BETTER_AUTH_SECRET?.trim(),
    baseURL: env.BETTER_AUTH_URL?.trim(),
  };
}

export const OAUTH_CALLBACK_PATH = "/api/auth/oauth2/callback/grok-google";

export function grokGoogleCallbackUrl(origin: string): string {
  return `${origin.replace(/\/+$/, "")}${OAUTH_CALLBACK_PATH}`;
}
