export const CREATION_KINDS = [
  "note",
  "message",
  "email",
  "plan",
  "summary",
  "outline",
  "study",
  "script",
  "other",
] as const;
export type CreationKind = (typeof CREATION_KINDS)[number];

export const CREATION_TITLE_MAX = 120;
export const CREATION_BODY_MAX = 12000;

export type Creation = {
  id: number;
  kind: CreationKind;
  title: string;
  body: string;
  locale: string;
  conversationId: number | null;
  createdAt: string;
  updatedAt: string;
};

export type CreationRow = {
  id: unknown;
  kind: string;
  title: string;
  body: string;
  locale: string;
  conversation_id: unknown;
  created_at: unknown;
  updated_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

export function asCreationKind(value: string | null | undefined): CreationKind {
  return (CREATION_KINDS as readonly string[]).includes(value ?? "")
    ? (value as CreationKind)
    : "note";
}

export function mapCreation(row: CreationRow): Creation | null {
  const id = asId(row.id);
  if (!id) return null;
  return {
    id,
    kind: asCreationKind(row.kind),
    title: row.title,
    body: row.body,
    locale: row.locale || "en",
    conversationId: asId(row.conversation_id) || null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}
