export const TARGET_SAMPLE_RATE = 16_000;
export const PREROLL_MS = 320;
export const MAX_UTTERANCE_MS = 20_000;
export const VAD_START_FRAMES = 2;
export const SHORT_HANGOVER_MS = 120;
export const LONG_HANGOVER_MS = 240;
export const SHORT_UTTERANCE_MS = 600;

export type VadState = {
  noiseFloor: number;
  speechFrames: number;
  silenceMs: number;
  speaking: boolean;
  speechMs: number;
};

export function createVadState(): VadState {
  return {
    noiseFloor: 0.01,
    speechFrames: 0,
    silenceMs: 0,
    speaking: false,
    speechMs: 0,
  };
}

export function rmsFloat(samples: Float32Array): number {
  if (samples.length === 0) return 0;
  let sum = 0;
  for (let i = 0; i < samples.length; i += 1) {
    const v = samples[i] ?? 0;
    sum += v * v;
  }
  return Math.sqrt(sum / samples.length);
}

export function speechStartThreshold(noiseFloor: number): number {
  return Math.max(0.012, noiseFloor * 2.5);
}

export function speechHoldThreshold(noiseFloor: number): number {
  return Math.max(0.007, noiseFloor * 1.65);
}

export function bargeThreshold(noiseFloor: number): number {
  return Math.max(0.05, noiseFloor * 6.5);
}

export function hangoverMs(speechMs: number): number {
  return speechMs < SHORT_UTTERANCE_MS ? SHORT_HANGOVER_MS : LONG_HANGOVER_MS;
}

export function stepVad(
  state: VadState,
  rms: number,
  frameMs: number,
): { started: boolean; ended: boolean; speaking: boolean } {
  const ms = Math.max(1, frameMs);
  if (!state.speaking) {
    state.noiseFloor = Math.max(0.0035, state.noiseFloor * 0.96 + rms * 0.04);
    if (rms >= speechStartThreshold(state.noiseFloor)) {
      state.speechFrames += 1;
      if (state.speechFrames >= VAD_START_FRAMES) {
        state.speaking = true;
        state.silenceMs = 0;
        state.speechMs = state.speechFrames * ms;
        return { started: true, ended: false, speaking: true };
      }
    } else {
      state.speechFrames = 0;
    }
    return { started: false, ended: false, speaking: false };
  }

  state.speechMs += ms;
  if (rms >= speechHoldThreshold(state.noiseFloor)) {
    state.silenceMs = 0;
    return { started: false, ended: false, speaking: true };
  }
  state.silenceMs += ms;
  if (state.silenceMs >= hangoverMs(state.speechMs)) {
    state.speaking = false;
    state.speechFrames = 0;
    state.silenceMs = 0;
    return { started: false, ended: true, speaking: false };
  }
  return { started: false, ended: false, speaking: true };
}

export function downsampleTo16k(input: Float32Array, fromRate: number): Float32Array {
  if (input.length === 0) return new Float32Array(0);
  if (!Number.isFinite(fromRate) || fromRate <= 0) return input;
  if (Math.abs(fromRate - TARGET_SAMPLE_RATE) < 1) return input.slice();
  const ratio = fromRate / TARGET_SAMPLE_RATE;
  const outLen = Math.max(1, Math.floor(input.length / ratio));
  const out = new Float32Array(outLen);
  for (let i = 0; i < outLen; i += 1) {
    const src = i * ratio;
    const i0 = Math.floor(src);
    const i1 = Math.min(input.length - 1, i0 + 1);
    const frac = src - i0;
    const a = input[i0] ?? 0;
    const b = input[i1] ?? 0;
    out[i] = a + (b - a) * frac;
  }
  return out;
}

export function encodeWavPcm16(samples: Float32Array, sampleRate = TARGET_SAMPLE_RATE): Uint8Array {
  const count = samples.length;
  const bytes = new Uint8Array(44 + count * 2);
  const view = new DataView(bytes.buffer);
  const writeStr = (offset: number, text: string) => {
    for (let i = 0; i < text.length; i += 1) bytes[offset + i] = text.charCodeAt(i);
  };
  writeStr(0, "RIFF");
  view.setUint32(4, 36 + count * 2, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, "data");
  view.setUint32(40, count * 2, true);
  let offset = 44;
  for (let i = 0; i < count; i += 1) {
    const s = Math.max(-1, Math.min(1, samples[i] ?? 0));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    offset += 2;
  }
  return bytes;
}

export class PcmRing {
  private buf: Float32Array;
  private writeAt = 0;
  private filled = 0;

  constructor(capacity: number) {
    this.buf = new Float32Array(Math.max(1, capacity));
  }

  write(chunk: Float32Array): void {
    for (let i = 0; i < chunk.length; i += 1) {
      this.buf[this.writeAt] = chunk[i] ?? 0;
      this.writeAt = (this.writeAt + 1) % this.buf.length;
      if (this.filled < this.buf.length) this.filled += 1;
    }
  }

  snapshot(): Float32Array {
    const out = new Float32Array(this.filled);
    const start = (this.writeAt - this.filled + this.buf.length) % this.buf.length;
    for (let i = 0; i < this.filled; i += 1) {
      out[i] = this.buf[(start + i) % this.buf.length] ?? 0;
    }
    return out;
  }
}

export function concatFloat32(parts: Float32Array[]): Float32Array {
  let total = 0;
  for (const part of parts) total += part.length;
  const out = new Float32Array(total);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

export function prerollSampleCount(ms = PREROLL_MS): number {
  return Math.round((TARGET_SAMPLE_RATE * ms) / 1000);
}

/** Drop leading/trailing near-silence so STT is not paid to transcribe hangover/preroll. */
export function trimSilence(
  samples: Float32Array,
  threshold = 0.008,
  padMs = 80,
): Float32Array {
  if (samples.length === 0) return samples;
  const pad = Math.round((TARGET_SAMPLE_RATE * padMs) / 1000);
  let start = 0;
  while (start < samples.length && Math.abs(samples[start] ?? 0) < threshold) start += 1;
  let end = samples.length - 1;
  while (end > start && Math.abs(samples[end] ?? 0) < threshold) end -= 1;
  if (start >= end) return samples.slice(0, Math.min(samples.length, pad));
  start = Math.max(0, start - pad);
  end = Math.min(samples.length - 1, end + pad);
  return samples.subarray(start, end + 1);
}
