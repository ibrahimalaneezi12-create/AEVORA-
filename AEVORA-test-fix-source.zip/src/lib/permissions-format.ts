import type { PermissionLevel } from "./orchestrator/types.ts";

/** User-set floor. Restricted is not a floor — it cannot be chosen or loosened. */
export const CONFIRM_FLOORS = ["safe", "review", "approval"] as const;
export type ConfirmFloor = (typeof CONFIRM_FLOORS)[number];

const RANK: Record<PermissionLevel, number> = {
  safe: 0,
  review: 1,
  approval: 2,
  restricted: 3,
};

export function asConfirmFloor(value: string | null | undefined): ConfirmFloor {
  if (value === "review" || value === "approval" || value === "safe") return value;
  return "safe";
}

/**
 * Effective confirmation level: the louder of catalog and floor.
 * Restricted stays Restricted. A quieter floor never lowers the catalog.
 */
export function effectiveLevel(
  catalog: PermissionLevel,
  floor: ConfirmFloor,
): PermissionLevel {
  if (catalog === "restricted") return "restricted";
  return RANK[catalog] >= RANK[floor] ? catalog : floor;
}

export function isConfirmFloor(value: string): value is ConfirmFloor {
  return (CONFIRM_FLOORS as readonly string[]).includes(value);
}

export type PermissionSettings = {
  confirmFloor: ConfirmFloor;
  autoRunSafe: false;
  autoRunReview: false;
  updatedAt: string;
};

export type PermissionSettingsRow = {
  confirm_floor: string | null;
  auto_run_safe: boolean;
  auto_run_review: boolean;
  updated_at: unknown;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

export function mapPermissionSettings(row: PermissionSettingsRow): PermissionSettings {
  return {
    confirmFloor: asConfirmFloor(row.confirm_floor),
    autoRunSafe: false,
    autoRunReview: false,
    updatedAt: toIso(row.updated_at),
  };
}
