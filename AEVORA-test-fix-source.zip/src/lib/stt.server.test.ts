import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { transcribeSpeech } from "./stt.server.ts";

describe("transcribeSpeech without a key", () => {
  it("does not invent a transcript when XAI_API_KEY is missing", async () => {
    const prev = process.env.XAI_API_KEY;
    delete process.env.XAI_API_KEY;
    try {
      const result = await transcribeSpeech({ audioBase64: Buffer.from("not-audio").toString("base64") });
      assert.equal(result.ok, false);
      if (result.ok) throw new Error("expected failure");
      assert.equal(result.unavailable, true);
      assert.match(result.error, /not available/i);
    } finally {
      if (prev === undefined) delete process.env.XAI_API_KEY;
      else process.env.XAI_API_KEY = prev;
    }
  });
});
