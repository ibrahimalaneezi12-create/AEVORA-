import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { isLiveVoicePhase, reduceVoice } from "./voice-machine.ts";

describe("voice state machine", () => {
  it("starts, listens, thinks, speaks, then listens again", () => {
    let phase = reduceVoice("idle", { type: "start" }).phase;
    assert.equal(phase, "permission");
    phase = reduceVoice(phase, { type: "mic_ready" }).phase;
    assert.equal(phase, "listening");
    phase = reduceVoice(phase, { type: "speech_start" }).phase;
    assert.equal(phase, "user_speaking");
    phase = reduceVoice(phase, { type: "speech_end" }).phase;
    assert.equal(phase, "thinking");
    phase = reduceVoice(phase, { type: "first_audio" }).phase;
    assert.equal(phase, "speaking");
    phase = reduceVoice(phase, { type: "playback_done" }).phase;
    assert.equal(phase, "listening");
    assert.equal(isLiveVoicePhase(phase), true);
  });

  it("barge-in from speaking goes interrupted then thinking", () => {
    let phase = reduceVoice("speaking", { type: "barge" }).phase;
    assert.equal(phase, "interrupted");
    phase = reduceVoice(phase, { type: "speech_end" }).phase;
    assert.equal(phase, "thinking");
  });

  it("does not leave disabled except via stop staying disabled", () => {
    assert.equal(reduceVoice("disabled", { type: "mic_ready" }).phase, "disabled");
    assert.equal(reduceVoice("disabled", { type: "stop" }).phase, "disabled");
  });

  it("permission denied stays on permission with an error", () => {
    const next = reduceVoice("permission", { type: "permission_denied" });
    assert.equal(next.phase, "permission");
    assert.match(next.error ?? "", /blocked/i);
  });

  it("returns to listening after a skipped or failed transcript", () => {
    assert.equal(reduceVoice("thinking", { type: "mic_ready" }).phase, "listening");
    assert.equal(reduceVoice("error", { type: "mic_ready" }).phase, "listening");
  });

  it("stop from a live session returns to idle", () => {
    assert.equal(reduceVoice("thinking", { type: "stop" }).phase, "idle");
    assert.equal(reduceVoice("speaking", { type: "stop" }).phase, "idle");
  });
});
