/**
 * Portfolio speech from a broker payload. Empty or missing fields stay missing.
 * Never fills in a price, balance, or return.
 */
import { z } from "zod";
import type { AlpacaAccount, AlpacaOrderResult, AlpacaPosition } from "./brokers/alpaca.server.ts";

export type BrokerSnapshot = {
  connected: boolean;
  verified: boolean;
  mode: "paper" | "live" | null;
  provider: string;
  capabilities: string[];
  account: AlpacaAccount | null;
  positions: AlpacaPosition[];
  orders: AlpacaOrderResult[];
  accountStatus: string;
  lastCheckedAt: string;
  error: string;
};

export function emptySnapshot(): BrokerSnapshot {
  return {
    connected: false,
    verified: false,
    mode: null,
    provider: "",
    capabilities: [],
    account: null,
    positions: [],
    orders: [],
    accountStatus: "",
    lastCheckedAt: "",
    error: "",
  };
}

export function portfolioSpeech(snapshot: BrokerSnapshot): string {
  if (!snapshot.connected) {
    return "No broker is connected. I can't see balances, holdings, or orders. Nothing was sent.";
  }
  if (snapshot.error && !snapshot.verified) {
    return `The broker did not return a portfolio. ${snapshot.error} I will not fill in numbers.`;
  }
  const mode = snapshot.mode === "live" ? "live" : "paper";
  const equity = snapshot.account?.equity;
  const cash = snapshot.account?.cash;
  const lines = [`Connected to Alpaca (${mode}).`];
  if (equity) lines.push(`Equity reported by the broker: ${equity}.`);
  else lines.push("The broker did not include equity.");
  if (cash) lines.push(`Cash reported by the broker: ${cash}.`);
  if (snapshot.positions.length === 0) {
    lines.push(
      snapshot.error && !snapshot.capabilities.includes("positions.read")
        ? "Positions were not read."
        : "The broker returned no open positions.",
    );
  } else {
    const held = snapshot.positions
      .slice(0, 8)
      .map((p) => `${p.symbol} ${p.qty || "qty not returned"}`)
      .join(", ");
    lines.push(`Open positions: ${held}.`);
  }
  const orders = snapshot.orders ?? [];
  if (!snapshot.capabilities.includes("orders.read")) {
    lines.push("Recent orders were not read.");
  } else if (orders.length === 0) lines.push("The broker returned no recent orders.");
  else {
    lines.push(
      `Recent orders: ${orders
        .slice(0, 6)
        .map((order) => `${order.symbol} ${order.side} ${order.status}`)
        .join(", ")}. A pending or accepted order is not filled.`,
    );
  }
  if (!snapshot.capabilities.includes("order.create")) {
    lines.push("This connection cannot place orders.");
  }
  if (snapshot.error) lines.push(snapshot.error);
  return lines.join(" ");
}

export function portfolioAnalysisSpeech(snapshot: BrokerSnapshot): string {
  const base = portfolioSpeech(snapshot);
  if (!snapshot.connected || snapshot.error) return base;
  const valued = snapshot.positions
    .map((position) => ({ symbol: position.symbol, value: Number(position.marketValue) }))
    .filter((position) => position.symbol && Number.isFinite(position.value) && position.value > 0);
  if (valued.length === 0) {
    return `${base} I can't measure concentration. The broker did not return market values. Sector and geography are not in this payload, so I will not estimate them. This is not a risk score.`;
  }
  const total = valued.reduce((sum, position) => sum + position.value, 0);
  const top = [...valued].sort((a, b) => b.value - a.value)[0];
  const share = top && total > 0 ? Math.round((top.value / total) * 100) : 0;
  return `${base} Largest reported position by market value: ${top?.symbol ?? "unknown"}, about ${share}% of the values the broker returned. Sector and geography are not in this payload, so I will not estimate them. This is not a risk score, and no return is guaranteed.`;
}

export function orderSpeech(status: string, symbol: string, mode: "paper" | "live"): string {
  const where = mode === "live" ? "live Alpaca" : "Alpaca paper";
  if (status === "filled") return `${where} reports the ${symbol} order is filled.`;
  if (status === "partially_filled") return `${where} reports the ${symbol} order is partially filled. It is not complete.`;
  if (status === "cancelled") return `${where} reports the ${symbol} order was cancelled. Nothing else was sent.`;
  if (status === "accepted") return `${where} accepted the ${symbol} order. It is not filled.`;
  if (status === "rejected" || status === "failed") return `${where} rejected the ${symbol} order. Nothing was filled.`;
  if (status === "pending") return `${where} reports the ${symbol} order is pending. It is not filled.`;
  return `${where} reports the ${symbol} order status as ${status || "unknown"}. It is not reported as filled.`;
}

export function mayUseBroker(sessionUserId: string, ownerUserId: string): boolean {
  return Boolean(sessionUserId) && sessionUserId === ownerUserId;
}

const orderIntent = z
  .object({
    symbol: z.string().trim().min(1).max(16),
    side: z.enum(["buy", "sell"]),
    notional: z.string().trim().max(32).optional(),
    qty: z.string().trim().max(32).optional(),
    mode: z.enum(["paper", "live"]).optional(),
    liveConfirm: z.boolean().optional(),
  })
  .strict();

export type OrderIntent = z.infer<typeof orderIntent>;

/** Client user ids and account ids are rejected, not trusted. */
export function parseOrderIntent(payload: unknown): OrderIntent | null {
  const parsed = orderIntent.safeParse(payload);
  return parsed.success ? parsed.data : null;
}

export function brokerStatusNote(link: {
  connected: boolean;
  mode: "paper" | "live" | null;
  accountStatus: string;
  capabilities: string[];
  error?: string;
}): string {
  if (!link.connected || (link.mode !== "paper" && link.mode !== "live")) {
    return "This user has no saved broker link. Do not invent a connection, a balance, or an order.";
  }
  const caps = link.capabilities.length ? link.capabilities.join(", ") : "none listed";
  const status = link.accountStatus ? ` Last saved account status: ${link.accountStatus}.` : "";
  const problem = link.error ? ` Last check: ${link.error}` : "";
  return `This user has a saved Alpaca ${link.mode} link.${status} Capabilities on file: ${caps}.${problem} Do not say no broker is connected. Do not invent balances, positions, or fills. Those appear only when this turn actually read them.`;
}

export function brokerClientOrderId(proposalId: number | undefined): string {
  if (typeof proposalId !== "number" || !Number.isInteger(proposalId) || proposalId < 1) return "";
  return `aegis-${proposalId}`;
}

export function comparisonSpeech(): string {
  return "Compare only on facts this turn retrieved. Do not declare a winner. If a metric is missing, say it is missing. Do not invent valuation, growth, or a price.";
}

export function scenarioSpeech(): string {
  return "Bull, base, and bear are scenarios, not forecasts. Do not assign a price, a return, or a probability unless it is already in assembled context. Say what would have to be true for each case. No return is guaranteed.";
}

export function rebalanceSpeech(hasPlan: boolean, snapshot: BrokerSnapshot): string {
  if (!hasPlan) {
    return "No investment plan is saved, so there is no target allocation to compare. I will not invent one. Nothing was sent.";
  }
  if (!snapshot.verified) {
    return "A plan is saved, but the broker did not return holdings this turn, so the allocation cannot be compared. Nothing was sent.";
  }
  const valued = snapshot.positions.filter((position) => Number(position.marketValue) > 0);
  if (valued.length === 0) {
    return "Holdings were returned without market values, so a rebalance cannot be calculated. I will not estimate one. Nothing was sent.";
  }
  return "A difference from the saved plan can be described from returned market values only. That description is not an order. Nothing is sent unless you ask to invest and then approve it.";
}

export function thesisSpeech(notes: { id: number; symbol: string; title: string; body: string }[]): string {
  if (notes.length === 0) {
    return "No investment thesis is saved. I will not invent a thesis, a target, or a price.";
  }
  return notes
    .slice(0, 4)
    .map((note) => `Thesis #${note.id}${note.symbol ? ` ${note.symbol}` : ""}: ${note.title}. ${note.body || "No detail was saved."}`)
    .join(" ");
}

export function journalSpeech(count: number): string {
  if (count < 1) {
    return "The investment journal is empty. I will not invent a thesis, a decision, or a return.";
  }
  const noun = count === 1 ? "item is" : "items are";
  return `${count} journal ${noun} on file. They are what you wrote, not a performance record and not a forecast. No return is guaranteed.`;
}

export function watchSpeech(symbols: string[]): string {
  const names = symbols.map((symbol) => symbol.trim()).filter(Boolean).slice(0, 8);
  if (names.length === 0) {
    return "The watchlist is empty. A symbol here is not a holding and has no stored price.";
  }
  return `Watching ${names.join(", ")}. These are names you saved, not holdings, and no price is stored with them.`;
}

export function questionNeedsPortfolio(text: string): boolean {
  return (
    /\b(portfolio|holdings|positions|diversif|concentrat|allocation|broker|equity|balance|invested|my orders|open orders|recent orders|alpaca|paper account|live account)\b/i.test(
      text,
    ) || /\b(?:buy|sell|invest\s+[£$€]?\s?\d+)\b/i.test(text)
  );
}
