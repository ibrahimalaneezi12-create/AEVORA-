/**
 * Normalized business records. Only fields a provider actually returned.
 * Missing totals stay missing. Empty is not a zero.
 */

export type BusinessLead = {
  source: string;
  id: string;
  name: string;
  email: string;
  stage: string;
  /** null when the provider did not include the field. */
  lastContact: string | null;
};

export type BusinessOrder = {
  source: string;
  id: string;
  total: string;
  currency: string;
  status: string;
  createdAt: string;
};

export function leadSpeech(opts: { connected: boolean; leads: BusinessLead[]; error: string }): string {
  if (!opts.connected) return "No CRM is connected. I can't see leads, and I won't guess a count.";
  if (opts.error) return `The CRM did not return contacts. ${opts.error} I will not invent leads.`;
  if (opts.leads.length === 0) return "The CRM returned no contacts. I will not invent a pipeline.";
  const lines = opts.leads.slice(0, 8).map((lead) => {
    const name = lead.name || "Unnamed contact";
    const stage = lead.stage ? `stage ${lead.stage}` : "stage not returned";
    return `${name} (${stage})`;
  });
  return `HubSpot returned ${opts.leads.length} contact${opts.leads.length === 1 ? "" : "s"}: ${lines.join("; ")}. These are contacts, not a revenue figure.`;
}

export function followUpSpeech(leads: BusinessLead[]): string {
  const missing = leads.filter((lead) => lead.lastContact === "");
  if (missing.length === 0) {
    return "No returned contact has an empty last-contact date. I will not say who needs a follow-up.";
  }
  const names = missing.slice(0, 8).map((lead) => lead.name || "Unnamed contact");
  return `${missing.length} returned contact${missing.length === 1 ? "" : "s"} ha${missing.length === 1 ? "s" : "ve"} no last-contact date: ${names.join("; ")}. That is not proof they were never contacted. Confidence is low. Next step is to check before writing to them.`;
}

export function orderMoneySpeech(opts: { connected: boolean; orders: BusinessOrder[]; error: string }): string {
  if (!opts.connected) return "No store is connected. Revenue is not being calculated.";
  if (opts.error) return `The store did not return orders. ${opts.error} Revenue is not calculated.`;
  if (opts.orders.length === 0) return "The store returned no orders. Revenue is not calculated.";
  const priced = opts.orders.filter((order) => /^\d+(\.\d+)?$/.test(order.total));
  if (priced.length !== opts.orders.length) {
    return `The store returned ${opts.orders.length} orders. Some totals were missing, so revenue is not calculated.`;
  }
  const currencies = new Set(priced.map((order) => order.currency).filter(Boolean));
  if (currencies.size > 1) {
    return "Returned orders use more than one currency, so they were not added together.";
  }
  const sum = priced.reduce((total, order) => total + Number(order.total), 0);
  const currency = priced[0]?.currency ? ` ${priced[0].currency}` : "";
  return `Among the ${priced.length} orders returned, the totals add up to ${sum.toFixed(2)}${currency}. This is not the store's full revenue.`;
}

export function mailboxSpeech(status: string, lines: string[]): string {
  if (status !== "connected") {
    return "I don't have your business email connected yet. I won't guess how many leads need follow-up.";
  }
  if (lines.length === 0) return "Gmail is connected. No inbox items were returned, so I can't count leads.";
  return `Gmail returned ${lines.length} inbox item${lines.length === 1 ? "" : "s"}. These are messages, not confirmed leads: ${lines.join("; ")}.`;
}

export function calendarLinkSpeech(status: string, lines: string[]): string {
  if (status !== "connected") return "Google Calendar is not connected. I won't invent meetings.";
  if (lines.length === 0) return "Google Calendar is connected. No upcoming events were returned.";
  return `Google Calendar returned ${lines.length} event${lines.length === 1 ? "" : "s"}: ${lines.join("; ")}.`;
}

export function productStockSpeech(opts: {
  connected: boolean;
  products: { title: string; inventory: string | null }[];
  error: string;
}): string {
  if (!opts.connected) return "No store is connected. Products and stock were not read.";
  if (opts.error) return `The store did not return products. ${opts.error} Stock is not estimated.`;
  if (opts.products.length === 0) return "The store returned no products. Stock is not estimated.";
  const named = opts.products
    .slice(0, 8)
    .map((product) => {
      const title = product.title || "Untitled product";
      return product.inventory === null ? `${title} (stock not returned)` : `${title} (stock ${product.inventory})`;
    })
    .join("; ");
  const counted = opts.products.filter((product) => product.inventory !== null);
  if (counted.length === 0) return `Shopify returned ${opts.products.length} products: ${named}. Stock quantities were not in the payload, so inventory is not calculated.`;
  return `Shopify returned ${opts.products.length} products: ${named}. Only quantities Shopify included are used. This is not a full-catalog count.`;
}
