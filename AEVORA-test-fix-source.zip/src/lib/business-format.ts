import { clipText } from "./memory-format.ts";
import { sessionOwns } from "./privacy.ts";

export const BUSINESS_NAME_MAX = 80;
export const BUSINESS_FIELD_MAX = 500;
export const BUSINESS_NOTE_TITLE_MAX = 80;
export const BUSINESS_NOTE_BODY_MAX = 4000;
export const BUSINESS_CONTEXT_LIMIT = 2;
export const BUSINESS_NOTE_CONTEXT_LIMIT = 8;

export const BUSINESS_NOTE_KINDS = [
  "note",
  "product",
  "customer",
  "competitor",
  "decision",
  "process",
  "opportunity",
  "risk",
] as const;
export type BusinessNoteKind = (typeof BUSINESS_NOTE_KINDS)[number];

export type Business = {
  id: number;
  name: string;
  offer: string;
  audience: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
};

export type BusinessNote = {
  id: number;
  businessId: number;
  kind: BusinessNoteKind;
  title: string;
  body: string;
  createdAt: string;
  updatedAt: string;
};

export type BusinessRow = {
  id: unknown;
  name: string;
  offer: string;
  audience: string;
  notes: string;
  created_at: unknown;
  updated_at: unknown;
};

export type BusinessNoteRow = {
  id: unknown;
  business_id: unknown;
  kind: string;
  title: string;
  body: string;
  created_at: unknown;
  updated_at: unknown;
};

export type BusinessBriefing = {
  businesses: Business[];
  notes: BusinessNote[];
  empty: boolean;
  missing: string[];
  speech: string;
};

export type ManagerSectionId = "well" | "attention" | "recorded" | "working" | "owner";

export type ManagerSection = {
  id: ManagerSectionId;
  title: string;
  lines: string[];
};

export type BusinessManagerReport = {
  empty: boolean;
  sections: ManagerSection[];
  speech: string;
};

function toIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return String(value);
}

function asPositiveInt(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isInteger(n) || n < 1) return 0;
  return n;
}

export function asBusinessNoteKind(value: string): BusinessNoteKind {
  return (BUSINESS_NOTE_KINDS as readonly string[]).includes(value)
    ? (value as BusinessNoteKind)
    : "note";
}

export function mapBusiness(row: BusinessRow): Business | null {
  const id = asPositiveInt(row.id);
  if (!id) return null;
  return {
    id,
    name: row.name,
    offer: row.offer ?? "",
    audience: row.audience ?? "",
    notes: row.notes ?? "",
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function mapBusinessNote(row: BusinessNoteRow): BusinessNote | null {
  const id = asPositiveInt(row.id);
  const businessId = asPositiveInt(row.business_id);
  if (!id || !businessId) return null;
  return {
    id,
    businessId,
    kind: asBusinessNoteKind(row.kind),
    title: row.title,
    body: row.body ?? "",
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export function businessMayAccess(sessionUserId: string, rowUserId: string | null | undefined): boolean {
  return sessionOwns(sessionUserId, rowUserId);
}

export function formatBusinessBlock(businesses: Business[], notes: BusinessNote[]): string {
  if (businesses.length === 0 && notes.length === 0) return "";
  const lines: string[] = [];
  for (const b of businesses) {
    const bits = [
      `-(#${b.id}) ${clipText(b.name, 80)}`,
      b.offer ? `offer: ${clipText(b.offer, 120)}` : "",
      b.audience ? `audience: ${clipText(b.audience, 80)}` : "",
    ].filter(Boolean);
    lines.push(bits.join(" — "));
  }
  for (const n of notes) {
    lines.push(
      `- note #${n.id} (${n.kind} for business #${n.businessId}) ${clipText(n.title, 80)}: ${clipText(n.body, 160)}`,
    );
  }
  return lines.join("\n");
}

export function composeBusinessBriefing(businesses: Business[], notes: BusinessNote[]): BusinessBriefing {
  const missing: string[] = [];
  if (businesses.length === 0) missing.push("No business identity is saved in your keep.");
  const hasRevenue = notes.some((n) => /\brevenue|sales|pipeline|customers?\b/i.test(`${n.title} ${n.body}`));
  if (!hasRevenue) missing.push("No revenue, customers, or pipeline figures are recorded. None were invented.");
  const empty = businesses.length === 0 && notes.length === 0;
  const speech = empty
    ? "I do not have a business identity saved yet. Tell me the name, what you sell, and who it is for — I will propose saving it. I will not invent numbers."
    : [
        businesses.map((b) => `${b.name}${b.offer ? ` — ${b.offer}` : ""}`).join("; "),
        missing.join(" "),
        notes.length > 0 ? `${notes.length} note${notes.length === 1 ? "" : "s"} on file.` : "No operational notes yet.",
      ]
        .filter(Boolean)
        .join(" ");
  return { businesses, notes, empty, missing, speech };
}

const SECTION_TITLES: Record<ManagerSectionId, string> = {
  well: "What's going well",
  attention: "What needs attention",
  recorded: "What is on file",
  working: "What AEVORA has done",
  owner: "What needs you",
};

function pushSection(sections: ManagerSection[], id: ManagerSectionId, lines: string[]): void {
  const clean = lines.map((line) => line.trim()).filter(Boolean).slice(0, 4);
  if (clean.length === 0) return;
  sections.push({ id, title: SECTION_TITLES[id], lines: clean });
}

/**
 * Manager view from records only. Empty sections are omitted.
 * Never invents revenue, customers, or background work.
 */
export function composeBusinessManagerReport(opts: {
  businesses: Business[];
  notes: BusinessNote[];
  pendingTitles?: string[];
  executedTitles?: string[];
}): BusinessManagerReport {
  const notes = opts.notes;
  const sections: ManagerSection[] = [];
  pushSection(
    sections,
    "well",
    notes.filter((n) => n.kind === "opportunity").map((n) => n.title),
  );
  pushSection(
    sections,
    "attention",
    notes.filter((n) => n.kind === "risk").map((n) => n.title),
  );
  pushSection(sections, "recorded", [
    ...opts.businesses.map((b) => b.name),
    ...notes.filter((n) => n.kind !== "opportunity" && n.kind !== "risk").map((n) => `${n.kind}: ${n.title}`),
  ]);
  pushSection(
    sections,
    "working",
    (opts.executedTitles ?? []).map((title) => title),
  );
  pushSection(
    sections,
    "owner",
    (opts.pendingTitles ?? []).map((title) => title),
  );
  const empty = sections.length === 0;
  const speech = empty
    ? "Nothing is saved for the business yet. Tell me the name, what you sell, and who it is for. I will not invent numbers or claim I have been working."
    : sections.map((section) => `${section.title}: ${section.lines.join("; ")}.`).join(" ");
  return { empty, sections, speech };
}

const PRICE_HOLD =
  /not (?:to )?lower(?:ing)? prices|do not lower prices|won'?t lower prices|keep (?:the )?prices|decided against (?:a )?discount/i;
const PRICE_CUT = /lower(?:ing)? (?:the )?prices|cut prices|price cut|discount|reduce prices/i;

/**
 * Quote a saved decision when the new request would reverse it.
 * Only fires on records. Does not invent a decision.
 */
export function decisionWarnings(notes: BusinessNote[], request: string): string[] {
  const out: string[] = [];
  for (const note of notes) {
    if (note.kind !== "decision") continue;
    const blob = `${note.title} ${note.body}`;
    if (PRICE_HOLD.test(blob) && PRICE_CUT.test(request)) {
      out.push(
        `You previously decided not to lower prices (${note.title}). This request would change that. Ask before reconsidering.`,
      );
    }
  }
  return out.slice(0, 3);
}
