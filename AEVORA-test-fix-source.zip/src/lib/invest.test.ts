import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  composeInvestOverview,
  formatInvestBlock,
  investMayAccess,
  investNoteFeature,
  isTradeRequest,
  normalizeSymbol,
  type InvestNote,
  type WatchItem,
} from "./invest-format.ts";
import { catalogLevel, canRunTool } from "./orchestrator/catalog.ts";
import { investOperatorDecision, planAllowsFeature } from "./entitlements-format.ts";

function watch(partial: Partial<WatchItem> & Pick<WatchItem, "id" | "symbol">): WatchItem {
  return {
    name: "",
    thesis: "",
    createdAt: "2026-09-22T00:00:00.000Z",
    updatedAt: "2026-09-22T00:00:00.000Z",
    ...partial,
  };
}

function note(partial: Partial<InvestNote> & Pick<InvestNote, "id" | "title" | "body">): InvestNote {
  return {
    symbol: "",
    kind: "note",
    createdAt: "2026-09-22T00:00:00.000Z",
    updatedAt: "2026-09-22T00:00:00.000Z",
    ...partial,
  };
}

describe("invest keep", () => {
  it("isolates watchlists by session owner", () => {
    assert.equal(investMayAccess("user-a", "user-a"), true);
    assert.equal(investMayAccess("user-a", "user-b"), false);
  });

  it("normalizes tickers and refuses a trade tool", () => {
    assert.equal(normalizeSymbol(" nvda "), "NVDA");
    assert.equal(normalizeSymbol("brk.b!"), "BRK.B");
    assert.equal(canRunTool("invest.trade"), false);
    assert.equal(canRunTool("invest.broker"), false);
    assert.equal(catalogLevel("invest.trade"), "restricted");
    assert.equal(catalogLevel("invest.watch"), "review");
    assert.equal(catalogLevel("invest.unwatch"), "approval");
    assert.equal(catalogLevel("invest.note"), "review");
    assert.equal(canRunTool("invest.watch"), true);
  });

  it("detects trade language without executing", () => {
    assert.equal(isTradeRequest("Buy 10 shares of NVDA"), true);
    assert.equal(isTradeRequest("Research NVDA"), false);
  });

  it("does not invent prices or guarantee returns", () => {
    const overview = composeInvestOverview([watch({ id: 1, symbol: "NVDA" })], []);
    assert.doesNotMatch(overview.speech, /\$\d/);
    assert.match(overview.disclaimer, /No guaranteed returns/);
    assert.match(overview.disclaimer, /No autonomous trades/);
  });

  it("formats watchlist and journal with ids", () => {
    const block = formatInvestBlock(
      [watch({ id: 3, symbol: "NVDA", thesis: "Long-term compute demand." })],
      [note({ id: 8, symbol: "NVDA", kind: "paper", title: "Paper buy", body: "Pretend fill at a price I will look up." })],
    );
    assert.match(block, /watch #3 NVDA/);
    assert.match(block, /journal #8/);
  });
});

describe("investment operator", () => {
  it("never executes a real order without a broker, even on Pro", () => {
    const free = investOperatorDecision("free");
    const plus = investOperatorDecision("plus");
    const pro = investOperatorDecision("pro");
    assert.equal(free.canExecute, false);
    assert.equal(plus.canExecute, false);
    assert.equal(plus.featureAllowed, false);
    assert.equal(pro.featureAllowed, true);
    assert.equal(pro.brokerConnected, false);
    assert.equal(pro.canExecute, false);
    assert.match(pro.reason, /assembled context/i);
    assert.doesNotMatch(pro.reason, /no broker is connected/i);
    assert.equal(planAllowsFeature("free", "investBasic"), true);
    assert.equal(planAllowsFeature("free", "investCopilot"), false);
    assert.equal(planAllowsFeature("plus", "investCopilot"), true);
    assert.equal(planAllowsFeature("plus", "investOperator"), false);
    assert.equal(canRunTool("invest.trade"), false);
    assert.equal(isTradeRequest("Invest £500 according to my investment plan."), true);
    assert.equal(investNoteFeature("paper"), "investBasic");
    assert.equal(investNoteFeature("thesis"), "investBasic");
    assert.equal(investNoteFeature("scenario"), "investCopilot");
  });
});
