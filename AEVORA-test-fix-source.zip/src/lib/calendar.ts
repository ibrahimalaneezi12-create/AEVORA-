import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { calendarCreatePayload, calendarUpdatePayload, idPayload } from "@/lib/confirm-format";
import {
  CALENDAR_RECURRENCES,
  formatCalendarContextLine,
  mapCalendarEvent,
  type CalendarEvent,
  type CalendarEventRow,
} from "@/lib/calendar-format";
import type { LinkStatus } from "@/lib/links-format";
import { classifyGatePeek } from "@/lib/providers/gate-peek";
import type { ToolHandler } from "@/lib/tools/types";

export type { CalendarEvent } from "@/lib/calendar-format";

export type CalendarConnection = {
  connected: boolean;
  status: LinkStatus;
  detail: string;
};

async function listOwned(userId: string, fromIso: string, toIso: string): Promise<CalendarEvent[]> {
  const sql = await getSql();
  const rows = await sql<CalendarEventRow>`
    select id, title, notes, location, start_at, end_at, timezone, status, source, recurrence, created_at, updated_at
    from calendar_events
    where user_id = ${userId}
      and status = ${"confirmed"}
      and start_at >= ${fromIso}::timestamptz
      and start_at < ${toIso}::timestamptz
    order by start_at asc
    limit 80
  `;
  const out: CalendarEvent[] = [];
  for (const row of rows) {
    const mapped = mapCalendarEvent(row);
    if (mapped) out.push(mapped);
  }
  return out;
}

export async function listOwnCalendarForContext(userId: string, now = new Date()): Promise<CalendarEvent[]> {
  const from = new Date(now.getTime() - 12 * 60 * 60 * 1000).toISOString();
  const to = new Date(now.getTime() + 8 * 24 * 60 * 60 * 1000).toISOString();
  try {
    return await listOwned(userId, from, to);
  } catch {
    return [];
  }
}

export function formatCalendarBlock(rows: CalendarEvent[]): string {
  if (rows.length === 0) return "";
  return rows.map(formatCalendarContextLine).join("\n");
}

export const listCalendarEvents = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<CalendarEvent[]> => {
    const now = new Date();
    const from = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();
    const to = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();
    return listOwned(context.userId, from, to);
  });

export const calendarListHandler: ToolHandler = async ({ userId }) => {
  const rows = await listOwnCalendarForContext(userId);
  const google = await peekGoogleCalendar();
  const local =
    rows.length === 0
      ? "No upcoming events on your AEVORA calendar."
      : rows.length === 1
        ? "1 upcoming AEVORA event."
        : `${rows.length} upcoming AEVORA events.`;
  return `${local} ${google.detail}`;
};

export async function peekGoogleCalendar(): Promise<{
  connected: boolean;
  status: LinkStatus;
  detail: string;
  lines: string[];
  loginUrl: string;
  lastCheckedAt: string;
}> {
  const lastCheckedAt = new Date().toISOString();
  try {
    const { callTool } = await import("@/lib/app-data/client.server");
    const { ConnectorType, GoogleCalendarTools } = await import("@/lib/app-data/types");
    const result = await callTool(
      GoogleCalendarTools.search,
      { query: "after:today", maxResults: 8 },
      { connectorType: ConnectorType.GoogleCalendar },
    );
    const gate = classifyGatePeek("Google Calendar", result);
    if (!gate.connected) return { ...gate, lines: [], lastCheckedAt };
    const lines = extractGoogleLines(result.data);
    return {
      connected: true,
      status: "connected",
      detail: lines.length
        ? `Google Calendar connected (${lines.length} upcoming).`
        : "Google Calendar is connected. No upcoming events returned.",
      lines,
      loginUrl: "",
      lastCheckedAt,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : "";
    if (/gate|not ready|connector/i.test(message)) {
      return {
        connected: false,
        status: "not_configured",
        detail: "Google Calendar is not configured in this keep yet. Nothing was read.",
        lines: [],
        loginUrl: "",
        lastCheckedAt,
      };
    }
    return {
      connected: false,
      status: "connection_error",
      detail: "Google Calendar could not be checked. Nothing was read.",
      lines: [],
      loginUrl: "",
      lastCheckedAt,
    };
  }
}

function extractGoogleLines(data: unknown): string[] {
  const out: string[] = [];
  const visit = (value: unknown) => {
    if (!value || out.length >= 8) return;
    if (Array.isArray(value)) {
      for (const item of value) visit(item);
      return;
    }
    if (typeof value === "object") {
      const rec = value as Record<string, unknown>;
      const title = typeof rec.summary === "string" ? rec.summary : typeof rec.title === "string" ? rec.title : "";
      const start =
        typeof rec.start === "string"
          ? rec.start
          : rec.start && typeof rec.start === "object" && typeof (rec.start as { dateTime?: string }).dateTime === "string"
            ? (rec.start as { dateTime: string }).dateTime
            : "";
      if (title) out.push(start ? `${title} — ${start}` : title);
      if ("items" in rec) visit(rec.items);
      if ("events" in rec) visit(rec.events);
    }
  };
  visit(data);
  return out;
}

export function formatGoogleCalendarBlock(peek: { connected: boolean; detail: string; lines: string[] }): string {
  if (!peek.connected) return peek.detail;
  if (peek.lines.length === 0) return peek.detail;
  return `${peek.detail}\n${peek.lines.map((line) => `- ${line}`).join("\n")}`;
}

export const calendarCreateHandler: ToolHandler = async ({ userId, payload, title: proposalTitle }) => {
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "calendar");
  const parsed = calendarCreatePayload.parse(payload);
  const title = (parsed.title ?? proposalTitle).trim();
  if (!title) throw new Error("Add a title.");
  const startAt = parsed.startAt?.trim();
  if (!startAt) throw new Error("Add a start time.");
  const sql = await getSql();
  const rows = await sql<CalendarEventRow>`
    insert into calendar_events (
      user_id, title, notes, location, start_at, end_at, timezone, status, source, recurrence
    )
    values (
      ${userId},
      ${title.slice(0, 120)},
      ${(parsed.notes ?? "").trim()},
      ${(parsed.location ?? "").trim()},
      ${startAt}::timestamptz,
      ${parsed.endAt ? parsed.endAt : null},
      ${(parsed.timezone ?? "UTC").trim() || "UTC"},
      ${"confirmed"},
      ${"aegis"},
      ${parsed.recurrence ?? "once"}
    )
    returning id, title, notes, location, start_at, end_at, timezone, status, source, recurrence, created_at, updated_at
  `;
  const mapped = rows[0] ? mapCalendarEvent(rows[0]) : null;
  if (!mapped) throw new Error("Event could not be saved.");
  return `Created event ${mapped.id} for ${mapped.startAt}.`;
};

export const calendarUpdateHandler: ToolHandler = async ({ userId, payload }) => {
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "calendar");
  const parsed = calendarUpdatePayload.parse(payload);
  const sql = await getSql();
  const existing = await sql<CalendarEventRow>`
    select id, title, notes, location, start_at, end_at, timezone, status, source, recurrence, created_at, updated_at
    from calendar_events
    where id = ${parsed.id} and user_id = ${userId}
  `;
  const current = existing[0] ? mapCalendarEvent(existing[0]) : null;
  if (!current) throw new Error("Event not found.");
  const nextEnd = "endAt" in (payload as object) ? parsed.endAt : current.endAt;
  const rows = await sql<CalendarEventRow>`
    update calendar_events
    set
      title = ${(parsed.title ?? current.title).trim()},
      notes = ${parsed.notes ?? current.notes},
      location = ${parsed.location ?? current.location},
      start_at = ${parsed.startAt ?? current.startAt}::timestamptz,
      end_at = ${nextEnd},
      timezone = ${parsed.timezone ?? current.timezone},
      updated_at = now()
    where id = ${current.id} and user_id = ${userId}
    returning id, title, notes, location, start_at, end_at, timezone, status, source, recurrence, created_at, updated_at
  `;
  if (!rows[0]) throw new Error("Event not found.");
  return `Updated event ${current.id}.`;
};

export const calendarDeleteHandler: ToolHandler = async ({ userId, payload }) => {
  const { assertFeature } = await import("@/lib/entitlements");
  await assertFeature(userId, "calendar");
  const parsed = idPayload.parse(payload);
  const sql = await getSql();
  const rows = await sql<{ id: unknown }>`
    update calendar_events
    set status = ${"cancelled"}, updated_at = now()
    where id = ${parsed.id} and user_id = ${userId} and status = ${"confirmed"}
    returning id
  `;
  if (!rows[0]) throw new Error("Event not found.");
  return `Cancelled event ${parsed.id}.`;
};

const createInput = z.object({
  title: z.string().trim().min(1).max(120),
  notes: z.string().max(2000).optional(),
  location: z.string().max(200).optional(),
  startAt: z.string().trim().min(1).max(64),
  endAt: z.string().trim().max(64).optional(),
  timezone: z.string().trim().min(1).max(64).optional(),
  recurrence: z.enum(CALENDAR_RECURRENCES).optional(),
});

export const createCalendarEvent = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => createInput.parse(input))
  .handler(async ({ context, data }): Promise<CalendarEvent> => {
    const { assertFeature } = await import("@/lib/entitlements");
    await assertFeature(context.userId, "calendar");
    const sql = await getSql();
    const recurrence = data.recurrence ?? "once";
    const rows = await sql<CalendarEventRow>`
      insert into calendar_events (
        user_id, title, notes, location, start_at, end_at, timezone, status, source, recurrence
      )
      values (
        ${context.userId},
        ${data.title},
        ${(data.notes ?? "").trim()},
        ${(data.location ?? "").trim()},
        ${data.startAt}::timestamptz,
        ${data.endAt ? data.endAt : null},
        ${(data.timezone ?? "UTC").trim() || "UTC"},
        ${"confirmed"},
        ${"aegis"},
        ${recurrence}
      )
      returning id, title, notes, location, start_at, end_at, timezone, status, source, recurrence, created_at, updated_at
    `;
    const mapped = rows[0] ? mapCalendarEvent(rows[0]) : null;
    if (!mapped) throw new Error("Event could not be saved.");
    return mapped;
  });

export const getCalendarStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async (): Promise<CalendarConnection> => {
    const peek = await peekGoogleCalendar();
    return { connected: peek.connected, status: peek.status, detail: peek.detail };
  });

const idInput = z.object({ id: z.number().int().positive() });

export const cancelCalendarEvent = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }): Promise<{ id: number }> => {
    const { assertFeature } = await import("@/lib/entitlements");
    await assertFeature(context.userId, "calendar");
    const sql = await getSql();
    const rows = await sql<{ id: unknown }>`
      update calendar_events
      set status = ${"cancelled"}, updated_at = now()
      where id = ${data.id} and user_id = ${context.userId} and status = ${"confirmed"}
      returning id
    `;
    if (!rows[0]) throw new Error("Event not found.");
    return { id: data.id };
  });
