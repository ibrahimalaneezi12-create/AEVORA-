import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  addMinutesUtc,
  formatInZone,
  nextOccurrence,
  zonedDateTimeToUtc,
} from "./time-format.ts";

describe("zonedDateTimeToUtc", () => {
  it("converts a New York winter wall time to UTC", () => {
    const d = zonedDateTimeToUtc("2026-01-15", "19:00", "America/New_York");
    assert.ok(d);
    assert.equal(d.toISOString(), "2026-01-16T00:00:00.000Z");
  });

  it("converts a New York summer wall time to UTC (DST)", () => {
    const d = zonedDateTimeToUtc("2026-07-15", "19:00", "America/New_York");
    assert.ok(d);
    assert.equal(d.toISOString(), "2026-07-15T23:00:00.000Z");
  });

  it("keeps UTC as UTC", () => {
    const d = zonedDateTimeToUtc("2026-09-18", "07:00", "UTC");
    assert.ok(d);
    assert.equal(d.toISOString(), "2026-09-18T07:00:00.000Z");
  });
});

describe("nextOccurrence", () => {
  it("finds the next daily fire after a UTC instant", () => {
    const from = new Date("2026-09-18T18:00:00.000Z");
    const next = nextOccurrence({
      from,
      timeZone: "UTC",
      localTime: "19:00",
      recurrence: "daily",
    });
    assert.ok(next);
    assert.equal(formatInZone(next, "UTC").time, "19:00");
    assert.ok(next.getTime() > from.getTime());
  });

  it("skips weekend for weekdays recurrence", () => {
    const friday = new Date("2026-09-18T18:00:00.000Z");
    const next = nextOccurrence({
      from: friday,
      timeZone: "UTC",
      localTime: "09:00",
      recurrence: "weekdays",
    });
    assert.ok(next);
    assert.equal(formatInZone(next, "UTC").weekday, 1);
  });
});

describe("addMinutesUtc", () => {
  it("snoozes by 10 minutes", () => {
    const from = new Date("2026-09-18T12:00:00.000Z");
    assert.equal(addMinutesUtc(from, 10).toISOString(), "2026-09-18T12:10:00.000Z");
  });
});
