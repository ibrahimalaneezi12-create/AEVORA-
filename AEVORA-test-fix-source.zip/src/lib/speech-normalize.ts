const MAX_SPEAK_CHARS = 1800;

export function stripMarkdownForSpeech(text: string): string {
  let out = text.replace(/\r\n/g, "\n");
  out = out.replace(/```[\s\S]*?```/g, " code. ");
  out = out.replace(/`([^`]+)`/g, "$1");
  out = out.replace(/!\[[^\]]*]\([^)]+\)/g, " ");
  out = out.replace(/\[([^\]]+)]\([^)]+\)/g, "$1");
  out = out.replace(/^#{1,6}\s+/gm, "");
  out = out.replace(/^\s*[-*+]\s+/gm, "");
  out = out.replace(/^\s*\d+\.\s+/gm, "");
  out = out.replace(/\*\*([^*]+)\*\*/g, "$1");
  out = out.replace(/__([^_]+)__/g, "$1");
  out = out.replace(/\*([^*]+)\*/g, "$1");
  out = out.replace(/_([^_]+)_/g, "$1");
  return out;
}

export function normalizeForSpeech(text: string): string {
  let out = stripMarkdownForSpeech(text);
  out = out.replace(/https?:\/\/[^\s)]+/gi, " link ");
  out = out.replace(/\bwww\.[^\s)]+/gi, " link ");
  out = out.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, " email address ");
  out = out.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, " ");
  out = out.replace(/[<>]/g, " ");
  out = out.replace(/[|]/g, ", ");
  out = out.replace(/\n{2,}/g, ". ");
  out = out.replace(/\n/g, ". ");
  out = out.replace(/\s{2,}/g, " ");
  out = out.replace(/\s+([,.;!?])/g, "$1");
  out = out.trim();
  if (out.length <= MAX_SPEAK_CHARS) return out;
  const clipped = out.slice(0, MAX_SPEAK_CHARS);
  const lastStop = Math.max(
    clipped.lastIndexOf(". "),
    clipped.lastIndexOf("? "),
    clipped.lastIndexOf("! "),
  );
  return (lastStop > 200 ? clipped.slice(0, lastStop + 1) : clipped).trim();
}

const SENTENCE_RE = /[^.!?]+[.!?]+(?:\s|$)|[^.!?]+$/g;

export function splitSpeakableSentences(text: string): string[] {
  const normalized = normalizeForSpeech(text);
  if (!normalized) return [];
  const parts = normalized.match(SENTENCE_RE) ?? [normalized];
  const sentences: string[] = [];
  let buf = "";
  for (const raw of parts) {
    const piece = raw.trim();
    if (!piece) continue;
    if ((buf + " " + piece).trim().length < 42) {
      buf = `${buf} ${piece}`.trim();
      continue;
    }
    if (buf) sentences.push(buf);
    buf = piece;
  }
  if (buf) sentences.push(buf);
  return expandClauses(sentences);
}

function expandClauses(sentences: string[]): string[] {
  const out: string[] = [];
  for (const sentence of sentences) {
    if (sentence.length < 70 || !/[,;:]/.test(sentence)) {
      out.push(sentence);
      continue;
    }
    const bits = sentence.split(/(?<=[,;:])\s+/);
    let buf = "";
    for (const bit of bits) {
      const next = `${buf} ${bit}`.trim();
      if (buf && next.length >= 40) {
        out.push(buf);
        buf = bit;
      } else {
        buf = next;
      }
    }
    if (buf) out.push(buf);
  }
  return out;
}

export function stripProposalFence(text: string): string {
  const cut = text.search(/<<<\s*aegis-proposals/i);
  return cut >= 0 ? text.slice(0, cut).trimEnd() : text;
}

/** Finished sentences/clauses only — the trailing fragment is omitted until it ends. */
export function completeSentencesForSpeech(text: string): string[] {
  const safe = stripProposalFence(text);
  const parts = splitSpeakableSentences(safe);
  if (parts.length === 0) return [];
  const trimmed = safe.trim();
  const ended = /[.!?…]["')\]]*\s*$/.test(trimmed);
  if (ended) return parts;
  return parts.slice(0, -1);
}
