import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  conversationIdFromHash,
  isWorkspaceChatHash,
  parseChatWorkspace,
  workspaceAllows,
  workspaceChatHash,
  workspaceChatHref,
  workspaceChatPath,
  workspaceFromPathname,
  workspaceIntentNote,
  workspaceThreadLink,
} from "./chat-workspace.ts";

describe("chat workspaces", () => {
  it("keeps unknown workspaces on personal chat", () => {
    assert.equal(parseChatWorkspace(undefined), "main");
    assert.equal(parseChatWorkspace("studio"), "main");
    assert.equal(parseChatWorkspace("business"), "business");
    assert.equal(parseChatWorkspace("invest"), "invest");
  });

  it("does not open a thread from another workspace", () => {
    assert.equal(workspaceAllows("business", "main"), false);
    assert.equal(workspaceAllows("invest", "business"), false);
    assert.equal(workspaceAllows("main", "main"), true);
    assert.equal(workspaceAllows("business", "business"), true);
    assert.equal(workspaceAllows(null, "business"), false);
  });

  it("does not claim a provider is connected from the workspace note", () => {
    assert.match(workspaceIntentNote("business"), /not connected/i);
    assert.match(workspaceIntentNote("business"), /do not invent/i);
    assert.doesNotMatch(workspaceIntentNote("business"), /is connected/i);
    assert.match(workspaceIntentNote("invest"), /do not invent/i);
    assert.match(workspaceIntentNote("invest"), /pending is not filled/i);
    assert.equal(workspaceIntentNote("main"), "");
  });

  it("reads only a business or invest hash id", () => {
    assert.equal(conversationIdFromHash("chat"), null);
    assert.equal(conversationIdFromHash("#chat/4"), 4);
    assert.equal(conversationIdFromHash("chat/0"), "invalid");
    assert.equal(conversationIdFromHash("chat/nope"), "invalid");
  });

  it("does not send Business or Invest chat to Main Chat", () => {
    assert.equal(workspaceFromPathname("/app/business"), "business");
    assert.equal(workspaceFromPathname("/app/invest"), "invest");
    assert.equal(workspaceFromPathname("/app/chat"), "main");
    assert.equal(workspaceFromPathname("/app"), "main");
    assert.equal(workspaceChatPath("business"), "/app/business");
    assert.equal(workspaceChatPath("invest"), "/app/invest");
    assert.equal(workspaceChatPath("main"), "/app/chat");
    assert.equal(workspaceChatHash("business"), "chat");
    assert.equal(workspaceChatHash("business", 9), "chat/9");
    assert.equal(workspaceChatHash("main", 9), "");
    assert.equal(workspaceChatHref("business"), "/app/business#chat");
    assert.equal(workspaceChatHref("business", 9), "/app/business#chat/9");
    assert.equal(workspaceChatHref("invest", 3), "/app/invest#chat/3");
    assert.equal(workspaceChatHref("main", 3), "/app/chat/3");
    assert.equal(workspaceChatHref("main"), "/app/chat");
    assert.equal(isWorkspaceChatHash("#chat"), true);
    assert.equal(isWorkspaceChatHash("chat/9"), true);
    assert.equal(isWorkspaceChatHash(""), false);
    assert.deepEqual(workspaceThreadLink("business", 9), {
      to: "/app/business",
      hash: "chat/9",
    });
    assert.deepEqual(workspaceThreadLink("invest", 4), {
      to: "/app/invest",
      hash: "chat/4",
    });
    assert.deepEqual(workspaceThreadLink("main", 4), {
      to: "/app/chat/$id",
      params: { id: "4" },
      hash: "",
    });
  });
});
