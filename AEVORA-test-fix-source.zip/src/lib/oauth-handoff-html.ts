/**
 * Live-preview OAuth popup only (`*.grok-sandbox.com`). Production never uses this.
 *
 * 200 + Set-Cookie first (Chromium drops SameSite=Lax cookies set on a 302 to
 * Google). Then:
 * - Chromium/Firefox: auto-navigate to the broker (cookie survives).
 * - Safari: require a first-party tap on this grok-sandbox document so ITP
 *   bounce-tracking does not delete the Better Auth CSRF state cookie.
 *
 * skipStateCookieCheck stays off. This is not a second Google login and not
 * used on a deployed first-party origin.
 */
export function brokerHandoffHtml(brokerUrl: string): string {
  const payload = JSON.stringify(brokerUrl).replace(/</g, "\\u003c");
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Preview sign-in</title>
<style>
  html,body{margin:0;min-height:100%;background:#0b0b0c;color:#e8e4d9;
    font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
  main{min-height:100vh;display:grid;place-items:center;padding:1.5rem;text-align:center}
  a#grok-auth-preview-continue{display:inline-block;margin-top:1rem;background:#e8e4d9;color:#12141a;
    border-radius:8px;padding:.7rem 1.15rem;font:inherit;font-weight:600;text-decoration:none}
  .preview-note{color:#a1a1aa;max-width:24rem;margin:0 auto}
  .preview-limit{color:#8b8b78;font-size:12px;max-width:24rem;margin:1rem auto 0}
  #grok-auth-preview-actions{display:none}
</style>
</head>
<body>
<main>
  <p class="preview-note">Continuing to Google from this preview window…</p>
  <div id="grok-auth-preview-actions">
    <p class="preview-note">Safari in this live preview needs one tap here so the sign-in cookie stays on this site. Production Google sign-in is a single click on the AEVORA origin.</p>
    <p><a id="grok-auth-preview-continue" href="#">Continue from this preview window</a></p>
    <p class="preview-limit">Preview / Safari limitation. Not the production login.</p>
  </div>
</main>
<script type="application/json" id="grok-auth-broker-url">${payload}</script>
<script>
(function () {
  var el = document.getElementById("grok-auth-broker-url");
  var url = "";
  try { if (el && el.textContent) url = JSON.parse(el.textContent); } catch (e) {}
  if (typeof url !== "string" || url.indexOf("https://") !== 0) return;
  var link = document.getElementById("grok-auth-preview-continue");
  if (link) link.setAttribute("href", url);
  var ua = navigator.userAgent || "";
  var safari = /Safari/i.test(ua) && !/Chrome|Chromium|Android|CriOS|FxiOS|EdgiOS/i.test(ua);
  if (!safari) {
    window.location.replace(url);
    return;
  }
  var actions = document.getElementById("grok-auth-preview-actions");
  if (actions) actions.style.display = "block";
})();
</script>
</body>
</html>`;
}

export function handoffIsPreviewOnly(html: string): boolean {
  return (
    html.includes("id=\"grok-auth-preview-continue\"") &&
    html.includes("Preview / Safari limitation") &&
    html.includes("Not the production login")
  );
}

export function handoffKeepsSafariFirstPartyTap(html: string): boolean {
  return (
    html.includes("grok-auth-preview-actions") &&
    html.includes("Continue from this preview window") &&
    !html.includes('id="grok-auth-continue"') &&
    !html.includes("Continue with Google")
  );
}
