/**
 * Per-user Alpaca link. Secrets stay in `broker_links.sealed` and are never
 * returned. Account ids from the client are ignored.
 */
import { getSql } from "@/lib/db";
import { appendAudit } from "@/lib/audit";
import { assertFeature } from "@/lib/entitlements";
import { canSealSecrets, openSecret, sealSecret } from "@/lib/seal.server";
import {
  alpacaRequest,
  capabilitiesFromAccount,
  parseAccount,
  parseOrder,
  parseOrderList,
  parsePositions,
  type BrokerMode,
} from "@/lib/brokers/alpaca.server";
import { emptySnapshot, brokerClientOrderId, orderSpeech, parseOrderIntent, type BrokerSnapshot } from "@/lib/invest-brain";
import type { ToolHandler } from "@/lib/tools/types";

type LinkRow = {
  id: unknown;
  user_id: string;
  mode: string;
  status: string;
  key_hint: string;
  sealed: string;
  capabilities: string;
  account_ref: string;
  last_error: string;
};

function hint(keyId: string): string {
  return keyId.slice(-4);
}

function parseCaps(value: string): string[] {
  return value.split(",").map((part) => part.trim()).filter(Boolean);
}

async function loadLink(userId: string, mode: BrokerMode): Promise<LinkRow | null> {
  const sql = await getSql();
  const rows = await sql<LinkRow>`
    select id, user_id, mode, status, key_hint, sealed, capabilities, account_ref, last_error
    from broker_links
    where user_id = ${userId} and provider = ${"alpaca"} and mode = ${mode}
    limit 1
  `;
  const row = rows[0];
  if (!row || row.user_id !== userId) return null;
  return row;
}

function keysFrom(row: LinkRow): { keyId: string; secret: string } | null {
  const plain = openSecret(row.sealed);
  if (!plain) return null;
  try {
    const parsed = JSON.parse(plain) as { keyId?: unknown; secret?: unknown };
    if (typeof parsed.keyId !== "string" || typeof parsed.secret !== "string") return null;
    if (!parsed.keyId || !parsed.secret) return null;
    return { keyId: parsed.keyId, secret: parsed.secret };
  } catch {
    return null;
  }
}

export async function connectAlpacaForUser(
  userId: string,
  data: { mode: BrokerMode; keyId: string; secret: string },
): Promise<{ ok: true; mode: BrokerMode; hint: string; capabilities: string[] } | { ok: false; error: string }> {
    if (!canSealSecrets()) {
      return { ok: false, error: "This keep cannot store a broker key safely yet. Nothing was saved." };
    }
    const sealed = sealSecret(JSON.stringify({ keyId: data.keyId, secret: data.secret }));
    if (!sealed) return { ok: false, error: "This keep cannot store a broker key safely yet. Nothing was saved." };

    const accountCall = await alpacaRequest({
      mode: data.mode,
      path: "/v2/account",
      keyId: data.keyId,
      secret: data.secret,
    });
    if (!accountCall.ok) {
      return { ok: false, error: accountCall.error || "Alpaca rejected the key. Nothing was saved." };
    }
    const account = parseAccount(accountCall.body);
    if (!account) return { ok: false, error: "Alpaca did not return an account. Nothing was saved." };

    const [positionsCall, ordersCall] = await Promise.all([
      alpacaRequest({ mode: data.mode, path: "/v2/positions", keyId: data.keyId, secret: data.secret }),
      alpacaRequest({ mode: data.mode, path: "/v2/orders?status=all&limit=1", keyId: data.keyId, secret: data.secret }),
    ]);
    const capabilities = capabilitiesFromAccount(account, positionsCall.ok, ordersCall.ok);
    const sql = await getSql();
    await sql`
      insert into broker_links (
        user_id, provider, mode, status, key_hint, sealed, capabilities, account_ref, account_status, last_error, last_checked_at, updated_at
      )
      values (
        ${userId},
        ${"alpaca"},
        ${data.mode},
        ${"connected"},
        ${hint(data.keyId)},
        ${sealed},
        ${capabilities.join(",")},
        ${account.accountNumber || account.id},
        ${account.status},
        ${""},
        now(),
        now()
      )
      on conflict (user_id, provider, mode) do update set
        status = excluded.status,
        key_hint = excluded.key_hint,
        sealed = excluded.sealed,
        capabilities = excluded.capabilities,
        account_ref = excluded.account_ref,
        account_status = excluded.account_status,
        last_error = ${""},
        last_checked_at = now(),
        updated_at = now()
    `;
    await appendAudit({
      userId,
      actor: "user",
      action: "broker.connected",
      entityType: "broker",
      entityId: data.mode,
      detail: `alpaca ${data.mode}`,
    });
    return { ok: true, mode: data.mode, hint: hint(data.keyId), capabilities };
}

export async function disconnectAlpacaForUser(userId: string, mode: BrokerMode): Promise<{ ok: true }> {
    const sql = await getSql();
    await sql`
      delete from broker_links
      where user_id = ${userId} and provider = ${"alpaca"} and mode = ${mode}
    `;
    await appendAudit({
      userId,
      actor: "user",
      action: "broker.disconnected",
      entityType: "broker",
      entityId: mode,
      detail: `alpaca ${mode}`,
    });
    return { ok: true };
}

export type BrokerPublic = {
  connected: boolean;
  mode: BrokerMode | null;
  hint: string;
  capabilities: string[];
  accountStatus: string;
  lastCheckedAt: string;
  error: string;
};

function checkedAt(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return "";
}

export async function publicBroker(userId: string): Promise<BrokerPublic> {
  const sql = await getSql();
  const rows = await sql<{
    mode: string;
    status: string;
    key_hint: string;
    capabilities: string;
    account_status: string;
    last_error: string;
    last_checked_at: unknown;
  }>`
    select mode, status, key_hint, capabilities, account_status, last_error, last_checked_at
    from broker_links
    where user_id = ${userId} and provider = ${"alpaca"} and status = ${"connected"}
    order by updated_at desc
    limit 1
  `;
  const row = rows[0];
  if (!row || (row.mode !== "paper" && row.mode !== "live")) {
    return { connected: false, mode: null, hint: "", capabilities: [], accountStatus: "", lastCheckedAt: "", error: "" };
  }
  return {
    connected: true,
    mode: row.mode,
    hint: row.key_hint,
    capabilities: parseCaps(row.capabilities),
    accountStatus: row.account_status ?? "",
    lastCheckedAt: checkedAt(row.last_checked_at),
    error: row.last_error,
  };
}

export async function readBrokerSnapshot(userId: string): Promise<BrokerSnapshot> {
  const pub = await publicBroker(userId);
  if (!pub.connected || !pub.mode) return emptySnapshot();
  const row = await loadLink(userId, pub.mode);
  if (!row) return emptySnapshot();
  const keys = keysFrom(row);
  if (!keys) {
    return {
      ...emptySnapshot(),
      connected: true,
      verified: false,
      mode: pub.mode,
      provider: "alpaca",
      error: "The saved broker key could not be read. Reconnect. Nothing was sent.",
    };
  }
  const accountCall = await alpacaRequest({
    mode: pub.mode,
    path: "/v2/account",
    keyId: keys.keyId,
    secret: keys.secret,
  });
  if (!accountCall.ok) {
    const sql = await getSql();
    await sql`
      update broker_links
      set last_error = ${accountCall.error.slice(0, 180)}, updated_at = now()
      where user_id = ${userId} and provider = ${"alpaca"} and mode = ${pub.mode}
    `;
    return {
      ...emptySnapshot(),
      connected: true,
      verified: false,
      mode: pub.mode,
      provider: "alpaca",
      capabilities: pub.capabilities,
      accountStatus: pub.accountStatus,
      lastCheckedAt: pub.lastCheckedAt,
      error: accountCall.error,
    };
  }
  const account = parseAccount(accountCall.body);
  const [positionsCall, ordersCall] = await Promise.all([
    alpacaRequest({ mode: pub.mode, path: "/v2/positions", keyId: keys.keyId, secret: keys.secret }),
    alpacaRequest({
      mode: pub.mode,
      path: "/v2/orders?status=all&limit=10&direction=desc",
      keyId: keys.keyId,
      secret: keys.secret,
    }),
  ]);
  const readNotes: string[] = [];
  if (!positionsCall.ok) readNotes.push(positionsCall.error);
  if (!ordersCall.ok) readNotes.push(ordersCall.error || "Recent orders were not read.");
  const capabilities = account
    ? capabilitiesFromAccount(account, positionsCall.ok, ordersCall.ok)
    : pub.capabilities;
  const sql = await getSql();
  await sql`
    update broker_links
    set
      capabilities = ${capabilities.join(",")},
      account_status = ${account?.status ?? ""},
      last_error = ${readNotes.join(" ").slice(0, 180)},
      last_checked_at = now(),
      updated_at = now()
    where user_id = ${userId} and provider = ${"alpaca"} and mode = ${pub.mode}
  `;
  return {
    connected: true,
    verified: Boolean(account),
    mode: pub.mode,
    provider: "alpaca",
    capabilities,
    account,
    positions: positionsCall.ok ? parsePositions(positionsCall.body) : [],
    orders: ordersCall.ok ? parseOrderList(ordersCall.body) : [],
    accountStatus: account?.status ?? "",
    lastCheckedAt: new Date().toISOString(),
    error: readNotes.join(" "),
  };
}

export const brokerOrderHandler: ToolHandler = async ({ userId, payload, proposalId }) => {
  const parsed = parseOrderIntent(payload);
  if (!parsed) throw new Error("Nothing was sent.");
  const sql = await getSql();
  const pub = await publicBroker(userId);
  const mode = parsed.mode ?? pub.mode;
  if (!mode || !pub.connected) {
    throw new Error("No broker is connected. Nothing was sent.");
  }
  if (parsed.mode && parsed.mode !== pub.mode) {
    const specific = await loadLink(userId, parsed.mode);
    if (!specific || specific.status !== "connected") {
      throw new Error("That broker mode is not connected. Nothing was sent.");
    }
  }
  const useMode = parsed.mode && parsed.mode !== pub.mode ? parsed.mode : pub.mode ?? mode;
  await assertFeature(userId, useMode === "live" ? "investOperator" : "investCopilot");
  if (useMode === "live" && parsed.liveConfirm !== true) {
    throw new Error("Live orders need an explicit confirmation. Nothing was sent.");
  }
  const row = await loadLink(userId, useMode);
  if (!row || row.user_id !== userId || row.status !== "connected") {
    throw new Error("No broker is connected. Nothing was sent.");
  }
  const caps = parseCaps(row.capabilities);
  if (!caps.includes("order.create")) {
    throw new Error("This broker connection cannot place orders. Nothing was sent.");
  }
  const keys = keysFrom(row);
  if (!keys) throw new Error("The saved broker key could not be read. Nothing was sent.");
  const symbol = parsed.symbol.toUpperCase().replace(/[^A-Z0-9.-]/g, "");
  if (!symbol) throw new Error("Nothing was sent.");
  const clientOrderId = brokerClientOrderId(proposalId);
  if (clientOrderId) {
    const prior = await sql<{ broker_order_id: string; status: string }>`
      select broker_order_id, status from invest_orders
      where user_id = ${userId} and client_order_id = ${clientOrderId}
      limit 1
    `;
    const existing = prior[0];
    if (existing?.broker_order_id) {
      const again = await alpacaRequest({
        mode: useMode,
        path: `/v2/orders/${encodeURIComponent(existing.broker_order_id)}`,
        keyId: keys.keyId,
        secret: keys.secret,
      });
      const order = again.ok ? parseOrder(again.body) : null;
      return orderSpeech(order?.status || existing.status || "pending", symbol, useMode);
    }
  }
  const body: Record<string, string> = {
    symbol,
    side: parsed.side,
    type: "market",
    time_in_force: "day",
  };
  if (clientOrderId) body.client_order_id = clientOrderId;
  if (parsed.notional && /^\d+(\.\d{1,2})?$/.test(parsed.notional)) body.notional = parsed.notional;
  else if (parsed.qty && /^\d+(\.\d{1,9})?$/.test(parsed.qty)) body.qty = parsed.qty;
  else throw new Error("An order needs a quantity or a cash amount. Nothing was sent.");

  let placed = await alpacaRequest({
    mode: useMode,
    path: "/v2/orders",
    method: "POST",
    keyId: keys.keyId,
    secret: keys.secret,
    body,
  });
  if (!placed.ok && clientOrderId && /client_order_id/i.test(placed.error)) {
    placed = await alpacaRequest({
      mode: useMode,
      path: `/v2/orders:by_client_order_id?client_order_id=${encodeURIComponent(clientOrderId)}`,
      keyId: keys.keyId,
      secret: keys.secret,
    });
  }
  if (!placed.ok) {
    try {
      await sql`
        insert into invest_orders (user_id, mode, provider, symbol, side, requested_amount, qty, status, detail, client_order_id)
        values (
          ${userId}, ${useMode}, ${"alpaca"}, ${symbol}, ${parsed.side},
          ${body.notional ?? ""}, ${body.qty ?? ""}, ${"failed"}, ${placed.error}, ${clientOrderId}
        )
      `;
    } catch {
      /* a previous attempt already recorded this approval */
    }
    throw new Error(`${placed.error} Nothing was filled.`);
  }
  const order = parseOrder(placed.body);
  const status = order?.status ?? "pending";
  try {
    await sql`
      insert into invest_orders (
        user_id, mode, provider, broker_order_id, symbol, side, requested_amount, qty, status, detail, client_order_id
      )
      values (
        ${userId}, ${useMode}, ${"alpaca"}, ${order?.id ?? ""}, ${symbol}, ${parsed.side},
        ${body.notional ?? ""}, ${order?.filledQty || body.qty || ""}, ${status}, ${""}, ${clientOrderId}
      )
    `;
  } catch (err) {
    if (!order?.id) throw err;
  }
  await appendAudit({
    userId,
    actor: "system",
    action: "broker.order",
    entityType: "invest_order",
    entityId: order?.id || symbol,
    detail: `${useMode} ${status} ${symbol}`,
  });
  return orderSpeech(status, symbol, useMode);
};
