export async function requestNotificationPermission(): Promise<"granted" | "denied" | "default"> {
  if (typeof Notification === "undefined") return "denied";
  if (Notification.permission === "granted") return "granted";
  try {
    const next = await Notification.requestPermission();
    if (next === "granted" || next === "denied") return next;
    return "default";
  } catch {
    return "denied";
  }
}
