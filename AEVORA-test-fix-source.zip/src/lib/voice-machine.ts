import type { VoiceState } from "./voice-format.ts";

export type VoiceEvent =
  | { type: "start" }
  | { type: "permission_denied" }
  | { type: "unsupported" }
  | { type: "mic_ready" }
  | { type: "speech_start" }
  | { type: "speech_end" }
  | { type: "transcript" }
  | { type: "first_audio" }
  | { type: "playback_done" }
  | { type: "barge" }
  | { type: "error"; message?: string }
  | { type: "stop" }
  | { type: "disable" };

export type VoiceReduce = {
  phase: VoiceState;
  error?: string;
};

const ERROR_DEFAULT = "Voice ran into a problem";

export function reduceVoice(phase: VoiceState, event: VoiceEvent): VoiceReduce {
  if (event.type === "disable") return { phase: "disabled" };
  if (event.type === "stop") {
    return { phase: phase === "disabled" ? "disabled" : "idle" };
  }
  if (phase === "disabled") return { phase: "disabled" };

  switch (event.type) {
    case "start":
      if (phase === "idle" || phase === "error" || phase === "permission") {
        return { phase: "permission" };
      }
      return { phase };
    case "permission_denied":
      return { phase: "permission", error: "Microphone is blocked" };
    case "unsupported":
      return { phase: "error", error: "This browser cannot listen" };
    case "mic_ready":
      if (
        phase === "permission" ||
        phase === "idle" ||
        phase === "error" ||
        phase === "thinking" ||
        phase === "interrupted" ||
        phase === "user_speaking"
      ) {
        return { phase: "listening" };
      }
      return { phase };
    case "speech_start":
      if (phase === "listening" || phase === "interrupted") return { phase: "user_speaking" };
      if (phase === "speaking" || phase === "thinking") return { phase: "interrupted" };
      return { phase };
    case "speech_end":
      if (phase === "user_speaking" || phase === "interrupted") return { phase: "thinking" };
      return { phase };
    case "transcript":
      if (phase === "user_speaking") return { phase: "thinking" };
      return { phase };
    case "first_audio":
      if (phase === "thinking" || phase === "interrupted") return { phase: "speaking" };
      return { phase };
    case "playback_done":
      if (phase === "speaking") return { phase: "listening" };
      return { phase };
    case "barge":
      if (phase === "speaking" || phase === "thinking") return { phase: "interrupted" };
      return { phase };
    case "error":
      return { phase: "error", error: event.message?.trim() || ERROR_DEFAULT };
    default:
      return { phase };
  }
}

export function isLiveVoicePhase(phase: VoiceState): boolean {
  return (
    phase === "listening" ||
    phase === "user_speaking" ||
    phase === "thinking" ||
    phase === "speaking" ||
    phase === "interrupted" ||
    phase === "permission"
  );
}
