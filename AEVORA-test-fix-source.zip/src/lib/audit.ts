import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { displayNameFor } from "@/lib/orchestrator/catalog";
import type { PermissionLevel } from "@/lib/orchestrator/types";
import {
  ACTIVITY_PAGE_SIZE,
  ACTIVITY_PENDING_LIMIT,
  AUDIT_ACTION_MAX,
  asActivityLevelFilter,
  asActor,
  asPermissionLevel,
  clipAuditText,
  decodeCursor,
  mapActivityEvent,
  pageFromRows,
  sanitizeDetail,
  toIso,
  type ActivityCursor,
  type ActivityEvent,
  type ActivityPage,
  type ActivityPending,
  type AuditActor,
  type AuditRow,
} from "./audit-format.ts";

export {
  ACTIVITY_LEVEL_FILTERS,
  ACTIVITY_PAGE_SIZE,
  ACTIVITY_PENDING_LIMIT,
  AUDIT_ACTIONS,
  asActivityLevelFilter,
  encodeCursor,
  eventTitle,
  mapActivityEvent,
  sanitizeDetail,
} from "./audit-format.ts";
export type {
  ActivityCursor,
  ActivityEvent,
  ActivityLevelFilter,
  ActivityPage,
  ActivityPending,
  AuditAction,
  AuditActor,
} from "./audit-format.ts";

type PendingRow = {
  id: unknown;
  conversation_id: unknown;
  tool_id: string;
  permission_level: string;
  title: string;
  summary: string;
  created_at: unknown;
};

function asId(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n > 0 ? n : 0;
}

function asLevel(value: string): PermissionLevel {
  return asPermissionLevel(value) ?? "restricted";
}

function mapPending(row: PendingRow): ActivityPending | null {
  const id = asId(row.id);
  if (!id) return null;
  const conversationId = asId(row.conversation_id);
  return {
    id,
    conversationId: conversationId || null,
    toolId: row.tool_id,
    displayName: displayNameFor(row.tool_id),
    permissionLevel: asLevel(row.permission_level),
    title: row.title,
    summary: row.summary,
    createdAt: toIso(row.created_at),
  };
}

/**
 * Append-only write. Never updates or deletes. Fail-open: domain writes
 * must still succeed if the log insert fails. Unknown future action names
 * are stored so later tools can plug in without a viewer change.
 */
export async function appendAudit(input: {
  userId: string;
  actor: AuditActor;
  action: string;
  entityType: string;
  entityId: string;
  permissionLevel?: PermissionLevel | null;
  detail?: string;
}): Promise<void> {
  try {
    const action = clipAuditText(input.action, AUDIT_ACTION_MAX);
    if (!input.userId || !action) return;
    const sql = await getSql();
    const actor = asActor(input.actor);
    const entityType = clipAuditText(input.entityType, AUDIT_ACTION_MAX);
    const entityId = clipAuditText(input.entityId, AUDIT_ACTION_MAX);
    const detail = sanitizeDetail(input.detail ?? "");
    const permissionLevel = asPermissionLevel(input.permissionLevel ?? null);
    await sql`
      insert into audit_logs (
        user_id, actor, action, entity_type, entity_id, permission_level, detail
      )
      values (
        ${input.userId},
        ${actor},
        ${action},
        ${entityType},
        ${entityId},
        ${permissionLevel},
        ${detail}
      )
    `;
  } catch {
    // Domain writes must still succeed if audit insert fails.
  }
}

const listInput = z
  .object({
    level: z.enum(["all", "safe", "review", "approval", "restricted"]).optional(),
    cursor: z.string().max(80).optional().nullable(),
  })
  .optional();

async function loadPending(userId: string): Promise<{ items: ActivityPending[]; total: number }> {
  const sql = await getSql();
  const [countRows, pendingRows] = await Promise.all([
    sql<{ n: number }>`
      select count(*)::int as n
      from proposed_actions
      where user_id = ${userId} and status = ${"pending"}
    `,
    sql<PendingRow>`
      select id, conversation_id, tool_id, permission_level, title, summary, created_at
      from proposed_actions
      where user_id = ${userId} and status = ${"pending"}
      order by created_at desc
      limit ${ACTIVITY_PENDING_LIMIT}
    `,
  ]);
  const items: ActivityPending[] = [];
  for (const row of pendingRows) {
    const mapped = mapPending(row);
    if (mapped) items.push(mapped);
  }
  return { items, total: countRows[0]?.n ?? 0 };
}

async function loadEvents(
  userId: string,
  level: ReturnType<typeof asActivityLevelFilter>,
  cursor: ActivityCursor | null,
): Promise<ActivityEvent[]> {
  const sql = await getSql();
  const limit = ACTIVITY_PAGE_SIZE + 1;
  const rows =
    level === "all"
      ? cursor
        ? await sql<AuditRow>`
            select id, actor, action, entity_type, entity_id, permission_level, detail, created_at
            from audit_logs
            where user_id = ${userId}
              and (
                created_at < ${cursor.createdAt}::timestamptz
                or (created_at = ${cursor.createdAt}::timestamptz and id < ${cursor.id})
              )
            order by created_at desc, id desc
            limit ${limit}
          `
        : await sql<AuditRow>`
            select id, actor, action, entity_type, entity_id, permission_level, detail, created_at
            from audit_logs
            where user_id = ${userId}
            order by created_at desc, id desc
            limit ${limit}
          `
      : cursor
        ? await sql<AuditRow>`
            select id, actor, action, entity_type, entity_id, permission_level, detail, created_at
            from audit_logs
            where user_id = ${userId}
              and permission_level = ${level}
              and (
                created_at < ${cursor.createdAt}::timestamptz
                or (created_at = ${cursor.createdAt}::timestamptz and id < ${cursor.id})
              )
            order by created_at desc, id desc
            limit ${limit}
          `
        : await sql<AuditRow>`
            select id, actor, action, entity_type, entity_id, permission_level, detail, created_at
            from audit_logs
            where user_id = ${userId}
              and permission_level = ${level}
            order by created_at desc, id desc
            limit ${limit}
          `;
  const items: ActivityEvent[] = [];
  for (const row of rows) {
    const mapped = mapActivityEvent(row);
    if (mapped) items.push(mapped);
  }
  return items;
}

/**
 * Read this user's activity. Append-only table; this function never writes.
 * Scoped to context.userId. Does not return payloads or other users' rows.
 */
export const listActivity = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => listInput.parse(input ?? {}))
  .handler(async ({ context, data }): Promise<ActivityPage> => {
    const userId = context.userId;
    const level = asActivityLevelFilter(data?.level);
    const cursor = decodeCursor(data?.cursor ?? null);
    const [events, pending] = await Promise.all([
      loadEvents(userId, level, cursor),
      loadPending(userId),
    ]);
    const page = pageFromRows(events, ACTIVITY_PAGE_SIZE);
    return {
      items: page.items,
      nextCursor: page.nextCursor,
      pending: pending.items,
      pendingTotal: pending.total,
    };
  });
