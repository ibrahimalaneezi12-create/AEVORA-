import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  echoGuard,
  listCompatibleVoices,
  pickVoice,
  voiceSupportsLocale,
  type BrowserVoice,
} from "./voice-format.ts";

const voices: BrowserVoice[] = [
  { name: "AEVORA English", lang: "en-US", default: true },
  { name: "AEVORA Arabic", lang: "ar-SA" },
  { name: "Quiet British", lang: "en-GB" },
];

describe("pickVoice", () => {
  it("uses the preferred name when it matches the language", () => {
    const picked = pickVoice(voices, "Quiet British", "en");
    assert.equal(picked?.name, "Quiet British");
  });

  it("falls back when the preferred voice cannot speak Arabic", () => {
    const picked = pickVoice(voices, "AEVORA English", "ar");
    assert.equal(picked?.name, "AEVORA Arabic");
    assert.equal(voiceSupportsLocale(picked, "ar"), true);
  });

  it("does not list incompatible voices as selectable", () => {
    const ar = listCompatibleVoices(voices, "ar");
    assert.deepEqual(
      ar.map((v) => v.name),
      ["AEVORA Arabic"],
    );
  });
});

describe("echoGuard", () => {
  it("treats a prefix of the spoken reply as echo", () => {
    assert.equal(
      echoGuard("Here's what you have planned today", "Here's what you have planned today for calculus."),
      true,
    );
    assert.equal(echoGuard("study at 8", "Here's what you have planned today"), false);
  });
});
