import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { aegisContainsProfanity, sanitizeAegisText } from "./personality.ts";

describe("Aegis personality", () => {
  it("strips vulgar words without mirroring the user", () => {
    assert.equal(
      sanitizeAegisText("I get why that's frustrating. Let's figure out what's slowing it down."),
      "I get why that's frustrating. Let's figure out what's slowing it down.",
    );
    assert.equal(aegisContainsProfanity("Why the fuck is this slow?"), true);
    assert.equal(sanitizeAegisText("This is fucking slow."), "This is slow.");
    assert.equal(aegisContainsProfanity("class assignment"), false);
  });
});
