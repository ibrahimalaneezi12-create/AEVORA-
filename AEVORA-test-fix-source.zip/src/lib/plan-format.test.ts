import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { composeDailyBriefing, composeDayPlan, composeWeekPlan, goalHealth } from "./plan-format.ts";
import type { Goal, Task } from "./goals-format.ts";
import type { Reminder } from "./reminders-format.ts";

function goal(partial: Partial<Goal> & Pick<Goal, "id" | "title">): Goal {
  return {
    description: "",
    status: "active",
    targetDate: null,
    createdAt: "2026-09-01T00:00:00.000Z",
    updatedAt: "2026-09-17T00:00:00.000Z",
    ...partial,
  };
}

function task(partial: Partial<Task> & Pick<Task, "id" | "title">): Task {
  return {
    goalId: null,
    notes: "",
    status: "todo",
    dueDate: null,
    sortOrder: 0,
    createdAt: "2026-09-17T00:00:00.000Z",
    updatedAt: "2026-09-17T00:00:00.000Z",
    ...partial,
  };
}

function reminder(partial: Partial<Reminder> & Pick<Reminder, "id" | "title">): Reminder {
  return {
    body: "",
    timezone: "UTC",
    fireAt: "2026-09-18T19:00:00.000Z",
    localDate: "2026-09-18",
    localTime: "19:00",
    recurrence: "once",
    weekday: null,
    status: "scheduled",
    snoozeUntil: null,
    lastFiredAt: null,
    locale: "en",
    retryCount: 0,
    relatedTaskId: null,
    relatedGoalId: null,
    createdAt: "2026-09-18T00:00:00.000Z",
    updatedAt: "2026-09-18T00:00:00.000Z",
    ...partial,
  };
}

const now = new Date("2026-09-18T12:00:00.000Z");

describe("composeDayPlan", () => {
  it("uses only real due tasks and reminders and stays empty otherwise", () => {
    const empty = composeDayPlan({ now, timezone: "UTC", tasks: [], reminders: [], goals: [] });
    assert.equal(empty.empty, true);
    assert.match(empty.note, /invented/);
    const plan = composeDayPlan({
      now,
      timezone: "UTC",
      tasks: [task({ id: 1, title: "Study calculus", dueDate: "2026-09-18" })],
      reminders: [reminder({ id: 9, title: "Study" })],
      goals: [],
    });
    assert.equal(plan.empty, false);
    assert.equal(plan.items.some((i) => i.title === "Study calculus"), true);
    assert.equal(plan.items.some((i) => i.id === 9), true);
  });

  it("does not invent a calendar event", () => {
    const plan = composeDayPlan({
      now,
      timezone: "UTC",
      tasks: [task({ id: 2, title: "Later", dueDate: "2026-09-25" })],
      reminders: [],
      goals: [],
    });
    assert.equal(plan.items.length, 0);
  });
});

describe("goalHealth", () => {
  it("does not manufacture a score and reports missing tasks honestly", () => {
    const g = goal({ id: 3, title: "Pass exams" });
    const health = goalHealth(g, [], "2026-09-18", now);
    assert.equal(health.openTaskCount, 0);
    assert.ok(health.notes.some((n) => /Not enough/.test(n)));
  });
});

describe("composeDailyBriefing", () => {
  it("stays empty without fake progress", () => {
    const brief = composeDailyBriefing({
      now,
      timezone: "UTC",
      greetingName: "Ibrahim",
      locale: "en",
      tasks: [],
      goals: [],
      reminders: [],
    });
    assert.equal(brief.empty, true);
    assert.equal(brief.tasks.length, 0);
  });
});

describe("composeWeekPlan", () => {
  it("groups dated tasks by day", () => {
    const week = composeWeekPlan({
      now,
      timezone: "UTC",
      tasks: [task({ id: 4, title: "Exam prep", dueDate: "2026-09-20" })],
      reminders: [],
    });
    const day = week.byDate.find((d) => d.date === "2026-09-20");
    assert.ok(day);
    assert.equal(day.items[0]?.title, "Exam prep");
  });
});
