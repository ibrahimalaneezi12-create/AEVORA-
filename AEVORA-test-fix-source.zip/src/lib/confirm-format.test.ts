import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  CANNOT_APPROVE,
  NOT_PENDING,
  approvalBlockedReason,
  canApproveStatus,
  canDenyStatus,
  cannotApproveMessage,
  mapConfirmView,
  mapProposalView,
  parsePayloadJson,
  payloadPreview,
  requiredBody,
  requiredTitle,
  memorySavePayload,
  taskCreatePayload,
  type ProposalRow,
} from "./confirm-format.ts";
import { registerTool } from "./orchestrator/catalog.ts";

function row(partial: Partial<ProposalRow> & Pick<ProposalRow, "id" | "tool_id">): ProposalRow {
  return {
    conversation_id: 1,
    permission_level: "review",
    title: "Save tea preference",
    summary: "Remember black tea.",
    payload_json: "{}",
    status: "pending",
    created_at: "2026-09-17T00:00:00.000Z",
    error: null,
    ...partial,
  };
}

describe("approvalBlockedReason", () => {
  it("allows business and invest keep tools and blocks invented trades", () => {
    assert.equal(approvalBlockedReason("business.save", "review"), null);
    assert.equal(approvalBlockedReason("invest.watch", "review"), null);
    assert.equal(approvalBlockedReason("invest.unwatch", "approval"), null);
    assert.equal(approvalBlockedReason("invest.trade", "review"), CANNOT_APPROVE);
  });

  it("blocks stored Restricted even if the catalog would be quieter", () => {
    assert.equal(approvalBlockedReason("memory.save", "restricted"), CANNOT_APPROVE);
  });

  it("blocks catalog Restricted and unregistered ids", () => {
    assert.equal(approvalBlockedReason("permission.update", "restricted"), CANNOT_APPROVE);
    assert.equal(approvalBlockedReason("permission.update", "safe"), CANNOT_APPROVE);
    assert.equal(approvalBlockedReason("external.email", "approval"), CANNOT_APPROVE);
    assert.equal(approvalBlockedReason("shell.exec", "safe"), CANNOT_APPROVE);
  });

  it("blocks chat.reply", () => {
    assert.equal(approvalBlockedReason("chat.reply", "safe"), CANNOT_APPROVE);
  });

  it("blocks a registered tool that cannot run", () => {
    registerTool({
      id: "test.step14.confirm.nohandler",
      displayName: "No handler",
      description: "Missing handler",
      permissionLevel: "review",
      enabled: true,
    });
    assert.equal(
      approvalBlockedReason("test.step14.confirm.nohandler", "review"),
      CANNOT_APPROVE,
    );
  });
});

describe("cannotApproveMessage / canDenyStatus", () => {
  it("refuses non-pending rows", () => {
    assert.equal(cannotApproveMessage("memory.save", "review", "approved"), NOT_PENDING);
    assert.equal(cannotApproveMessage("memory.save", "review", "denied"), NOT_PENDING);
    assert.equal(cannotApproveMessage("memory.save", "review", "executed"), NOT_PENDING);
    assert.equal(cannotApproveMessage("memory.save", "review", "failed"), NOT_PENDING);
    assert.equal(canApproveStatus("memory.save", "review", "executed"), false);
    assert.equal(canDenyStatus("executed"), false);
    assert.equal(canDenyStatus("denied"), false);
    assert.equal(canDenyStatus("pending"), true);
  });

  it("allows a pending Review tool", () => {
    assert.equal(cannotApproveMessage("memory.save", "review", "pending"), null);
    assert.equal(canApproveStatus("memory.save", "review", "pending"), true);
  });
});

describe("parsePayloadJson", () => {
  it("returns objects and fails closed on junk", () => {
    assert.deepEqual(parsePayloadJson('{"kind":"preference"}'), { kind: "preference" });
    assert.deepEqual(parsePayloadJson("[]"), {});
    assert.deepEqual(parsePayloadJson("not-json"), {});
  });
});

describe("payloadPreview", () => {
  it("renders plain-language lines and skips empty nested values", () => {
    const lines = payloadPreview({
      kind: "preference",
      body: "black tea",
      pinned: true,
      nested: { secret: "nope" },
      tags: "",
    });
    assert.deepEqual(lines, [
      { label: "Kind", value: "preference" },
      { label: "Memory", value: "black tea" },
      { label: "Pinned", value: "Yes" },
    ]);
  });
});

describe("mapConfirmView", () => {
  it("lets a pending Review tool be approved or denied", () => {
    const view = mapConfirmView(row({ id: 4, tool_id: "memory.save" }), "Save a memory");
    assert.equal(view?.canApprove, true);
    assert.equal(view?.canDeny, true);
    assert.equal(view?.blockedReason, null);
    assert.equal(view?.status, "pending");
  });

  it("does not leak raw payload_json onto the view", () => {
    const view = mapConfirmView(
      row({
        id: 5,
        tool_id: "memory.save",
        payload_json: '{"body":"payload-secret-orchid-77"}',
      }),
      "Save a memory",
    );
    assert.equal(JSON.stringify(view).includes("payload_json"), false);
    assert.equal(view?.payloadPreview.some((l) => l.value === "payload-secret-orchid-77"), true);
  });

  it("blocks Restricted and still allows deny while pending", () => {
    const view = mapConfirmView(
      row({
        id: 6,
        tool_id: "permission.update",
        permission_level: "restricted",
      }),
      "Change permissions",
    );
    assert.equal(view?.canApprove, false);
    assert.equal(view?.canDeny, true);
    assert.equal(view?.blockedReason, CANNOT_APPROVE);
  });

  it("locks executed rows", () => {
    const view = mapConfirmView(
      row({ id: 7, tool_id: "memory.save", status: "executed" }),
      "Save a memory",
    );
    assert.equal(view?.canApprove, false);
    assert.equal(view?.canDeny, false);
  });
});

describe("mapProposalView", () => {
  it("drops invalid ids", () => {
    assert.equal(mapProposalView(row({ id: 0, tool_id: "memory.save" }), "Save a memory"), null);
  });
});

describe("requiredTitle / requiredBody", () => {
  it("falls back to the proposal title and summary", () => {
    assert.equal(requiredTitle(undefined, "Save tea preference"), "Save tea preference");
    assert.equal(requiredBody(undefined, "Remember black tea.", "Save tea"), "Remember black tea.");
  });
});

describe("payload schemas", () => {
  it("accepts a partial memory.save payload", () => {
    const parsed = memorySavePayload.parse({ kind: "preference", body: "tea" });
    assert.equal(parsed.kind, "preference");
    assert.equal(parsed.body, "tea");
  });

  it("accepts task.create without a due date", () => {
    const parsed = taskCreatePayload.parse({ title: "Buy tea" });
    assert.equal(parsed.title, "Buy tea");
    assert.equal(parsed.dueDate, null);
  });
});
