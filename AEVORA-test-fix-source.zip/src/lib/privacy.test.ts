import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { taskMayLinkToGoal } from "./goals-format.ts";
import { classifyTurnIntent, intentNeedsKeep, intentNeedsCalendar, intentNeedsMail, providerContextFlags } from "./intent-format.ts";
import { isFounderEmail } from "./founder-email.ts";
import { shouldExposeVoiceDiag } from "./latency-format.ts";
import { sanitizeIlike } from "./memory-format.ts";
import { NOT_FOUND } from "./confirm-format.ts";
import { canRunTool, catalogLevel } from "./orchestrator/catalog.ts";
import { sanitizeAegisText, aegisContainsProfanity } from "./personality.ts";
import {
  PRIVATE_HTTP_HEADERS,
  GENERIC_NOT_FOUND,
  sessionOwns,
  founderDoesNotBypassOwnership,
  clientUserIdMustBeIgnored,
} from "./privacy.ts";

describe("private data isolation", () => {
  it("allows a user to own their own resource and denies everyone else", () => {
    assert.equal(sessionOwns("user-a", "user-a"), true);
    assert.equal(sessionOwns("user-a", "user-b"), false);
    assert.equal(sessionOwns("user-b", "user-a"), false);
    assert.equal(sessionOwns("user-a", null), false);
    assert.equal(sessionOwns("", "user-a"), false);
  });

  it("refuses to attach a task to another user's goal", () => {
    assert.equal(taskMayLinkToGoal("user-a", "user-a"), true);
    assert.equal(taskMayLinkToGoal("user-a", "user-b"), false);
    assert.equal(taskMayLinkToGoal("user-b", "user-a"), false);
  });

  it("does not let founder status read another account's keep", () => {
    assert.equal(
      founderDoesNotBypassOwnership({
        sessionUserId: "founder",
        resourceUserId: "someone-else",
        isFounder: true,
      }),
      false,
    );
    assert.equal(
      founderDoesNotBypassOwnership({
        sessionUserId: "founder",
        resourceUserId: "founder",
        isFounder: true,
      }),
      true,
    );
    assert.equal(isFounderEmail("not-the-founder@example.com"), false);
  });

  it("ignores a client-supplied user id in favor of the session", () => {
    assert.equal(clientUserIdMustBeIgnored("session-a", "session-b"), "session-a");
    assert.equal(clientUserIdMustBeIgnored("session-a", null), "session-a");
  });

  it("does not confirm another user's resources exist", () => {
    assert.equal(NOT_FOUND, "Proposal not found.");
    assert.equal(GENERIC_NOT_FOUND, "Not found.");
    assert.doesNotMatch(NOT_FOUND, /user-b|email|secret/i);
  });

  it("keeps private responses uncacheable", () => {
    assert.match(PRIVATE_HTTP_HEADERS["Cache-Control"], /no-store/);
    assert.match(PRIVATE_HTTP_HEADERS["Cache-Control"], /private/);
    assert.match(PRIVATE_HTTP_HEADERS.Vary, /Authorization/);
  });

  it("does not load keep, calendar, or mail for public search or casual chat", () => {
    assert.equal(intentNeedsKeep(classifyTurnIntent("I'm bored.")), false);
    assert.equal(intentNeedsKeep(classifyTurnIntent("search for the weather in London")), false);
    assert.equal(intentNeedsKeep(classifyTurnIntent("research the evidence on sleep")), false);
    assert.equal(intentNeedsKeep(classifyTurnIntent("Switch to Arabic.")), false);
    assert.equal(intentNeedsCalendar(classifyTurnIntent("I'm bored."), "I'm bored."), false);
    assert.equal(intentNeedsMail(classifyTurnIntent("What's 2 plus 2?"), "What's 2 plus 2?"), false);
  });

  it("does not send business or invest keep on unrelated turns", () => {
    const bored = providerContextFlags(classifyTurnIntent("What's up?"), "What's up?");
    assert.equal(bored.business, false);
    assert.equal(bored.invest, false);
    assert.equal(bored.keep, false);
    const company = providerContextFlags(classifyTurnIntent("Research this company."), "Research this company.");
    assert.equal(company.invest, false);
    assert.equal(company.business, false);
    assert.equal(company.keep, false);
    assert.equal(company.calendar, false);
    assert.equal(company.mail, false);
    const owned = providerContextFlags(classifyTurnIntent("How is my portfolio?"), "How is my portfolio?");
    assert.equal(owned.invest, true);
  });

  it("still loads this user's keep for memory, tasks, and planning", () => {
    assert.equal(intentNeedsKeep(classifyTurnIntent("Remember that I drink tea.")), true);
    assert.equal(intentNeedsKeep(classifyTurnIntent("Remind me tomorrow at 7 to study.")), true);
    assert.equal(intentNeedsKeep(classifyTurnIntent("Plan my day.")), true);
    assert.equal(intentNeedsKeep(classifyTurnIntent("What did we decide?")), true);
  });

  it("strips search wildcards so a user cannot broaden another query", () => {
    assert.equal(sanitizeIlike("tea%preference_"), "tea preference");
  });

  it("hides voice diagnostics from the normal UI", () => {
    assert.equal(shouldExposeVoiceDiag(), false);
  });

  it("never executes restricted or invented tools", () => {
    assert.equal(canRunTool("permission.update"), false);
    assert.equal(catalogLevel("permission.update"), "restricted");
    assert.equal(canRunTool("shell.exec"), false);
    assert.equal(canRunTool("external.http"), false);
    assert.equal(catalogLevel("external.http"), "restricted");
    assert.equal(canRunTool("not.a.real.tool"), false);
    assert.equal(canRunTool("invest.trade"), false);
    assert.equal(catalogLevel("invest.trade"), "restricted");
  });

  it("strips profanity from Aegis speech", () => {
    assert.equal(aegisContainsProfanity("That is fucking ridiculous."), true);
    assert.equal(sanitizeAegisText("That is fucking ridiculous.").includes("fuck"), false);
  });
});
