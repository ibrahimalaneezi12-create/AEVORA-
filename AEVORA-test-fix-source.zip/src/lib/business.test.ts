import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  businessMayAccess,
  composeBusinessBriefing,
  composeBusinessManagerReport,
  decisionWarnings,
  formatBusinessBlock,
  mapBusiness,
  type Business,
  type BusinessNote,
} from "./business-format.ts";
import { catalogLevel, canRunTool } from "./orchestrator/catalog.ts";

function biz(partial: Partial<Business> & Pick<Business, "id" | "name">): Business {
  return {
    offer: "",
    audience: "",
    notes: "",
    createdAt: "2026-09-22T00:00:00.000Z",
    updatedAt: "2026-09-22T00:00:00.000Z",
    ...partial,
  };
}

function note(partial: Partial<BusinessNote> & Pick<BusinessNote, "id" | "title" | "body">): BusinessNote {
  return {
    businessId: 1,
    kind: "note",
    createdAt: "2026-09-22T00:00:00.000Z",
    updatedAt: "2026-09-22T00:00:00.000Z",
    ...partial,
  };
}

describe("business keep", () => {
  it("isolates businesses by session owner", () => {
    assert.equal(businessMayAccess("user-a", "user-a"), true);
    assert.equal(businessMayAccess("user-a", "user-b"), false);
    assert.equal(businessMayAccess("founder", "user-b"), false);
  });

  it("does not invent revenue when none is recorded", () => {
    const briefing = composeBusinessBriefing([biz({ id: 1, name: "North Lamp" })], []);
    assert.equal(briefing.empty, false);
    assert.equal(briefing.missing.some((m) => /revenue/i.test(m)), true);
    assert.doesNotMatch(briefing.speech, /\$\d/);
    assert.doesNotMatch(briefing.speech, /\b\d{3,}\s*(customers|revenue)/i);
  });

  it("empty keep stays honest", () => {
    const briefing = composeBusinessBriefing([], []);
    assert.equal(briefing.empty, true);
    assert.match(briefing.speech, /will not invent numbers/i);
  });

  it("formats owned rows with ids and omits empty blocks", () => {
    const block = formatBusinessBlock(
      [biz({ id: 4, name: "North Lamp", offer: "Desk lamps" })],
      [note({ id: 9, title: "Competitor", body: "Public pricing on their site is $40.", kind: "competitor" })],
    );
    assert.match(block, /#4/);
    assert.match(block, /North Lamp/);
    assert.match(block, /note #9/);
    assert.equal(formatBusinessBlock([], []), "");
  });

  it("maps rows and drops junk ids", () => {
    assert.equal(mapBusiness({ id: 0, name: "x", offer: "", audience: "", notes: "", created_at: "", updated_at: "" }), null);
    assert.equal(mapBusiness({ id: 2, name: "x", offer: "", audience: "", notes: "", created_at: "2026-01-01", updated_at: "2026-01-01" })?.id, 2);
  });

  it("registers business tools as review and never invents a trade or HTTP tool", () => {
    assert.equal(catalogLevel("business.save"), "review");
    assert.equal(catalogLevel("business.note"), "review");
    assert.equal(canRunTool("business.save"), true);
    assert.equal(canRunTool("external.stripe"), false);
  });

  it("omits empty manager sections and never invents work", () => {
    const empty = composeBusinessManagerReport({ businesses: [], notes: [] });
    assert.equal(empty.empty, true);
    assert.equal(empty.sections.length, 0);
    assert.match(empty.speech, /not invent numbers/i);

    const report = composeBusinessManagerReport({
      businesses: [biz({ id: 1, name: "North Lamp" })],
      notes: [
        note({ id: 2, kind: "opportunity", title: "Repeat wholesale order", body: "They asked again." }),
        note({ id: 3, kind: "risk", title: "Supplier delay", body: "Two weeks late." }),
      ],
      pendingTitles: ["Save a decision"],
      executedTitles: [],
    });
    assert.equal(report.sections.some((s) => s.id === "working"), false);
    assert.equal(report.sections.find((s) => s.id === "well")?.lines[0], "Repeat wholesale order");
    assert.equal(report.sections.find((s) => s.id === "attention")?.lines[0], "Supplier delay");
    assert.equal(report.sections.find((s) => s.id === "owner")?.lines[0], "Save a decision");
    assert.doesNotMatch(report.speech, /revenue is up|customers grew|I have been monitoring/i);
  });

  it("quotes a saved price decision instead of silently reversing it", () => {
    const warnings = decisionWarnings(
      [note({ id: 4, kind: "decision", title: "Pricing", body: "We decided not to lower prices." })],
      "Should we lower prices this quarter?",
    );
    assert.equal(warnings.length, 1);
    assert.match(warnings[0] ?? "", /previously decided not to lower prices/i);
    assert.equal(
      decisionWarnings(
        [note({ id: 4, kind: "decision", title: "Pricing", body: "We decided not to lower prices." })],
        "How's the business?",
      ).length,
      0,
    );
  });
});
