import { calendarDateInZone, classifyDue } from "./dashboard-format.ts";
import type { Goal } from "./goals-format.ts";
import type { Task } from "./goals-format.ts";
import type { Reminder } from "./reminders-format.ts";
import { clipText } from "./memory-format.ts";

const OPEN_TASK = new Set(["todo", "doing"]);

export type GoalHealth = {
  id: number;
  title: string;
  status: Goal["status"];
  openTaskCount: number;
  overdueTaskCount: number;
  daysSinceUpdate: number | null;
  daysToTarget: number | null;
  stalled: boolean;
  notes: string[];
};

export type PlanItem = {
  kind: "task" | "reminder" | "goal";
  id: number;
  title: string;
  when: string | null;
  detail: string;
};

export type DayPlan = {
  today: string;
  timezone: string;
  items: PlanItem[];
  conflicts: string[];
  empty: boolean;
  note: string;
};

export type WeekPlan = {
  start: string;
  end: string;
  timezone: string;
  byDate: { date: string; items: PlanItem[] }[];
  conflicts: string[];
  empty: boolean;
  note: string;
};

export type DailyBriefing = {
  today: string;
  timezone: string;
  greetingName: string;
  locale: string;
  tasks: PlanItem[];
  deadlines: PlanItem[];
  goals: GoalHealth[];
  reminders: PlanItem[];
  followUps: string[];
  suggestedPriorities: string[];
  conflicts: string[];
  empty: boolean;
};

function daysBetween(a: string, b: string): number {
  const ms = Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`);
  if (Number.isNaN(ms)) return 0;
  return Math.round(ms / 86400000);
}

export function goalHealth(
  goal: Goal,
  tasks: Task[],
  today: string,
  now: Date,
): GoalHealth {
  const linked = tasks.filter((t) => t.goalId === goal.id);
  const open = linked.filter((t) => OPEN_TASK.has(t.status));
  const overdue = open.filter((t) => classifyDue(t.dueDate, today) === "overdue");
  const updated = Date.parse(goal.updatedAt);
  const daysSinceUpdate = Number.isNaN(updated)
    ? null
    : Math.max(0, Math.round((now.getTime() - updated) / 86400000));
  const daysToTarget = goal.targetDate ? daysBetween(today, goal.targetDate) : null;
  const notes: string[] = [];
  if (goal.status !== "active") notes.push(`Goal is ${goal.status}.`);
  if (open.length === 0 && goal.status === "active") {
    notes.push("No open tasks are linked. Not enough to score progress.");
  }
  if (overdue.length > 0) notes.push(`${overdue.length} overdue task(s).`);
  if (daysToTarget !== null && daysToTarget < 0) notes.push("Target date has passed.");
  const stalled =
    goal.status === "active" &&
    daysSinceUpdate !== null &&
    daysSinceUpdate >= 14 &&
    overdue.length === 0 &&
    open.length > 0;
  if (stalled) notes.push("No updates in 14 days — may be stalled.");
  return {
    id: goal.id,
    title: goal.title,
    status: goal.status,
    openTaskCount: open.length,
    overdueTaskCount: overdue.length,
    daysSinceUpdate,
    daysToTarget,
    stalled,
    notes,
  };
}

export function composeDayPlan(opts: {
  now: Date;
  timezone: string;
  tasks: Task[];
  reminders: Reminder[];
  goals: Goal[];
}): DayPlan {
  const timezone = opts.timezone.trim() || "UTC";
  const today = calendarDateInZone(opts.now, timezone);
  const items: PlanItem[] = [];
  for (const task of opts.tasks) {
    if (!OPEN_TASK.has(task.status)) continue;
    const kind = classifyDue(task.dueDate, today);
    if (kind !== "overdue" && kind !== "today") continue;
    items.push({
      kind: "task",
      id: task.id,
      title: task.title,
      when: task.dueDate,
      detail: kind === "overdue" ? "overdue" : "due today",
    });
  }
  for (const reminder of opts.reminders) {
    if (reminder.status !== "scheduled" && reminder.status !== "snoozed") continue;
    const fireDate = calendarDateInZone(new Date(reminder.fireAt), timezone);
    if (fireDate !== today) continue;
    items.push({
      kind: "reminder",
      id: reminder.id,
      title: reminder.title,
      when: reminder.fireAt,
      detail: reminder.recurrence === "once" ? "once" : reminder.recurrence,
    });
  }
  const conflicts: string[] = [];
  const overdueCount = items.filter((i) => i.detail === "overdue").length;
  if (overdueCount >= 3) {
    conflicts.push("Several overdue tasks land on today. The plan cannot finish all of them.");
  }
  const empty = items.length === 0;
  return {
    today,
    timezone,
    items,
    conflicts,
    empty,
    note: empty
      ? "Nothing due today. No tasks or reminders were invented."
      : "Built from your tasks and reminders only. No calendar is connected.",
  };
}

function datePlus(start: string, days: number): string {
  const t = Date.parse(`${start}T00:00:00Z`);
  if (Number.isNaN(t)) return start;
  return new Date(t + days * 86400000).toISOString().slice(0, 10);
}

export function composeWeekPlan(opts: {
  now: Date;
  timezone: string;
  tasks: Task[];
  reminders: Reminder[];
}): WeekPlan {
  const timezone = opts.timezone.trim() || "UTC";
  const start = calendarDateInZone(opts.now, timezone);
  const end = datePlus(start, 6);
  const byDate: { date: string; items: PlanItem[] }[] = [];
  for (let i = 0; i < 7; i += 1) {
    const date = datePlus(start, i);
    const items: PlanItem[] = [];
    for (const task of opts.tasks) {
      if (!OPEN_TASK.has(task.status) || !task.dueDate) continue;
      if (task.dueDate !== date) continue;
      items.push({
        kind: "task",
        id: task.id,
        title: task.title,
        when: task.dueDate,
        detail: "due",
      });
    }
    for (const reminder of opts.reminders) {
      if (reminder.status !== "scheduled" && reminder.status !== "snoozed") continue;
      const fireDate = calendarDateInZone(new Date(reminder.fireAt), timezone);
      if (fireDate !== date) continue;
      items.push({
        kind: "reminder",
        id: reminder.id,
        title: reminder.title,
        when: reminder.fireAt,
        detail: reminder.recurrence,
      });
    }
    byDate.push({ date, items });
  }
  const conflicts: string[] = [];
  for (const day of byDate) {
    if (day.items.length >= 6) {
      conflicts.push(`${day.date} is overloaded (${day.items.length} items).`);
    }
  }
  const empty = byDate.every((d) => d.items.length === 0);
  return {
    start,
    end,
    timezone,
    byDate,
    conflicts,
    empty,
    note: empty
      ? "No dated tasks or reminders this week. Nothing was invented."
      : "Week view uses due dates and scheduled reminders only.",
  };
}

export function composeDailyBriefing(opts: {
  now: Date;
  timezone: string;
  greetingName: string;
  locale: string;
  tasks: Task[];
  goals: Goal[];
  reminders: Reminder[];
}): DailyBriefing {
  const timezone = opts.timezone.trim() || "UTC";
  const today = calendarDateInZone(opts.now, timezone);
  const day = composeDayPlan(opts);
  const deadlines: PlanItem[] = [];
  for (const task of opts.tasks) {
    if (!OPEN_TASK.has(task.status) || !task.dueDate) continue;
    if (task.dueDate <= today) continue;
    const soon = daysBetween(today, task.dueDate);
    if (soon >= 0 && soon <= 3) {
      deadlines.push({
        kind: "task",
        id: task.id,
        title: task.title,
        when: task.dueDate,
        detail: `in ${soon}d`,
      });
    }
  }
  const goals = opts.goals
    .filter((g) => g.status === "active")
    .slice(0, 6)
    .map((g) => goalHealth(g, opts.tasks, today, opts.now));
  const followUps: string[] = [];
  for (const g of goals) {
    if (g.stalled) followUps.push(`Goal #${g.id} “${clipText(g.title, 40)}” looks stalled.`);
    if (g.overdueTaskCount > 0) {
      followUps.push(`Goal #${g.id} has ${g.overdueTaskCount} overdue task(s).`);
    }
  }
  const overdueTasks = day.items.filter((i) => i.detail === "overdue");
  const suggestedPriorities: string[] = [];
  if (overdueTasks[0]) suggestedPriorities.push(`Clear overdue: ${overdueTasks[0].title}`);
  const firstToday = day.items.find((i) => i.detail === "due today");
  if (firstToday) suggestedPriorities.push(`Due today: ${firstToday.title}`);
  const firstReminder = day.items.find((i) => i.kind === "reminder");
  if (firstReminder) suggestedPriorities.push(`Reminder: ${firstReminder.title}`);
  const empty =
    day.items.length === 0 && deadlines.length === 0 && goals.length === 0 && followUps.length === 0;
  return {
    today,
    timezone,
    greetingName: opts.greetingName,
    locale: opts.locale,
    tasks: day.items.filter((i) => i.kind === "task"),
    deadlines,
    goals,
    reminders: day.items.filter((i) => i.kind === "reminder"),
    followUps,
    suggestedPriorities: suggestedPriorities.slice(0, 3),
    conflicts: day.conflicts,
    empty,
  };
}

export function formatBriefingSpeech(brief: DailyBriefing): string {
  if (brief.empty) {
    return "Nothing is due today. There are no upcoming deadlines, active-goal alerts, or reminders in the next window. I will not invent any.";
  }
  const lines: string[] = [];
  lines.push(`Today is ${brief.today} (${brief.timezone}).`);
  if (brief.tasks.length) {
    lines.push(
      `Tasks: ${brief.tasks.map((t) => `#${t.id} ${t.title} (${t.detail})`).join("; ")}.`,
    );
  }
  if (brief.reminders.length) {
    lines.push(`Reminders: ${brief.reminders.map((r) => `#${r.id} ${r.title}`).join("; ")}.`);
  }
  if (brief.deadlines.length) {
    lines.push(
      `Upcoming: ${brief.deadlines.map((d) => `#${d.id} ${d.title} ${d.detail}`).join("; ")}.`,
    );
  }
  if (brief.goals.length) {
    lines.push(
      `Goals: ${brief.goals.map((g) => `#${g.id} ${g.title}${g.notes[0] ? ` — ${g.notes[0]}` : ""}`).join("; ")}.`,
    );
  }
  if (brief.followUps.length) lines.push(brief.followUps.join(" "));
  if (brief.conflicts.length) lines.push(brief.conflicts.join(" "));
  if (brief.suggestedPriorities.length) {
    lines.push(`Suggested focus: ${brief.suggestedPriorities.join(" · ")}`);
  }
  lines.push("No calendar is connected. Nothing here was invented.");
  return lines.join(" ");
}

export function formatDayPlanSpeech(plan: DayPlan): string {
  if (plan.empty) return plan.note;
  const body = plan.items
    .map((i) => `#${i.id} ${i.title}${i.when ? ` (${i.detail}${i.when ? `, ${i.when}` : ""})` : ""}`)
    .join("; ");
  const extra = plan.conflicts.length ? ` ${plan.conflicts.join(" ")}` : "";
  return `${plan.note} ${body}.${extra}`;
}
