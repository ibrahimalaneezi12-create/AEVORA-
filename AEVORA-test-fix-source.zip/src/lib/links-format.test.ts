import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { businessLinks } from "./links-format.ts";

describe("business links", () => {
  it("does not mark accounting, ads, or a store as connected", () => {
    const links = businessLinks({
      gmail: false,
      gmailDetail: "Gmail is not connected.",
      calendar: true,
      calendarDetail: "Google Calendar is connected.",
    });
    const books = links.find((link) => link.id === "books");
    const ads = links.find((link) => link.id === "ads");
    const shop = links.find((link) => link.id === "shop");
    const crm = links.find((link) => link.id === "crm");
    assert.equal(books?.connected, false);
    assert.equal(books?.available, false);
    assert.equal(books?.status, "not_configured");
    assert.equal(ads?.connected, false);
    assert.equal(ads?.available, false);
    assert.equal(shop?.connected, false);
    assert.equal(shop?.available, true);
    assert.equal(crm?.connected, false);
    assert.equal(links.find((link) => link.id === "calendar")?.connected, true);
    assert.equal(links.find((link) => link.id === "gmail")?.connected, false);
    assert.equal(links.find((link) => link.id === "gmail")?.connect, "gate");
    assert.equal(ads?.connect, "oauth");
    assert.equal(books?.connect, "oauth");
    const inventory = links.find((link) => link.id === "inventory");
    assert.equal(inventory?.status, "provider_unavailable");
    assert.equal(inventory?.connected, false);
    assert.equal(inventory?.connect, "shopify");
    assert.match(inventory?.detail ?? "", /Shopify/);
    assert.equal(links.some((link) => link.id === "books" && link.connected), false);
  });
});
