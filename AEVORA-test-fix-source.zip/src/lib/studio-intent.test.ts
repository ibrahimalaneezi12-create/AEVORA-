import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { classifyStudioIntent } from "./studio-intent.ts";

const empty = {
  hasPhotoAttachment: false,
  hasVideoAttachment: false,
  hasCurrentPhoto: false,
  hasCurrentVideo: false,
};

describe("studio conversational intent", () => {
  it("defaults a visual ask to a photo", () => {
    assert.equal(classifyStudioIntent({ ...empty, prompt: "Make a futuristic city." }).action, "photo.generate");
    assert.equal(
      classifyStudioIntent({ ...empty, prompt: "Make me a realistic photo of a futuristic city at night." }).action,
      "photo.generate",
    );
    assert.equal(
      classifyStudioIntent({
        ...empty,
        prompt: "Make me a black Lamborghini driving through Tokyo at night.",
      }).action,
      "photo.generate",
    );
  });

  it("detects video without a mode picker", () => {
    assert.equal(
      classifyStudioIntent({
        ...empty,
        prompt: "Make me a 10 second cinematic video of a black sports car driving through Tokyo at night.",
      }).action,
      "video.generate",
    );
  });

  it("edits and animates the current still", () => {
    assert.equal(
      classifyStudioIntent({ ...empty, hasCurrentPhoto: true, prompt: "Make it rain." }).action,
      "photo.edit",
    );
    assert.equal(
      classifyStudioIntent({ ...empty, hasCurrentPhoto: true, prompt: "Now turn it into a 10-second video." }).action,
      "photo.animate",
    );
    assert.equal(
      classifyStudioIntent({ ...empty, hasCurrentPhoto: true, prompt: "Bring this to life." }).action,
      "photo.animate",
    );
    assert.equal(
      classifyStudioIntent({ ...empty, hasCurrentPhoto: true, prompt: "Create another version." }).action,
      "photo.variation",
    );
  });

  it("starts a new photo when the user clearly asks for one", () => {
    assert.equal(
      classifyStudioIntent({ ...empty, hasCurrentPhoto: true, prompt: "Make me a photo of a cat." }).action,
      "photo.generate",
    );
  });

  it("uses an attached photo or clip as the source", () => {
    assert.equal(
      classifyStudioIntent({ ...empty, hasPhotoAttachment: true, prompt: "Remove the person." }).action,
      "photo.edit",
    );
    assert.equal(
      classifyStudioIntent({ ...empty, hasVideoAttachment: true, prompt: "Make it more cinematic." }).action,
      "video.edit",
    );
  });

  it("varies a generated video including vertical", () => {
    assert.equal(
      classifyStudioIntent({
        ...empty,
        hasCurrentVideo: true,
        prompt: "Make it vertical.",
      }).action,
      "video.variation",
    );
  });
});
