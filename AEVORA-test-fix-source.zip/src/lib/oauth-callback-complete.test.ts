import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  cookieValueFromSetCookie,
  isPopupDoneLocation,
  oauthCallbackLocation,
} from "./oauth-callback-complete.ts";

describe("oauth callback completion", () => {
  it("reads the session cookie value from Set-Cookie without other attributes", () => {
    const token = cookieValueFromSetCookie(
      [
        "better-auth.oauth_state=abc; Path=/; Secure",
        "__Host-grok-auth.session_token=session.sig; Path=/; Secure; HttpOnly; SameSite=Lax",
      ],
      "__Host-grok-auth.session_token",
    );
    assert.equal(token, "session.sig");
  });

  it("returns null when the session cookie is absent", () => {
    assert.equal(cookieValueFromSetCookie(["better-auth.oauth_state=abc"], "__Host-grok-auth.session_token"), null);
  });

  it("recognizes the popup completion redirect", () => {
    const res = new Response(null, {
      status: 302,
      headers: { location: "/auth/popup?done=1" },
    });
    const loc = oauthCallbackLocation(res, "https://keep.grok-sandbox.com");
    assert.ok(loc);
    assert.equal(isPopupDoneLocation(loc), true);
    assert.equal(loc.searchParams.get("error"), null);
  });
});
