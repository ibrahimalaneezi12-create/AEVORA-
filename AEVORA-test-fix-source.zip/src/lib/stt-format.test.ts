import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  filenameForMime,
  isSpeechLevel,
  parseTranscriptBody,
  pickRecorderMime,
  rmsFromTimeDomain,
  STT_MODEL,
} from "./stt-format.ts";

describe("recorder mime", () => {
  it("prefers mp4 on Safari-like support and webm when that is all that exists", () => {
    assert.equal(STT_MODEL, "grok-voice-transcribe-2.0");
    assert.equal(
      pickRecorderMime((t) => t === "audio/mp4" || t.startsWith("audio/webm")),
      "audio/webm;codecs=opus",
    );
    assert.equal(
      pickRecorderMime((t) => t === "audio/mp4"),
      "audio/mp4",
    );
    assert.equal(filenameForMime("audio/mp4"), "speech.m4a");
  });
});

describe("transcript parse", () => {
  it("reads text without inventing a phrase", () => {
    assert.equal(parseTranscriptBody({ text: " Remind me at 8. " }), "Remind me at 8.");
    assert.equal(parseTranscriptBody({ transcript: "مرحبا" }), "مرحبا");
    assert.equal(parseTranscriptBody({ hello: true }), "");
  });
});

describe("vad", () => {
  it("treats a loud frame as speech and silence as not", () => {
    const loud = Uint8Array.from({ length: 32 }, () => 255);
    const quiet = Uint8Array.from({ length: 32 }, () => 128);
    assert.equal(isSpeechLevel(rmsFromTimeDomain(loud)), true);
    assert.equal(isSpeechLevel(rmsFromTimeDomain(quiet)), false);
  });
});
