import {
  DEFAULT_LOCALE,
  detectLanguageCode,
  dirForCode,
  englishNameFor,
  isLanguageCode,
  listedLanguages,
  lookupLanguage,
  resolveLanguageCode,
  speechTagFor,
  type LanguageMeta,
} from "./languages.ts";

export type AppLocale = string;

export const APP_LOCALES = listedLanguages().map((l) => l.code);

export { DEFAULT_LOCALE, listedLanguages, lookupLanguage, isLanguageCode };

export function resolveLocale(value: string | null | undefined): AppLocale {
  return resolveLanguageCode(value, DEFAULT_LOCALE);
}

export function dirFor(locale: AppLocale): "rtl" | "ltr" {
  return dirForCode(locale);
}

export function hasArabic(text: string): boolean {
  return /[\u0600-\u06FF]/.test(text);
}

export function hasLatin(text: string): boolean {
  return /[A-Za-z]/.test(text);
}

export function detectLocale(text: string): AppLocale | null {
  return detectLanguageCode(text);
}

export function resolveTurnLocale(opts: {
  preferred: AppLocale;
  detect: boolean;
  text: string;
  fallback?: AppLocale;
}): AppLocale {
  const preferred = resolveLocale(opts.preferred);
  if (!opts.detect) return preferred;
  return detectLocale(opts.text) ?? preferred;
}

export function speechLangFor(locale: AppLocale): string {
  return speechTagFor(locale);
}

export function applyDocumentLocale(locale: AppLocale): void {
  if (typeof document === "undefined") return;
  const resolved = resolveLocale(locale);
  const meta = lookupLanguage(resolved);
  const root = document.documentElement;
  root.lang = meta?.speech ?? resolved;
  root.dir = dirFor(resolved);
  root.dataset.locale = resolved;
}

export const LOCALE_LABELS: Record<string, { native: string; english: string }> =
  Object.fromEntries(
    listedLanguages().map((l) => [l.code, { native: l.nativeName, english: l.englishName }]),
  );

export function localeLabel(locale: AppLocale): { native: string; english: string } {
  const meta = lookupLanguage(locale);
  if (!meta) return { native: "English", english: "English" };
  return { native: meta.nativeName, english: meta.englishName };
}

export function languageDisplayName(locale: AppLocale): string {
  return englishNameFor(locale);
}

export function languageMeta(locale: AppLocale): LanguageMeta | null {
  return lookupLanguage(locale);
}
