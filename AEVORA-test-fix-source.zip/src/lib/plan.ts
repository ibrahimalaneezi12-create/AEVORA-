import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { mapGoal, mapTask, type Goal, type GoalRow, type Task, type TaskRow } from "@/lib/goals-format";
import { firstName } from "@/lib/dashboard-format";
import { resolveLocale } from "@/lib/locale";
import { mapReminder, type Reminder, type ReminderRow } from "@/lib/reminders-format";
import {
  composeDailyBriefing,
  composeDayPlan,
  composeWeekPlan,
  goalHealth,
  type DailyBriefing,
  type DayPlan,
  type GoalHealth,
  type WeekPlan,
} from "./plan-format.ts";

export {
  composeDailyBriefing,
  composeDayPlan,
  composeWeekPlan,
  formatBriefingSpeech,
  formatDayPlanSpeech,
  goalHealth,
} from "./plan-format.ts";
export type { DailyBriefing, DayPlan, GoalHealth, WeekPlan } from "./plan-format.ts";

type ProfileBits = {
  display_name: string | null;
  timezone: string | null;
  locale: string | null;
};

async function loadPlanningBits(userId: string): Promise<{
  timezone: string;
  locale: string;
  greetingName: string;
  goals: Goal[];
  tasks: Task[];
  reminders: Reminder[];
}> {
  const sql = await getSql();
  const [profileRows, goalRows, taskRows, reminderRows] = await Promise.all([
    sql<ProfileBits>`
      select display_name, timezone, locale
      from profiles
      where user_id = ${userId}
    `,
    sql<GoalRow>`
      select id, title, description, status, target_date, created_at, updated_at
      from goals
      where user_id = ${userId}
      order by updated_at desc
      limit 80
    `,
    sql<TaskRow>`
      select id, goal_id, title, notes, status, due_date, sort_order, created_at, updated_at
      from tasks
      where user_id = ${userId}
      order by sort_order asc, id asc
      limit 200
    `,
    sql<ReminderRow>`
      select id, title, body, timezone, fire_at, local_date, local_time, recurrence, weekday,
             status, snooze_until, last_fired_at, locale, retry_count, related_task_id, related_goal_id,
             created_at, updated_at
      from reminders
      where user_id = ${userId}
        and status in (${"scheduled"}, ${"snoozed"}, ${"pending_delivery"})
      order by fire_at asc
      limit 80
    `,
  ]);
  const goals: Goal[] = [];
  for (const row of goalRows) {
    const mapped = mapGoal(row);
    if (mapped) goals.push(mapped);
  }
  const tasks: Task[] = [];
  for (const row of taskRows) {
    const mapped = mapTask(row);
    if (mapped) tasks.push(mapped);
  }
  const reminders: Reminder[] = [];
  for (const row of reminderRows) {
    const mapped = mapReminder(row);
    if (mapped) reminders.push(mapped);
  }
  return {
    timezone: profileRows[0]?.timezone?.trim() || "UTC",
    locale: resolveLocale(profileRows[0]?.locale),
    greetingName: firstName(profileRows[0]?.display_name),
    goals,
    tasks,
    reminders,
  };
}

export const getDailyBriefing = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<DailyBriefing> => {
    const bits = await loadPlanningBits(context.userId);
    return composeDailyBriefing({
      now: new Date(),
      timezone: bits.timezone,
      greetingName: bits.greetingName,
      locale: bits.locale,
      tasks: bits.tasks,
      goals: bits.goals,
      reminders: bits.reminders,
    });
  });

export const getDayPlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<DayPlan> => {
    const bits = await loadPlanningBits(context.userId);
    return composeDayPlan({
      now: new Date(),
      timezone: bits.timezone,
      tasks: bits.tasks,
      reminders: bits.reminders,
      goals: bits.goals,
    });
  });

export const getWeekPlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<WeekPlan> => {
    const bits = await loadPlanningBits(context.userId);
    return composeWeekPlan({
      now: new Date(),
      timezone: bits.timezone,
      tasks: bits.tasks,
      reminders: bits.reminders,
    });
  });

export const getGoalHealth = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<GoalHealth[]> => {
    const bits = await loadPlanningBits(context.userId);
    const today = composeDayPlan({
      now: new Date(),
      timezone: bits.timezone,
      tasks: bits.tasks,
      reminders: bits.reminders,
      goals: bits.goals,
    }).today;
    return bits.goals
      .filter((g) => g.status === "active")
      .slice(0, 12)
      .map((g) => goalHealth(g, bits.tasks, today, new Date()));
  });
