/**
 * Follow-up resolution for the same conversation.
 * "Make it 8" / "Move that to Thursday" are not new topics.
 */

const FOLLOWUP_RE =
  /^(?:make it|change it(?: to)?|move (?:that|it|this)|actually(?: make it)?|instead|the other one|that one|do the first|do the second)\b/i;

const PRONOUN_EDIT_RE =
  /\b(move|change|delete|cancel|snooze|postpone|rename|mark|update|forget)\s+(that|this|it)\b/i;

export function isFollowUpTurn(text: string): boolean {
  const trimmed = text.trim();
  if (!trimmed || trimmed.length > 120) return false;
  if (FOLLOWUP_RE.test(trimmed)) return true;
  if (PRONOUN_EDIT_RE.test(trimmed) && trimmed.split(/\s+/).length <= 12) return true;
  return false;
}

export function followUpNote(): string {
  return "This is a follow-up. Resolve 'it/that/this' from the current conversation and pending actions. If two objects could match, ask which one — do not guess. Use real ids from assembled context.";
}
