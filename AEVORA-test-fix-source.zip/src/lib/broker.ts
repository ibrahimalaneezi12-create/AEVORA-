import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import type { BrokerSnapshot } from "@/lib/invest-brain";

function snapshotForClient(snapshot: BrokerSnapshot): BrokerSnapshot {
  if (!snapshot.account) return snapshot;
  return {
    ...snapshot,
    account: { ...snapshot.account, id: "", accountNumber: "" },
  };
}

const connectInput = z
  .object({
    mode: z.enum(["paper", "live"]),
    keyId: z.string().trim().min(8).max(128),
    secret: z.string().trim().min(8).max(256),
  })
  .strict();

const modeInput = z.object({ mode: z.enum(["paper", "live"]) });

export const connectAlpaca = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => connectInput.parse(input))
  .handler(async ({ context, data }) => {
    const { connectAlpacaForUser } = await import("./broker.server");
    const result = await connectAlpacaForUser(context.userId, data);
    if (!result.ok) return { ok: false as const, error: result.error };
    return { ok: true as const, mode: result.mode, capabilities: result.capabilities };
  });

export const disconnectAlpaca = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => modeInput.parse(input))
  .handler(async ({ context, data }) => {
    const { disconnectAlpacaForUser } = await import("./broker.server");
    return disconnectAlpacaForUser(context.userId, data.mode);
  });

export const brokerStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { publicBroker } = await import("./broker.server");
    const status = await publicBroker(context.userId);
    return {
      connected: status.connected,
      mode: status.mode,
      capabilities: status.capabilities,
      accountStatus: status.accountStatus,
      lastCheckedAt: status.lastCheckedAt,
      error: status.error,
    };
  });

export const loadBrokerSnapshot = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<BrokerSnapshot> => {
    const { readBrokerSnapshot } = await import("./broker.server");
    return snapshotForClient(await readBrokerSnapshot(context.userId));
  });
