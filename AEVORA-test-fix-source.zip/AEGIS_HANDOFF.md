# AEVORA handoff

Private personal steward. One brain. Chat proposes; the app permits.
Product rules: `docs/SPEC.md`. Current gate: `docs/STATUS.md`.
Deploy notes: `docs/DEPLOY.md`. Device checklist: `docs/ACCEPTANCE.md`.
History: `docs/DEVLOG.md` (older entries before the reconstructed tail are gone).

**Release gate: NOT READY.** Do not mark a provider Connected, a balance,
a fill, revenue, or a model reply unless that external call actually succeeded.

This archive is the source tree as of the export. It is not a claim that the
last uncommitted edits were re-proven by a full test run. See “Verification”.

## Stack

React 19, TanStack Start / Router (`@tanstack/react-start` 1.168.61),
Tailwind v4, Radix, Zustand, Zod, Better Auth ~1.6.30, Neon when
`DATABASE_URL` is set, otherwise PGLite. xAI is called with raw `fetch`.
There is no xAI SDK. Production target is Vercel (`npm run build` writes
`.vercel/output`).

Node 22. Package manager: npm. Lockfile: `package-lock.json`.

## Setup

```bash
npm ci
# optional: copy .env.example into the host secret store. Do not commit secrets.
npm run dev
```

`npm run dev` listens on `0.0.0.0:8080` through `scripts/with-app-env.mjs`,
which reads `.grok/app-env.json` (`VITE_AUTH_ENABLED`). Do not start Vite
directly. `startup.sh` is the idempotent preview start script.

Without `DATABASE_URL`, the server uses PGLite and applies `migrations/*.sql`
(picked up by `import.meta.glob` in `src/lib/db.ts`) when the db module loads.
`npm run build` also runs `npm run db:migrate`, which skips when
`DATABASE_URL` is unset.

```bash
npm test
npm run typecheck
npm run lint
npm run build
```

The product test list is explicit in `package.json` `scripts.test`. A new
`src/lib/*.test.ts` file is not run until it is added there.
Browser scripts live at the repo root as `_qa-*.mjs` (Playwright) and under
`scripts/*browser*`. They are not part of `npm test`.

## Environment

Names and descriptions only: `.env.example`.
Required in production: `DATABASE_URL`, `BETTER_AUTH_URL`, `BETTER_AUTH_SECRET`,
`GROK_AUTH_ISSUER`, `GROK_AUTH_CLIENT_ID`, `GROK_AUTH_CLIENT_SECRET`,
`XAI_API_KEY`, and `VITE_AUTH_ENABLED` not equal to `false`.

Alpaca, HubSpot, and Shopify credentials are typed into the signed-in UI,
checked against the provider, then sealed with `BETTER_AUTH_SECRET`. They are
not env vars. Google Ads and QuickBooks are OAuth and stay unconfigured until
their env vars exist.

Read `XAI_API_KEY` with bracket access (`process.env["XAI_API_KEY"]`). A dotted
read is statically replaced by Vite when the key is absent at bundle time.

The shared Grok **preview** OAuth client secret that normally lives in
`src/lib/auth/preview.ts` was **redacted in this ZIP**. The constant is now
`REDACTED_PREVIEW_CLIENT_SECRET`. Deployed apps must set `GROK_AUTH_*`.
Sandbox preview sign-in on `*.grok-sandbox.com` will not work from this
archive until a broker-issued preview secret is restored in that file.
No `.env` file was in the workspace. Local PGLite data (`.data/`) and the
generated `.vercel/output` build were not included.

## Architecture

One user, one model, one tool registry, one confirmation path, one audit log.

| Area | Where |
|---|---|
| Routes | `src/routes/` — public `/`, `/login`, app shell `src/routes/app/route.tsx` |
| Chat | `src/lib/chat.ts`, `src/lib/chat-turn.server.ts`, `src/routes/api/chat/stream.ts`, `src/components/chat/` |
| Workspaces | `src/lib/chat-workspace.ts`. Column `conversations.workspace` (`main` \| `business` \| `invest`), migration `0015_conversation_workspace.sql` |
| Intent / knowledge | `src/lib/intent-format.ts`, `src/lib/knowledge-format.ts` |
| Model routing | `src/lib/ai/router.ts`, `src/lib/ai/xai-env.server.ts`, `src/lib/ai/complete.server.ts`, `src/lib/search.server.ts` |
| Tools | `src/lib/tools/`, `src/lib/orchestrator/` |
| Permissions | `src/lib/permissions.ts`, `src/lib/confirm.ts`, `src/components/permissions/` |
| Memory, goals, reminders, plans | `src/lib/memory.ts`, `goals.ts`, `reminders.ts`, `plan.ts` |
| Business | `src/lib/business.ts`, `business-brain.ts`, `src/components/business/`, `src/lib/providers.server.ts` |
| Invest / Alpaca | `src/lib/invest.ts`, `invest-brain.ts`, `src/lib/broker.server.ts`, `src/lib/brokers/alpaca.server.ts` |
| OAuth callback | `src/routes/api/business/oauth/callback.ts`, `src/lib/providers/oauth.server.ts` |
| Gmail / Calendar | existing Grok connector gate, `src/lib/providers/gate-peek.ts`. No second Google login. |
| Studio | `src/components/studio/studio-workspace.tsx` via `src/components/creation/creation-workspace.tsx` at `/app/create`. `studio-landing.tsx` is unused. |
| Auth | `src/lib/auth/`. Do not rewrite this except `email-password.ts`. Do not add `src/routes/auth/popup.tsx`. |
| SEO | `src/lib/seo.ts`, `src/routes/robots[.]txt.ts`, `src/routes/sitemap[.]xml.ts` |

Navigation (phone hides Memory, Plans, Studio): Home, Main Chat, Memory,
Plans, Business, Invest, Studio, Settings.

Chat separation:

- Main Chat is `/app/chat` and `/app/chat/$id`.
- Business Chat is `/app/business#chat` and `#chat/:id`.
- Invest Chat is `/app/invest#chat` and `#chat/:id`.
- Lists, get, send, retry, and stream are scoped by workspace. A mismatch returns “Conversation not found.”
- The shell Chat item, while the path is Business or Invest, goes to that workspace’s chat instead of Main Chat. Elsewhere it stays Main Chat.
- Thread back, approval “back to chat”, and Home “continue last conversation” use the conversation’s workspace.

Same brain: `assembleTurnExtra` forces business or invest flags and prepends `workspaceIntentNote`. Voice uses the same brain and cannot self-approve.

AI: primary `grok-4.5`, fallbacks `grok-4` then `grok-3` on 403/404 only. `grok-4-fast` is not requested. Lanes are `fast` and `deep`. Unknown named entities go to search (`decideKnowledge` / `looksLikeNamedEntity`). “Compare Dola and GPT” is research. “Compare Nvidia and AMD” is invest because AMD is a ticker. Missing key returns `Grok is not connected. Nothing was sent to a model.` and does not invent a reply. A 401/403 from the provider still says the AI is unavailable; try again.

Invest: paper host `https://paper-api.alpaca.markets`, live host `https://api.alpaca.markets`. Connected only after the account call succeeds. Orders need an ACTIVE account, trading not blocked, an explicit live confirmation when live, and the existing approval step. Pending is not filled. `BROKER_CONNECTED` in `src/lib/entitlements-format.ts` stays hardcoded `false`. A plan flag is not a connection.

Business: HubSpot and Shopify save only after HTTP 200. Ads and Books return missing-config when OAuth env is absent. Inventory is Shopify only. `BUSINESS_SYSTEMS_CONNECTED` stays hardcoded `false`. Gmail and Calendar use the connector gate and are not marked connected without a successful probe.

Studio: one composer (“What do you want to create?”). `classifyStudioIntent` chooses photo, video, edit, variation, or animate. Advanced aspect, duration, and quality sit behind Advanced. If xAI is unavailable the composer is disabled and the page says Grok is not connected.

Confirmation is mandatory. Client-sent user ids are ignored. Founder email does not bypass ownership or approval.

## What is unfinished

- No live xAI key in this keep, so chat, search, research, Studio, TTS, and STT were not live-called.
- No Alpaca, HubSpot, Shopify, Google Ads, or QuickBooks credentials. Connect and Test paths are honest; they are not Connected.
- Gmail and Calendar need the platform connector gate. This app does not start a second Google login.
- Payments are not connected. Background monitoring is not connected. No scheduler.
- `docs/STATUS.md` still says the missing-key reply is “the model is unavailable”. The code now says “Grok is not connected. Nothing was sent to a model.” STATUS was not rewritten for that sentence.
- Personal bills, a real business book of record, and a learning track remain **NEEDS IBRAHIM** (`AGENTS.project.md`).
- `docs/DEVLOG.md` was reconstructed. Entries before the latest business/invest/SEO notes are not in this copy.
- The unused `StudioLanding` mode picker is still in the tree. The live Studio page does not render it.
- Home Talk / Type still open Main Chat. That is intentional. Mail, Calendar, and writing “ask AEVORA” links also open Main Chat.

## Known risks in the latest edits

These edits are in the tree and were **not** followed by a second full `npm test`, typecheck, lint, or production build:

- Workspace-aware shell Chat, thread back link, confirmation back link, and dashboard “continue” link (`src/components/layout/app-shell.tsx`, `src/components/chat/thread.tsx`, `src/components/permissions/confirmation-screen.tsx`, `src/components/dashboard/dashboard-workspace.tsx`, `src/lib/chat-workspace.ts`, `src/lib/confirm.ts`, `src/lib/dashboard.ts`).
- Missing-key copy in `src/lib/ai/complete.server.ts` and `src/lib/search.server.ts`.
- Studio unavailable copy in `src/components/studio/studio-workspace.tsx`.
- Extra assertions in `src/lib/knowledge-format.test.ts`, `src/lib/studio-intent.test.ts`, `src/lib/chat-workspace.test.ts`, `src/lib/ai/xai-env.server.test.ts`.

`src/lib/chat-workspace.test.ts` was run alone after the helper change and passed (35). The full suite was not re-run after the later copy and navigation edits. Treat typecheck of the confirmation `Link` (`to` / `params` / `hash` union) as unverified.

## Last recorded full verification

From `docs/STATUS.md`, before the navigation and missing-key edits above:

- `npm test`: 196 script tests + 440 product tests, 0 fail, twice.
- `npm run typecheck`, `npm run lint`, `npm run build`: pass. Migrate skipped because `DATABASE_URL` was unset.

Do not treat that table as proof of the files changed after it.

## Security notes for the next developer

- Do not write a `.env` into the repo.
- Do not log or return provider tokens, the xAI key, or broker secrets.
- Do not flip `BROKER_CONNECTED` or `BUSINESS_SYSTEMS_CONNECTED` to true.
- Do not mix Alpaca paper and live hosts.
- Do not invent revenue, customers, leads, ad spend, balances, holdings, prices, P/L, fills, or KPIs.
- Queries stay scoped to the session user from `authMiddleware`.
- `@tanstack/react-start` must stay at or above 1.168.60 (CVE-2026-102989). This tree’s installed version was 1.168.61.
