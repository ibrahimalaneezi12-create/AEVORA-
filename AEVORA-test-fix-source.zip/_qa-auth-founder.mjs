import { chromium } from "playwright";
import { randomBytes } from "node:crypto";

const BASE = "http://127.0.0.1:8080";
const results = [];
const stamp = Date.now();
const otherEmail = `keep.other.${stamp}@example.com`;
const founderEmail = "ibrahimalaneezi12@gmail.com";
const password = `Aegis-${randomBytes(9).toString("base64url")}-9`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 220) : ""}`);
}

async function gotoStable(page, path) {
  let lastErr = null;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    try {
      await page.goto(`${BASE}${path}`, { waitUntil: "domcontentloaded", timeout: 20000 });
      return;
    } catch (err) {
      lastErr = err;
      await page.waitForTimeout(400);
    }
  }
  throw lastErr ?? new Error(`goto failed ${path}`);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result = data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return { ok: false, error: err && err.message ? err.message : String(err) };
      }
    },
    { modulePath, name, data },
  );
}

async function fillLogin(page, { name, email, mode }) {
  await gotoStable(page, "/login");
  if (await page.getByRole("button", { name: "Sign out" }).locator("visible=true").count()) {
    await signOut(page);
    await gotoStable(page, "/login");
  }
  await page.locator("#auth-email").waitFor({ timeout: 15000 });
  if (mode === "signup") {
    const create = page.getByRole("button", { name: /Create an account/i });
    if (await create.isVisible().catch(() => false)) await create.click();
    await page.locator("#auth-name").waitFor({ timeout: 15000 });
    if (name) await page.locator("#auth-name").fill(name);
  } else {
    const have = page.getByRole("button", { name: /Have an account/i });
    if (await have.isVisible().catch(() => false)) await have.click();
  }
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" }).locator("visible=true").first();
  if (await btn.count()) {
    await btn.click();
    await page.locator("#auth-email").waitFor({ timeout: 20000 });
  }
}

async function main() {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  try {
    await gotoStable(page, "/login");
    const google = page.getByRole("button", { name: /Continue with Google/i });
    await google.waitFor({ timeout: 15000 });
    record("google-button-visible", (await google.count()) > 0);

    const oauth = await page.evaluate(async () => {
      const res = await fetch("/api/auth/sign-in/oauth2", {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          providerId: "grok-google",
          callbackURL: "/app",
          errorCallbackURL: "/login",
        }),
      });
      const body = await res.json().catch(() => ({}));
      return { status: res.status, url: body.url || "" };
    });
    record("google-oauth-start", oauth.status === 200 && /idp=google/.test(oauth.url), String(oauth.status));
    record(
      "google-oauth-broker",
      /auth\.grok\.me/.test(oauth.url) && /callback%2Fgrok-google/.test(oauth.url),
      oauth.url.slice(0, 180),
    );

    await fillLogin(page, { name: "Other Keep", email: otherEmail, mode: "signup" });
    await page.getByRole("button", { name: "Create account" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    const otherProfile = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    const otherEnt = await callFn(page, "/src/lib/entitlements.ts", "getEntitlement");
    record("other-signup", otherProfile.ok && Boolean(otherProfile.result?.userId));
    record(
      "other-is-not-founder",
      otherEnt.ok && otherEnt.result?.plan === "free" && otherEnt.result?.grantedReason !== "founder-email",
      JSON.stringify(otherEnt.result || otherEnt.error),
    );
    await callFn(page, "/src/lib/goals.ts", "createGoal", { title: "Other secret goal" });
    await signOut(page);
    record("other-signed-out", /login/.test(page.url()) || (await page.locator("#auth-email").count()) > 0);

    await fillLogin(page, { email: otherEmail, mode: "signin" });
    await page.getByRole("button", { name: "Sign in" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    record("email-login-persists", /\/app/.test(page.url()));
    await page.getByRole("button", { name: "Sign out" }).locator("visible=true").first().waitFor({ timeout: 15000 });
    await signOut(page);

    const other2 = `keep.other2.${stamp}@example.com`;
    await fillLogin(page, { name: "Other Two", email: other2, mode: "signup" });
    await page.getByRole("button", { name: "Create account" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    const other2Ent = await callFn(page, "/src/lib/entitlements.ts", "getEntitlement");
    record(
      "second-user-is-not-founder",
      other2Ent.ok && other2Ent.result?.plan === "free",
      JSON.stringify(other2Ent.result || other2Ent.error),
    );
    const otherGoals = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
    const leaked = (otherGoals.result?.goals || []).some((g) => /Other secret goal/i.test(g.title || ""));
    record("user-isolation-goals", otherGoals.ok && !leaked, JSON.stringify(otherGoals.result || otherGoals.error).slice(0, 180));
    await page.getByRole("button", { name: "Sign out" }).locator("visible=true").first().waitFor({ timeout: 15000 });
    await signOut(page);

    await fillLogin(page, { name: "Ibrahim", email: founderEmail, mode: "signup" });
    await page.getByRole("button", { name: "Create account" }).click();
    await page.waitForTimeout(2000);
    const founderOnApp = /\/app/.test(page.url());
    if (founderOnApp) {
      const founderEnt = await callFn(page, "/src/lib/entitlements.ts", "getEntitlement");
      record(
        "founder-plan",
        founderEnt.ok && founderEnt.result?.plan === "founder" && founderEnt.result?.grantedReason === "founder-email",
        JSON.stringify(founderEnt.result || founderEnt.error),
      );
      await page.getByRole("button", { name: "Sign out" }).locator("visible=true").first().waitFor({ timeout: 15000 });
      await signOut(page);
    } else {
      const alert = (await page.getByRole("alert").textContent().catch(() => "")) || "";
      record("founder-email-already-provisioned", /already exists/i.test(alert), alert || page.url());
    }
    await gotoStable(page, "/app");
    await page.waitForTimeout(500);
    record("signed-out-app-blocked", /login/.test(page.url()) || (await page.locator("#auth-email").count()) > 0);
  } finally {
    await browser.close();
  }

  const failed = results.filter((r) => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} passed`);
  if (failed.length) process.exit(1);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
