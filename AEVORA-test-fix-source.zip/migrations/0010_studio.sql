-- Aegis Studio: photos, uploaded clips, versions. Additive.

create table if not exists studio_projects (
  id                 serial primary key,
  user_id            text not null,
  kind               text not null,
  origin             text not null,
  title              text not null default '',
  prompt             text not null default '',
  status             text not null default 'draft',
  aspect_ratio       text not null default '1:1',
  current_asset_id   integer,
  original_asset_id  integer,
  linked_video_id    integer,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create index if not exists studio_projects_user_idx
  on studio_projects (user_id, updated_at desc);

create table if not exists studio_assets (
  id          serial primary key,
  project_id  integer not null references studio_projects(id) on delete cascade,
  user_id     text not null,
  role        text not null,
  version_n   integer not null default 1,
  mime        text not null,
  payload     text not null,
  prompt      text not null default '',
  created_at  timestamptz not null default now()
);
create index if not exists studio_assets_project_idx
  on studio_assets (user_id, project_id, version_n desc);

create table if not exists studio_jobs (
  id               serial primary key,
  project_id       integer not null references studio_projects(id) on delete cascade,
  user_id          text not null,
  kind             text not null,
  status           text not null default 'queued',
  provider         text not null default 'xai',
  model            text not null default '',
  provider_job_id  text not null default '',
  error            text not null default '',
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index if not exists studio_jobs_user_idx
  on studio_jobs (user_id, created_at desc);

create table if not exists studio_usage (
  id          serial primary key,
  user_id     text not null,
  job_id      integer,
  model       text not null,
  operation   text not null,
  status      text not null,
  created_at  timestamptz not null default now()
);
create index if not exists studio_usage_user_idx
  on studio_usage (user_id, created_at desc);