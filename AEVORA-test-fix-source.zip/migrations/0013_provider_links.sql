-- Safe connection metadata. Sealed ciphertext is never selected by page queries.

alter table broker_links add column if not exists account_status text not null default '';

create table if not exists provider_links (
  id              serial primary key,
  user_id         text not null,
  provider        text not null,
  status          text not null default 'disconnected',
  key_hint        text not null default '',
  sealed          text not null default '',
  capabilities    text not null default '',
  account_label   text not null default '',
  last_error      text not null default '',
  last_checked_at timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (user_id, provider)
);
create index if not exists provider_links_user_idx on provider_links (user_id);
