-- Aegis Video: private projects, scenes, jobs, versions, usage.
-- Additive. Do not edit 0001–0008.

create table if not exists video_projects (
  id              serial primary key,
  user_id         text not null,
  title           text not null,
  description     text not null default '',
  status          text not null default 'draft',
  aspect_ratio    text not null default '16:9',
  resolution      text not null default '720p',
  generate_audio  boolean not null default true,
  captions        text not null default '',
  captions_locale text not null default 'en',
  brief           text not null default '',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists video_projects_user_idx
  on video_projects (user_id, updated_at desc);

create table if not exists video_scenes (
  id              serial primary key,
  project_id      integer not null references video_projects(id) on delete cascade,
  user_id         text not null,
  sort_order      integer not null default 0,
  title           text not null default '',
  prompt          text not null,
  duration_sec    integer not null default 8,
  camera          text not null default '',
  status          text not null default 'draft',
  provider_job_id text not null default '',
  media_url       text not null default '',
  error           text not null default '',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists video_scenes_project_idx
  on video_scenes (user_id, project_id, sort_order);

create table if not exists video_jobs (
  id              serial primary key,
  project_id      integer not null references video_projects(id) on delete cascade,
  scene_id        integer references video_scenes(id) on delete set null,
  user_id         text not null,
  kind            text not null default 'generate',
  status          text not null default 'queued',
  provider        text not null default 'xai',
  model           text not null default 'grok-imagine-video-1.5',
  provider_job_id text not null default '',
  media_url       text not null default '',
  error           text not null default '',
  duration_sec    integer,
  resolution      text not null default '720p',
  aspect_ratio    text not null default '16:9',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists video_jobs_user_idx
  on video_jobs (user_id, created_at desc);
create index if not exists video_jobs_provider_idx
  on video_jobs (provider_job_id);

create table if not exists video_versions (
  id              serial primary key,
  project_id      integer not null references video_projects(id) on delete cascade,
  user_id         text not null,
  label           text not null,
  snapshot_json   text not null,
  created_at      timestamptz not null default now()
);
create index if not exists video_versions_project_idx
  on video_versions (user_id, project_id, created_at desc);

create table if not exists video_usage (
  id              serial primary key,
  user_id         text not null,
  job_id          integer,
  model           text not null,
  operation       text not null,
  duration_sec    integer not null default 0,
  resolution      text not null default '',
  status          text not null,
  created_at      timestamptz not null default now()
);
create index if not exists video_usage_user_idx
  on video_usage (user_id, created_at desc);
