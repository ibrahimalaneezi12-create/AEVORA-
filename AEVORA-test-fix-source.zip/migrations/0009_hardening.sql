-- Steps 21–24 hardening. Additive. Do not edit 0001–0008.

alter table profiles
  add column if not exists response_style text not null default 'calm',
  add column if not exists quiet_hours_start integer,
  add column if not exists quiet_hours_end integer;

alter table calendar_events
  add column if not exists recurrence text not null default 'once';
