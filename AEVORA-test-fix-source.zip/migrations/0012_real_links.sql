-- Real broker links and user-stated plans/experiments. Additive.
-- The sealed column is ciphertext. Page queries must not select it.

create table if not exists broker_links (
  id              serial primary key,
  user_id         text not null,
  provider        text not null,
  mode            text not null,
  status          text not null default 'disconnected',
  key_hint        text not null default '',
  sealed          text not null default '',
  capabilities    text not null default '',
  account_ref     text not null default '',
  last_error      text not null default '',
  last_checked_at timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (user_id, provider, mode)
);
create index if not exists broker_links_user_idx on broker_links (user_id);

create table if not exists invest_orders (
  id               serial primary key,
  user_id          text not null,
  mode             text not null,
  provider         text not null default '',
  broker_order_id  text not null default '',
  symbol           text not null,
  side             text not null,
  requested_amount text not null default '',
  qty              text not null default '',
  status           text not null,
  detail           text not null default '',
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index if not exists invest_orders_user_idx on invest_orders (user_id, created_at desc);

create table if not exists invest_plans (
  id           serial primary key,
  user_id      text not null,
  title        text not null,
  body         text not null,
  horizon      text not null default '',
  contribution text not null default '',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists invest_plans_user_idx on invest_plans (user_id, updated_at desc);

create table if not exists business_experiments (
  id           serial primary key,
  user_id      text not null,
  hypothesis   text not null,
  metric       text not null,
  window_days  integer not null default 14,
  success      text not null default '',
  result       text not null default '',
  status       text not null default 'open',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists business_experiments_user_idx
  on business_experiments (user_id, updated_at desc);
