-- Step 14: seed the durable allowlist. Additive. Do not edit 0002.
-- In-code catalog remains the classification source. Execute checks this table.
insert into tool_catalog (id, display_name, description, permission_level, enabled)
values
  ('memory.search', 'Search memory', 'Read own memories', 'safe', true),
  ('task.list', 'List tasks', 'Read own tasks and goals', 'safe', true),
  ('memory.save', 'Save a memory', 'Insert or update own memory', 'review', true),
  ('task.create', 'Create a task', 'Insert own task', 'review', true),
  ('task.update', 'Update a task', 'Update own task', 'review', true),
  ('goal.create', 'Create a goal', 'Insert own goal', 'review', true),
  ('memory.delete', 'Delete a memory', 'Destructive memory delete', 'approval', true),
  ('task.delete', 'Delete a task', 'Destructive task delete', 'approval', true),
  ('conversation.delete', 'Delete a conversation', 'Destructive conversation delete', 'approval', true),
  ('profile.update', 'Update profile', 'Identity change', 'approval', true),
  ('permission.update', 'Change permissions', 'Frozen off; no self-loosening', 'restricted', true)
on conflict (id) do update set
  display_name = excluded.display_name,
  description = excluded.description,
  permission_level = excluded.permission_level,
  enabled = excluded.enabled;
