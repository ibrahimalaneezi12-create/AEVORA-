-- Conversational business + invest keep. Additive. Do not edit 0001–0010.
-- User-owned only. No fabricated revenue, prices, or trades.

create table if not exists businesses (
  id          serial primary key,
  user_id     text not null,
  name        text not null,
  offer       text not null default '',
  audience    text not null default '',
  notes       text not null default '',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists businesses_user_idx on businesses (user_id, updated_at desc);

create table if not exists business_notes (
  id           serial primary key,
  user_id      text not null,
  business_id  integer references businesses(id) on delete cascade,
  kind         text not null default 'note',
  title        text not null,
  body         text not null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists business_notes_user_idx on business_notes (user_id, updated_at desc);

create table if not exists invest_watchlist (
  id          serial primary key,
  user_id     text not null,
  symbol      text not null,
  name        text not null default '',
  thesis      text not null default '',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (user_id, symbol)
);
create index if not exists invest_watchlist_user_idx on invest_watchlist (user_id, updated_at desc);

create table if not exists invest_journal (
  id          serial primary key,
  user_id     text not null,
  symbol      text not null default '',
  kind        text not null default 'note',
  title       text not null,
  body        text not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists invest_journal_user_idx on invest_journal (user_id, updated_at desc);

insert into tool_catalog (id, display_name, description, permission_level, enabled)
values
  ('business.save', 'Save business', 'Insert or update own business identity', 'review', true),
  ('business.note', 'Save a business note', 'Store an owned business note', 'review', true),
  ('invest.watch', 'Watch an investment', 'Add a symbol to the owned watchlist', 'review', true),
  ('invest.unwatch', 'Remove from watchlist', 'Remove an owned watchlist row', 'approval', true),
  ('invest.note', 'Save an investment note', 'Thesis, decision, or paper trade', 'review', true)
on conflict (id) do update set
  display_name = excluded.display_name,
  description = excluded.description,
  permission_level = excluded.permission_level,
  enabled = excluded.enabled;
