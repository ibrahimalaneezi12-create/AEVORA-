-- Step 16: locale + voice preferences on the existing profiles row.
-- Additive. Do not edit 0001–0005.

alter table profiles add column if not exists locale text not null default 'en';
alter table profiles add column if not exists voice_enabled boolean not null default true;
alter table profiles add column if not exists voice_name text not null default '';
alter table profiles add column if not exists detect_language boolean not null default true;
