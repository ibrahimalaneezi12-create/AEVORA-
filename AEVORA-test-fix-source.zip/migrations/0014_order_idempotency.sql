-- One approval sends one broker order. The id is not a secret.

alter table invest_orders add column if not exists client_order_id text not null default '';

create unique index if not exists invest_orders_client_idx
  on invest_orders (user_id, client_order_id)
  where client_order_id <> '';
