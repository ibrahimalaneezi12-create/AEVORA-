-- Steps 18–20: reminders, notification devices/attempts, language fallback.
-- Additive. Do not edit 0001–0006.

alter table profiles
  add column if not exists fallback_language text not null default 'en';

create table if not exists reminders (
  id               serial primary key,
  user_id          text not null,
  title            text not null,
  body             text not null default '',
  timezone         text not null default 'UTC',
  fire_at          timestamptz not null,
  local_date       text,
  local_time       text,
  recurrence       text not null default 'once',
  weekday          integer,
  status           text not null default 'scheduled',
  snooze_until     timestamptz,
  last_fired_at    timestamptz,
  completed_at     timestamptz,
  cancelled_at     timestamptz,
  related_task_id  integer,
  related_goal_id  integer,
  locale           text not null default 'en',
  retry_count      integer not null default 0,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index if not exists reminders_user_id_idx on reminders (user_id);
create index if not exists reminders_user_fire_idx on reminders (user_id, status, fire_at);

create table if not exists notification_devices (
  id            serial primary key,
  user_id       text not null,
  device_key    text not null,
  label         text not null default '',
  permission    text not null default 'default',
  last_seen_at  timestamptz not null default now(),
  revoked_at    timestamptz,
  created_at    timestamptz not null default now(),
  unique (user_id, device_key)
);
create index if not exists notification_devices_user_idx on notification_devices (user_id);

create table if not exists notification_attempts (
  id            serial primary key,
  user_id       text not null,
  reminder_id   integer not null references reminders(id) on delete cascade,
  device_id     integer references notification_devices(id) on delete set null,
  status        text not null default 'pending',
  error         text not null default '',
  attempted_at  timestamptz not null default now()
);
create index if not exists notification_attempts_user_idx
  on notification_attempts (user_id, reminder_id, attempted_at desc);

insert into tool_catalog (id, display_name, description, permission_level, enabled)
values
  ('reminder.list', 'List reminders', 'Read own reminders', 'safe', true),
  ('reminder.create', 'Create a reminder', 'Schedule a reminder', 'review', true),
  ('reminder.update', 'Update a reminder', 'Edit own reminder', 'review', true),
  ('reminder.snooze', 'Snooze a reminder', 'Postpone own reminder', 'review', true),
  ('reminder.complete', 'Complete a reminder', 'Mark own reminder done', 'review', true),
  ('reminder.cancel', 'Cancel a reminder', 'Cancel own reminder', 'approval', true),
  ('goal.update', 'Update a goal', 'Update own goal', 'review', true)
on conflict (id) do update set
  display_name = excluded.display_name,
  description = excluded.description,
  permission_level = excluded.permission_level,
  enabled = excluded.enabled;
