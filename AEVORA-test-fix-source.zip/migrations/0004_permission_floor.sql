-- Additive. Do not edit 0002_aegis.sql.
-- Step 11: user may raise confirmation loudness. Never a loosen column.
alter table permission_settings
  add column if not exists confirm_floor text not null default 'safe';
