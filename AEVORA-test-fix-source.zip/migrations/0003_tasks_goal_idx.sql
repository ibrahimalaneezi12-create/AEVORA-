-- Additive. Do not edit 0002_aegis.sql.
-- Speeds task→goal lookups and ON DELETE SET NULL on goals.
create index if not exists tasks_goal_id_idx on tasks (goal_id);
