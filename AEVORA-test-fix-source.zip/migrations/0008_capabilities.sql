-- Steps 21–24: entitlements, calendar, email, creation, pulse, voice prefs.
-- Additive. Do not edit 0001–0007.

create table if not exists entitlements (
  user_id         text primary key,
  plan            text not null default 'free',
  granted_at      timestamptz not null default now(),
  granted_reason  text not null default 'signup'
);
create index if not exists entitlements_plan_idx on entitlements (plan);

alter table profiles
  add column if not exists voice_speed numeric not null default 1,
  add column if not exists pulse_enabled boolean not null default true,
  add column if not exists notify_reminders boolean not null default true,
  add column if not exists notify_pulse boolean not null default true;

create table if not exists calendar_events (
  id            serial primary key,
  user_id       text not null,
  title         text not null,
  notes         text not null default '',
  location      text not null default '',
  start_at      timestamptz not null,
  end_at        timestamptz,
  timezone      text not null default 'UTC',
  status        text not null default 'confirmed',
  source        text not null default 'aegis',
  external_id   text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists calendar_events_user_start_idx
  on calendar_events (user_id, start_at);

create table if not exists email_drafts (
  id                serial primary key,
  user_id           text not null,
  to_address        text not null,
  cc_address        text not null default '',
  subject           text not null,
  body              text not null,
  status            text not null default 'draft',
  conversation_id   integer,
  sent_at           timestamptz,
  error             text not null default '',
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index if not exists email_drafts_user_idx
  on email_drafts (user_id, status, updated_at desc);

create table if not exists creations (
  id                serial primary key,
  user_id           text not null,
  kind              text not null default 'note',
  title             text not null,
  body              text not null,
  locale            text not null default 'en',
  conversation_id   integer,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index if not exists creations_user_idx
  on creations (user_id, updated_at desc);

create table if not exists pulse_events (
  id             serial primary key,
  user_id        text not null,
  kind           text not null,
  title          text not null,
  body           text not null,
  severity       text not null default 'info',
  related_type   text not null default '',
  related_id     text not null default '',
  dismissed_at   timestamptz,
  created_at     timestamptz not null default now()
);
create index if not exists pulse_events_user_idx
  on pulse_events (user_id, created_at desc);

create table if not exists integration_status (
  user_id      text not null,
  kind         text not null,
  provider     text not null default '',
  status       text not null default 'disconnected',
  last_error   text not null default '',
  updated_at   timestamptz not null default now(),
  primary key (user_id, kind)
);

insert into tool_catalog (id, display_name, description, permission_level, enabled)
values
  ('calendar.list', 'List calendar', 'Read own calendar', 'safe', true),
  ('calendar.create', 'Create calendar event', 'Insert own event', 'review', true),
  ('calendar.update', 'Update calendar event', 'Edit own event', 'review', true),
  ('calendar.delete', 'Delete calendar event', 'Remove own event', 'approval', true),
  ('email.list', 'List email drafts', 'Read own drafts', 'safe', true),
  ('email.draft', 'Draft an email', 'Create an email draft', 'review', true),
  ('email.send', 'Send an email', 'Send a prepared email', 'approval', true),
  ('creation.save', 'Save a creation', 'Store generated writing', 'review', true),
  ('search.web', 'Search the web', 'Look up current public information', 'safe', true),
  ('research.query', 'Research a question', 'Multi-source investigation', 'safe', true)
on conflict (id) do update set
  display_name = excluded.display_name,
  description = excluded.description,
  permission_level = excluded.permission_level,
  enabled = excluded.enabled;
