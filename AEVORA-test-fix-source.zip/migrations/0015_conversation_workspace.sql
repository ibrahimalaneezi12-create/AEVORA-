-- Separate persistent threads for personal, business, and invest chat.
-- One brain. Histories do not mix. Existing rows stay personal.

alter table conversations add column if not exists workspace text not null default 'main';

create index if not exists conversations_user_workspace_idx
  on conversations (user_id, workspace, updated_at desc);
