-- Aegis app schema (Step 4). Applied once; do not edit. Additive files only after this.
-- user_id is TEXT (Better Auth ids). No extensions. JSON stored as text.

create table if not exists profiles (
  user_id          text primary key,
  display_name     text,
  bio              text not null default '',
  timezone         text not null default 'UTC',
  theme            text not null default 'system',
  onboarding_done  boolean not null default false,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create table if not exists conversations (
  id          serial primary key,
  user_id     text not null,
  title       text not null default 'New conversation',
  archived    boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists conversations_user_id_idx on conversations (user_id);

create table if not exists messages (
  id               serial primary key,
  user_id          text not null,
  conversation_id  integer not null references conversations(id) on delete cascade,
  role             text not null,
  content          text not null,
  token_count      integer,
  created_at       timestamptz not null default now()
);
create index if not exists messages_conversation_idx
  on messages (user_id, conversation_id, id);

create table if not exists memories (
  id          serial primary key,
  user_id     text not null,
  kind        text not null,
  title       text not null,
  body        text not null,
  tags        text not null default '',
  source      text not null default 'user',
  pinned      boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists memories_user_id_idx on memories (user_id);

create table if not exists goals (
  id           serial primary key,
  user_id      text not null,
  title        text not null,
  description  text not null default '',
  status       text not null default 'active',
  target_date  date,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists goals_user_id_idx on goals (user_id);

create table if not exists tasks (
  id          serial primary key,
  user_id     text not null,
  goal_id     integer references goals(id) on delete set null,
  title       text not null,
  notes       text not null default '',
  status      text not null default 'todo',
  due_date    date,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists tasks_user_id_idx on tasks (user_id);

create table if not exists permission_settings (
  user_id           text primary key,
  auto_run_safe     boolean not null default false,
  auto_run_review   boolean not null default false,
  updated_at        timestamptz not null default now()
);

create table if not exists tool_catalog (
  id                 text primary key,
  display_name       text not null,
  description        text not null,
  permission_level   text not null,
  enabled            boolean not null default true
);

create table if not exists proposed_actions (
  id                 serial primary key,
  user_id            text not null,
  conversation_id    integer references conversations(id) on delete set null,
  tool_id            text not null,
  permission_level   text not null,
  title              text not null,
  summary            text not null,
  payload_json       text not null default '{}',
  status             text not null default 'pending',
  created_at         timestamptz not null default now(),
  decided_at         timestamptz,
  executed_at        timestamptz,
  error              text
);
create index if not exists proposed_actions_user_status_idx
  on proposed_actions (user_id, status, created_at desc);

create table if not exists audit_logs (
  id                 serial primary key,
  user_id            text not null,
  actor              text not null,
  action             text not null,
  entity_type        text not null default '',
  entity_id          text not null default '',
  permission_level   text,
  detail             text not null default '',
  created_at         timestamptz not null default now()
);
create index if not exists audit_logs_user_id_idx
  on audit_logs (user_id, created_at desc);
