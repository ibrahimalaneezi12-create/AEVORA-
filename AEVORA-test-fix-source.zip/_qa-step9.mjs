import { chromium } from "playwright";
import { writeFileSync } from "node:fs";

const BASE = "http://127.0.0.1:8080";
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step9.${stamp}@example.com`;
const emailB = `ibrahim.step9b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Create an account" }).click();
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

const browser = await chromium.launch({ headless: true });
const contextA = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page = await contextA.newPage();
const consoleErrors = [];
page.on("pageerror", (err) => consoleErrors.push(String(err)));
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});

try {
  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  record("signed-out-goals", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const g401 = await callFn(page, "/src/lib/goals.ts", "createGoal", {
    title: "Nope",
    description: "",
    status: "active",
    targetDate: null,
  });
  record("unauth-create-goal", /unauthorized/i.test(g401.error || ""), g401.error || JSON.stringify(g401));
  const t401 = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Nope",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: null,
  });
  record("unauth-create-task", /unauthorized/i.test(t401.error || ""), t401.error || JSON.stringify(t401));
  const list401 = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
  record("unauth-list", /unauthorized/i.test(list401.error || ""), list401.error || JSON.stringify(list401));

  await signup(page, { name: "Ibrahim Step9", email: emailA });
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("dashboard-regression", await page.getByRole("heading", { name: /Hello/ }).isVisible());
  record("dashboard-goals-copy", await page.getByText(/Open Goals to set/).isVisible());

  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Working toward" }).waitFor({ timeout: 15000 });
  record("empty-state", await page.getByText(/Nothing yet/).isVisible());
  record(
    "nav-goals-active",
    (await page.locator("aside nav a", { hasText: "Goals" }).first().getAttribute("aria-current")) === "page",
  );

  await page.getByRole("button", { name: "Add goal" }).click();
  await page.getByRole("form", { name: "New goal" }).waitFor({ timeout: 10000 });
  await page.getByLabel("Title").fill("Drink less sugar");
  await page.getByLabel("Description").fill("Keep mornings unsweetened.");
  await page.getByRole("button", { name: "Save goal" }).click();
  const goalCard = page.getByRole("article", { name: "Goal: Drink less sugar" });
  await goalCard.waitFor({ timeout: 15000 });
  record("created-goal", /Active/i.test(await goalCard.innerText()));

  const listed = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
  const goal = (listed.result?.goals ?? []).find((g) => g.title === "Drink less sugar");
  record("read-own-goals", Boolean(goal) && goal.status === "active", JSON.stringify(goal || listed).slice(0, 240));
  const goalId = goal?.id ?? 0;

  const fetched = await callFn(page, "/src/lib/goals.ts", "getGoal", { id: goalId });
  record("get-own-goal", fetched.ok && fetched.result?.id === goalId, JSON.stringify(fetched).slice(0, 200));

  await page.getByRole("button", { name: "Add task to Drink less sugar" }).click();
  await page.getByRole("form", { name: "New task" }).waitFor({ timeout: 10000 });
  await page.getByLabel("Title").fill("Buy loose-leaf tea");
  await page.getByLabel("Notes").fill("No sugar in the tin.");
  const selectedGoal = await page.locator("#task-goal").inputValue();
  record("task-form-prelinked", selectedGoal === String(goalId), selectedGoal);
  await page.getByRole("button", { name: "Save task" }).click();
  const taskCard = page.getByRole("article", { name: "Task: Buy loose-leaf tea" });
  await taskCard.waitFor({ timeout: 15000 });
  record("created-linked-task", /Linked to Drink less sugar/i.test(await taskCard.innerText()));

  const afterLink = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
  const linkedTask = (afterLink.result?.tasks ?? []).find((t) => t.title === "Buy loose-leaf tea");
  record(
    "task-linked-to-owned-goal",
    Boolean(linkedTask) && linkedTask.goalId === goalId,
    JSON.stringify(linkedTask || afterLink).slice(0, 240),
  );
  const taskId = linkedTask?.id ?? 0;

  const gotOwnTask = await callFn(page, "/src/lib/goals.ts", "getTask", { id: taskId });
  record(
    "get-own-task",
    gotOwnTask.ok && gotOwnTask.result?.id === taskId && gotOwnTask.result?.goalId === goalId,
    JSON.stringify(gotOwnTask).slice(0, 200),
  );

  const updatedOwnTask = await callFn(page, "/src/lib/goals.ts", "updateTask", {
    id: taskId,
    title: "Buy loose-leaf tea",
    notes: "No sugar in the tin.",
    status: "doing",
    dueDate: "2026-09-21",
    goalId,
  });
  record(
    "update-own-task",
    updatedOwnTask.ok &&
      updatedOwnTask.result?.status === "doing" &&
      updatedOwnTask.result?.dueDate === "2026-09-21" &&
      updatedOwnTask.result?.goalId === goalId,
    JSON.stringify(updatedOwnTask).slice(0, 220),
  );

  await page.getByRole("button", { name: "Add task", exact: true }).click();
  await page.getByRole("form", { name: "New task" }).waitFor({ timeout: 10000 });
  await page.getByLabel("Title").fill("Inbox note");
  await page.locator("#task-goal").selectOption("");
  await page.getByRole("button", { name: "Save task" }).click();
  await page.getByRole("article", { name: "Task: Inbox note" }).waitFor({ timeout: 15000 });
  const inboxListed = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
  const inbox = (inboxListed.result?.tasks ?? []).find((t) => t.title === "Inbox note");
  record("task-without-goal", Boolean(inbox) && inbox.goalId == null, JSON.stringify(inbox || {}).slice(0, 200));
  const inboxId = inbox?.id ?? 0;

  const secondGoal = await callFn(page, "/src/lib/goals.ts", "createGoal", {
    title: "Sleep earlier",
    description: "",
    status: "active",
    targetDate: "2026-10-01",
  });
  record("second-goal-api", secondGoal.ok && secondGoal.result?.id > 0, JSON.stringify(secondGoal).slice(0, 200));
  const goal2Id = secondGoal.result?.id ?? 0;

  const moved = await callFn(page, "/src/lib/goals.ts", "updateTask", {
    id: inboxId,
    title: "Inbox note",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: goal2Id,
  });
  record("move-to-other-owned-goal", moved.ok && moved.result?.goalId === goal2Id, JSON.stringify(moved).slice(0, 200));

  const unlinked = await callFn(page, "/src/lib/goals.ts", "updateTask", {
    id: inboxId,
    title: "Inbox note",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: null,
  });
  record("remove-goal-link", unlinked.ok && unlinked.result?.goalId == null, JSON.stringify(unlinked).slice(0, 200));

  const missingGoal = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Ghost link",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: 999999,
  });
  record("nonexistent-goal-rejected", /not found/i.test(missingGoal.error || ""), JSON.stringify(missingGoal).slice(0, 200));

  const missingTask = await callFn(page, "/src/lib/goals.ts", "getTask", { id: 999999 });
  record("nonexistent-task-rejected", /not found/i.test(missingTask.error || ""), JSON.stringify(missingTask).slice(0, 200));

  const missingGetGoal = await callFn(page, "/src/lib/goals.ts", "getGoal", { id: 999999 });
  record("nonexistent-goal-get-rejected", /not found/i.test(missingGetGoal.error || ""), JSON.stringify(missingGetGoal).slice(0, 200));

  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  await page.getByRole("article", { name: "Goal: Drink less sugar" }).waitFor({ timeout: 10000 });
  await page.getByRole("button", { name: "Mark Drink less sugar done" }).click();
  await page.getByRole("button", { name: "Reopen Drink less sugar" }).waitFor({ timeout: 10000 });
  record("complete-goal", true);
  await page.getByRole("button", { name: "Reopen Drink less sugar" }).click();
  await page.getByRole("button", { name: "Mark Drink less sugar done" }).waitFor({ timeout: 10000 });
  record("reopen-goal", true);

  await page.getByRole("button", { name: "Mark Buy loose-leaf tea done" }).click();
  await page.getByRole("button", { name: "Reopen Buy loose-leaf tea" }).waitFor({ timeout: 10000 });
  record("complete-task", true);
  await page.getByRole("button", { name: "Reopen Buy loose-leaf tea" }).click();
  await page.getByRole("button", { name: "Mark Buy loose-leaf tea done" }).waitFor({ timeout: 10000 });
  record("uncomplete-task", true);

  await page.getByRole("button", { name: "Edit goal Drink less sugar" }).click();
  await page.getByRole("form", { name: "Edit goal" }).waitFor({ timeout: 10000 });
  await page.getByLabel("Title").fill("Drink less sugar this month");
  await page.getByRole("button", { name: "Save changes" }).click();
  await page.getByRole("article", { name: "Goal: Drink less sugar this month" }).waitFor({ timeout: 15000 });
  record("update-own-goal", true);

  await page.reload({ waitUntil: "networkidle" });
  await page.getByRole("article", { name: "Goal: Drink less sugar this month" }).waitFor({ timeout: 15000 });
  await page.getByRole("article", { name: "Task: Buy loose-leaf tea" }).waitFor({ timeout: 10000 });
  record("refresh-persists", true);

  const emptyGoal = await callFn(page, "/src/lib/goals.ts", "createGoal", {
    title: "",
    description: "",
    status: "active",
    targetDate: null,
  });
  record("empty-goal-title-rejected", !emptyGoal.ok, JSON.stringify(emptyGoal).slice(0, 180));
  const badDate = await callFn(page, "/src/lib/goals.ts", "createGoal", {
    title: "Bad date",
    description: "",
    status: "active",
    targetDate: "soon",
  });
  record("bad-date-rejected", !badDate.ok, JSON.stringify(badDate).slice(0, 180));

  const contextB = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other User", email: emailB });

  const idorGoal = await callFn(pageB, "/src/lib/goals.ts", "getGoal", { id: goalId });
  record("idor-get-goal", /not found/i.test(idorGoal.error || ""), JSON.stringify(idorGoal).slice(0, 200));
  const idorTask = await callFn(pageB, "/src/lib/goals.ts", "getTask", { id: taskId });
  record("idor-get-task", /not found/i.test(idorTask.error || ""), JSON.stringify(idorTask).slice(0, 200));
  const idorList = await callFn(pageB, "/src/lib/goals.ts", "listGoalsPage");
  const otherGoalIds = (idorList.result?.goals ?? []).map((g) => g.id);
  const otherTaskIds = (idorList.result?.tasks ?? []).map((t) => t.id);
  record(
    "idor-list-isolated",
    !otherGoalIds.includes(goalId) && !otherTaskIds.includes(taskId),
    JSON.stringify({ otherGoalIds, otherTaskIds }),
  );
  const idorUpdateGoal = await callFn(pageB, "/src/lib/goals.ts", "updateGoal", {
    id: goalId,
    title: "Hijacked",
    description: "",
    status: "done",
    targetDate: null,
  });
  record("idor-update-goal", /not found/i.test(idorUpdateGoal.error || ""), JSON.stringify(idorUpdateGoal).slice(0, 200));
  const idorUpdateTask = await callFn(pageB, "/src/lib/goals.ts", "updateTask", {
    id: taskId,
    title: "Hijacked",
    notes: "",
    status: "done",
    dueDate: null,
    goalId: null,
  });
  record("idor-update-task", /not found/i.test(idorUpdateTask.error || ""), JSON.stringify(idorUpdateTask).slice(0, 200));
  const idorDeleteGoal = await callFn(pageB, "/src/lib/goals.ts", "deleteGoal", { id: goalId });
  record("idor-delete-goal", /not found/i.test(idorDeleteGoal.error || ""), JSON.stringify(idorDeleteGoal).slice(0, 200));
  const idorDeleteTask = await callFn(pageB, "/src/lib/goals.ts", "deleteTask", { id: taskId });
  record("idor-delete-task", /not found/i.test(idorDeleteTask.error || ""), JSON.stringify(idorDeleteTask).slice(0, 200));

  const bGoal = await callFn(pageB, "/src/lib/goals.ts", "createGoal", {
    title: "B's goal",
    description: "",
    status: "active",
    targetDate: null,
  });
  const bGoalId = bGoal.result?.id ?? 0;
  const crossLink = await callFn(pageB, "/src/lib/goals.ts", "createTask", {
    title: "Steal A's goal",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId,
  });
  record(
    "cannot-link-foreign-goal",
    /not found/i.test(crossLink.error || ""),
    JSON.stringify(crossLink).slice(0, 240),
  );
  const bInbox = await callFn(pageB, "/src/lib/goals.ts", "createTask", {
    title: "B inbox",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: null,
  });
  record("b-own-unlinked-task", bInbox.ok && bInbox.result?.goalId == null, JSON.stringify(bInbox).slice(0, 200));
  const bTaskId = bInbox.result?.id ?? 0;
  const stealLink = await callFn(pageB, "/src/lib/goals.ts", "updateTask", {
    id: bTaskId,
    title: "B inbox",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId,
  });
  record(
    "cannot-relink-own-task-to-foreign-goal",
    /not found/i.test(stealLink.error || ""),
    JSON.stringify(stealLink).slice(0, 240),
  );
  const bInboxAfter = await callFn(pageB, "/src/lib/goals.ts", "getTask", { id: bTaskId });
  record(
    "own-task-unchanged-after-foreign-link",
    bInboxAfter.ok && bInboxAfter.result?.goalId == null && bInboxAfter.result?.title === "B inbox",
    JSON.stringify(bInboxAfter).slice(0, 220),
  );
  const crossMove = await callFn(pageB, "/src/lib/goals.ts", "updateTask", {
    id: taskId,
    title: "Buy loose-leaf tea",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: bGoalId,
  });
  record(
    "cannot-move-foreign-task",
    /not found/i.test(crossMove.error || ""),
    JSON.stringify(crossMove).slice(0, 240),
  );
  await contextB.close();

  const stillA = await callFn(page, "/src/lib/goals.ts", "getGoal", { id: goalId });
  record("owner-goal-unchanged", stillA.ok && stillA.result?.title === "Drink less sugar this month");

  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  await page.getByRole("article", { name: "Goal: Drink less sugar this month" }).waitFor({ timeout: 10000 });
  await page.getByRole("button", { name: "Delete goal Drink less sugar this month" }).click();
  await page.getByRole("button", { name: "Confirm delete goal Drink less sugar this month" }).click();
  await page.getByRole("article", { name: "Goal: Drink less sugar this month" }).waitFor({
    state: "hidden",
    timeout: 10000,
  });
  const afterDeleteGoal = await callFn(page, "/src/lib/goals.ts", "getTask", { id: taskId });
  record(
    "delete-goal-unlinks-task",
    afterDeleteGoal.ok && afterDeleteGoal.result?.goalId == null && afterDeleteGoal.result?.title === "Buy loose-leaf tea",
    JSON.stringify(afterDeleteGoal).slice(0, 240),
  );
  record(
    "unlinked-task-in-inbox",
    await page.getByRole("article", { name: "Task: Buy loose-leaf tea" }).isVisible(),
  );
  const relinkDeleted = await callFn(page, "/src/lib/goals.ts", "updateTask", {
    id: taskId,
    title: "Buy loose-leaf tea",
    notes: "No sugar in the tin.",
    status: "todo",
    dueDate: null,
    goalId,
  });
  record(
    "deleted-goal-link-rejected",
    /not found/i.test(relinkDeleted.error || ""),
    JSON.stringify(relinkDeleted).slice(0, 220),
  );

  await page.getByRole("button", { name: "Delete task Buy loose-leaf tea" }).click();
  await page.getByRole("button", { name: "Confirm delete task Buy loose-leaf tea" }).click();
  await page.getByRole("article", { name: "Task: Buy loose-leaf tea" }).waitFor({
    state: "hidden",
    timeout: 10000,
  });
  const gone = await callFn(page, "/src/lib/goals.ts", "getTask", { id: taskId });
  record("delete-own-task", /not found/i.test(gone.error || ""), JSON.stringify(gone).slice(0, 180));

  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("memory-regression", await page.getByRole("heading", { name: "What lasts" }).isVisible());
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("settings-regression", await page.getByLabel("Display name").isVisible());
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  record("chat-regression", await page.getByRole("heading", { name: "Conversations" }).isVisible());

  await signOut(page);
  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  record("signout-goals-gate", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  record(
    "signin-same-goals",
    await page.getByRole("article", { name: "Goal: Sleep earlier" }).isVisible(),
  );

  await page.screenshot({ path: "/workspace/screenshots/step9-goals.png", fullPage: true });

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
  );
  const labels = await page.locator("nav[aria-label='Primary']").innerText();
  record(
    "mobile-nav",
    !overflow && /Dashboard/.test(labels) && /Chat/.test(labels) && /Goals/.test(labels),
    JSON.stringify({ overflow, labels: labels.split(/\s+/).filter(Boolean) }),
  );
  record("mobile-goal-card", await page.getByRole("article", { name: "Goal: Sleep earlier" }).isVisible());
  await page.screenshot({ path: "/workspace/screenshots/step9-goals-mobile.png", fullPage: true });

  const serious = consoleErrors.filter(
    (e) => !/Download the React DevTools/i.test(e) && !/not found/i.test(e),
  );
  record("console-errors", serious.length === 0, serious.join(" | ").slice(0, 300));
} catch (err) {
  record("fatal", false, err && err.stack ? err.stack : String(err));
} finally {
  await browser.close();
}

const ok = results.filter((r) => r.ok).length;
const total = results.length;
writeFileSync(
  "/workspace/screenshots/verify-step9.json",
  JSON.stringify({ emailA, emailB, ok, total, results }, null, 2),
);
console.log(`\n${ok}/${total} passed`);
process.exit(ok === total ? 0 : 1);
