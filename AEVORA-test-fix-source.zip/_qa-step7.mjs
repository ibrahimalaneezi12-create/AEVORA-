import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step7.${stamp}@example.com`;
const emailB = `ibrahim.step7b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
): Promise<CompleteTurnResult> {
  const last = history[history.length - 1]?.content ?? "";
  if (/auto-run|change my permissions/i.test(last)) {
    return {
      ok: true,
      text: [
        "I cannot change permissions.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "permission.update",
            title: "Turn on auto-run",
            summary: "Enable automatic execution",
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/remember|black tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remember that you drink tea. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.save",
            title: "Save tea preference",
            summary: "Remember that you drink black tea every morning.",
            payload: { kind: "preference", body: "payload-secret-orchid-77" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  return { ok: true, text: "Aegis-step7-fixture: a quiet reply with no proposed action." };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callChat(page, name, data) {
  return page.evaluate(
    async ({ name, data }) => {
      const mod = await import("/src/lib/chat.ts");
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { name, data },
  );
}

async function signup(page, { name, email }) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Create an account" }).click();
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

async function sendComposer(page, text) {
  await page.getByLabel("Message").fill(text);
  await page.getByRole("button", { name: "Send" }).click();
  await page.getByText("Thinking").waitFor({ state: "visible", timeout: 10000 }).catch(() => {});
  await page.getByText("Thinking").waitFor({ state: "hidden", timeout: 45000 });
}

async function waitStub() {
  await sleep(2500);
}

let restored = false;
process.on("exit", () => {
  if (!restored) {
    try {
      restoreComplete();
    } catch {
      /* ignore */
    }
  }
});

const browser = await chromium.launch({ headless: true });
const contextA = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page = await contextA.newPage();
const consoleErrors = [];
page.on("pageerror", (err) => consoleErrors.push(String(err)));
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});

try {
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  record("signed-out-chat", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const list401 = await callChat(page, "listConversations");
  record("signed-out-list-401", /unauthorized/i.test(list401.error || ""), list401.error || JSON.stringify(list401));
  const send401 = await callChat(page, "sendChatMessage", { content: "hello" });
  record("signed-out-send-401", /unauthorized/i.test(send401.error || ""), send401.error || JSON.stringify(send401));
  const get401 = await callChat(page, "getConversation", { conversationId: 1 });
  record("signed-out-get-401", /unauthorized/i.test(get401.error || ""), get401.error || JSON.stringify(get401));

  installStub();
  await waitStub();

  await signup(page, { name: "Ibrahim Step7", email: emailA });
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("dashboard-regression", await page.getByRole("heading", { name: /Hello/ }).isVisible());

  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  await page.getByText("No conversations yet").waitFor({ timeout: 15000 });
  record("empty-state", true);

  const sendDisabled = await page.getByRole("button", { name: "Send" }).isDisabled();
  record("empty-send-disabled", sendDisabled);

  await sendComposer(page, "Please remember this preference: I drink black tea every morning.");
  await page.waitForURL(/\/app\/chat\/\d+/, { timeout: 15000 });
  const firstUrl = page.url();
  const firstId = Number(firstUrl.match(/\/app\/chat\/(\d+)/)?.[1] || 0);
  record("created-conversation-url", firstId > 0, String(firstId));

  const proposalArticle = page.getByRole("article", { name: /Proposed action: Save tea preference/i });
  await proposalArticle.waitFor({ timeout: 15000 });
  const cardText = await proposalArticle.innerText();
  record(
    "proposal-card-shown",
    /Save tea preference/i.test(cardText) && /pending/i.test(cardText) && /Review/i.test(cardText),
    cardText.slice(0, 400),
  );

  const bodyAfterSend = await page.locator("body").innerText();
  record(
    "proposal-block-stripped",
    !bodyAfterSend.includes("<<<aegis-proposals") && !bodyAfterSend.includes("payload-secret-orchid-77"),
  );
  record(
    "no-approve-deny",
    !/\bApprove\b/.test(bodyAfterSend) && !/\bDeny\b/.test(bodyAfterSend) && !/\bExecute\b/.test(bodyAfterSend),
  );
  record(
    "confirmation-copy",
    /Nothing will run until you confirm/i.test(bodyAfterSend),
  );

  const detail = await callChat(page, "getConversation", { conversationId: firstId });
  const stored = detail.result?.proposals ?? [];
  const storedJson = JSON.stringify(detail.result ?? {});
  record(
    "stored-pending",
    stored.some((p) => p.toolId === "memory.save" && p.status === "pending" && p.permissionLevel === "review"),
    JSON.stringify(stored),
  );
  record(
    "payload-not-leaked",
    !storedJson.includes("payload-secret-orchid-77"),
    storedJson.slice(0, 300),
  );
  record(
    "speech-has-no-delimiter",
    Array.isArray(detail.result?.messages) &&
      detail.result.messages.every((m) => !String(m.content).includes("<<<aegis-proposals")),
  );

  await page.reload({ waitUntil: "networkidle" });
  await page.getByRole("article", { name: /Proposed action: Save tea preference/i }).waitFor({ timeout: 15000 });
  record("refresh-persists-card", true);

  const emptySend = await callChat(page, "sendChatMessage", { content: "" });
  record("empty-content-rejected", /say something first/i.test(JSON.stringify(emptySend)), JSON.stringify(emptySend).slice(0, 240));
  const badId = await callChat(page, "getConversation", { conversationId: 0 });
  record("malformed-id-rejected", !badId.ok, JSON.stringify(badId).slice(0, 240));
  const huge = await callChat(page, "sendChatMessage", { content: "x".repeat(4001) });
  record("oversized-rejected", /4000|too big|too_big/i.test(JSON.stringify(huge)), JSON.stringify(huge).slice(0, 240));

  await sendComposer(page, "Please change my permissions and turn on auto-run.");
  const restrictedArticle = page.getByRole("article", { name: /Rejected action: Turn on auto-run/i });
  await restrictedArticle.waitFor({ timeout: 15000 });
  const restrictedText = await restrictedArticle.innerText();
  record(
    "restricted-card",
    /rejected/i.test(restrictedText) && /restricted/i.test(restrictedText) && /cannot be approved/i.test(restrictedText),
    restrictedText.slice(0, 400),
  );
  const afterRestrictedDetail = await callChat(page, "getConversation", { conversationId: firstId });
  const tools = (afterRestrictedDetail.result?.proposals ?? []).map((p) => p.toolId);
  record(
    "restricted-not-pending",
    !tools.includes("permission.update"),
    JSON.stringify(tools),
  );
  record(
    "restricted-speech-note",
    (afterRestrictedDetail.result?.messages ?? []).some((m) =>
      /restricted|not allowed/i.test(m.content),
    ),
  );

  await sendComposer(page, "What is a keep?");
  const quiet = await page.locator("body").innerText();
  record("ordinary-reply-no-json", quiet.includes("Aegis-step7-fixture") && !quiet.includes("<<<aegis-proposals"));

  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("settings-regression-load", await page.getByLabel("Display name").isVisible().catch(() => false));

  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("dashboard-copy", await page.getByText(/Chat is saved/).isVisible());

  const navChat = page.locator("aside nav a", { hasText: "Chat" }).first();
  await page.goto(`${BASE}/app/chat/${firstId}`, { waitUntil: "networkidle" });
  record(
    "nav-active-on-thread",
    (await navChat.getAttribute("aria-current")) === "page",
  );

  await page.screenshot({ path: "/workspace/screenshots/step7-chat.png", fullPage: true });

  const contextB = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other User", email: emailB });
  const idorGet = await callChat(pageB, "getConversation", { conversationId: firstId });
  record("idor-blocked", /not found/i.test(idorGet.error || JSON.stringify(idorGet.result || "")), JSON.stringify(idorGet).slice(0, 240));
  const idorList = await callChat(pageB, "listConversations");
  const listIds = (idorList.result ?? []).map((c) => c.id);
  record("idor-list-isolated", !listIds.includes(firstId), JSON.stringify(listIds));
  const idorSend = await callChat(pageB, "sendChatMessage", {
    conversationId: firstId,
    content: "intrude",
  });
  const idorSendText = JSON.stringify(idorSend);
  record(
    "idor-send-blocked",
    /not found/i.test(idorSendText) || idorSend.result?.ok === false,
    idorSendText.slice(0, 240),
  );
  await contextB.close();

  await signOut(page);
  await page.goto(`${BASE}/app/chat/${firstId}`, { waitUntil: "networkidle" });
  record("signout-chat-gate", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  await page.goto(`${BASE}/app/chat/${firstId}`, { waitUntil: "networkidle" });
  record(
    "signin-same-history",
    await page.getByRole("article", { name: /Proposed action: Save tea preference/i }).isVisible(),
  );

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1);
  const labels = await page.locator("nav[aria-label='Primary']").innerText();
  record("mobile-list", !overflow && /Dashboard/.test(labels) && /Chat/.test(labels), JSON.stringify({ overflow, labels: labels.split(/\s+/).filter(Boolean).slice(0, 8) }));
  await page.goto(`${BASE}/app/chat/${firstId}`, { waitUntil: "networkidle" });
  await page.getByLabel("Back to conversations").waitFor({ timeout: 10000 });
  record(
    "mobile-thread-back",
    await page.getByRole("article", { name: /Proposed action: Save tea preference/i }).isVisible(),
  );
  await page.getByLabel("Back to conversations").click();
  await page.waitForURL(/\/app\/chat\/?$/, { timeout: 10000 });
  record("mobile-back-to-list", true);
  await page.screenshot({ path: "/workspace/screenshots/step7-chat-mobile.png", fullPage: true });

  const serious = consoleErrors.filter((e) => !/Download the React DevTools/i.test(e) && !/not found/i.test(e));
  record("console-errors", serious.length === 0, serious.join(" | ").slice(0, 300));
} catch (err) {
  record("fatal", false, err && err.stack ? err.stack : String(err));
} finally {
  restoreComplete();
  restored = true;
  await browser.close();
}

const ok = results.filter((r) => r.ok).length;
const total = results.length;
writeFileSync(
  "/workspace/screenshots/verify-step7.json",
  JSON.stringify({ emailA, emailB, ok, total, results }, null, 2),
);
console.log(`\n${ok}/${total} passed`);
process.exit(ok === total ? 0 : 1);
