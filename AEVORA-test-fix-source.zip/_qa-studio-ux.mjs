import { chromium } from "playwright";

const BASE = "http://127.0.0.1:8080";
const email = `studio.ux.${Date.now()}@example.com`;
const password = "correct-horse-battery-1";

async function main() {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", (err) => errors.push(String(err)));

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const create = page.getByRole("button", { name: /Create an account/i });
  if (await create.isVisible().catch(() => false)) await create.click();
  await page.locator("#auth-name").waitFor({ timeout: 15000 });
  await page.locator("#auth-name").fill("Ibrahim");
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: /Create account|Sign up|Create/i }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });

  await page.goto(`${BASE}/app/create`, { waitUntil: "networkidle" });
  await page.waitForTimeout(800);
  const body = await page.locator("body").innerText();
  const checks = {
    heading: /What do you want to create/i.test(body),
    composer: await page.getByPlaceholder("Describe what you want…").count(),
    noModeWall: !/Text to video|Image to video/i.test(body),
    photoVideoButtons: (body.match(/\nPhoto\n/g) || []).length,
    advanced: await page.getByRole("button", { name: "Advanced" }).count(),
    attach: await page.getByRole("button", { name: "Attach" }).count(),
    speak: await page.getByRole("button", { name: /Speak|Stop listening/ }).count(),
    create: await page.getByRole("button", { name: "Create" }).count(),
    library: /Your creations/i.test(body),
    unavailable: /Studio is unavailable right now/i.test(body),
  };

  await page.screenshot({ path: "/workspace/screenshots/studio-desktop.png", fullPage: false });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(400);
  await page.screenshot({ path: "/workspace/screenshots/studio-mobile.png", fullPage: false });

  await page.getByRole("button", { name: "Advanced" }).click();
  await page.waitForTimeout(200);
  await page.screenshot({ path: "/workspace/screenshots/studio-advanced-mobile.png", fullPage: false });

  await page.setViewportSize({ width: 1280, height: 800 });
  await page.getByPlaceholder("Describe what you want…").fill("Make a futuristic city at night.");
  await page.getByRole("button", { name: "Create" }).click();
  await page.waitForTimeout(2500);
  const after = await page.locator("body").innerText();
  const afterChecks = {
    raw403: /\b403\b/.test(after),
    rawJson: /"error"\s*:/.test(after),
    calmFail: /unavailable|try again|Working/i.test(after),
  };
  await page.screenshot({ path: "/workspace/screenshots/studio-generate-attempt.png", fullPage: false });

  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  await page.waitForTimeout(400);
  await page.screenshot({ path: "/workspace/screenshots/home-desktop.png", fullPage: false });

  console.log(JSON.stringify({ checks, afterChecks, errors, email }, null, 2));
  await browser.close();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
