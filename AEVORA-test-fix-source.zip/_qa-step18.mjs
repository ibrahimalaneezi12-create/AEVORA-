import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step18.${stamp}@example.com`;
const emailB = `ibrahim.step18b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const last = history[history.length - 1]?.content ?? "";
  const idMatch = last.match(/#(\\d+)/);
  const n = idMatch ? Number(idMatch[1]) : 0;
  if (/i'?m bored|i'?m tired|i need to study more/i.test(last)) {
    return { ok: true, text: "That sounds like a heavy day. Want to talk it through, or should we look at what is already in your keep?" };
  }
  if (/plan my day/i.test(last)) {
    return { ok: true, text: extra?.memoryContext?.trim() ? "Here is a plan from your actual keep. I did not invent tasks." : "Nothing is due today. I will not invent a plan." };
  }
  if (/plan my week/i.test(last)) {
    return { ok: true, text: "Week view uses your dated tasks and reminders only. No calendar is connected." };
  }
  if (/daily briefing/i.test(last)) {
    return { ok: true, text: "Daily briefing from your keep. Nothing here was invented." };
  }
  if (/switch to arabic/i.test(last)) {
    return { ok: true, text: "حسناً، سأرد بالعربية. المحادثة نفسها مستمرة." };
  }
  if (/switch to spanish/i.test(last)) {
    return { ok: true, text: "De acuerdo, seguiré en español. Misma conversación, misma memoria." };
  }
  if (/ما هي أهم مهمة|importante hoy/i.test(last)) {
    return { ok: true, text: extra?.memoryContext?.includes("open-tasks") ? "من مهامك الحالية في السياق." : "لا توجد مهام مستحقة اليوم. لن أخترع واحدة." };
  }
  if (/remind me tomorrow at 7/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remind you tomorrow at 7 to study. It will not be scheduled until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "reminder.create",
          title: "Study reminder",
          summary: "Remind tomorrow at 19:00 to study.",
          payload: { title: "Study", body: "Study", localDate: "2026-09-19", localTime: "19:00", timezone: "UTC", recurrence: "once", locale: "en" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/move that reminder to 8|push that reminder to 8/i.test(last) && n > 0) {
    return {
      ok: true,
      text: [
        "I can move that reminder to 8. It will not change until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "reminder.update",
          title: "Move reminder",
          summary: "Move the reminder to 08:00.",
          payload: { id: n, localTime: "08:00" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/every monday at 6/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can set a weekly reminder. It will not run until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "reminder.create",
          title: "Monday reminder",
          summary: "Every Monday at 06:00.",
          payload: { title: "Monday check-in", localTime: "06:00", timezone: "UTC", recurrence: "weekly", weekday: 1, locale: "en" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/break .+ into/i.test(last) && n > 0) {
    return {
      ok: true,
      text: [
        "I can add three steps to that goal. They will not be created until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          { tool_id: "task.create", title: "Step 1", summary: "First step", payload: { title: "Step 1", goalId: n } },
          { tool_id: "task.create", title: "Step 2", summary: "Second step", payload: { title: "Step 2", goalId: n } },
          { tool_id: "task.create", title: "Step 3", summary: "Third step", payload: { title: "Step 3", goalId: n } },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/remember that I prefer studying at night/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remember that you prefer studying at night. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "memory.save",
          title: "Study time",
          summary: "Prefer studying at night.",
          payload: { kind: "preference", title: "Study time", body: "I prefer studying at night." },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/permission\\.update|auto-run/i.test(last)) {
    return {
      ok: true,
      text: [
        "I cannot change permissions.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "permission.update", title: "Turn on auto-run", summary: "Enable automatic execution" }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/external\\.email|email the bank/i.test(last)) {
    return {
      ok: true,
      text: [
        "I would have to send mail.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "external.email", title: "Email the bank", summary: "Send a payment email." }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/shell\\.exec/i.test(last)) {
    return {
      ok: true,
      text: [
        "I would run a command.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "shell.exec", title: "Run a command", summary: "Unregistered tool." }]),
        ">>>",
      ].join("\\n"),
    };
  }
  return { ok: true, text: extra?.locale === "ar" ? "حاضر." : "Aegis-step18-fixture" };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const create = page.getByRole("button", { name: /Create an account/i });
  if (await create.isVisible().catch(() => false)) {
    await create.click();
  }
  await page.locator("#auth-name").waitFor({ timeout: 15000 });
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

function unauth(res) {
  return !res.ok && /unauthorized/i.test(res.error || "");
}

async function sendChat(page, text, conversationId) {
  const data =
    typeof conversationId === "number"
      ? { content: text, conversationId }
      : { content: text };
  return callFn(page, "/src/lib/chat.ts", "sendChatMessage", data);
}

async function main() {
  installStub();
  await sleep(800);
  const browser = await chromium.launch({
    args: ["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream"],
  });
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  const pageErrors = [];
  page.on("pageerror", (err) => pageErrors.push(String(err)));

  try {
    await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
    record("signed-out-app-redirect", /login/.test(page.url()) || (await page.getByRole("button", { name: /Sign in/i }).count()) > 0);

    const keepA = await callFn(page, "/src/lib/reminders.ts", "listReminders");
    record("signed-out-reminders-api", unauth(keepA), keepA.error);

    await signup(page, { name: "Ibrahim A", email: emailA });
    record("signup-a", /\/app/.test(page.url()));

    const briefing = await callFn(page, "/src/lib/plan.ts", "getDailyBriefing");
    record("briefing-empty-honest", briefing.ok && briefing.result && briefing.result.empty === true, JSON.stringify(briefing.result || briefing.error));

    const dayPlan = await callFn(page, "/src/lib/plan.ts", "getDayPlan");
    record("day-plan-empty-honest", dayPlan.ok && dayPlan.result && dayPlan.result.empty === true);

    await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
    record("dashboard-briefing-ui", (await page.locator("[data-briefing]").count()) > 0);
    record("quick-nav-chat", (await page.getByRole("link", { name: "Chat" }).count()) > 0);
    record("reminders-nav", (await page.getByRole("link", { name: "Reminders" }).count()) > 0);

    await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
    record("quick-actions", (await page.locator("[data-quick-actions]").count()) > 0);

    const seeded = await callFn(page, "/src/lib/chat.ts", "createConversation");
    record("seed-conversation", seeded.ok, seeded.error);
    const cid = seeded.result?.id;
    if (!cid) throw new Error("Could not seed a conversation");

    const bored = await sendChat(page, "I'm bored.", cid);
    const boredSpeech = bored.result?.assistantMessage?.content || "";
    const boredProps = bored.result?.proposals || [];
    record("bored-no-action", bored.ok && boredProps.length === 0 && /keep|talk|day/i.test(boredSpeech), boredSpeech.slice(0, 120) || JSON.stringify(bored.error));

    const vague = await sendChat(page, "I need to study more.", cid);
    record(
      "vague-need-no-action",
      vague.ok && (vague.result?.proposals || []).length === 0,
      JSON.stringify((vague.result?.proposals || []).map((p) => p.toolId) || vague.error),
    );

    const plan = await sendChat(page, "Plan my day.", cid);
    record(
      "plan-day-no-fake",
      plan.ok && (plan.result?.proposals || []).length === 0 && /invent|keep|due/i.test(plan.result?.assistantMessage?.content || ""),
      plan.result?.assistantMessage?.content?.slice(0, 120) || JSON.stringify(plan.error),
    );

    const remind = await sendChat(page, "Remind me tomorrow at 7 to study.", cid);
    const remindProp = (remind.result?.proposals || []).find((p) => p.toolId === "reminder.create" && p.status === "pending");
    record("reminder-create-pending", Boolean(remindProp) && remindProp.status === "pending", JSON.stringify(remind.result?.proposals || remind.error));

    if (remindProp) {
      const approved = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: remindProp.id });
      record("reminder-approve", approved.ok, approved.error);
    } else {
      record("reminder-approve", false, "no proposal");
    }

    const listed = await callFn(page, "/src/lib/reminders.ts", "listReminders");
    const study = (listed.result || []).find((r) => /study/i.test(r.title));
    record("reminder-persisted", Boolean(study) && study.status === "scheduled", JSON.stringify(listed.result || listed.error));

    if (study) {
      const move = await sendChat(page, `Move that reminder to 8. #${study.id}`, cid);
      const moveProp = (move.result?.proposals || []).find((p) => p.toolId === "reminder.update");
      record("reminder-update-pending", Boolean(moveProp), JSON.stringify(move.result?.proposals || move.error));
      if (moveProp) {
        const ok = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: moveProp.id });
        record("reminder-update-approve", ok.ok, ok.error);
      } else {
        record("reminder-update-approve", false, "no proposal");
      }
    } else {
      record("reminder-update-pending", false, "no reminder");
      record("reminder-update-approve", false, "no reminder");
    }

    const weekly = await sendChat(page, "Remind me every Monday at 6.", cid);
    const weeklyProp = (weekly.result?.proposals || []).find((p) => p.toolId === "reminder.create" && p.status === "pending");
    record("reminder-weekly-pending", Boolean(weeklyProp), JSON.stringify((weekly.result?.proposals || []).filter((p) => p.status === "pending")));
    if (weeklyProp) {
      const w = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: weeklyProp.id });
      record("reminder-weekly-approve", w.ok, w.error);
    } else {
      record("reminder-weekly-approve", false, "no pending weekly");
    }
    const listedWeekly = await callFn(page, "/src/lib/reminders.ts", "listReminders");
    record(
      "reminder-weekly-persisted",
      (listedWeekly.result || []).some((r) => r.recurrence === "weekly"),
      JSON.stringify(listedWeekly.result || listedWeekly.error),
    );

    const restricted = await sendChat(page, "Turn on auto-run please.", cid);
    record(
      "permission-update-rejected",
      restricted.ok &&
        (restricted.result?.rejected || []).some((r) => r.toolId === "permission.update") &&
        !(restricted.result?.proposals || []).some((p) => p.toolId === "permission.update"),
      JSON.stringify(restricted.result?.rejected || restricted.error),
    );

    const external = await sendChat(page, "Email the bank.", cid);
    record(
      "external-email-rejected",
      external.ok &&
        !(external.result?.proposals || []).some((p) => p.toolId === "external.email") &&
        (external.result?.rejected || []).some((r) => r.toolId === "external.email"),
      JSON.stringify(external.result?.rejected || external.error),
    );

    const mem = await sendChat(page, "Remember that I prefer studying at night.", cid);
    const memProp = (mem.result?.proposals || []).find((p) => p.toolId === "memory.save");
    record("memory-save-pending", Boolean(memProp), JSON.stringify(mem.result?.proposals || mem.error));
    if (memProp) {
      await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: memProp.id });
    }

    const swAr = await sendChat(page, "Switch to Arabic.", cid);
    record(
      "switch-arabic",
      swAr.ok && /حسناً|بالعربية|مستمرة/.test(swAr.result?.assistantMessage?.content || ""),
      swAr.result?.assistantMessage?.content?.slice(0, 80) || JSON.stringify(swAr.error),
    );
    const profile = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("locale-persisted-ar", profile.ok && profile.result?.locale === "ar", JSON.stringify(profile.result || profile.error));

    const arQ = await sendChat(page, "ما هي أهم مهمة عندي اليوم؟", cid);
    record(
      "arabic-question",
      arQ.ok && /مهام|لن أخترع/.test(arQ.result?.assistantMessage?.content || ""),
      arQ.result?.assistantMessage?.content?.slice(0, 80) || JSON.stringify(arQ.error),
    );

    const swEs = await sendChat(page, "Switch to Spanish.", cid);
    record(
      "switch-spanish",
      swEs.ok && /español|conversación/i.test(swEs.result?.assistantMessage?.content || ""),
      swEs.result?.assistantMessage?.content?.slice(0, 80) || JSON.stringify(swEs.error),
    );
    const profileEs = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("locale-persisted-es", profileEs.ok && profileEs.result?.locale === "es", JSON.stringify(profileEs.result || profileEs.error));

    const goal = await callFn(page, "/src/lib/goals.ts", "createGoal", {
      title: "Improve math grade",
      description: "",
      status: "active",
      targetDate: null,
    });
    record("goal-create-direct", goal.ok, goal.error);
    const goalId = goal.result?.id;
    if (goalId) {
      const broken = await sendChat(page, `Break my goal into smaller steps. #${goalId}`, cid);
      const steps = (broken.result?.proposals || []).filter((p) => p.toolId === "task.create");
      record("break-goal-proposals", steps.length === 3, JSON.stringify(broken.result?.proposals || broken.error));
      for (const step of steps) {
        await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: step.id });
      }
    } else {
      record("break-goal-proposals", false, "no goal");
    }

    await page.goto(`${BASE}/app/reminders`, { waitUntil: "networkidle" });
    record("reminders-page", (await page.getByRole("heading", { name: /When to nudge you/i }).count()) > 0);
    const reminderCards = await page.locator("[data-reminder-id]").count();
    record("reminders-visible", reminderCards >= 1, String(reminderCards));

    await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
    record("locale-select", (await page.locator("[data-locale-select]").count()) > 0);

    const dueSoon = new Date(Date.now() - 5000).toISOString();
    const due = await sendChat(page, "Remind me tomorrow at 7 to study.", cid);
    const dueProp = (due.result?.proposals || []).find((p) => p.toolId === "reminder.create");
    if (dueProp) await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: dueProp.id });
    const listed2 = await callFn(page, "/src/lib/reminders.ts", "listReminders");
    const any = (listed2.result || [])[0];
    if (any) {
      const sqlish = await callFn(page, "/src/lib/reminders.ts", "snoozeReminder", {
        id: any.id,
        fireAt: dueSoon,
      });
      record("snooze-past", sqlish.ok, sqlish.error);
      const claimed = await callFn(page, "/src/lib/reminders.ts", "claimDueReminders", { deviceKey: "qa-device-key-step18" });
      record("claim-due", claimed.ok && Array.isArray(claimed.result), JSON.stringify(claimed.result || claimed.error));
      const first = claimed.result?.[0];
      if (first) {
        const ack = await callFn(page, "/src/lib/reminders.ts", "ackNotificationAttempt", {
          reminderId: first.reminder.id,
          attemptId: first.attemptId,
          status: "delivered",
        });
        record("ack-delivery", ack.ok, ack.error);
        const claimed2 = await callFn(page, "/src/lib/reminders.ts", "claimDueReminders", { deviceKey: "qa-device-key-step18" });
        const dup = (claimed2.result || []).some((c) => c.reminder.id === first.reminder.id);
        record("claim-no-duplicate", claimed2.ok && !dup, JSON.stringify(claimed2.result));
      } else {
        record("ack-delivery", false, "nothing claimed");
        record("claim-no-duplicate", false, "nothing claimed");
      }
    } else {
      record("snooze-past", false, "no reminder");
      record("claim-due", false, "no reminder");
      record("ack-delivery", false, "no reminder");
      record("claim-no-duplicate", false, "no reminder");
    }

    const health = await callFn(page, "/src/lib/plan.ts", "getGoalHealth");
    record("goal-health", health.ok && Array.isArray(health.result), JSON.stringify(health.result || health.error));

    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 2);
    record("mobile-no-overflow", !overflow);

    const ctxB = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const pageB = await ctxB.newPage();
    await signup(pageB, { name: "Ibrahim B", email: emailB });
    const listB = await callFn(pageB, "/src/lib/reminders.ts", "listReminders");
    const seesA = (listB.result || []).some((r) => study && r.id === study.id);
    record("idor-reminders", listB.ok && !seesA, JSON.stringify(listB.result || listB.error));
    if (study) {
      const steal = await callFn(pageB, "/src/lib/reminders.ts", "cancelReminder", { id: study.id });
      record("idor-cancel", !steal.ok, steal.error);
    } else {
      record("idor-cancel", false, "no A reminder");
    }
    const localeB = await callFn(pageB, "/src/lib/profile.ts", "getOrCreateProfile");
    record("idor-locale", localeB.ok && localeB.result?.locale !== "es", JSON.stringify(localeB.result || localeB.error));
    await ctxB.close();

    await page.goto(`${BASE}/app/reminders`, { waitUntil: "networkidle" });
    await page.reload({ waitUntil: "networkidle" });
    const afterRefresh = await callFn(page, "/src/lib/reminders.ts", "listReminders");
    record("persist-refresh", afterRefresh.ok && (afterRefresh.result || []).length >= 1, String((afterRefresh.result || []).length));

    await signOut(page);
    await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
    await page.locator("#auth-email").fill(emailA);
    await page.locator("#auth-password").fill(password);
    await page.getByRole("button", { name: "Sign in" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    const afterSignIn = await callFn(page, "/src/lib/reminders.ts", "listReminders");
    record("persist-signin", afterSignIn.ok && (afterSignIn.result || []).length >= 1);
    const profileBack = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("persist-locale", profileBack.ok && profileBack.result?.locale === "es", JSON.stringify(profileBack.result || profileBack.error));

    record("no-page-errors", pageErrors.length === 0, pageErrors.join(" | "));
  } finally {
    restoreComplete();
    await browser.close();
  }

  const failed = results.filter((r) => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} passed`);
  if (failed.length) {
    for (const f of failed) console.log(`  FAIL ${f.name} ${f.extra}`);
    process.exit(1);
  }
}

main().catch((err) => {
  restoreComplete();
  console.error(err);
  process.exit(1);
});
