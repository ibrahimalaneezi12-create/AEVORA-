import { chromium } from "playwright";

const BASE = "http://127.0.0.1:8080";
const results = [];
const stamp = Date.now();
const email = `ibrahim.step21.${stamp}@example.com`;
const emailB = `ibrahim.step21b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

async function gotoStable(page, path) {
  let lastErr = null;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    try {
      await page.goto(`${BASE}${path}`, { waitUntil: "domcontentloaded", timeout: 20000 });
      return;
    } catch (err) {
      lastErr = err;
      await page.waitForTimeout(500);
    }
  }
  throw lastErr ?? new Error(`goto failed ${path}`);
}

async function callFn(page, modulePath, name, data) {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      await page.waitForLoadState("domcontentloaded");
      return await page.evaluate(
        async ({ modulePath, name, data }) => {
          const mod = await import(modulePath);
          try {
            const result = data === undefined ? await mod[name]() : await mod[name]({ data });
            return { ok: true, result };
          } catch (err) {
            return { ok: false, error: err && err.message ? err.message : String(err) };
          }
        },
        { modulePath, name, data },
      );
    } catch (err) {
      if (attempt === 2) throw err;
      await page.waitForTimeout(400);
    }
  }
  throw new Error("callFn exhausted");
}

async function fillLogin(page, { name, email, password, mode }) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await gotoStable(page, "/login");
  await page.locator("#auth-email").waitFor({ timeout: 15000 });
  if (mode === "signup") {
    const create = page.getByRole("button", { name: /Create an account/i });
    if (await create.isVisible().catch(() => false)) await create.click();
    await page.locator("#auth-name").waitFor({ timeout: 15000 });
    if (name) await page.locator("#auth-name").fill(name);
  } else {
    const have = page.getByRole("button", { name: /Have an account/i });
    if (await have.isVisible().catch(() => false)) await have.click();
  }
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

async function main() {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  const pageErrors = [];
  page.on("pageerror", (err) => pageErrors.push(String(err)));

  try {
    await gotoStable(page, "/app");
    await page.waitForURL(/\/login|\/app/, { timeout: 15000 }).catch(() => {});
    await page.waitForSelector("h1, #auth-email, a[href='/login']", { timeout: 15000 }).catch(() => {});
    const signedOutHtml = await page.content();
    const signedOut =
      /login/.test(page.url()) ||
      /Sign in/i.test(signedOutHtml) ||
      (await page.getByRole("heading", { name: /Sign in/i }).count()) > 0 ||
      (await page.getByRole("link", { name: /^Sign in$/i }).count()) > 0;
    record("signed-out-app-redirect", signedOut, page.url());

    await fillLogin(page, { name: "Ibrahim 21", email, password, mode: "signup" });
    await page.getByRole("button", { name: "Create account" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    await page.waitForLoadState("load").catch(() => {});
    await page.getByRole("heading", { name: /Hello/i }).waitFor({ timeout: 20000 });
    record("signup-succeeds", /\/app/.test(page.url()));

    const profile = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    const userId = profile.result?.userId;
    record("profile-created", profile.ok && Boolean(userId), JSON.stringify(profile.result || profile.error));

    await gotoStable(page, "/app/settings");
    await page.getByRole("heading", { name: /Profile/i }).waitFor({ timeout: 15000 });
    const ent = await callFn(page, "/src/lib/entitlements.ts", "getEntitlement");
    record(
      "entitlement-server-side",
      ent.ok && (ent.result?.plan === "founder" || ent.result?.plan === "free") && ent.result?.userId === userId,
      JSON.stringify(ent.result || ent.error),
    );
    record(
      "founder-price-zero-or-free-label",
      ent.ok && (ent.result?.price === "£0" || ent.result?.price === "Free"),
      JSON.stringify(ent.result?.price),
    );
    await page.locator("#preferred-language").waitFor({ timeout: 15000 });
    await page.getByRole("heading", { name: "Pulse and tone" }).waitFor({ timeout: 15000 });
    record("settings-pulse-panel", (await page.getByRole("heading", { name: "Pulse and tone" }).count()) > 0);

    await gotoStable(page, "/app/calendar");
    await page.getByRole("heading", { name: /Your time/i }).waitFor({ timeout: 15000 });
    const cal = await callFn(page, "/src/lib/calendar.ts", "createCalendarEvent", {
      title: "Dentist",
      startAt: new Date(Date.now() + 86400000).toISOString(),
    });
    if (ent.result?.plan === "founder") {
      record("founder-can-calendar", cal.ok && cal.result?.title === "Dentist", JSON.stringify(cal.result || cal.error));
    } else {
      record(
        "free-calendar-denied-honestly",
        !cal.ok && /does not include calendar/i.test(cal.error || ""),
        cal.error,
      );
    }

    const listed = await callFn(page, "/src/lib/calendar.ts", "listCalendarEvents");
    record("calendar-list-scoped", listed.ok && Array.isArray(listed.result));

    const calStatus = await callFn(page, "/src/lib/calendar.ts", "getCalendarStatus");
    record(
      "calendar-google-honest",
      calStatus.ok && typeof calStatus.result?.connected === "boolean" && /Google Calendar/i.test(calStatus.result?.detail || ""),
      JSON.stringify(calStatus.result || calStatus.error),
    );

    if (cal.ok && cal.result?.id) {
      const cancelled = await callFn(page, "/src/lib/calendar.ts", "cancelCalendarEvent", { id: cal.result.id });
      record("calendar-cancel-owned", cancelled.ok, JSON.stringify(cancelled.result || cancelled.error));
    } else {
      record("calendar-cancel-owned", ent.result?.plan !== "founder", "skipped for free plan");
    }

    await gotoStable(page, "/app/mail");
    await page.getByRole("heading", { name: /Drafts/i }).waitFor({ timeout: 15000 });
    const mailStatus = await callFn(page, "/src/lib/mail.ts", "getMailStatus");
    record(
      "mail-gmail-honest",
      mailStatus.ok && typeof mailStatus.result?.connected === "boolean",
      JSON.stringify(mailStatus.result || mailStatus.error),
    );
    const drafts = await callFn(page, "/src/lib/mail.ts", "listEmailDrafts");
    record("mail-list-scoped", drafts.ok && Array.isArray(drafts.result));

    await gotoStable(page, "/app/create");
    await page.getByRole("heading", { name: "Keep the writing." }).waitFor({ timeout: 15000 });
    const savedWriting = await callFn(page, "/src/lib/creation.ts", "saveCreation", {
      title: "Study note",
      body: "Keep this.",
      kind: "note",
    });
    if (ent.result?.plan === "founder") {
      record(
        "founder-can-create",
        savedWriting.ok && savedWriting.result?.title === "Study note",
        JSON.stringify(savedWriting.result || savedWriting.error),
      );
    } else {
      record(
        "free-creation-denied-honestly",
        !savedWriting.ok && /does not include creation/i.test(savedWriting.error || ""),
        savedWriting.error,
      );
    }

    const pulse = await callFn(page, "/src/lib/pulse.ts", "getPulse");
    record(
      "pulse-from-keep",
      pulse.ok && typeof pulse.result?.enabled === "boolean" && Array.isArray(pulse.result?.suggestions),
      JSON.stringify(pulse.result || pulse.error),
    );

    const afterReload = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("refresh-same-account", afterReload.ok && afterReload.result?.userId === userId);

    const ctxB = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const pageB = await ctxB.newPage();
    await fillLogin(pageB, { name: "Ibrahim B", email: emailB, password, mode: "signup" });
    await pageB.getByRole("button", { name: "Create account" }).click();
    await pageB.waitForURL(/\/app/, { timeout: 20000 });
    await pageB.getByRole("heading", { name: /Hello/i }).waitFor({ timeout: 20000 });
    const profileB = await callFn(pageB, "/src/lib/profile.ts", "getOrCreateProfile");
    record("user-b-isolated", profileB.ok && profileB.result?.userId !== userId);
    await gotoStable(pageB, "/app/calendar");
    const listB = await callFn(pageB, "/src/lib/calendar.ts", "listCalendarEvents");
    const idsA = (listed.result || []).map((row) => row.id);
    const idsB = (listB.result || []).map((row) => row.id);
    record("calendar-idor", listB.ok && idsB.every((id) => !idsA.includes(id)));
    const draftsB = await callFn(pageB, "/src/lib/mail.ts", "listEmailDrafts");
    const mailIdsA = (drafts.result || []).map((row) => row.id);
    const mailIdsB = (draftsB.result || []).map((row) => row.id);
    record("mail-idor", draftsB.ok && mailIdsB.every((id) => !mailIdsA.includes(id)));
    await ctxB.close();

    await signOut(page);
    await gotoStable(page, "/app");
    await page.waitForSelector("h1, #auth-email", { timeout: 12000 }).catch(() => {});
    const blocked =
      /login/.test(page.url()) || (await page.getByRole("heading", { name: /Sign in/i }).count()) > 0;
    record("sign-out-blocks-app", blocked, page.url());

    await fillLogin(page, { email, password, mode: "signin" });
    const unsigned = await callFn(page, "/src/lib/calendar.ts", "listCalendarEvents");
    record(
      "signed-out-calendar-unauthorized",
      !unsigned.ok && /unauthorized/i.test(unsigned.error || ""),
      unsigned.error,
    );

    await page.getByRole("button", { name: "Sign in" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    await page.getByRole("heading", { name: /Hello/i }).waitFor({ timeout: 20000 });
    const back = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("correct-credentials-restore", back.ok && back.result?.userId === userId);

    await page.setViewportSize({ width: 390, height: 844 });
    await gotoStable(page, "/app");
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 2,
    );
    record("app-mobile-no-overflow", !overflow);
    record("no-page-errors", pageErrors.length === 0, pageErrors.join(" | "));
  } finally {
    await browser.close();
  }

  const failed = results.filter((r) => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} passed`);
  if (failed.length) {
    for (const f of failed) console.log(`  FAIL ${f.name} ${f.extra}`);
    process.exit(1);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
