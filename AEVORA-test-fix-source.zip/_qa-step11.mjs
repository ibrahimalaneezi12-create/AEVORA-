import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step11.${stamp}@example.com`;
const emailB = `ibrahim.step11b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const last = history[history.length - 1]?.content ?? "";
  if (/auto-run|change my permissions/i.test(last)) {
    return {
      ok: true,
      text: [
        "I cannot change permissions.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "permission.update",
            title: "Turn on auto-run",
            summary: "Enable automatic execution",
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/remember|black tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remember that you drink tea. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.save",
            title: "Save tea preference",
            summary: "Remember that you drink black tea every morning.",
            payload: { kind: "preference", body: "payload-secret-orchid-77" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  return { ok: true, text: "Aegis-step11-fixture: a quiet reply with no proposed action." };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Create an account" }).click();
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

let restored = false;
process.on("exit", () => {
  if (!restored) {
    try {
      restoreComplete();
    } catch {
      /* ignore */
    }
  }
});

const browser = await chromium.launch({ headless: true });
const contextA = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page = await contextA.newPage();
const consoleErrors = [];
page.on("pageerror", (err) => consoleErrors.push(String(err)));
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});

try {
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("signed-out-settings", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const unauthGet = await callFn(page, "/src/lib/permissions.ts", "getPermissionSettings");
  record("unauth-get", /unauthorized/i.test(unauthGet.error || ""), unauthGet.error || JSON.stringify(unauthGet));
  const unauthUp = await callFn(page, "/src/lib/permissions.ts", "updatePermissionSettings", {
    confirmFloor: "approval",
  });
  record("unauth-update", /unauthorized/i.test(unauthUp.error || ""), unauthUp.error || JSON.stringify(unauthUp));

  await signup(page, { name: "Ibrahim Step11", email: emailA });
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Permissions" }).waitFor({ timeout: 15000 });
  record("settings-profile", await page.getByLabel("Display name").isVisible());
  record("settings-permissions", await page.getByRole("heading", { name: "Permissions" }).isVisible());
  record("auto-run-frozen", await page.getByText(/cannot be turned on/i).isVisible());
  record("catalog-visible", await page.getByText("Save a memory").isVisible());
  record(
    "no-approve-deny",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /^Deny$/ }).count()) === 0,
  );

  const defaults = await callFn(page, "/src/lib/permissions.ts", "getPermissionSettings");
  record(
    "default-floor-safe",
    defaults.ok &&
      defaults.result?.confirmFloor === "safe" &&
      defaults.result?.autoRunSafe === false &&
      defaults.result?.autoRunReview === false,
    JSON.stringify(defaults).slice(0, 240),
  );

  const sneak = await callFn(page, "/src/lib/permissions.ts", "updatePermissionSettings", {
    confirmFloor: "review",
    autoRunSafe: true,
    autoRunReview: true,
  });
  record(
    "extra-autorun-ignored-or-rejected",
    (sneak.ok && sneak.result?.autoRunSafe === false && sneak.result?.autoRunReview === false) ||
      !sneak.ok,
    JSON.stringify(sneak).slice(0, 240),
  );
  const afterSneak = await callFn(page, "/src/lib/permissions.ts", "getPermissionSettings");
  record(
    "autorun-still-off",
    afterSneak.ok && afterSneak.result?.autoRunSafe === false && afterSneak.result?.autoRunReview === false,
    JSON.stringify(afterSneak).slice(0, 200),
  );

  const badFloor = await callFn(page, "/src/lib/permissions.ts", "updatePermissionSettings", {
    confirmFloor: "restricted",
  });
  record("restricted-floor-rejected", !badFloor.ok, JSON.stringify(badFloor).slice(0, 200));
  const junkFloor = await callFn(page, "/src/lib/permissions.ts", "updatePermissionSettings", {
    confirmFloor: "loud",
  });
  record("invalid-floor-rejected", !junkFloor.ok, JSON.stringify(junkFloor).slice(0, 200));

  await page.getByRole("button", { name: "At least Approval" }).click();
  await page.getByRole("button", { name: "Save permissions" }).click();
  await page.getByText("Permissions saved.").waitFor({ timeout: 15000 });
  record("ui-save-approval-floor", true);

  await page.reload({ waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Permissions" }).waitFor({ timeout: 15000 });
  const approvalPressed = await page.getByRole("button", { name: "At least Approval" }).getAttribute("aria-pressed");
  record("floor-persists", approvalPressed === "true", String(approvalPressed));
  const saved = await callFn(page, "/src/lib/permissions.ts", "getPermissionSettings");
  record("api-floor-approval", saved.ok && saved.result?.confirmFloor === "approval", JSON.stringify(saved).slice(0, 200));

  installStub();
  await sleep(2500);

  const sentTight = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please remember I drink black tea every morning.",
  });
  const tightProps = sentTight.result?.proposals ?? [];
  record(
    "tightened-review-stored-as-approval",
    sentTight.ok &&
      tightProps.some((p) => p.title === "Save tea preference" && p.permissionLevel === "approval"),
    JSON.stringify(tightProps).slice(0, 280),
  );
  record(
    "tightened-no-payload",
    !JSON.stringify(sentTight.result ?? {}).includes("payload-secret-orchid-77"),
    JSON.stringify(Object.keys(sentTight.result ?? {})),
  );
  record(
    "tightened-still-pending",
    tightProps.every((p) => p.status === "pending"),
    JSON.stringify(tightProps.map((p) => p.status)),
  );

  const restricted = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please change my permissions and turn on auto-run.",
  });
  record(
    "restricted-still-rejected",
    restricted.ok &&
      (restricted.result?.proposals ?? []).length === 0 &&
      (restricted.result?.rejected ?? []).some((r) => /restricted/i.test(r.reason || "") || r.toolId === "permission.update"),
    JSON.stringify({
      proposals: restricted.result?.proposals,
      rejected: restricted.result?.rejected,
    }).slice(0, 280),
  );

  const lower = await callFn(page, "/src/lib/permissions.ts", "updatePermissionSettings", {
    confirmFloor: "safe",
  });
  record("user-may-set-floor-back", lower.ok && lower.result?.confirmFloor === "safe", JSON.stringify(lower).slice(0, 180));

  const sentDefault = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Remember I drink black tea.",
  });
  const defaultProps = sentDefault.result?.proposals ?? [];
  record(
    "default-floor-review-again",
    sentDefault.ok &&
      defaultProps.some((p) => p.title === "Save tea preference" && p.permissionLevel === "review"),
    JSON.stringify(defaultProps).slice(0, 280),
  );

  restoreComplete();
  restored = true;
  utimesSync(COMPLETE, new Date(), new Date());
  await sleep(800);

  const dash = await callFn(page, "/src/lib/dashboard.ts", "getDashboard");
  record(
    "dashboard-still-composes",
    dash.ok && dash.result?.greetingName === "Ibrahim" && Array.isArray(dash.result?.pending),
    JSON.stringify({ greeting: dash.result?.greetingName, pending: dash.result?.pendingTotal }).slice(0, 200),
  );
  record(
    "dashboard-shows-tightened-pending",
    (dash.result?.pending ?? []).some((p) => p.title === "Save tea preference"),
    JSON.stringify(dash.result?.pending ?? []).slice(0, 240),
  );

  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: /Hello, Ibrahim/ }).waitFor({ timeout: 15000 });
  record("dashboard-ui", await page.getByRole("heading", { name: /Hello, Ibrahim/ }).isVisible());
  record(
    "dashboard-no-execute",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /Execute/i }).count()) === 0,
  );

  const contextB = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other User", email: emailB });
  const bGet = await callFn(pageB, "/src/lib/permissions.ts", "getPermissionSettings");
  record(
    "idor-b-has-own-defaults",
    bGet.ok && bGet.result?.confirmFloor === "safe",
    JSON.stringify(bGet).slice(0, 200),
  );
  const bRaise = await callFn(pageB, "/src/lib/permissions.ts", "updatePermissionSettings", {
    confirmFloor: "review",
  });
  record("b-can-set-own-floor", bRaise.ok && bRaise.result?.confirmFloor === "review");
  const aStill = await callFn(page, "/src/lib/permissions.ts", "getPermissionSettings");
  record(
    "idor-a-unchanged",
    aStill.ok && aStill.result?.confirmFloor === "safe",
    JSON.stringify(aStill).slice(0, 200),
  );
  await contextB.close();

  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  record("goals-regression", await page.getByRole("heading", { name: "Working toward" }).isVisible());
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("memory-regression", await page.getByRole("heading", { name: "What lasts" }).isVisible());
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  record("chat-regression", await page.getByRole("heading", { name: "Conversations" }).isVisible());

  await signOut(page);
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("signout-gate", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  const afterSignin = await callFn(page, "/src/lib/permissions.ts", "getPermissionSettings");
  record(
    "signin-same-floor",
    afterSignin.ok && afterSignin.result?.confirmFloor === "safe",
    JSON.stringify(afterSignin).slice(0, 200),
  );

  await page.screenshot({ path: "/workspace/screenshots/step11-settings.png", fullPage: true });

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Permissions" }).waitFor({ timeout: 15000 });
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
  );
  record("mobile-no-overflow", !overflow, JSON.stringify({ overflow }));
  record("mobile-permissions", await page.getByRole("heading", { name: "Permissions" }).isVisible());
  await page.screenshot({ path: "/workspace/screenshots/step11-settings-mobile.png", fullPage: true });

  const serious = consoleErrors.filter(
    (e) => !/Download the React DevTools/i.test(e) && !/not found/i.test(e),
  );
  record("console-errors", serious.length === 0, serious.join(" | ").slice(0, 300));
} catch (err) {
  record("fatal", false, err && err.stack ? err.stack : String(err));
} finally {
  if (!restored) {
    restoreComplete();
    restored = true;
  }
  await browser.close();
}

const ok = results.filter((r) => r.ok).length;
const total = results.length;
writeFileSync(
  "/workspace/screenshots/verify-step11.json",
  JSON.stringify({ emailA, emailB, ok, total, results }, null, 2),
);
console.log(`\n${ok}/${total} passed`);
process.exit(ok === total ? 0 : 1);
