#!/usr/bin/env node
/**
 * Nitro bundles `@electric-sql/pglite` but does not emit its sibling
 * `.wasm` / `.data` files. Local `vite preview` (no DATABASE_URL) loads
 * PGLite and will crash without them. Deployed apps use Neon and never
 * hit this path.
 */
import { copyFileSync, mkdirSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const srcDir = join(root, "node_modules/@electric-sql/pglite/dist");
const destDir = join(
  root,
  ".vercel/output/functions/__server.func/_libs",
);

const files = ["pglite.data", "pglite.wasm", "initdb.wasm"];

if (!existsSync(destDir)) {
  console.warn("[pglite-assets] no vercel server output — skipping");
  process.exit(0);
}

mkdirSync(destDir, { recursive: true });
for (const name of files) {
  const from = join(srcDir, name);
  const to = join(destDir, name);
  if (!existsSync(from)) {
    console.warn(`[pglite-assets] missing ${from}`);
    continue;
  }
  copyFileSync(from, to);
  console.log(`[pglite-assets] ${name}`);
}
