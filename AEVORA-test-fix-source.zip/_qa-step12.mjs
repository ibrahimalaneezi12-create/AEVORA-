import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step12.${stamp}@example.com`;
const emailB = `ibrahim.step12b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const last = history[history.length - 1]?.content ?? "";
  if (/auto-run|change my permissions/i.test(last)) {
    return {
      ok: true,
      text: [
        "I cannot change permissions.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "permission.update",
            title: "Turn on auto-run",
            summary: "Enable automatic execution",
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/delete the kettle note/i.test(last)) {
    const idMatch = last.match(/id=(\\d+)/);
    const id = idMatch ? Number(idMatch[1]) : 999999;
    return {
      ok: true,
      text: [
        "I can delete that memory. It will not be removed until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.delete",
            title: "Delete kettle note",
            summary: "Remove the kettle memory.",
            payload: { id },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/create a task to buy tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can add that task. It will not be created until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "task.create",
            title: "Buy loose-leaf tea",
            summary: "Add a task to buy tea.",
            payload: { title: "Buy loose-leaf tea", status: "todo" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/search my memories for tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can search your memory. It will not run until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.search",
            title: "Search tea memories",
            summary: "Look for tea in your keep.",
            payload: { query: "tea" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/remember|black tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remember that you drink tea. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.save",
            title: "Save tea preference",
            summary: "Remember that you drink black tea every morning.",
            payload: { kind: "preference", body: "payload-secret-orchid-77" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  return { ok: true, text: "Aegis-step12-fixture: a quiet reply with no proposed action." };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Create an account" }).click();
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

let restored = false;
process.on("exit", () => {
  if (!restored) {
    try {
      restoreComplete();
    } catch {
      /* ignore */
    }
  }
});

const browser = await chromium.launch({ headless: true });
const contextA = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page = await contextA.newPage();
const consoleErrors = [];
page.on("pageerror", (err) => consoleErrors.push(String(err)));
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});

try {
  await page.goto(`${BASE}/app/approvals/1`, { waitUntil: "networkidle" });
  record("signed-out-approval-page", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const unauthGet = await callFn(page, "/src/lib/confirm.ts", "getProposal", { id: 1 });
  record("unauth-get", /unauthorized/i.test(unauthGet.error || ""), unauthGet.error || JSON.stringify(unauthGet));
  const unauthAp = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: 1 });
  record("unauth-approve", /unauthorized/i.test(unauthAp.error || ""), unauthAp.error || JSON.stringify(unauthAp));
  const unauthDn = await callFn(page, "/src/lib/confirm.ts", "denyProposal", { id: 1 });
  record("unauth-deny", /unauthorized/i.test(unauthDn.error || ""), unauthDn.error || JSON.stringify(unauthDn));

  await signup(page, { name: "Ibrahim Step12", email: emailA });

  const missing = await callFn(page, "/src/lib/confirm.ts", "approveProposal");
  record("missing-id", !missing.ok, JSON.stringify(missing).slice(0, 200));
  const invalid = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: 0 });
  record("invalid-id", !invalid.ok, JSON.stringify(invalid).slice(0, 200));
  const missingGet = await callFn(page, "/src/lib/confirm.ts", "getProposal", { id: 999999 });
  record(
    "nonexistent",
    !missingGet.ok && /not found/i.test(missingGet.error || ""),
    JSON.stringify(missingGet).slice(0, 200),
  );

  installStub();
  await sleep(2500);

  const sentSave = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please remember I drink black tea every morning.",
  });
  const saveProps = sentSave.result?.proposals ?? [];
  const save = saveProps.find((p) => p.title === "Save tea preference");
  record(
    "review-proposal-pending",
    sentSave.ok && save && save.status === "pending" && save.permissionLevel === "review",
    JSON.stringify(saveProps).slice(0, 280),
  );
  record(
    "chat-result-no-payload-secret",
    !JSON.stringify(sentSave.result ?? {}).includes("payload-secret-orchid-77"),
  );

  const convoId = sentSave.result?.conversation?.id;
  await page.goto(`${BASE}/app/chat/${convoId}`, { waitUntil: "networkidle" });
  const reviewCard = page.getByRole("article", { name: /Proposed action: Save tea preference/i });
  await reviewCard.waitFor({ timeout: 15000 });
  record("review-card-approve", await reviewCard.getByRole("button", { name: /^Approve$/ }).isVisible());
  record("review-card-deny", await reviewCard.getByRole("button", { name: /^Deny$/ }).isVisible());
  const chatHtml = await page.content();
  record("chat-ui-no-payload-secret", !chatHtml.includes("payload-secret-orchid-77"));
  record(
    "chat-still-confirms",
    /Nothing will run until you confirm/i.test(await reviewCard.innerText()),
  );

  const got = await callFn(page, "/src/lib/confirm.ts", "getProposal", { id: save.id });
  record(
    "get-own-proposal",
    got.ok &&
      got.result?.id === save.id &&
      got.result?.canApprove === true &&
      got.result?.canDeny === true &&
      (got.result?.payloadPreview ?? []).some((l) => l.value === "payload-secret-orchid-77"),
    JSON.stringify(got).slice(0, 320),
  );

  const approved = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: save.id });
  record(
    "valid-approve-executes",
    approved.ok && approved.result?.status === "executed",
    JSON.stringify(approved).slice(0, 280),
  );
  const memoriesAfter = await callFn(page, "/src/lib/memory.ts", "listMemories");
  const teaRows = (memoriesAfter.result ?? []).filter(
    (m) => m.body === "payload-secret-orchid-77" || m.title === "Save tea preference",
  );
  record(
    "approve-wrote-memory-once",
    memoriesAfter.ok && teaRows.length === 1,
    JSON.stringify(teaRows).slice(0, 240),
  );

  const replayApprove = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: save.id });
  record(
    "replay-approve",
    !replayApprove.ok && /no longer pending/i.test(replayApprove.error || ""),
    JSON.stringify(replayApprove).slice(0, 200),
  );
  const replayExec = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: save.id });
  record(
    "replay-execution",
    !replayExec.ok && /no longer pending/i.test(replayExec.error || ""),
    JSON.stringify(replayExec).slice(0, 200),
  );
  const memoriesReplay = await callFn(page, "/src/lib/memory.ts", "listMemories");
  const teaReplay = (memoriesReplay.result ?? []).filter(
    (m) => m.body === "payload-secret-orchid-77" || m.title === "Save tea preference",
  );
  record("replay-did-not-duplicate", teaReplay.length === 1, String(teaReplay.length));

  const denyAfterApprove = await callFn(page, "/src/lib/confirm.ts", "denyProposal", { id: save.id });
  record(
    "deny-after-approve",
    !denyAfterApprove.ok && /no longer pending/i.test(denyAfterApprove.error || ""),
    JSON.stringify(denyAfterApprove).slice(0, 200),
  );

  const sentDeny = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Remember I drink black tea.",
  });
  const denyProp = (sentDeny.result?.proposals ?? []).find((p) => p.title === "Save tea preference");
  record("second-pending-created", Boolean(denyProp && denyProp.status === "pending"));
  const denied = await callFn(page, "/src/lib/confirm.ts", "denyProposal", { id: denyProp?.id });
  record(
    "valid-deny",
    denied.ok && denied.result?.status === "denied",
    JSON.stringify(denied).slice(0, 220),
  );
  const memoriesDenied = await callFn(page, "/src/lib/memory.ts", "listMemories");
  const teaDenied = (memoriesDenied.result ?? []).filter(
    (m) => m.body === "payload-secret-orchid-77" || m.title === "Save tea preference",
  );
  record("deny-did-not-execute", teaDenied.length === 1, String(teaDenied.length));
  const replayDeny = await callFn(page, "/src/lib/confirm.ts", "denyProposal", { id: denyProp?.id });
  record(
    "replay-deny",
    !replayDeny.ok && /no longer pending/i.test(replayDeny.error || ""),
    JSON.stringify(replayDeny).slice(0, 200),
  );
  const approveAfterDeny = await callFn(page, "/src/lib/confirm.ts", "approveProposal", {
    id: denyProp?.id,
  });
  record(
    "approve-after-deny",
    !approveAfterDeny.ok && /no longer pending/i.test(approveAfterDeny.error || ""),
    JSON.stringify(approveAfterDeny).slice(0, 200),
  );
  const teaStill = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "approve-after-deny-no-write",
    (teaStill.result ?? []).filter(
      (m) => m.body === "payload-secret-orchid-77" || m.title === "Save tea preference",
    ).length === 1,
  );

  const kettle = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "Kettle note",
    body: "The kettle is in the cupboard.",
    tags: "",
    pinned: false,
  });
  record("seed-kettle", kettle.ok && kettle.result?.id > 0, JSON.stringify(kettle).slice(0, 160));
  const kettleId = kettle.result?.id;
  const sentDel = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: `Please delete the kettle note id=${kettleId}`,
  });
  const delProp = (sentDel.result?.proposals ?? []).find((p) => p.toolId === "memory.delete");
  record(
    "approval-proposal-pending",
    Boolean(delProp && delProp.status === "pending" && delProp.permissionLevel === "approval"),
    JSON.stringify(sentDel.result?.proposals ?? []).slice(0, 240),
  );

  await page.goto(`${BASE}/app/chat/${sentDel.result?.conversation?.id}`, { waitUntil: "networkidle" });
  const delCard = page.getByRole("article", { name: /Proposed action: Delete kettle note/i });
  await delCard.waitFor({ timeout: 15000 });
  record(
    "approval-card-no-inthread-approve",
    (await delCard.getByRole("button", { name: /^Approve$/ }).count()) === 0,
  );
  record(
    "approval-card-review-link",
    await delCard.getByRole("link", { name: "Review this action" }).isVisible(),
  );

  await page.goto(`${BASE}/app/approvals/${delProp.id}`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Delete kettle note" }).waitFor({ timeout: 15000 });
  record("confirmation-page", await page.getByText("Confirmation").first().isVisible());
  record("confirmation-approve", await page.getByRole("button", { name: /^Approve$/ }).isVisible());
  record("confirmation-deny", await page.getByRole("button", { name: /^Deny$/ }).isVisible());
  record("confirmation-tool", await page.getByText("Delete a memory").isVisible());

  await page.reload({ waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Delete kettle note" }).waitFor({ timeout: 15000 });
  const stillPending = await callFn(page, "/src/lib/confirm.ts", "getProposal", { id: delProp.id });
  record(
    "refresh-did-not-execute",
    stillPending.ok && stillPending.result?.status === "pending",
    JSON.stringify(stillPending.result ?? {}).slice(0, 200),
  );
  const kettleStill = await callFn(page, "/src/lib/memory.ts", "getMemory", { id: kettleId });
  record("refresh-memory-intact", kettleStill.ok && kettleStill.result?.id === kettleId);

  await page.getByRole("button", { name: /^Approve$/ }).click();
  await page.getByRole("button", { name: /^Approve$/ }).waitFor({ state: "hidden", timeout: 15000 });
  record("page-approve-executed", await page.getByText(/Deleted memory/i).isVisible());
  const kettleGone = await callFn(page, "/src/lib/memory.ts", "getMemory", { id: kettleId });
  record("approval-delete-ran-once", !kettleGone.ok, JSON.stringify(kettleGone).slice(0, 160));

  await page.reload({ waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Delete kettle note" }).waitFor({ timeout: 15000 });
  record(
    "refresh-after-execute-no-buttons",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0,
  );
  const delReplay = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: delProp.id });
  record("refresh-replay-blocked", !delReplay.ok, JSON.stringify(delReplay).slice(0, 160));

  const restricted = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please change my permissions and turn on auto-run.",
  });
  record(
    "restricted-not-stored",
    restricted.ok &&
      (restricted.result?.proposals ?? []).length === 0 &&
      (restricted.result?.rejected ?? []).some((r) => r.toolId === "permission.update"),
    JSON.stringify({
      proposals: restricted.result?.proposals,
      rejected: restricted.result?.rejected,
    }).slice(0, 280),
  );

  const searchSent = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please search my memories for tea.",
  });
  const searchProp = (searchSent.result?.proposals ?? []).find((p) => p.toolId === "memory.search");
  record(
    "safe-proposal-pending",
    Boolean(searchProp && searchProp.status === "pending" && searchProp.permissionLevel === "safe"),
    JSON.stringify(searchSent.result?.proposals ?? []).slice(0, 220),
  );
  const searchRun = await callFn(page, "/src/lib/confirm.ts", "approveProposal", {
    id: searchProp?.id,
  });
  record(
    "safe-approve-executes-read",
    searchRun.ok && searchRun.result?.status === "executed",
    JSON.stringify(searchRun).slice(0, 220),
  );

  const taskSent = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please create a task to buy tea.",
  });
  const taskProp = (taskSent.result?.proposals ?? []).find((p) => p.toolId === "task.create");
  const taskRun = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: taskProp?.id });
  record(
    "review-task-create-executes",
    taskRun.ok && taskRun.result?.status === "executed",
    JSON.stringify(taskRun).slice(0, 220),
  );
  const tasks = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
  record(
    "task-created-once",
    (tasks.result?.tasks ?? []).filter((t) => t.title === "Buy loose-leaf tea").length === 1,
    JSON.stringify((tasks.result?.tasks ?? []).map((t) => t.title)).slice(0, 200),
  );
  const taskReplay = await callFn(page, "/src/lib/confirm.ts", "approveProposal", {
    id: taskProp?.id,
  });
  record("task-replay-blocked", !taskReplay.ok);
  const tasksReplay = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
  record(
    "task-not-duplicated",
    (tasksReplay.result?.tasks ?? []).filter((t) => t.title === "Buy loose-leaf tea").length === 1,
  );

  const dash = await callFn(page, "/src/lib/dashboard.ts", "getDashboard");
  record(
    "dashboard-pending-excludes-executed",
    dash.ok &&
      !(dash.result?.pending ?? []).some((p) => p.id === save.id || p.id === delProp.id),
    JSON.stringify(dash.result?.pending ?? []).slice(0, 240),
  );
  record(
    "dashboard-no-payload-json",
    !JSON.stringify(Object.keys(dash.result ?? {})).includes("payload") &&
      !(dash.result?.pending ?? []).some((row) => "payload" in row || "payload_json" in row),
    JSON.stringify(Object.keys(dash.result ?? {})),
  );

  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: /Hello, Ibrahim/ }).waitFor({ timeout: 15000 });
  record(
    "dashboard-no-approve-button",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /Execute/i }).count()) === 0,
  );

  const failedDel = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please delete the kettle note id=999999",
  });
  const failedProp = (failedDel.result?.proposals ?? []).find((p) => p.toolId === "memory.delete");
  const failedRun = await callFn(page, "/src/lib/confirm.ts", "approveProposal", {
    id: failedProp?.id,
  });
  record(
    "failed-execute-marks-failed",
    failedRun.ok && failedRun.result?.status === "failed",
    JSON.stringify(failedRun).slice(0, 240),
  );
  const failedReplay = await callFn(page, "/src/lib/confirm.ts", "approveProposal", {
    id: failedProp?.id,
  });
  record(
    "failed-replay-no-second-execute",
    !failedReplay.ok && /no longer pending/i.test(failedReplay.error || ""),
    JSON.stringify(failedReplay).slice(0, 200),
  );

  const contextB = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other User", email: emailB });
  const bGet = await callFn(pageB, "/src/lib/confirm.ts", "getProposal", { id: save.id });
  record(
    "idor-get",
    !bGet.ok && /not found/i.test(bGet.error || ""),
    JSON.stringify(bGet).slice(0, 200),
  );
  const bAp = await callFn(pageB, "/src/lib/confirm.ts", "approveProposal", { id: save.id });
  record("idor-approve", !bAp.ok && /not found/i.test(bAp.error || ""), JSON.stringify(bAp).slice(0, 200));
  const bDn = await callFn(pageB, "/src/lib/confirm.ts", "denyProposal", { id: denyProp?.id });
  record("idor-deny", !bDn.ok && /not found/i.test(bDn.error || ""), JSON.stringify(bDn).slice(0, 200));
  await pageB.goto(`${BASE}/app/approvals/${save.id}`, { waitUntil: "networkidle" });
  record(
    "idor-page",
    (await pageB.getByRole("heading", { name: "Not found" }).count()) > 0 ||
      (await pageB.getByText(/not found/i).count()) > 0,
    await pageB.locator("h1").innerText().catch(() => ""),
  );
  const bMem = await callFn(pageB, "/src/lib/memory.ts", "listMemories");
  record(
    "idor-no-foreign-memory",
    (bMem.result ?? []).every((m) => m.title !== "Save tea preference"),
    JSON.stringify(bMem.result ?? []).slice(0, 200),
  );
  await contextB.close();

  restoreComplete();
  restored = true;
  utimesSync(COMPLETE, new Date(), new Date());
  await sleep(800);

  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  record("goals-regression", await page.getByRole("heading", { name: "Working toward" }).isVisible());
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("memory-regression", await page.getByRole("heading", { name: "What lasts" }).isVisible());
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("settings-regression", await page.getByRole("heading", { name: "Permissions" }).isVisible());
  record(
    "settings-no-approve",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0,
  );
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  record("chat-regression", await page.getByRole("heading", { name: "Conversations" }).isVisible());

  await signOut(page);
  await page.goto(`${BASE}/app/approvals/${save.id}`, { waitUntil: "networkidle" });
  record("signout-gate", /\/login/.test(page.url()), page.url());

  await page.screenshot({ path: "/workspace/screenshots/step12-confirm.png", fullPage: true });

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app/approvals/${delProp.id}`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: "Delete kettle note" }).waitFor({ timeout: 15000 });
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
  );
  record("mobile-no-overflow", !overflow, JSON.stringify({ overflow }));
  await page.screenshot({ path: "/workspace/screenshots/step12-confirm-mobile.png", fullPage: true });

  const serious = consoleErrors.filter(
    (e) => !/Download the React DevTools/i.test(e) && !/not found/i.test(e),
  );
  record("console-errors", serious.length === 0, serious.join(" | ").slice(0, 300));
} catch (err) {
  record("fatal", false, err && err.stack ? err.stack : String(err));
} finally {
  if (!restored) {
    restoreComplete();
    restored = true;
  }
  await browser.close();
}

const ok = results.filter((r) => r.ok).length;
const total = results.length;
writeFileSync(
  "/workspace/screenshots/verify-step12.json",
  JSON.stringify({ emailA, emailB, ok, total, results }, null, 2),
);
console.log(`\n${ok}/${total} passed`);
process.exit(ok === total ? 0 : 1);
