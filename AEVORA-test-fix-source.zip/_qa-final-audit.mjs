import { chromium } from "playwright";

const BASE = "http://127.0.0.1:8080";
const results = [];
const stamp = Date.now();
const email = `ibrahim.final.${stamp}@example.com`;
const emailB = `ibrahim.finalb.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const ROUTES = [
  "/app",
  "/app/chat",
  "/app/memory",
  "/app/goals",
  "/app/reminders",
  "/app/calendar",
  "/app/mail",
  "/app/create",
  "/app/activity",
  "/app/settings",
];

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 200) : ""}`);
}

async function gotoStable(page, path) {
  let lastErr = null;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    try {
      await page.goto(`${BASE}${path}`, { waitUntil: "domcontentloaded", timeout: 20000 });
      return;
    } catch (err) {
      lastErr = err;
      await page.waitForTimeout(400);
    }
  }
  throw lastErr ?? new Error(`goto failed ${path}`);
}

async function callFn(page, modulePath, name, data) {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      await page.waitForLoadState("domcontentloaded");
      return await page.evaluate(
        async ({ modulePath, name, data }) => {
          const mod = await import(modulePath);
          try {
            const result = data === undefined ? await mod[name]() : await mod[name]({ data });
            return { ok: true, result };
          } catch (err) {
            return { ok: false, error: err && err.message ? err.message : String(err) };
          }
        },
        { modulePath, name, data },
      );
    } catch (err) {
      if (attempt === 2) throw err;
      await page.waitForTimeout(400);
    }
  }
  throw new Error("callFn exhausted");
}

async function fillLogin(page, { name, email, password, mode }) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await gotoStable(page, "/login");
  await page.locator("#auth-email").waitFor({ timeout: 15000 });
  if (mode === "signup") {
    const create = page.getByRole("button", { name: /Create an account/i });
    if (await create.isVisible().catch(() => false)) await create.click();
    await page.locator("#auth-name").waitFor({ timeout: 15000 });
    if (name) await page.locator("#auth-name").fill(name);
  } else {
    const have = page.getByRole("button", { name: /Have an account/i });
    if (await have.isVisible().catch(() => false)) await have.click();
  }
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
}

async function signOut(page) {
  await gotoStable(page, "/app");
  const btn = page.getByRole("button", { name: "Sign out" });
  await btn.waitFor({ timeout: 15000 });
  await btn.click();
  await page.waitForURL(/\/login|\/$/, { timeout: 15000 });
}

async function main() {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  const pageErrors = [];
  const consoleErrors = [];
  page.on("pageerror", (err) => pageErrors.push(String(err)));
  page.on("console", (msg) => {
    if (msg.type() === "error") consoleErrors.push(msg.text());
  });

  try {
    await gotoStable(page, "/");
    const land = await page.locator("body").innerText();
    record("landing-renders", /Aegis/i.test(land) && /private steward/i.test(land), land.slice(0, 80));
    record("landing-no-overflow", !(await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1)));

    await gotoStable(page, "/app");
    await page.waitForURL(/\/login/, { timeout: 15000 }).catch(() => {});
    record("signed-out-app-redirect", /login/.test(page.url()), page.url());

    await fillLogin(page, { email, password, mode: "signin" });
    await page.getByRole("button", { name: /Sign in/i }).click();
    await page.waitForTimeout(800);
    const alert = page.locator("[role=alert]").first();
    const unknown = (await alert.count()) ? await alert.innerText() : await page.locator("body").innerText();
    record("unknown-email-fails", /did not match|incorrect|could not|Sign in/i.test(unknown) && !/\/app(?:\/|$)/.test(new URL(page.url()).pathname));

    await fillLogin(page, { name: "Ibrahim Final", email, password, mode: "signup" });
    await page.getByRole("button", { name: "Create account" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    record("signup-succeeds", /\/app/.test(page.url()));

    const profile = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    const userId = profile.result?.userId;
    record("profile-created", profile.ok && Boolean(userId), userId);

    for (const path of ROUTES) {
      const errorsBefore = pageErrors.length;
      await gotoStable(page, path);
      await page.waitForTimeout(400);
      const text = await page.locator("body").innerText();
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
      );
      record(
        `route-${path}`,
        text.trim().length > 20 && !overflow && pageErrors.length === errorsBefore,
        `len=${text.trim().length} overflow=${overflow} url=${page.url()}`,
      );
    }

    await gotoStable(page, "/app/memory");
    const mem = await callFn(page, "/src/lib/memory.ts", "createMemory", {
      title: "Favourite kettle",
      body: "Steel stovetop, never plastic.",
      kind: "preference",
      tags: "home",
      pinned: false,
    });
    record("memory-create", mem.ok && mem.result?.id, JSON.stringify(mem.result || mem.error));
    const listed = await callFn(page, "/src/lib/memory.ts", "listMemories", {});
    record(
      "memory-list-owns",
      listed.ok && (listed.result ?? []).some((row) => row.id === mem.result?.id),
    );

    await gotoStable(page, "/app/goals");
    const goal = await callFn(page, "/src/lib/goals.ts", "createGoal", {
      title: "Ship Aegis",
      description: "Private steward",
      status: "active",
      targetDate: null,
    });
    record("goal-create", goal.ok && goal.result?.id, JSON.stringify(goal.result || goal.error));
    const task = await callFn(page, "/src/lib/goals.ts", "createTask", {
      title: "Write acceptance notes",
      notes: "",
      status: "todo",
      dueDate: null,
      goalId: goal.result?.id,
    });
    record("task-linked", task.ok && task.result?.goalId === goal.result?.id, JSON.stringify(task.result || task.error));

    await gotoStable(page, "/app/reminders");
    const when = new Date(Date.now() + 3600000);
    const rem = await callFn(page, "/src/lib/reminders.ts", "createReminder", {
      title: "Stand up",
      body: "Walk for two minutes",
      localDate: when.toISOString().slice(0, 10),
      localTime: `${String(when.getUTCHours()).padStart(2, "0")}:${String(when.getUTCMinutes()).padStart(2, "0")}`,
      recurrence: "once",
    });
    record("reminder-create", rem.ok && rem.result?.id, JSON.stringify(rem.result || rem.error).slice(0, 180));
    const rems = await callFn(page, "/src/lib/reminders.ts", "listReminders");
    record(
      "reminder-list",
      rems.ok && (rems.result ?? []).some((row) => row.id === rem.result?.id),
      JSON.stringify(rems.result || rems.error).slice(0, 120),
    );

    const cal = await callFn(page, "/src/lib/calendar.ts", "getCalendarStatus");
    record(
      "calendar-honest",
      cal.ok && cal.result?.connected === false,
      JSON.stringify(cal.result || cal.error).slice(0, 180),
    );
    await gotoStable(page, "/app/calendar");
    const calPage = await page.locator("body").innerText();
    record("calendar-page-no-invented-events", !/Meeting with|Lunch with Bob/i.test(calPage), calPage.slice(0, 120));

    const mail = await callFn(page, "/src/lib/mail.ts", "getMailStatus");
    record(
      "mail-honest",
      mail.ok && mail.result?.connected === false,
      JSON.stringify(mail.result || mail.error).slice(0, 180),
    );
    await gotoStable(page, "/app/mail");
    const mailPage = await page.locator("body").innerText();
    record("mail-page-draft-not-sent", !/Email sent to/i.test(mailPage));

    const pulse = await callFn(page, "/src/lib/pulse.ts", "getPulse", {});
    record(
      "pulse-real-data",
      pulse.ok && Array.isArray(pulse.result?.suggestions),
      JSON.stringify(pulse.result || pulse.error).slice(0, 180),
    );

    await gotoStable(page, "/app/settings");
    await page.getByRole("heading", { name: /Profile/i }).waitFor({ timeout: 15000 });
    await page.locator("#displayName, input[name=displayName], input").first().fill("Ibrahim Keep");
    const save = page.getByRole("button", { name: /Save/i }).first();
    if (await save.count()) await save.click();
    await page.waitForTimeout(600);
    const savedProfile = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record(
      "settings-persist",
      savedProfile.ok && /Ibrahim/i.test(savedProfile.result?.displayName ?? ""),
      savedProfile.result?.displayName,
    );

    const chatStatus = await callFn(page, "/src/lib/ai/chat.ts", "getAiStatus");
    record(
      "ai-status-honest",
      chatStatus.ok && typeof chatStatus.result?.available === "boolean",
      JSON.stringify(chatStatus.result || chatStatus.error),
    );

    await page.setViewportSize({ width: 390, height: 844 });
    await gotoStable(page, "/app");
    const mobileOverflow = await page.evaluate(
      () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
    );
    record("mobile-dashboard-no-overflow", !mobileOverflow);
    await gotoStable(page, "/app/chat");
    const mobileChatOverflow = await page.evaluate(
      () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
    );
    record("mobile-chat-no-overflow", !mobileChatOverflow);
    await page.setViewportSize({ width: 1280, height: 800 });

    const unreg = await callFn(page, "/src/lib/tools/registry.ts", "listToolCatalog", {});
    record("catalog-loads", unreg.ok && Array.isArray(unreg.result));

    const catalog = unreg;
    const ids = (catalog.result ?? []).map((t) => t.id);
    record(
      "catalog-no-external-shell",
      catalog.ok && !ids.some((id) => id.startsWith("external.") || id.includes("shell") || id.includes("http")),
      ids.join(","),
    );

    await page.reload({ waitUntil: "domcontentloaded" });
    const afterRefresh = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("refresh-same-account", afterRefresh.ok && afterRefresh.result?.userId === userId);

    await signOut(page);
    await gotoStable(page, "/app");
    await page.waitForURL(/\/login/, { timeout: 15000 });
    record("sign-out-blocks-app", /login/.test(page.url()), page.url());
    const signedOutMem = await callFn(page, "/src/lib/memory.ts", "listMemories", {});
    record("sign-out-api", !signedOutMem.ok && /unauthor/i.test(String(signedOutMem.error)), signedOutMem.error);

    await fillLogin(page, { name: "Ibrahim B", email: emailB, password, mode: "signup" });
    await page.getByRole("button", { name: "Create account" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    const profileB = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("user-b-isolated-id", profileB.ok && profileB.result?.userId && profileB.result.userId !== userId);
    const memB = await callFn(page, "/src/lib/memory.ts", "listMemories", {});
    record(
      "user-b-cannot-see-a-memory",
      memB.ok && !(memB.result ?? []).some((row) => row.id === mem.result?.id),
    );
    const remB = await callFn(page, "/src/lib/reminders.ts", "listReminders");
    record(
      "user-b-cannot-see-a-reminders",
      remB.ok && !(remB.result ?? []).some((row) => row.id === rem.result?.id),
    );
    const goalsB = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
    record(
      "user-b-cannot-see-a-goals",
      goalsB.ok && !(goalsB.result?.goals ?? []).some((row) => row.id === goal.result?.id),
    );

    const severeConsole = consoleErrors.filter(
      (t) =>
        !/favicon|Download the React DevTools|net::ERR_BLOCKED|401 \(UNAUTHORIZED\)/i.test(t),
    );
    record("no-page-errors", pageErrors.length === 0, pageErrors.join(" | "));
    record("console-clean-enough", severeConsole.length === 0, severeConsole.slice(0, 3).join(" | "));
  } catch (err) {
    record("audit-crash", false, err instanceof Error ? err.stack : String(err));
  } finally {
    const passed = results.filter((r) => r.ok).length;
    console.log(`\n${passed}/${results.length} passed`);
    await browser.close();
    if (passed !== results.length) process.exitCode = 1;
  }
}

main();
