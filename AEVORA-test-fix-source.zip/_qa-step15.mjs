import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step15.${stamp}@example.com`;
const emailB = `ibrahim.step15b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const last = history[history.length - 1]?.content ?? "";
  const idMatch = last.match(/#(\\d+)/);
  const n = idMatch ? Number(idMatch[1]) : 0;
  if (/auto-run|change my permissions/i.test(last)) {
    return {
      ok: true,
      text: [
        "I cannot change permissions.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "permission.update", title: "Turn on auto-run", summary: "Enable automatic execution" }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/email the bank|external\\.email/i.test(last)) {
    return {
      ok: true,
      text: [
        "I would have to send mail.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "external.email", title: "Email the bank", summary: "Send a payment email." }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/run a shell|shell\\.exec/i.test(last)) {
    return {
      ok: true,
      text: [
        "I would run a command.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "shell.exec", title: "Run a command", summary: "Unregistered tool." }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/valid_tool_name_typo|memory\\.sav\\b/i.test(last)) {
    return {
      ok: true,
      text: [
        "That id is not in the catalog.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{ tool_id: "memory.sav", title: "Typo save", summary: "Typoed tool id." }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/broken payload/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can delete that memory. It will not be removed until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "memory.delete",
          title: "Delete kettle note",
          summary: "Remove the kettle memory.",
          payload: { id: "not-a-number" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/search my memories/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can search your memory. It will not run until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "memory.search",
          title: "Search tea memories",
          summary: "Look for tea in your keep.",
          payload: { query: "tea" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/create a task to buy tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can add that task. It will not be created until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "task.create",
          title: "Buy loose-leaf tea",
          summary: "Add a task to buy tea.",
          payload: { title: "Buy loose-leaf tea", status: "todo" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/delete memory/i.test(last) && n > 0) {
    return {
      ok: true,
      text: [
        "I can delete that memory. It will not be removed until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "memory.delete",
          title: "Delete spare note",
          summary: "Remove the spare memory.",
          payload: { id: n },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  if (/remember|black tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remember that you drink tea. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([{
          tool_id: "memory.save",
          title: "Save tea preference",
          summary: "Remember that you drink black tea every morning.",
          payload: { kind: "preference", body: "payload-secret-orchid-77" },
        }]),
        ">>>",
      ].join("\\n"),
    };
  }
  return { ok: true, text: "Aegis-step15-fixture: a quiet reply with no proposed action." };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Create an account" }).click();
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

function leaky(value) {
  const s = typeof value === "string" ? value : JSON.stringify(value ?? "");
  return /payload_json|payload-secret-orchid-77/i.test(s);
}

function unauth(res) {
  return !res.ok && /unauthorized/i.test(res.error || "");
}

let restored = false;
const consoleErrors = [];
installStub();

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage();
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});
page.on("pageerror", (err) => consoleErrors.push(String(err)));

try {
  // --- Auth gates ---
  for (const path of [
    "/app",
    "/app/settings",
    "/app/memory",
    "/app/goals",
    "/app/activity",
    "/app/chat",
    "/app/approvals/1",
  ]) {
    await page.goto(`${BASE}${path}`, { waitUntil: "networkidle" });
    record(`signed-out-${path.replace(/\W+/g, "-")}`, /\/login/.test(page.url()), page.url());
  }

  const unauthCalls = [
    ["/src/lib/tools/registry.ts", "listToolCatalog", {}],
    ["/src/lib/confirm.ts", "approveProposal", { id: 1 }],
    ["/src/lib/confirm.ts", "denyProposal", { id: 1 }],
    ["/src/lib/audit.ts", "listActivity", { level: "all" }],
    ["/src/lib/memory.ts", "listMemories", undefined],
    ["/src/lib/goals.ts", "listGoalsPage", undefined],
    ["/src/lib/chat.ts", "listConversations", undefined],
    ["/src/lib/dashboard.ts", "getDashboard", undefined],
    ["/src/lib/permissions.ts", "getPermissionSettings", undefined],
    ["/src/lib/profile.ts", "getOrCreateProfile", undefined],
    ["/src/lib/chat.ts", "sendChatMessage", { content: "hi" }],
  ];
  for (const [mod, name, data] of unauthCalls) {
    const res = await callFn(page, mod, name, data);
    record(`unauth-${name}`, unauth(res), res.error || "");
  }

  await signup(page, { name: "Ibrahim", email: emailA });
  record("signup-lands-app", /\/app/.test(page.url()), page.url());

  // --- Profile ---
  const profile = await callFn(page, "/src/lib/profile.ts", "updateProfile", {
    displayName: "Ibrahim Keep",
    bio: "Drinks tea.",
    timezone: "Europe/London",
    theme: "dark",
  });
  record("profile-write", profile.ok && profile.result?.displayName === "Ibrahim Keep");
  const profile2 = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
  record("profile-persist", profile2.ok && profile2.result?.timezone === "Europe/London");
  const spoofProfile = await callFn(page, "/src/lib/profile.ts", "updateProfile", {
    displayName: "Ibrahim Keep",
    bio: "Drinks tea.",
    timezone: "Europe/London",
    theme: "dark",
    userId: "attacker",
  });
  record(
    "profile-ignores-client-userid",
    spoofProfile.ok &&
      spoofProfile.result?.displayName === "Ibrahim Keep" &&
      spoofProfile.result?.userId === profile2.result?.userId,
  );

  // --- Permissions: auto-run frozen, extra fields ignored ---
  const perms = await callFn(page, "/src/lib/permissions.ts", "getPermissionSettings");
  record(
    "permissions-auto-run-off",
    perms.ok && perms.result?.autoRunSafe === false && perms.result?.autoRunReview === false,
  );
  const permsPush = await callFn(page, "/src/lib/permissions.ts", "updatePermissionSettings", {
    confirmFloor: "review",
    autoRunSafe: true,
    autoRunReview: true,
    userId: "attacker",
  });
  record(
    "permissions-client-cannot-enable-autorun",
    permsPush.ok &&
      permsPush.result?.confirmFloor === "review" &&
      permsPush.result?.autoRunSafe === false &&
      permsPush.result?.autoRunReview === false,
  );
  await callFn(page, "/src/lib/permissions.ts", "updatePermissionSettings", { confirmFloor: "safe" });

  // --- Memory lifecycle ---
  const emptyMem = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "",
    body: "blank",
    tags: "",
    pinned: false,
  });
  record("memory-empty-title-rejected", !emptyMem.ok);
  const mem = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "Kettle note",
    body: "The kettle is in the cupboard.",
    tags: "kitchen",
    pinned: true,
  });
  record("memory-create", mem.ok && mem.result?.id > 0);
  const kettleId = mem.result?.id;
  const spare = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "fact",
    title: "Spare note",
    body: "Disposable spare for delete-via-registry.",
    tags: "",
    pinned: false,
  });
  const spareId = spare.result?.id;
  const listed = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "memory-list-own",
    (listed.result ?? []).some((m) => m.id === kettleId && m.title === "Kettle note"),
  );
  const updated = await callFn(page, "/src/lib/memory.ts", "updateMemory", {
    id: kettleId,
    kind: "fact",
    title: "Kettle note",
    body: "The kettle is in the cupboard, still.",
    tags: "kitchen",
    pinned: true,
  });
  record("memory-update", updated.ok && /still/.test(updated.result?.body ?? ""));
  const retrieved = await callFn(page, "/src/lib/memory.ts", "retrieveMemoriesForChat", { query: "kettle" });
  record(
    "memory-retrieve",
    (retrieved.result ?? []).some((m) => m.id === kettleId),
  );
  const badMem = await callFn(page, "/src/lib/memory.ts", "getMemory", { id: 999999, userId: "attacker" });
  record("memory-missing-and-userid-ignored", !badMem.ok);

  // --- Goals / tasks ---
  const emptyGoal = await callFn(page, "/src/lib/goals.ts", "createGoal", {
    title: "",
    description: "",
    status: "active",
    targetDate: null,
  });
  record("goal-empty-title-rejected", !emptyGoal.ok);
  const goal = await callFn(page, "/src/lib/goals.ts", "createGoal", {
    title: "Drink better tea",
    description: "Keep a kettle habit.",
    status: "active",
    targetDate: null,
  });
  record("goal-create", goal.ok && goal.result?.id > 0);
  const goalId = goal.result?.id;
  const task = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Buy loose-leaf tea",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId,
  });
  record("task-linked", task.ok && task.result?.goalId === goalId);
  const taskId = task.result?.id;
  const inbox = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Unlinked chore",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: null,
  });
  record("task-unlinked-ok", inbox.ok && inbox.result?.goalId == null);
  const missingGoal = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Ghost link",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: 999999,
  });
  record("task-nonexistent-goal-rejected", !missingGoal.ok);
  const done = await callFn(page, "/src/lib/goals.ts", "updateTask", {
    id: inbox.result?.id,
    title: "Unlinked chore",
    notes: "",
    status: "done",
    dueDate: null,
    goalId: null,
  });
  record("task-status-change", done.ok && done.result?.status === "done");

  // --- Catalog ---
  const catalog = await callFn(page, "/src/lib/tools/registry.ts", "listToolCatalog", {});
  const tools = catalog.result ?? [];
  const ids = tools.map((t) => t.id);
  record("catalog-count", catalog.ok && tools.length >= 11, String(tools.length));
  record(
    "catalog-no-external",
    !ids.some(
      (id) =>
        id.startsWith("external.") ||
        id.includes("http") ||
        id.includes("pay") ||
        id.includes("shell"),
    ),
    ids.join(","),
  );
  record("catalog-no-chat-reply", !ids.includes("chat.reply"));
  record(
    "catalog-restricted-listed",
    tools.some((t) => t.id === "permission.update" && t.permissionLevel === "restricted"),
  );
  record(
    "catalog-no-payload-or-handler",
    !leaky(catalog.result) &&
      tools.every((t) => !("handler" in t) && !("payload" in t) && !("userId" in t)),
  );

  const defs = await page.evaluate(async () => {
    const mod = await import("/src/lib/tools/definitions.ts");
    return {
      save: mod.canRunTool("memory.save"),
      del: mod.canRunTool("memory.delete"),
      restricted: mod.canRunTool("permission.update"),
      unknown: mod.canRunTool("shell.exec"),
      typo: mod.canRunTool("memory.sav"),
      external: mod.canRunTool("external.email"),
      execute: typeof mod.executeRegisteredTool,
    };
  });
  record(
    "client-cannot-execute",
    defs.save === true &&
      defs.del === true &&
      defs.restricted === false &&
      defs.unknown === false &&
      defs.typo === false &&
      defs.external === false &&
      defs.execute === "undefined",
    JSON.stringify(defs),
  );

  installStub();
  utimesSync(COMPLETE, new Date(), new Date());
  await sleep(800);

  // --- Tool registry: reject ---
  const unknown = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please run a shell.exec command.",
  });
  record(
    "unregistered-rejected",
    (unknown.result?.proposals ?? []).length === 0 &&
      (unknown.result?.rejected ?? []).some((r) => r.toolId === "shell.exec"),
  );
  const typo = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please memory.sav valid_tool_name_typo.",
  });
  record(
    "typo-rejected",
    (typo.result?.proposals ?? []).length === 0 &&
      (typo.result?.rejected ?? []).some((r) => r.toolId === "memory.sav"),
  );
  const external = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please email the bank.",
  });
  record(
    "external-rejected",
    (external.result?.proposals ?? []).length === 0 &&
      (external.result?.rejected ?? []).some((r) => r.toolId === "external.email"),
  );
  const restricted = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Please change my permissions and turn on auto-run.",
  });
  record(
    "restricted-rejected",
    (restricted.result?.proposals ?? []).length === 0 &&
      (restricted.result?.rejected ?? []).some((r) => r.toolId === "permission.update"),
  );
  const bogusApprove = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: 999999 });
  record("missing-proposal-not-found", !bogusApprove.ok && /not found/i.test(bogusApprove.error || ""));
  const badId = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: -1 });
  record("malformed-approve-id-rejected", !badId.ok);

  // --- Propose → deny (no side effect) ---
  const sent = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Remember I drink black tea.",
  });
  const save = (sent.result?.proposals ?? []).find((p) => p.toolId === "memory.save");
  record("proposal-pending", Boolean(save && save.status === "pending"));
  const denied = await callFn(page, "/src/lib/confirm.ts", "denyProposal", { id: save.id });
  record("deny-still-works", denied.ok && denied.result?.status === "denied");
  const memAfterDeny = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "deny-no-side-effect",
    (memAfterDeny.result ?? []).every((m) => m.body !== "payload-secret-orchid-77"),
  );

  // --- Propose → approve → execute → replay blocked ---
  const sent2 = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Remember I drink black tea.",
  });
  const save2 = (sent2.result?.proposals ?? []).find((p) => p.toolId === "memory.save");
  const approved = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: save2.id });
  record(
    "e2e-review-executes",
    approved.ok && approved.result?.status === "executed",
    JSON.stringify(approved.result ?? {}).slice(0, 200),
  );
  const replay = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: save2.id });
  record("replay-blocked", !replay.ok && /no longer pending/i.test(replay.error || ""));
  const memAfterSave = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "e2e-memory-written-once",
    (memAfterSave.result ?? []).filter((m) => m.body === "payload-secret-orchid-77").length === 1,
  );

  const search = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Search my memories for tea.",
  });
  const searchP = (search.result?.proposals ?? []).find((p) => p.toolId === "memory.search");
  const searchOk = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: searchP.id });
  record("e2e-safe-executes", searchOk.ok && searchOk.result?.status === "executed");

  const taskMsg = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Create a task to buy tea.",
  });
  const taskP = (taskMsg.result?.proposals ?? []).find((p) => p.toolId === "task.create");
  const taskOk = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: taskP.id });
  record("e2e-task-executes", taskOk.ok && taskOk.result?.status === "executed");

  const delMsg = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: `Delete memory #${spareId}`,
  });
  const delP = (delMsg.result?.proposals ?? []).find((p) => p.toolId === "memory.delete");
  record("approval-proposal-pending", Boolean(delP && delP.status === "pending"));
  const delOk = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: delP.id });
  record("e2e-approval-executes", delOk.ok && delOk.result?.status === "executed");
  const memAfterDel = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "e2e-delete-ran-once",
    (memAfterDel.result ?? []).every((m) => m.id !== spareId) &&
      (memAfterDel.result ?? []).some((m) => m.id === kettleId),
  );

  const broken = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    content: "Delete the kettle with a broken payload.",
  });
  const brokenP = (broken.result?.proposals ?? []).find((p) => p.toolId === "memory.delete");
  const brokenOk = await callFn(page, "/src/lib/confirm.ts", "approveProposal", { id: brokenP.id });
  record("malformed-fails-closed", brokenOk.ok && brokenOk.result?.status === "failed");
  const kettleStill = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record(
    "malformed-did-not-delete",
    (kettleStill.result ?? []).some((m) => m.id === kettleId),
  );

  // --- Activity ---
  const allAct = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  const actions = (allAct.result?.items ?? []).map((e) => e.action);
  record(
    "activity-pipeline-events",
    actions.includes("proposal.executed") &&
      actions.includes("proposal.approved") &&
      actions.includes("proposal.denied") &&
      actions.includes("proposal.rejected") &&
      actions.includes("proposal.failed") &&
      actions.includes("proposal.created"),
    actions.slice(0, 14).join(","),
  );
  record("activity-no-secret", !leaky(allAct.result));
  record("activity-no-user-id-field", JSON.stringify(allAct.result ?? {}).includes("userId") === false);

  const safeAct = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "safe" });
  record(
    "filter-safe",
    (safeAct.result?.items ?? []).length > 0 &&
      (safeAct.result?.items ?? []).every((e) => e.permissionLevel === "safe"),
  );
  const reviewAct = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "review" });
  record(
    "filter-review",
    (reviewAct.result?.items ?? []).length > 0 &&
      (reviewAct.result?.items ?? []).every((e) => e.permissionLevel === "review"),
  );
  const approvalAct = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "approval" });
  record(
    "filter-approval",
    (approvalAct.result?.items ?? []).length > 0 &&
      (approvalAct.result?.items ?? []).every((e) => e.permissionLevel === "approval"),
  );
  const restrictedAct = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "restricted" });
  record(
    "filter-restricted",
    (restrictedAct.result?.items ?? []).length > 0 &&
      (restrictedAct.result?.items ?? []).every((e) => e.permissionLevel === "restricted"),
  );

  restoreComplete();
  restored = true;
  utimesSync(COMPLETE, new Date(), new Date());
  await sleep(800);

  // --- Chat persistence + dashboard ---
  const convos = await callFn(page, "/src/lib/chat.ts", "listConversations");
  record("chat-persists", (convos.result ?? []).length > 0);
  const dash = await callFn(page, "/src/lib/dashboard.ts", "getDashboard");
  record("dashboard-composes", dash.ok && typeof dash.result?.greetingName === "string");
  record("dashboard-no-approve", JSON.stringify(dash.result ?? "").includes("Approve") === false);

  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("ui-dashboard", await page.getByRole("heading", { name: /Hello/i }).isVisible());
  record("ui-dashboard-no-approve", (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0);
  await page.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  record("ui-activity", await page.getByRole("heading", { name: "The record" }).isVisible());
  record(
    "ui-activity-no-approve-deny",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /^Deny$/ }).count()) === 0,
  );
  await page.getByRole("tab", { name: "Safe" }).click();
  await page.getByRole("tab", { name: "All" }).click();
  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  record("ui-goals", await page.getByRole("heading", { name: "Working toward" }).isVisible());
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("ui-memory", await page.getByRole("heading", { name: "What lasts" }).isVisible());
  record("ui-memory-kettle", await page.getByText("Kettle note").isVisible());
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("ui-settings", await page.getByRole("heading", { name: "Permissions" }).isVisible());
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  record("ui-chat", await page.getByRole("heading", { name: "Conversations" }).isVisible());

  // --- Refresh persistence ---
  await page.reload({ waitUntil: "networkidle" });
  const memRefresh = await callFn(page, "/src/lib/memory.ts", "listMemories");
  const goalsRefresh = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
  const profileRefresh = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
  const actRefresh = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  record("refresh-memory", (memRefresh.result ?? []).some((m) => m.id === kettleId));
  record("refresh-goal", (goalsRefresh.result?.goals ?? []).some((g) => g.id === goalId));
  record("refresh-task", (goalsRefresh.result?.tasks ?? []).some((t) => t.id === taskId && t.goalId === goalId));
  record("refresh-profile", profileRefresh.result?.displayName === "Ibrahim Keep");
  record("refresh-activity", (actRefresh.result?.items ?? []).length > 0);

  // --- IDOR (user B) ---
  const contextB = await browser.newContext();
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other", email: emailB });
  const bMem = await callFn(pageB, "/src/lib/memory.ts", "listMemories");
  record("idor-memory-list", (bMem.result ?? []).every((m) => m.id !== kettleId));
  const bGet = await callFn(pageB, "/src/lib/memory.ts", "getMemory", { id: kettleId });
  record("idor-memory-get", !bGet.ok);
  const bUpd = await callFn(pageB, "/src/lib/memory.ts", "updateMemory", {
    id: kettleId,
    kind: "fact",
    title: "stolen",
    body: "stolen",
    tags: "",
    pinned: false,
  });
  record("idor-memory-update", !bUpd.ok);
  const bGoals = await callFn(pageB, "/src/lib/goals.ts", "listGoalsPage");
  record("idor-goals-list", (bGoals.result?.goals ?? []).every((g) => g.id !== goalId));
  const bGoalGet = await callFn(pageB, "/src/lib/goals.ts", "getGoal", { id: goalId });
  record("idor-goal-get", !bGoalGet.ok);
  const bTaskGet = await callFn(pageB, "/src/lib/goals.ts", "getTask", { id: taskId });
  record("idor-task-get", !bTaskGet.ok);
  const bLink = await callFn(pageB, "/src/lib/goals.ts", "createTask", {
    title: "Steal link",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId,
  });
  record("idor-link-foreign-goal", !bLink.ok);
  const bApprove = await callFn(pageB, "/src/lib/confirm.ts", "approveProposal", { id: save2.id });
  record("idor-approve", !bApprove.ok && /not found/i.test(bApprove.error || ""));
  const bDeny = await callFn(pageB, "/src/lib/confirm.ts", "denyProposal", { id: save2.id });
  record("idor-deny", !bDeny.ok);
  const bAct = await callFn(pageB, "/src/lib/audit.ts", "listActivity", { level: "all" });
  record("idor-activity", !JSON.stringify(bAct.result ?? {}).includes("Kettle note"));
  const bChat = await callFn(pageB, "/src/lib/chat.ts", "listConversations");
  record(
    "idor-chat",
    !(bChat.result ?? []).some((c) => /black tea|kettle/i.test(c.title ?? "")),
  );
  const bDash = await callFn(pageB, "/src/lib/dashboard.ts", "getDashboard");
  record("idor-dashboard", !JSON.stringify(bDash.result ?? {}).includes("Kettle note"));
  const bPerms = await callFn(pageB, "/src/lib/permissions.ts", "getPermissionSettings");
  record("idor-permissions-own-defaults", bPerms.ok && bPerms.result?.confirmFloor === "safe");
  const bProf = await callFn(pageB, "/src/lib/profile.ts", "getOrCreateProfile");
  record("idor-profile", bProf.ok && bProf.result?.displayName !== "Ibrahim Keep");
  await contextB.close();

  // --- Sign out / sign in persistence ---
  await signOut(page);
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("signout-gate", /\/login/.test(page.url()), page.url());
  const afterOut = await callFn(page, "/src/lib/memory.ts", "listMemories");
  record("signout-api", unauth(afterOut), afterOut.error || "");

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  const memIn = await callFn(page, "/src/lib/memory.ts", "listMemories");
  const goalsIn = await callFn(page, "/src/lib/goals.ts", "listGoalsPage");
  const profIn = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
  const actIn = await callFn(page, "/src/lib/audit.ts", "listActivity", { level: "all" });
  const chatIn = await callFn(page, "/src/lib/chat.ts", "listConversations");
  record("signin-memory", (memIn.result ?? []).some((m) => m.id === kettleId));
  record("signin-goal-task", (goalsIn.result?.tasks ?? []).some((t) => t.id === taskId && t.goalId === goalId));
  record("signin-profile", profIn.result?.displayName === "Ibrahim Keep");
  record("signin-activity", (actIn.result?.items ?? []).some((e) => e.action === "proposal.executed"));
  record("signin-chat", (chatIn.result ?? []).length > 0);

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
  );
  record("mobile-no-overflow", !overflow);
  await page.screenshot({ path: "/workspace/screenshots/step15-dashboard-mobile.png", fullPage: true });
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(`${BASE}/app/activity`, { waitUntil: "networkidle" });
  await page.screenshot({ path: "/workspace/screenshots/step15-activity.png", fullPage: true });

  const serious = consoleErrors.filter(
    (e) => !/Download the React DevTools/i.test(e) && !/not found/i.test(e),
  );
  record("console-errors", serious.length === 0, serious.join(" | ").slice(0, 300));
} catch (err) {
  record("fatal", false, err && err.stack ? err.stack : String(err));
} finally {
  if (!restored) {
    restoreComplete();
    restored = true;
  }
  await browser.close();
}

const ok = results.filter((r) => r.ok).length;
const total = results.length;
writeFileSync(
  "/workspace/screenshots/verify-step15.json",
  JSON.stringify({ emailA, emailB, ok, total, results }, null, 2),
);
console.log(`\\n${ok}/${total} passed`);
process.exit(ok === total ? 0 : 1);
