import { chromium } from "playwright";

const BASE = "http://127.0.0.1:8080";
const results = [];
const stamp = Date.now();
const email = `ibrahim.auth.${stamp}@example.com`;
const emailB = `ibrahim.authb.${stamp}@example.com`;
const password = "correct-horse-battery-1";
const wrong = "definitely-not-the-password-9";

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

async function callFn(page, modulePath, name, data) {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      await page.waitForLoadState("domcontentloaded");
      return await page.evaluate(
        async ({ modulePath, name, data }) => {
          const mod = await import(modulePath);
          try {
            const result =
              data === undefined ? await mod[name]() : await mod[name]({ data });
            return { ok: true, result };
          } catch (err) {
            return {
              ok: false,
              error: err && err.message ? err.message : String(err),
            };
          }
        },
        { modulePath, name, data },
      );
    } catch (err) {
      if (attempt === 2) throw err;
      await page.waitForTimeout(400);
    }
  }
  throw new Error("callFn exhausted");
}

async function fillLogin(page, { name, email, password, mode }) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  if (mode === "signup") {
    const create = page.getByRole("button", { name: /Create an account/i });
    if (await create.isVisible().catch(() => false)) await create.click();
    await page.locator("#auth-name").waitFor({ timeout: 15000 });
    if (name) await page.locator("#auth-name").fill(name);
  } else {
    const have = page.getByRole("button", { name: /Have an account/i });
    if (await have.isVisible().catch(() => false)) await have.click();
  }
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

async function main() {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  const pageErrors = [];
  page.on("pageerror", (err) => pageErrors.push(String(err)));

  try {
    await page.goto(`${BASE}/app`, { waitUntil: "domcontentloaded" });
    await page.waitForURL(/\/login/, { timeout: 12000 }).catch(() => {});
    await page.waitForSelector("h1, #auth-email, [role=alert]", { timeout: 12000 }).catch(() => {});
    const signedOut =
      /login/.test(page.url()) ||
      (await page.getByRole("heading", { name: /Sign in/i }).count()) > 0 ||
      (await page.getByRole("button", { name: /^Sign in$/i }).count()) > 0;
    record("signed-out-app-redirect", signedOut, page.url());

    const keep = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("signed-out-profile-api", !keep.ok && /unauthorized/i.test(keep.error || ""), keep.error);

    await fillLogin(page, { email: "nobody-auth-qa@example.com", password: wrong, mode: "signin" });
    await page.getByRole("button", { name: "Sign in" }).click();
    await page.locator("[role=alert]").waitFor({ timeout: 15000 });
    const unknownText = (await page.locator("[role=alert]").textContent()) || "";
    record(
      "unknown-email-fails",
      /email or password/i.test(unknownText) && !/\/app/.test(page.url()),
      unknownText,
    );

    await fillLogin(page, { name: "Ibrahim Auth", email, password, mode: "signup" });
    await page.getByRole("button", { name: "Create account" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    await page.waitForLoadState("networkidle");
    record("signup-succeeds", /\/app/.test(page.url()));

    const profile = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    const userId = profile.result?.userId;
    record("profile-created", profile.ok && Boolean(userId), JSON.stringify(profile.result || profile.error));

    const forged = await callFn(page, "/src/lib/profile.ts", "updateProfile", {
      userId: "someone-else",
      displayName: "Hacked",
      bio: "",
      timezone: "UTC",
      theme: "system",
    });
    record(
      "client-userid-ignored",
      forged.ok && forged.result?.userId === userId && forged.result?.displayName === "Hacked",
      JSON.stringify(forged.result || forged.error),
    );

    await page.reload({ waitUntil: "networkidle" });
    record("refresh-keeps-session", /\/app/.test(page.url()));
    const afterReload = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("refresh-same-account", afterReload.ok && afterReload.result?.userId === userId);

    await signOut(page);
    await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
    await page.waitForSelector("h1, #auth-email", { timeout: 12000 }).catch(() => {});
    const blocked =
      /login/.test(page.url()) ||
      (await page.getByRole("heading", { name: /Sign in/i }).count()) > 0 ||
      !(await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile")).ok;
    record("sign-out-blocks-app", blocked, page.url());

    await fillLogin(page, { email, password: wrong, mode: "signin" });
    await page.getByRole("button", { name: "Sign in" }).click();
    await page.locator("[role=alert]").waitFor({ timeout: 15000 });
    const badText = (await page.locator("[role=alert]").textContent()) || "";
    record("wrong-password-fails", /email or password/i.test(badText) && !/\/app/.test(page.url()), badText);

    await fillLogin(page, { email, password, mode: "signin" });
    await page.getByRole("button", { name: "Sign in" }).click();
    await page.waitForURL(/\/app/, { timeout: 20000 });
    const back = await callFn(page, "/src/lib/profile.ts", "getOrCreateProfile");
    record("correct-credentials-restore", back.ok && back.result?.userId === userId, JSON.stringify(back.result || back.error));

    const ctxB = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const pageB = await ctxB.newPage();
    await fillLogin(pageB, { name: "Ibrahim B", email: emailB, password, mode: "signup" });
    await pageB.getByRole("button", { name: "Create account" }).click();
    await pageB.waitForURL(/\/app/, { timeout: 20000 });
    const profileB = await callFn(pageB, "/src/lib/profile.ts", "getOrCreateProfile");
    record("user-b-isolated", profileB.ok && profileB.result?.userId !== userId, JSON.stringify(profileB.result || profileB.error));
    await ctxB.close();

    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 2,
    );
    record("login-mobile-no-overflow", !overflow);
    record("no-page-errors", pageErrors.length === 0, pageErrors.join(" | "));
  } finally {
    await browser.close();
  }

  const failed = results.filter((r) => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} passed`);
  if (failed.length) {
    for (const f of failed) console.log(`  FAIL ${f.name} ${f.extra}`);
    process.exit(1);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
