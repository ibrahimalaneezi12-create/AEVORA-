# AEVORA — project instructions

Authoritative current state: `docs/STATUS.md`.
Product rules: `docs/SPEC.md`.
History: `docs/DEVLOG.md`.
Device checklist: `docs/ACCEPTANCE.md`.

## Current step

Final completion + audit of the implemented product. Do **not** invent a
new numbered roadmap. Original bills / business / learning remain
**NEEDS IBRAHIM**.

Do not treat an older DEVLOG “verified” line as a current checkout pass.

## Product

**AEVORA** — a private personal steward. Chat, memory, goals, permissioned
actions. The model proposes; the app permits.

## Hard rules (in addition to AGENTS.md)

1. Spec first.
2. Auth ON. Do not persist personal data without `authMiddleware`.
3. Do not rewrite auth internals casually. Security hardening now requires `src/lib/auth/preview.ts` to read the preview OAuth secret from the host-managed `GROK_AUTH_CLIENT_SECRET` variable, and `src/lib/auth/server.ts` to warn when it is missing; preserve this behavior unless an equivalent secure configuration is verified.
4. Do not create `src/routes/auth/popup.tsx`.
5. Do not write `.env`. Do not expose `XAI_API_KEY`.
6. xAI only, server-only, user-initiated, capped.
7. No autonomous loops. No unregistered tools. No Restricted execution.
8. Queries scoped to `context.userId`.
9. Do not delete `docs/`.
10. Mark personal/business choices **NEEDS IBRAHIM**.
11. Voice and language are interfaces, not a second brain.
12. Do not silent-save chat or voice transcripts as long-term memory.

## Stack

React 19, TanStack Start, Tailwind v4, Radix, Zustand, Zod, Better Auth,
Neon/PGLite, xAI. Preview on `0.0.0.0:8080` via `npm run dev` and
`/workspace/startup.sh`.
