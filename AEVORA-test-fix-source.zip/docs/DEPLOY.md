# AEVORA — production deployment

Do not paste secrets into chat. Do not put secrets in client code.

Production Google login is one click on the AEVORA origin:

AEVORA → Google → AEVORA `/app`

The Safari preview popup/tap exists only on `*.grok-sandbox.com`.

---

## Required server secrets

Enter these as **server-only** environment variables on the host
(Production). Never prefix them with `VITE_` — that would ship them to
the browser.

| Variable | Required | What it is |
|---|---|---|
| `DATABASE_URL` | yes | Postgres connection string |
| `BETTER_AUTH_URL` | yes | Public HTTPS origin, e.g. `https://your-aegis-host` (no trailing slash) |
| `BETTER_AUTH_SECRET` | yes | Long random secret (≥32 bytes). Rotate if leaked. |
| `GROK_AUTH_ISSUER` | yes | Grok auth broker, normally `https://auth.grok.me` |
| `GROK_AUTH_CLIENT_ID` | yes | Production broker client id (not a Google Cloud client id) |
| `GROK_AUTH_CLIENT_SECRET` | yes | Production broker client secret |
| `XAI_API_KEY` | yes for AI | xAI key for chat, search, TTS. Missing → honest “AI unavailable”. |
| `VITE_AUTH_ENABLED` | yes | Must be `true` (or unset-but-not-`false`). `false` turns auth off. |

Optional:

| Variable | Default | Use |
|---|---|---|
| `XAI_API_BASE_URL` | `https://api.x.ai/v1` | Only if xAI is proxied |
| `GROK_CONNECTORS_URL` | platform | Calendar/Mail for Grok-signed-in viewers |
| `GROK_CONNECTOR_ACCESS_TOKEN` | platform | Injected per viewer; do not hardcode |
| `GROK_PROJECT_ID` | platform | Injected per viewer |

Founder entitlement is **not** an env var. It is the signed-in email
`ibrahimalaneezi12@gmail.com` only.

---

## Google callback (one URL)

Register this redirect on the **Grok auth broker** (not in the AEVORA
frontend):

```
https://<PRODUCTION_HOST>/api/auth/oauth2/callback/grok-google
```

`<PRODUCTION_HOST>` must match `BETTER_AUTH_URL` exactly (scheme + host).

Do **not** add Google Cloud client ids/secrets to AEVORA.

---

## Fail-closed rules (already in code)

- If `DATABASE_URL` or `VERCEL=1` is set, preview OAuth credentials are
  **not** used. Missing production auth env → Google login stays off.
- CSRF, PKCE S256, and OAuth state checks stay on.
- Auto-run stays off.
- Confirmation catalog stays server-side.

---

## Deploy

This repo is built for Vercel (`npm run build` → `.vercel/output`).

From Grok App Builder: **Publish** the app. The platform runs the
production build and injects `DATABASE_URL` plus Grok auth credentials
when sign-in is enabled.

If you control the Vercel project directly:

1. Set the table above as Production env vars.
2. Set `BETTER_AUTH_URL` to the final HTTPS origin.
3. Register the callback URL on the Grok broker.
4. Deploy the current checkout (`npm run build` must already pass).
5. Confirm the host serves AEVORA over HTTPS, not a 502.

Never commit a `.env` file.
