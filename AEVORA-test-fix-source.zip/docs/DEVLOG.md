# Aegis development log

Newest entries first. Every completed step records:

Completed / Tests / Problems / Decisions / Next Step.

---

## Public pages can be indexed. The keep cannot.

**Completed:** 2026-09-25

The public landing had no robots rule, and `/robots.txt` and `/sitemap.xml` did not exist. `/` now says `index, follow`. `/login` and `/app` say `noindex, nofollow`. `robots.txt` allows `/` and disallows `/app`, `/login`, `/api`, and `/auth`. The sitemap lists only the public landing, and only when `BETTER_AUTH_URL` is an https origin that is not localhost or a preview host. This preview has no such origin, so the sitemap is an empty urlset and no localhost URL is published. The landing states what Aegis, Business, Invest, and Studio are. It does not invent prices, ratings, or testimonials. Product comparisons such as “Compare Dola and Claude” stay research. An equity compare still needs a ticker, so “Compare Nvidia and AMD” stays invest. There is no Dola-only exception.

Tests: script suite 196/196 and product suite 440/440, twice. Typecheck, lint, and production build passed. The public landing was rendered on desktop and a phone width. No overflow. No console errors.

**Next:** a production https origin in `BETTER_AUTH_URL` before a canonical sitemap URL can be published. Live AI, broker, and business credentials are still absent.

---

## Business connections stay honest until a provider answers

**Completed:** 2026-09-24

Gmail and Google Calendar now separate "not configured" from "authorization required" and a real connection error. Test connection and last checked are on every business source. HubSpot and Shopify still save a token only after the provider accepts it. Shopify also reads products, and stock only when `inventory_quantity` is present. Google Ads and QuickBooks OAuth is wired. A login is saved only after Google lists accessible customers or QuickBooks returns a company name. Inventory is Shopify or unavailable. No spend, income, lead, order, or stock figure is invented. Tokens stay sealed. Better Auth, Studio, and the plan flags were not changed.

Tests: script suite 196/196 and product suite 432/432, twice. Typecheck, lint, and production build passed. Signed-in Business connections were rendered on desktop and a phone width. No overflow. Nothing shown as Connected.

**Next:** approve Gmail and Calendar on the connector gate, then enter a HubSpot token and a Shopify admin token in Business. Google Ads and QuickBooks still need their official app credentials in the server environment. No secret was pasted in chat.

---

## Business and Invest talk to the same manager

**Completed:** 2026-09-24

Natural business questions now stay on the business manager: why something is happening in the business, what to focus on in the business, marketing, a plan to grow sales, a price test, and a weekly review. Personal “what should I focus on today?” stays planning. “Compare Nvidia and AMD” is invest research. “Compare Dola and GPT” stays general research. “What is a bull case?” does not load the private book. “Should I rebalance?” and “How diversified am I?” do. Strategy and competitor answers use only saved notes and say what is missing. The executive brief includes only work that was actually proposed or executed. Experiments are loaded only when the user asks to test one. The Invest opening question is “How is my portfolio?”

Tests: script suite 196/196 and product suite 424/424, twice. Typecheck, lint, and production build passed. Signed-in Business and Invest pages were rendered on desktop and a phone width. No overflow. Nothing shown as Connected.

**Next:** a real Alpaca paper key, and a real HubSpot or Shopify credential, still have to be entered in the product. No key was pasted in chat.

---

## Broker chat no longer denies a saved connection

**Completed:** 2026-09-24

Invest chat was told “no broker is connected” from a plan flag, even after a per-user Alpaca link was saved. The plan flag still cannot execute an order. Chat now reads the saved link and does not invent balances. One approval uses one broker client-order id.

Tests 421/421 twice. Typecheck, lint, and build passed.

---

Older entries that were in this file before 2026-09-25 are not in this copy. `docs/SPEC.md` and `docs/STATUS.md` remain the product rules and the current gate.
