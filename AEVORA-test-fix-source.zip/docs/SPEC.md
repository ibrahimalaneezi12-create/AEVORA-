# AEVORA — Step 1 Specification

**Status:** Accepted as source of truth (2026-09-16); N1–N4 locked 2026-09-16  
**Product working name:** AEVORA  
**Owner:** Ibrahim  
**Author:** Technical co-founder (Grok Build)

This document is the source of truth. Later steps implement it; they do not
re-litigate it. If reality disagrees with this file, **change this file first**
and record the delta in `docs/DEVLOG.md`.

Open product choices are tagged **NEEDS IBRAHIM**. Engineering may proceed with
the stated default until that decision lands.

---

## 1. Product

### 1.1 One-line

AEVORA is a private personal steward: it chats with you, remembers what matters,
tracks goals, and **never takes a side-effecting action without a permission
level you have already allowed**.

### 1.2 Who it is for

A single person who wants an AI that is useful and **obedient** — not an
autonomous agent that emails, pays, or posts on its own.

### 1.3 Promise

- You always know what AEVORA is about to do.
- Chat context is temporary. Memory is permanent and yours to edit.
- **No action executes automatically.** AEVORA shows the proposed action and
  waits for an explicit confirmation. Chat replies are speech, not actions.
- Every action is written to an audit log you can read.

### 1.4 Non-goals (this product, all phases)

- No multi-tenant teams, orgs, or roles-between-users. One account = one life.
- No unconstrained tool execution, shell, or arbitrary HTTP from the model.
- No hidden background agent loops, self-prompting, or “just go do it.”
- No other LLM providers. xAI Grok only.
- No other auth providers than Google, X, and email/password.

---

## 2. Exact MVP

MVP = steps 2–15 of the roadmap. It is a **signed-in personal workspace** with
chat, memory, goals, a permissioned orchestrator, confirmation, and audit.

### 2.1 In MVP

| Capability | Step | Meaning |
|---|---|---|
| App skeleton, preview, build | 2 | Runs, typed, production-buildable |
| Simple AI chat proof | 2 | One-shot server call to Grok; not the full chat product |
| Core UI + login + responsive | 3 | Shell, dashboard frame, sign-in |
| Secure accounts | 4 | Real sessions; no mock users |
| Profile + settings | 5 | Name, theme, timezone, permission defaults |
| Full AI chat | 6 | Conversations, history, persisted messages |
| Orchestrator skeleton | 7 | Propose actions; **no autonomy, no loops** |
| Universal memory | 8 | Durable memories, separate from chat |
| Tasks + goals | 9 | CRUD, link tasks to goals |
| Personal dashboard | 10 | Home: goals, tasks, pending approvals, recent memory |
| Permission system | 11 | Safe / Review / Approval / Restricted |
| Confirmation screens | 12 | Approval-level actions cannot run without them |
| Activity + audit log | 13 | Append-only, user-readable |
| Safe tool framework | 14 | Allowlisted tools; no unregistered execution |
| Agent execution + human approval | 15 | Execute only after permission + confirmation |

### 2.2 Out of MVP (later, do not build during 2–15)

| Module | Step | Gate |
|---|---|---|
| Negotiate bills (transparent) | later | Needs real-world billing data + Ibrahim rules |
| Business-in-a-box | later | Needs Ibrahim’s business scope |
| Learning world | later | Needs Ibrahim’s pedagogy scope |
| Security audit (formal pass) | 19 | After 15 |
| Reliability testing | 20 | After 19 |
| Performance optimization | 21 | After 20 |
| Production deployment | 22 | Platform publish; Ibrahim trigger |
| Beta with real users | 23 | **NEEDS IBRAHIM** |
| Iterate on feedback | 24 | **NEEDS IBRAHIM** |
| Public launch | 25 | **NEEDS IBRAHIM** |

Original-roadmap “16–18” (bills / business / learning) stay gated
**NEEDS IBRAHIM**. They are separate product modules. They are **not**
capability Steps 16–17.

### 2.3 MVP success test

A signed-in user can:

1. Chat with Grok.
2. Pin a memory that still exists in a new conversation.
3. Create a goal and a task.
4. See them on the dashboard.
5. Watch the assistant **propose** a tool action that does **not** run until
   Ibrahim explicitly confirms it. Restricted never runs. Confirmation
   volume differs by level (compact / card / full page); auto-run does not.
6. Read that event in Activity.

### 2.4 Long-term capabilities (locked direction)

The AEVORA vision (voice, languages, reminders + device notifications, stronger
memory, planning, briefing, search, calendar, email, creation, companion
conversation, safety controls) **is the product**, sequenced. It is not a
backlog of optional ideas.

Order after the MVP foundation (steps 2–15, verified):

1. **Step 16 — Voice + multilingual** (this pair with 17). Same brain as
   text. English + Arabic first. Browser speech in, same chat path, speech out.
2. **Step 17 — Advanced memory + context.** Relevance-aware retrieval,
   assembled context, follow-ups, forget/edit. Same tools as Step 14.
3. **Steps 18–20 together (Ibrahim, 2026-09-18).** Command center +
   advanced reasoning; real reminders + notifications + follow-ups;
   planning + goal health + daily briefing; global language registry.
4. **Steps 21–24 (COMPLETE, 2026-09-18).** Search and research through
   the same brain with real citations. AEVORA calendar plus connected Gmail
   when authorized. Creation, Pulse, entitlements (Founder at £0), and
   premium voice. No second brain. Step 25 remains locked.

Original-roadmap bills / business / learning stay gated **NEEDS IBRAHIM**
and are separate product modules, not a substitute for the list above.
They are **not** Steps 16–17.

N4 still holds: no auto-run. Voice cannot skip confirmation. Context is
not permission.

---

## 3. Architecture

### 3.1 Shape

Single web app. Browser never holds secrets. All durable data and all model
calls go through authenticated server functions.

```text
[ Browser: React UI ]
        |  createServerFn (same-origin)
        v
[ Server: TanStack Start ]
   ├── Auth (Better Auth → Grok broker: Google, X; local email/password)
   ├── Domain API (always scoped to verified user id)
   ├── AI gateway (xAI, grok-4.5, server-only key)
   ├── Orchestrator (propose → classify → queue or run)
   ├── Tool registry (allowlist only)
   └── Postgres (Neon in production, embedded PGLite in preview)
```

### 3.2 Trust boundary

| Side | Allowed | Forbidden |
|---|---|---|
| Browser | Render, collect input, call server functions | API keys, raw SQL, other users’ ids, connector tokens |
| Server functions | DB, xAI, permission checks, audit writes | Trusting client-sent `userId` |
| Model | Text + structured **proposals** | Direct tool execution, network, filesystem |

The model never “calls a tool.” It emits a proposal. The orchestrator decides.

### 3.3 Runtime modes

| Mode | Database | Auth | AI |
|---|---|---|---|
| Live preview | Embedded Postgres (in-memory; resets on server restart) | Real sign-in once Step 3+ is on | Real xAI if key present; friendly fallback if not |
| Deployed | Neon Postgres | Real sign-in (Google, X, email/password) | Real xAI |

### 3.4 Orchestrator (Step 7+, constrained)

One turn:

1. Load user, permission settings, retrieved memories, open goals/tasks.
2. Send **bounded** context + the new user message to Grok.
3. Persist the assistant reply as chat.
4. Parse zero or more **proposed actions** (tool id + payload).
5. For each proposal: look up tool → permission level → branch:
   - **Safe** → insert `proposed_actions` `pending`; compact in-thread confirm; run only after Approve; audit.
   - **Review** → insert `proposed_actions` `pending`; card + Activity; run only after Approve; audit.
   - **Approval** → insert `proposed_actions` `pending`; full confirmation page; run only after Approve; audit.
   - **Restricted** → reject, audit, tell the user. Cannot be approved.
6. Stop. No retry storm, no chain-of-thought loop, no background jobs.

Voice (Step 16) is another input to this same turn. It does not add a second
orchestrator.

### 3.5 Memory vs context

| | Temporary context | Universal memory |
|---|---|---|
| Lives in | `messages` for the current conversation | `memories` table |
| Lifetime | Until the conversation is deleted | Until the user edits/deletes |
| Sent to model | Last N messages (token-capped) **plus** a bounded assembled context | Retrieved **relevant** subset (pinned + scored overlap). Never the whole table. |
| Who writes | Chat pipeline (text or voice transcript) | User, or assistant at Review level after Approve |

No vector database. Preview Postgres cannot load extensions. Retrieval is
SQL candidates (pinned, `ilike`, recency) then in-process ranking. Voice
transcripts are conversation history, **not** automatic long-term memory.

The context engine (Step 17) assembles, for one turn: relevant memories,
a few active goals, due/open tasks, pending actions, and language. It
does not dump every row. Follow-ups (`that`, `it`, `tomorrow`) resolve
from conversation history plus this block. Context never grants
permission.

### 3.6 Folder layout (target)

```text
src/
  routes/                 # pages + /api/auth/$
  components/ui/          # shadcn primitives
  components/layout/      # app shell, nav
  components/chat/
  components/dashboard/
  components/memory/
  components/goals/
  components/permissions/ # confirmation + level badges
  lib/auth/               # pre-wired; do not rewrite
  lib/db.ts               # pre-wired
  lib/ai/                 # xAI client (server-only)
  lib/orchestrator/
  lib/permissions/
  lib/tools/
  lib/memory/
  lib/audit/
migrations/
  0001_auth.sql           # copied from migrations/auth/ when sign-in turns on
  0002_aegis.sql          # app schema
docs/
  SPEC.md                 # this file
  DEVLOG.md
```

---

## 4. UI plan

### 4.1 Visual language

Editorial, quiet, “private study” — not neon, not purple, not chatbot-bubble
cliché.

| Token | Value | Why |
|---|---|---|
| Background | `#0c0d0f` | Warm near-black, long sessions |
| Elevated | `#15171c` | Panels, not glass soup |
| Foreground | `#ecece8` | Paper on ink |
| Muted | `#8b8d94` | Meta, timestamps |
| Accent | `#9aa6b2` steel | One cool accent; never purple/gold |
| Primary button | near-white on dark | Hierarchy without neon |
| Danger | `#c45c4a` rust, badges only | Restricted / deny |
| Caution | `#c4a574` dust, badges only | Approval pending |
| Fonts | **Newsreader** (display) + **Figtree** (body) | Serif confidence, humanist body; two families only |
| Icons | `lucide-react` stroke | No emoji in chrome |
| Radius | concentric 4 / 8 / 12 / 16 / 24 | Nested panels |
| Motion | 150–250ms opacity+transform | `prefers-reduced-motion` respected |

**NEEDS IBRAHIM:** name, palette, serif-vs-sans. Default stands until then.

### 4.2 Information architecture

| Route | Audience | Purpose |
|---|---|---|
| `/` | Signed-out: landing. Signed-in: dashboard (after Step 3). | First paint |
| `/login` | Signed-out | Google, X, email/password |
| `/app` | Signed-in | Personal dashboard |
| `/app/chat`, `/app/chat/$id` | Signed-in | Conversations |
| `/app/memory` | Signed-in | Universal memory |
| `/app/goals` | Signed-in | Goals + tasks |
| `/app/activity` | Signed-in | Audit + review queue |
| `/app/approvals/$id` | Signed-in | Confirmation screen |
| `/app/settings` | Signed-in | Profile, theme, **language, voice**, permission defaults |

Step 2 only ships `/` with a simple chat proof. Later steps add routes; they
do not invent a second IA.

### 4.3 Shell

**Desktop (≥768px):** left rail — mark, Dashboard, Chat, Memory, Goals,
Activity, Settings, account button.

**Mobile (~390px):** top bar (mark + account) + bottom nav (Dashboard, Chat,
Goals, More). Tap targets ≥44px. No horizontal overflow.

**Chat:** message column + pinned composer. Assistant proposals render as
cards (Safe/Review/Approval/Restricted), not as raw JSON. Voice is a dock on
the same composer. Transcripts land in the same thread.

**Dashboard:** greeting, pending approvals (highest emphasis), today’s tasks,
active goals, recent memories, last conversation.

**Confirmation (Step 12):** full-page, not a tiny toast. Shows tool name,
human summary, payload in plain language, permission level, Approve / Deny.
Default is Deny (close without executing).

### 4.4 States every surface owes

Loading (skeleton), empty, error, disabled (AI unavailable), reduced-motion.

Voice also owes: idle, microphone permission required, listening, thinking,
speaking, interrupted, error, disabled.

### 4.5 Copy tone

Short, plain, adult. Verbs on buttons. No “magic,” no sparkles, no emoji.

---

## 5. Tech stack (locked) and reasons

| Choice | Why | Alternative rejected |
|---|---|---|
| React 19 + TanStack Start | Already installed; SSR + file routes + server functions | Next.js / remix-from-scratch would fight the platform |
| TanStack Router / Query | Installed; typed routes; cache for lists | Ad-hoc fetch |
| Tailwind v4 + CSS `@theme` tokens | Installed; design-system-first | Ad-hoc hex in JSX |
| Radix + shadcn-style primitives | Accessible dialogs, menus, switches | Hand-rolled modal |
| Zustand | Ephemeral UI (composer draft, nav) only | Not a second database |
| Zod | Server function validators | Unchecked `as` casts |
| Better Auth (Google, X, email/password) | Pre-wired, real sessions in preview | Clerk / mock users |
| Neon Postgres + PGLite fallback | Per-user durable data; preview works without a cloud DB | localStorage for secrets/memory |
| xAI `grok-4.5` via `https://api.x.ai/v1` | Platform key; spend is the owner’s; OpenAI-compatible | Other vendors, mocked replies |
| `lucide-react` | Installed icon set | Emoji |
| `recharts` | Dashboard later | Hand-drawn SVG charts |
| Browser Web Speech (STT/TTS) | Voice is an interface, not a second model path; no extra spend | A second VoiceAI service |

**Hard platform rules baked in**

- Bind preview on all interfaces, port 8080; start with `npm run dev`.
- Never write a `.env`. Never put non-`VITE_` secrets in the client.
- Never edit `src/lib/auth/server.ts`. Email/password is a one-line flag.
- Never create `src/routes/auth/popup.tsx`.
- Never call xAI from the browser.
- `user_id` columns are `TEXT`. Scope every query with `authMiddleware`.
- No Postgres extensions (preview cannot load them).
- JSON payloads stored as `text` (portable; parse in app).

---

## 6. Database schema

Auth tables come from `migrations/auth/0001_auth.sql` (do not edit). App tables
live in `migrations/0002_aegis.sql` and later additive files. Never edit an
applied migration.

All app tables that hold user data have `user_id text not null`. Serial integer
ids (no `uuid` type, no `create extension`).

### 6.1 `profiles`

```sql
create table if not exists profiles (
  user_id          text primary key,
  display_name     text,
  bio              text not null default '',
  timezone         text not null default 'UTC',
  theme            text not null default 'system', -- system | dark | light
  onboarding_done  boolean not null default false,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
```

Step 16 adds on `profiles` (migration `0006_voice_locale.sql`, additive):

- `locale` text not null default `'en'` — registered language code
- `voice_enabled` boolean not null default true
- `voice_name` text not null default `''` (browser voice name; empty = default compatible)
- `detect_language` boolean not null default true

Step 18–20 add (migration `0007_reminders_languages.sql`, additive):

- `profiles.fallback_language` text not null default `'en'`
- `reminders`, `notification_devices`, `notification_attempts`

Voice and language are this user’s preferences. They do not change
intelligence, tools, or permissions. Languages after English and Arabic
are registry rows, not separate brains.

### 6.2 Chat (temporary context)

```sql
create table if not exists conversations (
  id          serial primary key,
  user_id     text not null,
  title       text not null default 'New conversation',
  archived    boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists conversations_user_id_idx on conversations (user_id);

create table if not exists messages (
  id               serial primary key,
  user_id          text not null,
  conversation_id  integer not null references conversations(id) on delete cascade,
  role             text not null, -- user | assistant | system
  content          text not null,
  token_count      integer,
  created_at       timestamptz not null default now()
);
create index if not exists messages_conversation_idx
  on messages (user_id, conversation_id, id);
```

Voice transcripts are stored as ordinary `messages` (role `user` / `assistant`).
There is no `voice_messages` table.

### 6.3 Universal memory

```sql
create table if not exists memories (
  id          serial primary key,
  user_id     text not null,
  kind        text not null, -- fact | preference | person | project | decision
  title       text not null,
  body        text not null,
  tags        text not null default '',
  source      text not null default 'user', -- user | assistant
  pinned      boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists memories_user_id_idx on memories (user_id);
```

Memories are not chat. A conversation message does not become a memory unless
the user asks to remember it and confirms `memory.save`.

Retrieval (Step 17): load a candidate pool (pinned, `ilike` on title/body/tags,
recency), then rank by token overlap, kind, and pin. Cap 8 rows / 2400
characters into the prompt. Include memory ids so the model can propose
`memory.delete` / `memory.save` with an id. Do not dump the whole table.

A newer preference that clearly updates an older one should **update** that
row (same user, `kind = preference`, similar title/body) rather than insert a
contradictory duplicate. Ambiguous cases stay as a proposal and may ask.

### 6.4 Goals and tasks

```sql
create table if not exists goals (
  id           serial primary key,
  user_id      text not null,
  title        text not null,
  description  text not null default '',
  status       text not null default 'active', -- active | paused | done | archived
  target_date  date,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists goals_user_id_idx on goals (user_id);

create table if not exists tasks (
  id          serial primary key,
  user_id     text not null,
  goal_id     integer references goals(id) on delete set null,
  title       text not null,
  notes       text not null default '',
  status      text not null default 'todo', -- todo | doing | done | cancelled
  due_date    date,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists tasks_user_id_idx on tasks (user_id);
```

A task may link to a goal only if that goal belongs to the same user.
`0003` adds `tasks_goal_id_idx`.

“Remind me to …” in Steps 16–17 maps to `task.create` (Review), not a
reminder/push system.

### 6.5 Permissions, proposals, tools, audit

```sql
create table if not exists permission_settings (
  user_id           text primary key,
  auto_run_safe     boolean not null default false,
  auto_run_review   boolean not null default false,
  updated_at        timestamptz not null default now()
);

create table if not exists tool_catalog (
  id                 text primary key,
  display_name       text not null,
  description        text not null,
  permission_level   text not null,
  enabled            boolean not null default true
);

create table if not exists proposed_actions (
  id                 serial primary key,
  user_id            text not null,
  conversation_id    integer references conversations(id) on delete set null,
  tool_id            text not null,
  permission_level   text not null,
  title              text not null,
  summary            text not null,
  payload_json       text not null default '{}',
  status             text not null default 'pending',
  -- pending | approved | denied | executed | failed | cancelled
  created_at         timestamptz not null default now(),
  decided_at         timestamptz,
  executed_at        timestamptz,
  error              text
);

create table if not exists audit_logs (
  id                 serial primary key,
  user_id            text not null,
  actor              text not null, -- user | assistant | system
  action             text not null,
  entity_type        text not null default '',
  entity_id          text not null default '',
  permission_level   text,
  detail             text not null default '',
  created_at         timestamptz not null default now()
);
```

`auto_run_safe` and `auto_run_review` exist as columns and stay false.
`0004` adds `confirm_floor` (`safe` | `review` | `approval`). A user may
raise the floor, never lower a catalog level. Restricted is unchanged.

`0005` seeds `tool_catalog` with the eleven in-product ids from §7.2.

`actor` is `user` | `assistant` | `system`. Domain writes still succeed if
an audit insert fails.

### 6.6 When schema is applied

| File | Applied in step |
|---|---|
| `0001_auth.sql` (copy) | 3 (sign-in on) |
| `0002_aegis.sql` (all tables above) | 4 (accounts exist; profile row on first session) |
| `0003_tasks_goal_idx.sql` | 9 |
| `0004_permission_floor.sql` | 11 |
| Tool catalog seed (`0005`) | 14 |
| `0006_voice_locale.sql` | 16 |
| `0007_reminders_languages.sql` | 18–20 |

Creating tables earlier than their feature step is allowed **only** if a later
step would otherwise migrate destructively. Prefer one `0002` so preview and
production share a single additive schema. Unused tables in early steps are
empty, not a second product. Never edit an applied file.

---

## 7. Permission system

Four levels. Every tool declares exactly one. The orchestrator never upgrades a
level. A user setting may **tighten** (force Review tools through Approval) but
never **loosen** (run Approval as Safe).

### 7.1 Levels

Levels classify **how loud the confirmation is**, not whether confirmation
happens. **Nothing executes without an explicit Approve.** There is no auto-run
path (Ibrahim N4, 2026-09-16). `auto_run_safe` and `auto_run_review` stay
`false`; no settings UI may turn them on.

| Level | Side effect | When it runs | UI |
|---|---|---|---|
| **Safe** | None outside the current turn’s read path (search own memory, list own tasks) | After confirmation | Compact confirm in-thread |
| **Review** | Mutates **this user’s** AEVORA data (save memory, create task) | After confirmation | Card + Activity row; undo when possible |
| **Approval** | External, irreversible, bulk-destructive, or sending | After the confirmation **page** | Full confirmation page |
| **Restricted** | Out of policy for this product version, or never allowed | **Never.** No override in MVP. | Rejection + audit |

`chat.reply` is the assistant message, not a tool action, and does not go
through this table.

Default for a brand-new account: every tool action is pending until confirmed;
Restricted blocks. A user may raise `permission_settings.confirm_floor`
(`safe` default, or `review`, or `approval`). The classifier uses the louder
of the catalog level and that floor. A quieter floor never lowers the catalog.
Restricted is unchanged. Auto-run columns stay false; no UI or API may turn
them on.

### 7.2 MVP tool map (declared early, implemented in 14–15)

| Tool id | Level | Notes |
|---|---|---|
| `chat.reply` | Safe | The visible assistant message; not a “tool” in UI |
| `memory.search` | Safe | Read own memories |
| `task.list` | Safe | Read own tasks/goals |
| `memory.save` | Review | Insert/update own memory |
| `task.create` | Review | Insert own task |
| `task.update` | Review | Update own task |
| `goal.create` | Review | Insert own goal |
| `memory.delete` | Approval | Destructive |
| `task.delete` | Approval | Destructive |
| `conversation.delete` | Approval | Destructive |
| `profile.update` | Approval | Identity |
| `permission.update` | Restricted | Auto-run flags are frozen off; no self-loosening |
| `external.*` | Restricted | Email, pay, post, browse arbitrary URLs — **not implemented** |
| unregistered id | Restricted | Hard block |

Steps 16–17 add **no** new tool ids. Voice and memory/context reuse this map.
Later capabilities may add tools; they start as Restricted until explicitly
classified.

### 7.3 Confirmation contract (Step 12)

A pending action (Safe, Review, or Approval) is not executed by:

- a chat reply,
- a voice transcript,
- a checkbox in settings,
- a timer,
- “the user said yes in natural language,”
- or any auto-run flag.

Only the confirmation control’s **Approve** action, which hits a server
function that re-checks `user_id`, `status = pending`, and tool allowlist.
Restricted cannot be approved.

The gate is **tool-agnostic**: Approve / Deny take a proposal id, not a tool
name. Execution uses the stored `tool_id` + `payload_json` after the catalog
check. Chat, a later voice turn, or a dashboard link all hit the same POST.
New tools (Step 14+) register; they do not get a second approval system.

### 7.4 Tool registry (Step 14)

Tools plug into **one** pipeline. Future capabilities (voice, reminders,
calendar, email, creation) add a catalog entry, a payload schema, and a
handler. They do not add a second confirmation or audit system.

```text
Authentication → Authorization → Permission → Proposal → Approval
  → Execution → Verification → Activity
```

A tool may run only when **all** of these hold:

1. The caller is signed in. `user_id` comes from `context.userId`, never the client.
2. The id is registered in the in-code catalog (`src/lib/tools/`).
3. A matching **enabled** row exists in `tool_catalog`.
4. The in-code level, the table level, and the stored proposal are not Restricted.
5. A handler is registered for that id.
6. The payload passes that tool’s Zod schema.
7. Approve claimed the row `pending` → `approved` (Step 12). Replay cannot run.

If the in-code catalog and `tool_catalog` disagree, **fail closed**. Do not run.

Registering a tool:

- in-code metadata (id, display name, description, permission level, executable)
- handler + payload schema
- durable row (seed migration and/or `syncToolCatalog`)

Unregistered ids are Restricted. `external.*` (HTTP, email, pay, post, browse)
stay Restricted and have **no handlers** in this step. `chat.reply` is speech,
not a tool. `permission.update` is registered so it can be rejected by name;
it cannot be approved or executed.

The in-code catalog is the classification source (sync, no model input). The
table is the durable allowlist checked at execute.

### 7.5 End-to-end (Step 15)

Step 15 adds **no** tools, tables, handlers, or second gate. It proves steps
7–14 together:

- Propose → confirm → execute → audit is one path.
- Human Approve is required. Deny does not execute. Replay cannot run.
- Unregistered, Restricted, and `permission.update` cannot be approved.
- Rows are scoped to `context.userId`. Another user cannot read or mutate them.
- Chat, memory, goals, tasks, profile, permissions, and activity persist
  across refresh and sign-out / sign-in.

No background agents. No HTTP / email / pay tools.

### 7.6 Voice + multilingual (Step 16)

Voice is an **interface** into the existing brain. Not a second assistant.

```text
speech → transcript → sendChatMessage → context + orchestrator
  → confirmation → registry → audit → reply text → TTS
```

Rules:

1. The only turn entry is `sendChatMessage` (and `retryChat` on the same
   conversation). No VoiceAI, VoiceBrain, VoiceTools, or VoicePermissions.
2. Browser Web Speech API for STT and TTS (Chromium). No extra model path.
3. Transcripts persist as `messages`. They are not auto-saved as memories.
4. Barge-in: if AEVORA is speaking and the user starts speaking, cancel TTS,
   capture the new request, do not talk over them.
5. States: idle, permission required, listening, thinking, speaking,
   interrupted, error, disabled. Cleanup mic tracks, recognition, TTS, and
   timers when the session ends or voice is disabled.
6. Multiple selectable browser voices. Persist `voice_name` on the profile.
   If the selected voice does not speak the active language, pick an explicit
   compatible fallback — do not pretend.
7. Languages: English and Arabic. Architecture allows more later without a
   rebuild. Preferred locale persists. Optional per-turn detection when
   `detect_language` is on. Mixed EN/AR is valid, not an error.
8. Arabic is a real language: input, output, STT/TTS where the provider
   supports it, `html[dir=rtl]`, language-aware voice. Chrome labels may stay
   English; the conversation and memory must not.
9. Voice cannot bypass auth, IDOR, confirmation, Restricted, or the registry.
10. Switching voice ↔ text keeps the same conversation, memory, and pending
    actions.

“Remind me …” is `task.create` through the existing Review path. No push,
calendar, or email in this step.

### 7.7 Advanced memory + context (Step 17)

Upgrade retrieval and assembly. Do not add a second memory store.

1. Distinguish conversation history, turn context, long-term memory, goals,
   tasks, preferences, decisions, and pending actions. Do not treat every
   row as “memory.”
2. Explicit remember / forget / search / edit use existing tools
   (`memory.save`, `memory.delete`, `memory.search`) through confirmation.
3. Do not silent-save every message (voice or text).
4. Retrieve by relevance. Irrelevant rows stay out of the prompt.
5. Context engine assembles the smallest useful block: relevant memories
   (with ids), a few active goals, due tasks, pending action titles,
   language. Token-capped. No N+1 dump.
6. Follow-ups (`that`, `it`, `tomorrow`, `change it to 8`) resolve from
   conversation history plus this block. Context improves understanding;
   it does not grant permission.
7. Preference conflict: a newer preference that matches an existing one
   updates that row instead of duplicating. Ask when ambiguous.
8. Memory is language-independent at rest. An English question may retrieve
   an Arabic-origin memory and vice versa.
9. Every query stays on `context.userId`. Deleted memory is actually
   deleted (not hidden).

### 7.8 Command center (Step 18)

One brain. Chat is the command center. Quick actions only send or draft
through `sendChatMessage`. Intent classification is a hint plus a
fail-closed guard: casual speech (`I'm bored`, `I need to study more`)
cannot persist mutating proposals. Ambiguous `that`/`it` must ask.

New tools (same registry): `goal.update`, `reminder.*`. No second
orchestrator.

### 7.9 Reminders (Step 19)

Reminders are not tasks. `reminder.create` is Review. `reminder.cancel`
is Approval. Store `fire_at` as UTC; keep IANA timezone + local wall
time for recurrence and DST. Claim due rows with compare-and-set so a
job cannot notify twice. Devices are `(user_id, device_key)` — never
shared. Browser `Notification` is the delivery channel while the keep
is open. Background web-push without VAPID is out of this step, not
faked. Follow-ups appear in the briefing; AEVORA does not spam.

### 7.10 Planning + briefing (Step 20)

Daily/weekly plans and the briefing are composed from tasks, goals, and
reminders that already exist. Empty states say so. Goal health is
signals (overdue, stalled, missing tasks), not a manufactured score.
No calendar is connected.

### 7.11 Global languages

Languages are a registry (`languages.ts`). English and Arabic remain
first-class. Adding a language is a catalog row: code, dir, speech tag,
names. Mixed scripts return null (keep preferred). RTL uses `dir`.
Voice uses the same registry. Memory stays language-independent.

---

## 8. Security model

### 8.1 Identity

- Sign-in methods: Google, X (broker), email/password (local Better Auth).
- Email/password is **on from Step 3** (Ibrahim N3). Flag:
  `src/lib/auth/email-password.ts`.
- No mock/demo users in any build that has auth on.
- Gate viewers (opened from Grok) are already signed in — never show them
  “Sign in with Grok” buttons.
- `authMiddleware` on **every** server function that reads or writes user data.
- Queries always `where user_id = context.userId`. Never a client-supplied id.

### 8.2 Secrets and AI spend

- `XAI_API_KEY` and `DATABASE_URL` are server-only, injected, never written to
  files, never returned in responses, never `VITE_`-prefixed.
- Calls are user-initiated (submit/click). No call on page load, keystroke, or
  timer. Voice STT/TTS in the browser does not spend the key. A spoken turn
  still hits Grok once, the same as a typed turn.
- Caps: `max_tokens` 1024 for chat; prompt trimmed; one in-flight request per
  user; retry at most once on transport failure, never on 4xx.
- If the key is missing: UI state “AI is unavailable,” no crash.

### 8.3 Web

- XSS: React text escaping; no `dangerouslySetInnerHTML` for model output.
- SQL: tagged-template parameters only.
- CSRF / sibling isolation: keep Better Auth `__Host-` cookies and Fetch
  Metadata checks. Do not disable them.
- Confirmation pages are POST server functions, not GET with an id in the URL
  as the only gate (id in the URL is fine for rendering; execute is POST).

### 8.4 Agent

- Allowlisted tools only.
- Payload schema validated (Zod) before execute.
- Restricted cannot be approved.
- Audit every proposal, approval, denial, execution, and failure.
- No tool may disable audit, change another user’s rows, or spawn subprocesses.
- Voice is not an execution path. Memory retrieval is not an execution path.

### 8.5 Data classes

| Class | Examples | Storage |
|---|---|---|
| Identity | email, name | Auth tables |
| Personal | memories, goals, chat, locale, voice preference | App tables, user-scoped |
| Secrets | API keys | Environment only |
| Audit | activity | Append-only, user-scoped |

No personal data in unowned (world-writable) rows. Auth-off exists only in
Step 2, and Step 2 **must not persist** chat or memories.

---

## 9. Roadmap (strict step boundaries)

Do **not** skip. Do **not** merge major steps. After each step: test, log,
stop merging more product into that step.

| Step | Deliverable | Test bar | Must not include |
|---|---|---|---|
| **1** | This spec | Completeness vs 25-step brief; no code required | Scaffolding |
| **2** | Skeleton, `startup.sh`, tokens, home, **ephemeral** AI ping | `npm run build`, `npm run typecheck`, browser render, one successful or graceful AI round-trip | Auth routes, persistence, orchestrator |
| **3** | App shell, responsive nav, login (Google, X, email/password), auth flag on, session-gated `/app`, dashboard frame | Sign-in UI renders; signed-out can reach login; email sign-up/sign-in works; `/app` redirects when signed out; mobile 390px | Profile fields, persisted chat |
| **4** | First-session `profiles` row, `0002_aegis.sql`, signed-out server-fn 401 proof | Profile row after sign-in; user-scoped tables exist; no mock users | Memory/goals features, settings UI |
| **5** | Profile + settings | Update display name/theme/timezone; scoped to user | Permission engine UI (stub ok) |
| **6** | Persisted conversations + messages + xAI chat | Refresh keeps history; no key leak; user-initiated | Tool execution |
| **7** | Orchestrator types + “proposal” parse; **no execute** | A proposal can be shown as a card and stored pending | Autonomy, loops, cron |
| **8** | Memory CRUD + retrieval into chat context | New chat can see pinned memory | Vector DB |
| **9** | Goals + tasks CRUD | Link task→goal; user-scoped | Agent-created tasks without Review path |
| **10** | Dashboard composition | Real data, empty states, mobile | New backend concepts |
| **11** | Permission settings + classifier | Tightening works; loosening does not | External tools |
| **12** | Confirmation screens | Approve executes once; Deny does not; refresh-safe | Skip-confirm shortcuts |
| **13** | Activity / audit viewer | Append-only; filter by level | Editing logs |
| **14** | Tool registry + handlers for in-product tools | Unregistered id cannot run | HTTP/email/pay tools |
| **15** | End-to-end: propose → confirm → execute → audit | Human approval required for Approval tools | Background agents |
| **16** | Voice + multilingual | Same brain; EN+AR; STT/TTS; barge-in; persist locale/voice; confirmation intact | Second assistant; auto-run; reminders/push |
| **17** | Advanced memory + context | Relevance retrieval; assembled context; forget/edit; no silent-save | Vector DB; permission bypass; new execution path |
| **18** | Command center + advanced reasoning | Intent vs conversation; NL edit; quick actions; same brain | Second orchestrator; silent task creation |
| **19** | Reminders + notifications + follow-ups | Scheduled jobs; device notify; snooze/cancel; timezone | Fake “reminders”; auto-run; email/push vendors |
| **20** | Planning + goals + daily briefing | Real data only; goal health signals; reviews | Invented calendar; duplicate task stores |
| Later | Bills / business / learning | **NEEDS IBRAHIM** | Not a substitute for the vision list |
| Next | Search, then calendar / email / creation | Separate steps after 20 | Bypass 7–15 |
| **H** | Hardening (original 19–21) | After the vision slice | Feature creep |
| **22–25** | Ship / beta / launch | **NEEDS IBRAHIM** | — |

Ibrahim asked that Steps 18, 19, and 20 ship together with a global language
registry (2026-09-18). Do not start search / calendar / email / creation
until these are verified.

---

## 10. Open decisions

| ID | Question | Status | Notes |
|---|---|---|---|
| N1 | Product name “AEVORA”? | **Locked** | Rename to AEVORA per the latest user instruction (2026-10-15) |
| N2 | Visual: dark ink + steel + Newsreader/Figtree? | **Locked** | Keep current style |
| N3 | Email/password + Google + X? | **Locked** | All three on the Step 3 login surface |
| N4 | Auto-run? | **Locked** | **Never.** Every tool action requires explicit confirmation. No setting may enable auto-run. Voice cannot skip it. |
| N5 | First later *module* after 15: bills, business, or learning? | Open | Separate from platform capabilities; none until Ibrahim picks |
| N6 | Public-facing landing copy / positioning | Open | Steward, not “agent army” |
| N7 | First major *capability* after 12–15? | **Locked** | Voice (Ibrahim, 2026-09-17). Same AEVORA brain as text. Built as Step 16 with multilingual. |
| N8 | Is the vision list optional? | **Locked** | **No.** Sequenced. Voice + languages (16) → advanced memory/context (17) → command/reminders/planning (18–20) → search/calendar/email/creation. Not forgotten. |

---

## 11. Quality bar (every implementation step)

- `npm run build` and `npm run typecheck` pass.
- Dev server left running for preview.
- Browser smoke: visible content, no console errors, desktop + mobile.
- Interactive paths actually clicked, not only requested.
- No secrets in client bundles or logs.
- DEVLOG updated with Completed / Tests / Problems / Decisions / Next Step.
