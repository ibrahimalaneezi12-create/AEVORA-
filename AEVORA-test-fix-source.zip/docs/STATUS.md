# AEVORA — authoritative current state

This is the **only** current-state document.
History: `docs/DEVLOG.md`. Rules: `docs/SPEC.md`.
Device checklist: `docs/ACCEPTANCE.md`.

---

## Final release gate

**NOT READY — BLOCKERS REMAIN**

Business and Invest stay one steward. Nothing is marked Connected unless
that provider accepted the credential. A rejected key is not saved.

This keep has no Alpaca account, no HubSpot private-app token, no Shopify
shop token, no Google Ads app, no QuickBooks app, and no `XAI_API_KEY`.
Gmail and Google Calendar use the existing connector gate; this keep
reports them as Needs configuration. Connect is shown, but it does not
start a second Google login and does not mark them connected. No order
was sent. No revenue, balance, lead count, campaign spend, or stock
figure was invented.

Better Auth and Studio were not modified. Google Ads and QuickBooks
Connect calls the real OAuth start and shows the missing server
configuration. Nothing is connected until those apps exist and the
provider accepts a login. Inventory is Shopify only and says so.
`BROKER_CONNECTED` and `BUSINESS_SYSTEMS_CONNECTED` stay false. A plan
flag is not a connection.

Main Chat, Business chat, and Invest chat are separate threads on the
same brain. A thread from one workspace is not listed or opened in
another. Another user cannot open them.


---

## Latest independent audit — 2026-10-15

**Release status: NOT READY TO DEPLOY.** The user-facing product branding has been changed to AEVORA across the current UI, metadata, server response text, and share-card artwork. Internal protocol identifiers such as `X-Aegis-*`, `x-aegis-locale`, existing storage keys, and helper identifiers remain unchanged intentionally to avoid breaking integrations or stored state.

Current verification in the audit environment:

| Gate | Latest result |
|---|---|
| Platform/script tests | **196 passed, 0 failed** |
| Full package test command | **311 passed, 8 test files could not start** because dependencies were unavailable (`zod`, `jose`, `@tanstack/react-start/server`) |
| TypeScript/TSX syntax transpilation | **279/279 passed** (syntax only, not type-checking) |
| JavaScript/MJS syntax | **25/25 passed** |
| Dependency lock consistency | Root dependencies match the lockfile |
| Typecheck | **Blocked** — missing installed type packages (`node`, `vite/client`) |
| Lint | **Blocked** — ESLint is not installed |
| Production build | **Blocked** — Vite is not installed |
| Private browser preview | **Not verified** |

The package registry failed with DNS `EAI_AGAIN` during installation, and npm itself exited abnormally. This is an environment/network blocker; it is not evidence that the eight affected test suites contain assertion failures. Do not report the app as fully tested or deploy-ready until dependencies can be installed from a trusted registry/cache and all gates are rerun against this exact source.

The hard-coded preview OAuth client secret has been removed from source. Preview OAuth now requires `GROK_AUTH_CLIENT_SECRET` from the host managed secret store; the broker must use the matching value. Rotate the previously embedded credential with the broker owner before public release, then verify private-preview sign-in. Until the secret is configured, preview OAuth intentionally remains unavailable and logs a warning.

The existing `.vercel/output` directory is a stale prebuilt bundle and still contains the old Aegis brand. It is excluded from the release candidate and must never be used as proof that the current source builds or as the current preview.

---

## Historical evidence from an earlier checkout (not verified after the latest source changes)

| Gate | Result |
|---|---|
| Product + platform unit tests (run 1) | **196 script + 440 product, 0 fail** |
| Product + platform unit tests (run 2) | **196 script + 440 product, 0 fail** |
| Typecheck | PASS |
| Lint | PASS (0 errors) |
| Production build | PASS. Migrate skipped: `DATABASE_URL` unset. The preview database migrates on process start |
| Signed-in Business desktop and phone | PASS. Gmail and Calendar: Needs configuration, Connect, Test connection, last checked. HubSpot and Shopify: Not connected, password fields; a rejected token is not saved. Google Ads and QuickBooks: Needs configuration, Connect returns the missing-app message and does not navigate. Inventory: Needs a provider, Connect through Shopify, Test connection, no stock. No overflow, no console errors, no provider marked Connected |
| Signed-in chats | PASS. Business chat, Invest chat, and Main chat keep separate threads after refresh. Opening a business id on Main chat does not show that message. A second account cannot read the first account's threads |
| Signed-in Invest desktop and phone | Broker form not re-shot this pass. Invest chat was rendered on desktop. No overflow on the business phone chat |
| Live Gmail / Google Calendar | **ENVIRONMENT-BLOCKED.** This keep has no connector token and cannot resolve a gate host. Status stays Needs configuration. A gate sign-in link is opened only when the gate returns an https host on grok.me or app-builder-testing.com |
| Live HubSpot contacts or Shopify orders, products, stock | **ENVIRONMENT-BLOCKED** (no real token). A fake token was rejected and not saved. Mocked calls do not invent contacts, orders, or stock |
| QuickBooks / Google Ads | **ENVIRONMENT-BLOCKED.** OAuth is implemented. Connect reports that no app is registered. No spend or income is calculated |
| Live Alpaca account, positions, orders, paper or live fill | **ENVIRONMENT-BLOCKED** (no real broker account) |
| Live chat / search / research / Studio / voice | **ENVIRONMENT-BLOCKED** (no `XAI_API_KEY`). A user message can still be stored. The reply says the model is unavailable. Live provider calls were not run |
| Public indexing | **FIXED IN CODE.** `/` is `index, follow`. `/app` and `/login` are `noindex, nofollow`. `robots.txt` allows `/` and blocks private routes. Sitemap stays empty until `BETTER_AUTH_URL` is a real https origin. No localhost URL is published |
| Checkout | **Not connected.** No fake payment success |
| Background monitoring | **Not connected.** No scheduler |

---

## Connections that can be attempted

| Source | How | Connected means |
|---|---|---|
| Alpaca paper | `paper-api.alpaca.markets` only | Account JSON parsed after the key is accepted. Capabilities come from that account. `order.create` only if status is ACTIVE and trading is not blocked |
| Alpaca live | `api.alpaca.markets` only | Same checks, plus an explicit live confirmation and the existing approval step before any order |
| Gmail / Google Calendar | Existing connector gate only | A successful probe. Missing gate, pending token, or no host stays Not configured. A 401 on a deployed gate is Authorization required and can open only that gate's sign-in URL. This page cannot revoke the grant |
| HubSpot | Private-app token, checked before save | Contacts call succeeded. Deals are a separate capability. A later 401 keeps the token and asks for authorization again |
| Shopify | Admin token on a `*.myshopify.com` host only | Shop payload parsed. Orders and products are separate capabilities. Stock is recorded only when a variant includes `inventory_quantity` |
| Google Ads | OAuth on accounts.google.com, only when client id, secret, developer token, https redirect, and a seal key exist | Saved only after `listAccessibleCustomers` returns 200. Spend is the returned `cost_micros` only. Empty or missing cost is not zero. Currency is not invented |
| QuickBooks | OAuth on appcenter.intuit.com, only when client id, secret, an explicit sandbox or production environment, https redirect, and a seal key exist | Saved only after company info returns a name. Revenue is Total Income from the report that was returned. Sandbox and production hosts are never mixed |
| Inventory | Shopify only | Needs a provider until Shopify is connected. Connected only when Shopify returned numeric stock. Missing quantities stay missing. Connect focuses the shop field and does not invent a number |

Disconnected removes the saved link. Client-sent user ids are ignored.
Secrets are not returned to the page, the address bar, or the activity line.

---

## One brain, three chats

- Main chat stays the personal thread. It does not list Business or Invest history.
- Business chat lives at Business → Business chat. It forces business context and still refuses to invent leads, orders, stock, spend, or revenue.
- Invest chat lives at Invest → Invest chat. It forces invest context. Pending is not filled. Paper is not live.
- The same model, memory, permissions, tools, confirmation, and audit still apply. Threads are stored with a workspace and are refused across workspaces and across users.
- Studio stays the creation workspace.

### Plans (server-side, not a button hide)

| Plan | Business | Invest |
|---|---|---|
| Free | Basic identity, notes, experiments the user writes | Education, watchlist, notes, plans. No live order |
| Plus | Basic, plus research when the provider is available | Copilot. Paper orders only if Alpaca paper is connected and the user approves |
| Pro / Founder | Manager report from real records | Live orders only with an explicit live confirmation, an ACTIVE account, and approval. Founder does not skip that |

Founder does not bypass ownership, confirmation, or the registry.
Legacy plan id `business` remains full access so old rows do not break.

---

## BLOCKED — ENVIRONMENT (not product defects)

- Live model chat / search / research (missing `XAI_API_KEY`)
- Live photo / video generation (same missing key)
- Neural TTS and a real microphone
- Gmail and Google Calendar while the connector gate is not configured
- A real Alpaca paper or live account
- A real HubSpot or Shopify credential
- QuickBooks and Google Ads until a real OAuth app exists
- Inventory until a real provider is selected
- Closed-tab web push (no VAPID)
- Payments
- Background monitoring (no scheduler)

---

## Remaining work

- Enter a real Alpaca paper key in Invest (never in chat) and read the account the broker returns
- Connect Gmail or Calendar through the existing connectors
- Enter a real HubSpot or Shopify credential in Business (never in chat)
- Inject `XAI_API_KEY` server-side and run one signed-in business question and one invest question
- Do not add fake providers to close those gaps

---

## Chat models (configured, not live-verified)

Primary: `grok-4.5`
Fallbacks on 403/404 only, once each: `grok-4` → `grok-3`
`grok-4-fast` is **not** requested (retired 15 May 2026).

Intelligence router: FAST vs DEEP on the same documented chain. FAST uses
a smaller token budget. Difficult turns (compare, research, plan, business,
invest, safety, missions) go DEEP. Empty/helpless FAST replies escalate once.

User-facing 403/401 is always: “The AI is unavailable right now. Please try
again.” Server logs only `provider_status`, `category`, `code`, `model`.

**Actual 403 cause in this keep:** not observed. There is no key, so no
provider response body to classify.

---

## Production must inject

- `DATABASE_URL`
- `BETTER_AUTH_URL`
- `BETTER_AUTH_SECRET`
- `GROK_AUTH_ISSUER`
- `GROK_AUTH_CLIENT_ID`
- `GROK_AUTH_CLIENT_SECRET`
- `XAI_API_KEY` (chat, search, TTS, Imagine photo/video)
