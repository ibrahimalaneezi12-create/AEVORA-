# AEVORA — Step 25 manual acceptance (your phone)

Engineering gates are closed. Live microphone, live TTS quality, spoken
T0–T11 latency, and real Google Calendar/Gmail sends are **not** verified
until you run these tests on a real device.

Do not treat a PASS here as something I already proved.

---

## Before you start

1. Open AEVORA in the live preview on your phone (Safari or Chrome).
2. Sign in with email/password.
3. Open **Settings → Language & voice**.
   - Voice is **on**.
   - Language **English** first; later switch to **Arabic**.
4. Open **Chat**. Tap the microphone (“Tap to talk”).
5. Allow microphone if the browser asks.
6. You should see: **Listening**.
7. Normal Voice Mode has **no** latency panel. Diagnostics are developer-only:
   add `?voiceDebug=1` to the URL if you need T0–T11 numbers.

Record each test as **PASS / FAIL / BLOCKED** with one sentence why.

---

## TEST 1 — Normal conversation

**Say:** “How was your day — keep it short.”

**Expect:** Listening → thinking → AEVORA speaks a short reply → listening again.
Latency panel: T2, T3, T7, T8 should get numbers if speech and TTS ran.

## TEST 2 — Factual question

**Say:** “What is 17 times 24?”

**Expect:** A spoken answer. It should not invent tools or act.

## TEST 3 — Follow-up

After Test 2, **say:** “What about tomorrow?”

**Expect:** It treats this as a follow-up in the same thread, not a new
brain. It should not invent a calendar event.

## TEST 4 — Confirmation-required action

**Say:** “Create a task called buy milk.”

**Expect:** AEVORA **proposes** the task. It must **not** create it until
you tap **Approve**. Then the task exists. Deny on a second try must not
create anything.

## TEST 5 — Interrupt while speaking

Start a longer reply (ask it to explain something in a few sentences).
While it is speaking, talk over it.

**Expect:** Speech **stops immediately**. State becomes interrupted /
listening. T11 may read `unavailable — interrupted — no completion`.

## TEST 6 — Speak again after interrupt

Immediately after Test 5, ask a new short question.

**Expect:** It hears the new utterance and answers. It must not keep
playing the old audio.

## TEST 7 — Multi-turn

Have 3–4 back-and-forth turns in one session without tapping Stop.

**Expect:** Continuous listening after each spoken reply. Context holds.

## TEST 8 — Arabic voice

Settings → language **Arabic**. Start voice. Speak Arabic.

**Expect:** Recognition language is Arabic. Reply can be Arabic. If TTS
falls back to the browser voice, the UI may say so — record that, don’t
force a PASS on neural quality.

## TEST 9 — Switch language

Switch English → Arabic (or reverse) mid-session. Ask something in the
new language.

**Expect:** The next turn uses the new language. Memory/chat history stay.
No second account, no wiped keep.

## TEST 10 — Reminder

**Say:** “Remind me in two minutes to stand up.”

**Expect:** A **proposal** you must Approve. After approve, it appears
under Reminders. If the keep is open, it can notify; **closed-tab push is
not built** — BLOCKED for closed-app delivery, not a fake pass.

## TEST 11 — Calendar

Open **Calendar**, or ask “What’s on my calendar tomorrow?”

**If Google Calendar is not connected (current keep):** AEVORA must say it
is **not connected / not ready**. It must **not** invent events.

Record: **PASS** for honest disconnect. Live create/cancel on Google is
**UNVERIFIED** until you connect a real calendar.

## TEST 12 — Mail

Open **Mail**, or ask “Any new email?”

**If Gmail is not connected:** honest “not connected / not ready.”
Draft ≠ send. Send without connect must not claim it sent.

Record: **PASS** for honesty. Live Gmail send is **UNVERIFIED**.

---

## Measurements (developer-only)

Normal Voice Mode does not show timings. Add `?voiceDebug=1`, then after Test 1
and Test 5 record:

- T2 speech end
- T3 final transcript
- T4 orchestrator receive (likely unavailable)
- T5 reasoning start (likely unavailable)
- T6 first model output (when streaming reaches the phone)
- T7 first meaningful response
- T8 TTS request
- T9 first audio
- T10 first audible audio
- T11 completion

Write the numbers as shown. Do not round them into a story. Missing times must
say **unavailable** — never a fake 0.

---

## Failures that mean I must fix something

Bring me a screenshot / the latency panel if:

- Mic permission cannot start Voice Mode after you allowed it
- It never returns to listening
- It does not stop when you interrupt
- It acts (creates a task/reminder/mail) without Approve
- It invents calendar events or sent mail while disconnected
- It speaks the previous answer after you interrupted
- Arabic switch wipes the keep or opens a second brain
- Latency numbers appear for a normal user (they should only appear with `?voiceDebug=1`)
  or show invented round numbers with no “unavailable” labels for T4/T5
