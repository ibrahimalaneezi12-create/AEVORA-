import { chromium } from "playwright";
import { readFileSync, utimesSync, writeFileSync } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";

const BASE = "http://127.0.0.1:8080";
const COMPLETE = "/workspace/src/lib/ai/complete.server.ts";
const originalComplete = readFileSync(COMPLETE, "utf8");
const results = [];
const stamp = Date.now();
const emailA = `ibrahim.step10.${stamp}@example.com`;
const emailB = `ibrahim.step10b.${stamp}@example.com`;
const password = "correct-horse-battery-1";

const STUB_TURN = `
export async function completeTurn(
  history: ChatTurnMessage[],
  extra?: CompleteTurnExtra,
): Promise<CompleteTurnResult> {
  const last = history[history.length - 1]?.content ?? "";
  if (/remember|black tea/i.test(last)) {
    return {
      ok: true,
      text: [
        "I can remember that you drink tea. It will not be saved until you confirm.",
        "",
        "<<<aegis-proposals",
        JSON.stringify([
          {
            tool_id: "memory.save",
            title: "Save tea preference",
            summary: "Remember that you drink black tea every morning.",
            payload: { kind: "preference", body: "payload-secret-orchid-77" },
          },
        ]),
        ">>>",
      ].join("\\n"),
    };
  }
  return { ok: true, text: "Aegis-step10-fixture: a quiet reply with no proposed action." };
}
`;

function record(name, ok, extra = "") {
  results.push({ name, ok: Boolean(ok), extra: extra == null ? "" : String(extra) });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? "  — " + String(extra).slice(0, 180) : ""}`);
}

function installStub() {
  const next = originalComplete.replace(
    /\n\/\*\*\n \* One user-initiated Grok turn[\s\S]*$/,
    STUB_TURN,
  );
  if (next === originalComplete) throw new Error("Could not patch completeTurn");
  writeFileSync(COMPLETE, next);
  const now = new Date();
  utimesSync(COMPLETE, now, now);
}

function restoreComplete() {
  writeFileSync(COMPLETE, originalComplete);
}

async function callFn(page, modulePath, name, data) {
  return page.evaluate(
    async ({ modulePath, name, data }) => {
      const mod = await import(modulePath);
      try {
        const result =
          data === undefined ? await mod[name]() : await mod[name]({ data });
        return { ok: true, result };
      } catch (err) {
        return {
          ok: false,
          error: err && err.message ? err.message : String(err),
        };
      }
    },
    { modulePath, name, data },
  );
}

async function signup(page, { name, email }) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.getByRole("button", { name: "Create an account" }).click();
  await page.locator("#auth-name").fill(name);
  await page.locator("#auth-email").fill(email);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
}

async function signOut(page) {
  const btn = page.getByRole("button", { name: "Sign out" });
  if (await btn.count()) {
    await btn.click();
    await page.waitForURL(/\/login|\/$/, { timeout: 15000 }).catch(() => {});
  }
}

let restored = false;
process.on("exit", () => {
  if (!restored) {
    try {
      restoreComplete();
    } catch {
      /* ignore */
    }
  }
});

const today = new Date().toISOString().slice(0, 10);

const browser = await chromium.launch({ headless: true });
const contextA = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page = await contextA.newPage();
const consoleErrors = [];
page.on("pageerror", (err) => consoleErrors.push(String(err)));
page.on("console", (msg) => {
  if (msg.type() === "error") consoleErrors.push(msg.text());
});

try {
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("signed-out-dashboard", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const unauth = await callFn(page, "/src/lib/dashboard.ts", "getDashboard");
  record("unauth-dashboard", /unauthorized/i.test(unauth.error || ""), unauth.error || JSON.stringify(unauth));

  await signup(page, { name: "Ibrahim Step10", email: emailA });
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: /Hello, Ibrahim/ }).waitFor({ timeout: 15000 });
  record("greeting", await page.getByRole("heading", { name: /Hello, Ibrahim/ }).isVisible());
  record("empty-pending", await page.getByText("Nothing waiting.").isVisible());
  record("empty-tasks", await page.getByText(/Nothing due today/).isVisible());
  record("empty-goals", await page.getByText(/No active goals/).isVisible());
  record("empty-memory", await page.getByText(/Nothing kept yet/).isVisible());
  record("empty-chat", await page.getByText(/No conversations yet/).isVisible());
  record(
    "nav-dashboard-active",
    (await page.locator("aside nav a", { hasText: "Dashboard" }).first().getAttribute("aria-current")) === "page",
  );
  record(
    "no-approve-deny-empty",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /^Deny$/ }).count()) === 0,
  );

  const emptySnap = await callFn(page, "/src/lib/dashboard.ts", "getDashboard");
  record(
    "empty-snapshot",
    emptySnap.ok &&
      emptySnap.result?.pending?.length === 0 &&
      emptySnap.result?.todaysTasks?.length === 0 &&
      emptySnap.result?.activeGoals?.length === 0 &&
      emptySnap.result?.recentMemories?.length === 0 &&
      emptySnap.result?.lastConversation == null &&
      emptySnap.result?.greetingName === "Ibrahim",
    JSON.stringify(emptySnap).slice(0, 240),
  );

  const goal = await callFn(page, "/src/lib/goals.ts", "createGoal", {
    title: "Drink less sugar",
    description: "Keep mornings unsweetened.",
    status: "active",
    targetDate: "2026-10-01",
  });
  record("seed-goal", goal.ok && goal.result?.id > 0, JSON.stringify(goal).slice(0, 180));
  const goalId = goal.result?.id ?? 0;

  const paused = await callFn(page, "/src/lib/goals.ts", "createGoal", {
    title: "Paused aim",
    description: "",
    status: "paused",
    targetDate: null,
  });
  record("seed-paused-goal", paused.ok, JSON.stringify(paused).slice(0, 120));

  const todayTask = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Buy loose-leaf tea",
    notes: "No sugar in the tin.",
    status: "todo",
    dueDate: today,
    goalId,
  });
  record("seed-today-task", todayTask.ok && todayTask.result?.dueDate === today, JSON.stringify(todayTask).slice(0, 200));
  const todayTaskId = todayTask.result?.id ?? 0;

  const overdue = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Return the kettle",
    notes: "",
    status: "todo",
    dueDate: "2020-01-01",
    goalId,
  });
  record("seed-overdue-task", overdue.ok, JSON.stringify(overdue).slice(0, 160));

  const future = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Winter stocktake",
    notes: "",
    status: "todo",
    dueDate: "2099-12-01",
    goalId,
  });
  record("seed-future-task", future.ok, JSON.stringify(future).slice(0, 160));

  const undated = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Inbox note",
    notes: "",
    status: "todo",
    dueDate: null,
    goalId: null,
  });
  record("seed-undated-task", undated.ok && undated.result?.goalId == null, JSON.stringify(undated).slice(0, 160));

  const doneTask = await callFn(page, "/src/lib/goals.ts", "createTask", {
    title: "Already done",
    notes: "",
    status: "done",
    dueDate: today,
    goalId,
  });
  record("seed-done-task", doneTask.ok, JSON.stringify(doneTask).slice(0, 160));

  const memory = await callFn(page, "/src/lib/memory.ts", "createMemory", {
    kind: "preference",
    title: "Tea preference",
    body: "I drink black tea every morning.",
    tags: "drinks",
    pinned: true,
  });
  record("seed-memory", memory.ok && memory.result?.pinned === true, JSON.stringify(memory).slice(0, 180));

  const convo = await callFn(page, "/src/lib/chat.ts", "createConversation");
  record("seed-conversation", convo.ok && convo.result?.id > 0, JSON.stringify(convo).slice(0, 160));
  const convoId = convo.result?.id ?? 0;

  const filled = await callFn(page, "/src/lib/dashboard.ts", "getDashboard");
  const snap = filled.result ?? {};
  const taskTitles = (snap.todaysTasks ?? []).map((t) => t.title);
  const goalTitles = (snap.activeGoals ?? []).map((g) => g.title);
  record(
    "snapshot-greeting",
    filled.ok && snap.greetingName === "Ibrahim" && snap.today === today,
    JSON.stringify({ greetingName: snap.greetingName, today: snap.today, timezone: snap.timezone }),
  );
  record(
    "snapshot-today-task",
    taskTitles.includes("Buy loose-leaf tea"),
    JSON.stringify(taskTitles),
  );
  record("snapshot-overdue-task", taskTitles.includes("Return the kettle"), JSON.stringify(taskTitles));
  record(
    "snapshot-excludes-future-undated-done",
    !taskTitles.includes("Winter stocktake") &&
      !taskTitles.includes("Inbox note") &&
      !taskTitles.includes("Already done"),
    JSON.stringify(taskTitles),
  );
  record(
    "snapshot-active-goal",
    goalTitles.includes("Drink less sugar") && !goalTitles.includes("Paused aim"),
    JSON.stringify(goalTitles),
  );
  const sugar = (snap.activeGoals ?? []).find((g) => g.title === "Drink less sugar");
  record(
    "snapshot-goal-open-count",
    Boolean(sugar) && sugar.openTaskCount >= 3,
    JSON.stringify(sugar || {}),
  );
  record(
    "snapshot-memory",
    (snap.recentMemories ?? []).some((m) => m.title === "Tea preference" && m.pinned),
    JSON.stringify(snap.recentMemories ?? []).slice(0, 240),
  );
  record(
    "snapshot-last-conversation",
    snap.lastConversation?.id === convoId,
    JSON.stringify(snap.lastConversation || {}),
  );
  record(
    "snapshot-no-payload",
    !JSON.stringify(snap).includes("payload-secret-orchid-77") &&
      !JSON.stringify(snap).includes("payload_json"),
    JSON.stringify(Object.keys(snap)),
  );

  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  await page.getByRole("article", { name: "Goal: Drink less sugar" }).waitFor({ timeout: 15000 });
  record("ui-goal", await page.getByRole("article", { name: "Goal: Drink less sugar" }).isVisible());
  record("ui-today-task", await page.getByRole("article", { name: "Task: Buy loose-leaf tea" }).isVisible());
  record("ui-overdue", await page.getByText("Overdue").first().isVisible());
  record("ui-excludes-future", (await page.getByText("Winter stocktake").count()) === 0);
  record("ui-memory", await page.getByRole("article", { name: "Memory: Tea preference" }).isVisible());
  record("ui-memory-pinned", await page.getByText("Pinned").first().isVisible());
  record("ui-chat", await page.getByRole("article", { name: /Conversation:/ }).isVisible());

  await page.getByRole("button", { name: "Mark Buy loose-leaf tea done" }).click();
  await page.getByRole("article", { name: "Task: Buy loose-leaf tea" }).waitFor({
    state: "hidden",
    timeout: 15000,
  });
  record("mark-done-hides-task", (await page.getByRole("article", { name: "Task: Buy loose-leaf tea" }).count()) === 0);
  const afterDone = await callFn(page, "/src/lib/dashboard.ts", "getDashboard");
  const afterTitles = (afterDone.result?.todaysTasks ?? []).map((t) => t.title);
  record("mark-done-persists", !afterTitles.includes("Buy loose-leaf tea"), JSON.stringify(afterTitles));
  const stillTask = await callFn(page, "/src/lib/goals.ts", "getTask", { id: todayTaskId });
  record(
    "mark-done-status",
    stillTask.ok && stillTask.result?.status === "done",
    JSON.stringify(stillTask).slice(0, 200),
  );

  installStub();
  await sleep(2500);
  const sent = await callFn(page, "/src/lib/chat.ts", "sendChatMessage", {
    conversationId: convoId,
    content: "Please remember I drink black tea every morning.",
  });
  record(
    "proposal-created",
    sent.ok && (sent.result?.proposals ?? []).some((p) => p.title === "Save tea preference"),
    JSON.stringify(sent.result?.proposals ?? sent).slice(0, 240),
  );
  restoreComplete();
  restored = true;
  const now = new Date();
  utimesSync(COMPLETE, now, now);
  await sleep(800);

  const withPending = await callFn(page, "/src/lib/dashboard.ts", "getDashboard");
  const pending = withPending.result?.pending ?? [];
  record(
    "snapshot-pending",
    pending.some((p) => p.title === "Save tea preference" && p.permissionLevel === "review"),
    JSON.stringify(pending).slice(0, 240),
  );
  record(
    "pending-no-payload",
    !JSON.stringify(withPending.result).includes("payload-secret-orchid-77"),
    JSON.stringify(withPending.result?.pending ?? []).slice(0, 200),
  );

  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  await page.getByRole("article", { name: "Proposed action: Save tea preference" }).waitFor({ timeout: 15000 });
  record("ui-pending", await page.getByRole("article", { name: "Proposed action: Save tea preference" }).isVisible());
  record("ui-pending-waiting", await page.getByText(/waiting/).first().isVisible());
  record(
    "no-approve-deny-pending",
    (await page.getByRole("button", { name: /^Approve$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /^Deny$/ }).count()) === 0 &&
      (await page.getByRole("button", { name: /Execute/i }).count()) === 0,
  );
  const html = await page.content();
  record("ui-no-payload-secret", !html.includes("payload-secret-orchid-77"));

  const contextB = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const pageB = await contextB.newPage();
  await signup(pageB, { name: "Other User", email: emailB });
  const bDash = await callFn(pageB, "/src/lib/dashboard.ts", "getDashboard");
  const bSnap = bDash.result ?? {};
  record(
    "idor-dashboard",
    bDash.ok &&
      (bSnap.activeGoals ?? []).every((g) => g.title !== "Drink less sugar") &&
      (bSnap.todaysTasks ?? []).every((t) => t.title !== "Return the kettle") &&
      (bSnap.recentMemories ?? []).every((m) => m.title !== "Tea preference") &&
      (bSnap.pending ?? []).every((p) => p.title !== "Save tea preference") &&
      bSnap.lastConversation == null,
    JSON.stringify({
      goals: (bSnap.activeGoals ?? []).map((g) => g.title),
      tasks: (bSnap.todaysTasks ?? []).map((t) => t.title),
      memories: (bSnap.recentMemories ?? []).map((m) => m.title),
      pending: (bSnap.pending ?? []).map((p) => p.title),
    }),
  );
  await contextB.close();

  await page.goto(`${BASE}/app/goals`, { waitUntil: "networkidle" });
  record("goals-regression", await page.getByRole("heading", { name: "Working toward" }).isVisible());
  record("goals-still-has-task", await page.getByRole("article", { name: "Task: Return the kettle" }).isVisible());
  await page.goto(`${BASE}/app/memory`, { waitUntil: "networkidle" });
  record("memory-regression", await page.getByRole("heading", { name: "What lasts" }).isVisible());
  await page.goto(`${BASE}/app/settings`, { waitUntil: "networkidle" });
  record("settings-regression", await page.getByLabel("Display name").isVisible());
  await page.goto(`${BASE}/app/chat`, { waitUntil: "networkidle" });
  record("chat-regression", await page.getByRole("heading", { name: "Conversations" }).isVisible());

  await signOut(page);
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  record("signout-gate", /\/login/.test(page.url()), page.url());

  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.locator("#auth-email").fill(emailA);
  await page.locator("#auth-password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.waitForURL(/\/app/, { timeout: 20000 });
  await page.getByRole("article", { name: "Goal: Drink less sugar" }).waitFor({ timeout: 15000 });
  record("signin-same-dashboard", await page.getByRole("article", { name: "Goal: Drink less sugar" }).isVisible());
  record("signin-pending-still", await page.getByRole("article", { name: "Proposed action: Save tea preference" }).isVisible());

  await page.screenshot({ path: "/workspace/screenshots/step10-dashboard.png", fullPage: true });

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app`, { waitUntil: "networkidle" });
  await page.getByRole("heading", { name: /Hello, Ibrahim/ }).waitFor({ timeout: 15000 });
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
  );
  const labels = await page.locator("nav[aria-label='Primary']").innerText();
  record(
    "mobile-nav",
    !overflow && /Dashboard/.test(labels) && /Chat/.test(labels) && /Goals/.test(labels),
    JSON.stringify({ overflow, labels: labels.split(/\s+/).filter(Boolean) }),
  );
  record("mobile-pending", await page.getByRole("article", { name: "Proposed action: Save tea preference" }).isVisible());
  record("mobile-goal", await page.getByRole("article", { name: "Goal: Drink less sugar" }).isVisible());
  await page.screenshot({ path: "/workspace/screenshots/step10-dashboard-mobile.png", fullPage: true });

  const serious = consoleErrors.filter(
    (e) => !/Download the React DevTools/i.test(e) && !/not found/i.test(e),
  );
  record("console-errors", serious.length === 0, serious.join(" | ").slice(0, 300));
} catch (err) {
  record("fatal", false, err && err.stack ? err.stack : String(err));
} finally {
  if (!restored) {
    restoreComplete();
    restored = true;
  }
  await browser.close();
}

const ok = results.filter((r) => r.ok).length;
const total = results.length;
writeFileSync(
  "/workspace/screenshots/verify-step10.json",
  JSON.stringify({ emailA, emailB, today, ok, total, results }, null, 2),
);
console.log(`\n${ok}/${total} passed`);
process.exit(ok === total ? 0 : 1);
